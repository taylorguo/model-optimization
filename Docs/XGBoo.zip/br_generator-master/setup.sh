#!/bin/bash

if   [ ! -z $BRG_HOME ]; then
    echo "Setup has already run"
    return 1
fi

source /etc/os-release
system_type=""
case $ID in
debian|ubuntu|devuan)
    system_type="ubuntu"
    ;;
centos|fedora|rhel)
    system_type="centos"
    ;;
*)
    return 1
    ;;
esac

biren_tool="biren_tools"
python_lib="~/lib64/python3.6/site-packages"
tmp_cmodel="$HOME/cmodel_release"

export BRG_HOME=$(pwd)
export CM_HOME=$(realpath -- ${BRG_HOME}/../cmodel_br100 )
export GOLDEN_VECTORS_HOME=$(realpath -- ${BRG_HOME}/../golden_vectors )
export RELEASED_VECTORS_HOME=$(realpath -- ${BRG_HOME}/../vector )
export ASSEMBLER_HOME=$(realpath -- ${BRG_HOME}/../assembler )
export SYSTEM_TYPE=$system_type

export PYTHONPATH=$PYTHONPATH:${BRG_HOME}:${BRG_HOME}/command_generator:$python_lib
export PYTHONPATH=$PYTHONPATH:${BRG_HOME}/tests:${BRG_HOME}/command_generator
export PYTHONPATH=$PYTHONPATH:${BRG_HOME}/golden_generator/mini_test:${BRG_HOME}/code_generator
export PYTHONPATH=$PYTHONPATH:~/lib64/python3.6/site-packages/
export PYTHONPATH=$PYTHONPATH:${BRG_HOME}:${BRG_HOME}/parser:${BRG_HOME}/test_generator

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$tmp_cmodel/$system_type/lib
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${BRG_HOME}/../cmodel_release/$system_type/lib
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib:/usr/lib64
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/systemc/lib:/opt/systemc/lib64

export PATH=$PATH:${BRG_HOME}:${BRG_HOME}/command_generator:$BRG_HOME/bin

echo $PYTHONPATH
echo $LD_LIBRARY_PATH
echo $PATH
echo "br_generator environement variables set for ${BRG_HOME}"
