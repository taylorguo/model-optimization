import os, sys
import shutil


def rm_io(path):
    g = os.walk(path)
    for dirpath, dirname, filenames in g:
        # print(dirpath)
        # print(dirpath[-5:])
        if dirpath[-5:] == 'input' or dirpath[-6:] == 'output':
            #os.remove(dirpath)
            shutil.rmtree(dirpath)
        elif dirpath[-6:] == 'vector':
            for name in filenames:
                shutil.copy(os.path.join(dirpath,name), os.path.dirname(dirpath))
            shutil.rmtree(dirpath)

def cut_name(path):
    folders = os.listdir(path)
    for f in folders:
        if '.' not in f:
            old = os.path.join(path, f)
            new = os.path.join(path, f.split("_")[-1])
            os.rename(old,new)
            
def main():
    path = os.path.abspath(os.path.dirname(__file__))
    if sys.argv[1] == 'rm':
        rm_io(path)
    else:
        cut_name(path)


if __name__ == '__main__':
    main()
