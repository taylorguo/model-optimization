import  os


def reset_name(name):
    num = name[4:]
    if len(num) == 3:
        return name

    if len(num) == 1:
        new_num = '00' + num
    elif len(num) == 2:
        new_num = '0' + num
    else:
        new_num = num
    new_name = name[:4] + new_num
    return new_name


def modify(path, num):
    g = os.walk(path)
    # Search input&output files
    for dirpath, dirname, filenames in g:
        root_name = dirpath.split(os.sep)[-1]
        if root_name.isdigit():
            new_name = reset_name('case' + str(int(root_name)+num))
            parent = os.path.abspath(os.path.dirname(dirpath))
            os.rename(os.path.join(dirpath), os.path.join(parent, new_name))


if __name__ == '__main__':
    modify(os.path.abspath(os.path.dirname(__file__)), 75)
