import os


def xxd_cmd(path):
    g = os.walk(path)
    for root, dirs, filenames in g:
        for file in filenames:
            if file[-2:] == '.s':
                file_path = os.path.join(root, file)
                cmd_4 = 'xxd -e -g 8 -c 8 ' + file_path[:-2] + '.bin' ' | cut -d\' \' -f2 > ' + os.path.join(root, 'kernel.txt')
                print("cmd is ", cmd_4)
                os.system(cmd_4)


if __name__ == '__main__':
    xxd_cmd(os.path.abspath(os.path.dirname(__file__)))
