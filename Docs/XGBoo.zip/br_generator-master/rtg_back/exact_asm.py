import os, shutil

def exact(path):
    for root, dirs, filenames in os.walk(path):
        for file in filenames:
            if file.endswith(".s"):
                shutil.move(os.path.join(root, file),
                            os.path.join(path, file))

if __name__ == '__main__':
    exact(os.path.abspath(os.path.dirname(__file__)))