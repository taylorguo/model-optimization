## Steps to generate a case
1. Generate the golden data.  
Code:  
br_generator/golden_generator/mini_test/simple_conv.py  
br_generator/golden_generator/mini_test/simple_mma.py  
br_generator/golden_generator/mini_test/simple_bn.py  
br_generator/golden_generator/mini_test/simple_addrelu.py  
...  
Example:  
br-unit-fwd-U0-conv0-W-4DW-1x64x7x7-bf16.bin,  
br-unit-fwd-U1-conv0-A-3DA-1x64x8x8-bf16.bin,  
br-unit-fwd-U2-conv0-A-3DA-1x1x8x8-bf16.bin

2. Generate assembly code.
Code:  
br_generator/test_generator/make_golden.py, all **gen_assembly** functions  

3. Generate descriptor.json.  
Code:  
br_generator/command_generator/make_descriptors.py,  2 interfaces  
*def make_descriptor(desc, target_path=None, finished=False)*: generate **descriptor.json** with given dictionarry.  
*def make_desc_dic(path, word, csr=None, cnstLayout=0, cmd_packet="Submit_JD", gmb=0)*: generate **descriptor.json** according to the golden data files (as shown in the first point above).  

4. Generate command packet.  
Code:  
br_generator/command_generator/make_vectors.py  
br_generator/command_generator/make_dump.py  
br_generator/command_generator/dump_reverse.py  
*def gen_cmd_packet(case_path, clear, compare, asmfile=None)*: this is the interface  

## For Andy Zhang  
Code:  
br_generator/generate_kernel.sh  
br_generator/test_generator/generate_kernel.py  
Usage:  
sh generate_kernel.sh -c: make folder for each assembly code  
sh generate_kernel.sh -g: generate assembly files  
sh make_vectors.sh -d: generate command packets  
sh generate_kernel.sh -m [destination path]: re-construct cases  

## Read br_generator/test_generator/readme.md for details about generating cases.  

## Read br_generator/tests/code_gen/readme.md for details about pytest related codes.  
