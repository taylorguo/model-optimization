#!/bin/bash
cd ../../..
if [ ! -d cmodel_br100 ]; then
    git clone git@github01.birentech.com:arch/cmodel_br100.git
fi
cd cmodel_br100
if [ ! -d build ]; then
    mkdir -p build && cd build
    cmake .. && make -j8
else
    cd build
    cmake .. && make -j8
fi

