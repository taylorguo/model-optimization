/**
 * br_descriptor.h header file generated from an excel file.
 * Copyright 2020, Biren Technologies Inc.
 * All rights reserved.
 */

#ifndef _BR_DESCRIPTORS_H_
#define _BR_DESCRIPTORS_H_

#include <stdint.h>

#define VERSION 43928.0

enum TMD_GSMPARTITIONVALUE {
    V_0KB = 0,
    V_2KB = 1,
    V_4KB = 2,
    V_8KB = 3,
    V_16KB = 4,
    V_32KB = 5
}; // TMD_GSMPARTITIONVALUE

enum USHARP_VIEWTYPEVALUE {
    V_1D = 0,
    V_2D = 1,
    V_3D = 2,
    BUFFER = 4
}; // USHARP_VIEWTYPEVALUE

enum USHARP_VIEWFORMATVALUE {
    FORMAT_UNDEFINED = 0,
    FORMAT_G4R4_UNORM = 1,
    FORMAT_A4B4G4R4_UNORM = 2,
    FORMAT_A4R4G4B4_UNORM = 3,
    FORMAT_B5G6R5_UNORM = 4,
    FORMAT_R5G6B5_UNORM = 5,
    FORMAT_A1B5G5R5_UNORM = 6,
    FORMAT_A1R5G5B5_UNORM = 7,
    FORMAT_B5G5R5A1_UNORM = 8,
    FORMAT_R8_UNORM = 9,
    FORMAT_R8_SNORM = 10,
    FORMAT_R8_USCALED = 11,
    FORMAT_R8_SSCALED = 12,
    FORMAT_R8_UINT = 13,
    FORMAT_R8_SINT = 14,
    FORMAT_R8_SRGB = 15,
    FORMAT_R8G8_UNORM = 16,
    FORMAT_R8G8_SNORM = 17,
    FORMAT_R8G8_USCALED = 18,
    FORMAT_R8G8_SSCALED = 19,
    FORMAT_R8G8_UINT = 20,
    FORMAT_R8G8_SINT = 21,
    FORMAT_R8G8_SRGB = 22,
    FORMAT_R8G8B8_UNORM = 23,
    FORMAT_R8G8B8_SNORM = 24,
    FORMAT_R8G8B8_USCALED = 25,
    FORMAT_R8G8B8_SSCALED = 26,
    FORMAT_R8G8B8_UINT = 27,
    FORMAT_R8G8B8_SINT = 28,
    FORMAT_R8G8B8_SRGB = 29,
    FORMAT_B8G8R8_UNORM = 30,
    FORMAT_B8G8R8_SNORM = 31,
    FORMAT_B8G8R8_USCALED = 32,
    FORMAT_B8G8R8_SSCALED = 33,
    FORMAT_B8G8R8_UINT = 34,
    FORMAT_B8G8R8_SINT = 35,
    FORMAT_B8G8R8_SRGB = 36,
    FORMAT_R8G8B8A8_UNORM = 37,
    FORMAT_R8G8B8A8_SNORM = 38,
    FORMAT_R8G8B8A8_USCALED = 39,
    FORMAT_R8G8B8A8_SSCALED = 40,
    FORMAT_R8G8B8A8_UINT = 41,
    FORMAT_R8G8B8A8_SINT = 42,
    FORMAT_R8G8B8A8_SRGB = 43,
    FORMAT_B8G8R8A8_UNORM = 44,
    FORMAT_B8G8R8A8_SNORM = 45,
    FORMAT_B8G8R8A8_USCALED = 46,
    FORMAT_B8G8R8A8_SSCALED = 47,
    FORMAT_B8G8R8A8_UINT = 48,
    FORMAT_B8G8R8A8_SINT = 49,
    FORMAT_B8G8R8A8_SRGB = 50,
    FORMAT_B10G10R10A2_UNORM = 58,
    FORMAT_B10G10R10A2_SNORM = 59,
    FORMAT_B10G10R10A2_USCALED = 60,
    FORMAT_B10G10R10A2_SSCALED = 61,
    FORMAT_B10G10R10A2_UINT = 62,
    FORMAT_B10G10R10A2_SINT = 63,
    FORMAT_R10G10B10A2_UNORM = 64,
    FORMAT_R10G10B10A2_SNORM = 65,
    FORMAT_R10G10B10A2_USCALED = 66,
    FORMAT_R10G10B10A2_SSCALED = 67,
    FORMAT_R10G10B10A2_UINT = 68,
    FORMAT_R10G10B10A2_SINT = 69,
    FORMAT_R16_UNORM = 70,
    FORMAT_R16_SNORM = 71,
    FORMAT_R16_USCALED = 72,
    FORMAT_R16_SSCALED = 73,
    FORMAT_R16_UINT = 74,
    FORMAT_R16_SINT = 75,
    FORMAT_R16_SFLOAT = 76,
    FORMAT_R16G16_UNORM = 77,
    FORMAT_R16G16_SNORM = 78,
    FORMAT_R16G16_USCALED = 79,
    FORMAT_R16G16_SSCALED = 80,
    FORMAT_R16G16_UINT = 81,
    FORMAT_R16G16_SINT = 82,
    FORMAT_R16G16_SFLOAT = 83,
    FORMAT_R16G16B16_UNORM = 84,
    FORMAT_R16G16B16_SNORM = 85,
    FORMAT_R16G16B16_USCALED = 86,
    FORMAT_R16G16B16_SSCALED = 87,
    FORMAT_R16G16B16_UINT = 88,
    FORMAT_R16G16B16_SINT = 89,
    FORMAT_R16G16B16_SFLOAT = 90,
    FORMAT_R16G16B16A16_UNORM = 91,
    FORMAT_R16G16B16A16_SNORM = 92,
    FORMAT_R16G16B16A16_USCALED = 93,
    FORMAT_R16G16B16A16_SSCALED = 94,
    FORMAT_R16G16B16A16_UINT = 95,
    FORMAT_R16G16B16A16_SINT = 96,
    FORMAT_R16G16B16A16_SFLOAT = 97,
    FORMAT_R32_UINT = 98,
    FORMAT_R32_SINT = 99,
    FORMAT_R32_SFLOAT = 100,
    FORMAT_R32G32_UINT = 101,
    FORMAT_R32G32_SINT = 102,
    FORMAT_R32G32_SFLOAT = 103,
    FORMAT_R32G32B32_UINT = 104,
    FORMAT_R32G32B32_SINT = 105,
    FORMAT_R32G32B32_SFLOAT = 106,
    FORMAT_R32G32B32A32_UINT = 107,
    FORMAT_R32G32B32A32_SINT = 108,
    FORMAT_R32G32B32A32_SFLOAT = 109,
    FORMAT_R64_UINT = 110,
    FORMAT_R64_SINT = 111,
    FORMAT_R64_SFLOAT = 112,
    FORMAT_R64G64_UINT = 113,
    FORMAT_R64G64_SINT = 114,
    FORMAT_R64G64_SFLOAT = 115,
    FORMAT_R64G64B64_UINT = 116,
    FORMAT_R64G64B64_SINT = 117,
    FORMAT_R64G64B64_SFLOAT = 118,
    FORMAT_R64G64B64A64_UINT = 119,
    FORMAT_R64G64B64A64_SINT = 120,
    FORMAT_R64G64B64A64_SFLOAT = 121,
    FORMAT_R11G11B10_UFLOAT = 122,
    FORMAT_R9G9B9E5_UFLOAT = 123,
    FORMAT_D16_UNORM = 124,
    FORMAT_D24_X8_UNORM = 125,
    FORMAT_D32_SFLOAT = 126,
    FORMAT_S8_UINT = 127,
    FORMAT_D16_UNORM_S8_UINT = 128,
    FORMAT_D24_UNORM_S8_UINT = 129,
    FORMAT_D32_SFLOAT_S8_UINT = 130,
    FORMAT_BC1_RGB_UNORM_BLOCK = 131,
    FORMAT_BC1_RGB_SRGB_BLOCK = 132,
    FORMAT_BC1_RGBA_UNORM_BLOCK = 133,
    FORMAT_BC1_RGBA_SRGB_BLOCK = 134,
    FORMAT_BC2_UNORM_BLOCK = 135,
    FORMAT_BC2_SRGB_BLOCK = 136,
    FORMAT_BC3_UNORM_BLOCK = 137,
    FORMAT_BC3_SRGB_BLOCK = 138,
    FORMAT_BC4_UNORM_BLOCK = 139,
    FORMAT_BC4_SNORM_BLOCK = 140,
    FORMAT_BC5_UNORM_BLOCK = 141,
    FORMAT_BC5_SNORM_BLOCK = 142,
    FORMAT_BC6H_UFLOAT_BLOCK = 143,
    FORMAT_BC6H_SFLOAT_BLOCK = 144,
    FORMAT_BC7_UNORM_BLOCK = 145,
    FORMAT_BC7_SRGB_BLOCK = 146,
    FORMAT_ETC2_R8G8B8_UNORM_BLOCK = 147,
    FORMAT_ETC2_R8G8B8_SRGB_BLOCK = 148,
    FORMAT_ETC2_R8G8B8A1_UNORM_BLOCK = 149,
    FORMAT_ETC2_R8G8B8A1_SRGB_BLOCK = 150,
    FORMAT_ETC2_R8G8B8A8_UNORM_BLOCK = 151,
    FORMAT_ETC2_R8G8B8A8_SRGB_BLOCK = 152,
    FORMAT_EAC_R11_UNORM_BLOCK = 153,
    FORMAT_EAC_R11_SNORM_BLOCK = 154,
    FORMAT_EAC_R11G11_UNORM_BLOCK = 155,
    FORMAT_EAC_R11G11_SNORM_BLOCK = 156,
    FORMAT_ASTC_4X4_UNORM_BLOCK = 157,
    FORMAT_ASTC_4X4_SRGB_BLOCK = 158,
    FORMAT_ASTC_5X4_UNORM_BLOCK = 159,
    FORMAT_ASTC_5X4_SRGB_BLOCK = 160,
    FORMAT_ASTC_5X5_UNORM_BLOCK = 161,
    FORMAT_ASTC_5X5_SRGB_BLOCK = 162,
    FORMAT_ASTC_6X5_UNORM_BLOCK = 163,
    FORMAT_ASTC_6X5_SRGB_BLOCK = 164,
    FORMAT_ASTC_6X6_UNORM_BLOCK = 165,
    FORMAT_ASTC_6X6_SRGB_BLOCK = 166,
    FORMAT_ASTC_8X5_UNORM_BLOCK = 167,
    FORMAT_ASTC_8X5_SRGB_BLOCK = 168,
    FORMAT_ASTC_8X6_UNORM_BLOCK = 169,
    FORMAT_ASTC_8X6_SRGB_BLOCK = 170,
    FORMAT_ASTC_8X8_UNORM_BLOCK = 171,
    FORMAT_ASTC_8X8_SRGB_BLOCK = 172,
    FORMAT_ASTC_10X5_UNORM_BLOCK = 173,
    FORMAT_ASTC_10X5_SRGB_BLOCK = 174,
    FORMAT_ASTC_10X6_UNORM_BLOCK = 175,
    FORMAT_ASTC_10X6_SRGB_BLOCK = 176,
    FORMAT_ASTC_10X8_UNORM_BLOCK = 177,
    FORMAT_ASTC_10X8_SRGB_BLOCK = 178,
    FORMAT_ASTC_10X10_UNORM_BLOCK = 179,
    FORMAT_ASTC_10X10_SRGB_BLOCK = 180,
    FORMAT_ASTC_12X10_UNORM_BLOCK = 181,
    FORMAT_ASTC_12X10_SRGB_BLOCK = 182,
    FORMAT_ASTC_12X12_UNORM_BLOCK = 183,
    FORMAT_ASTC_12X12_SRGB_BLOCK = 184,
    FORMAT_G8B8G8R8_422_UNORM = 200,
    FORMAT_B8G8R8G8_422_UNORM = 201,
    FORMAT_G8_B8_R8_3PLANE_420_UNORM = 202,
    FORMAT_G8_B8R8_2PLANE_420_UNORM = 203,
    FORMAT_G8_B8_R8_3PLANE_422_UNORM = 204,
    FORMAT_G8_B8R8_2PLANE_422_UNORM = 205,
    FORMAT_G8_B8_R8_3PLANE_444_UNORM = 206,
    FORMAT_X6R10_UNORM = 207,
    FORMAT_X6R10X6G10_UNORM = 208,
    FORMAT_X6R10X6G10X6B10X6A10_UNORM = 209,
    FORMAT_X6G10X6B10X6G10X6R10_422_UNORM = 210,
    FORMAT_X6B10X6G10X6R10X6G10_422_UNORM = 211,
    FORMAT_X6G10_X6B10_X6R10_3PLANE_420_UNORM = 212,
    FORMAT_X6G10_X6B10X6R10_2PLANE_420_UNORM = 213,
    FORMAT_X6G10_X6B10_X6R10_3PLANE_422_UNORM = 214,
    FORMAT_X6G10_X6B10X6R10_2PLANE_422_UNORM = 215,
    FORMAT_X6G10_X6B10_X6R10_3PLANE_444_UNORM = 216,
    FORMAT_AI_FP32 = 249,
    FORMAT_AI_BF16 = 250,
    FORMAT_AI_F8_3 = 251,
    FORMAT_AI_F8_2 = 252,
    FORMAT_AI_INT8 = 253,
    FORMAT_AI_UINT8 = 254,
    FORMAT_AI_INT4 = 255
}; // USHARP_VIEWFORMATVALUE

enum USHARP_VIEWIMAGELAYOUTVALUE {
    LINEAR = 0,
    CNN_ACTIVATION_BLOCK_LINEAR = 1,
    MATRIX_ACTIVATION_BLOCK_LINEAR = 2,
    CNN_WEIGHT_BLOCK_LINEAR = 3,
    MATRIX_WEIGHT_BLOCK_LINEAR = 4
}; // USHARP_VIEWIMAGELAYOUTVALUE

enum USHARP_DIMENSIONVALUE {
    SSBOFORMATDIMENSION = 0,
    COLORFORMATDIMENSION = 1,
    TENSORFORMATDIMENSION = 2,
    RESERVED = 3
}; // USHARP_DIMENSIONVALUE

typedef struct {
    union {
        uint64_t all;
        struct {
            uint64_t dim : 32;
            uint64_t tgYSplit : 5;
            uint64_t tgZSplit : 5;
            uint64_t jobXSplit : 6;
            uint64_t jobYSplit : 6;
            uint64_t jobZSplit : 6;
            uint64_t workMode : 1;
            uint64_t numCwarp : 3;
        }f;
    }ddword0;
    union {
        uint64_t all;
        struct {
            uint64_t taskSplit : 6;
            uint64_t tgOffsetX : 16;
            uint64_t tgOffsetY : 16;
            uint64_t tgOffsetZ : 16;
            uint64_t idInputMode : 1;
            uint64_t tlrAddr : 8;
            uint64_t cwarpEn : 1;
        }f;
    }ddword1;
    union {
        uint64_t all;
        struct {
            uint64_t cudAddr;
        }f;
    }ddword2;
    union {
        uint64_t all;
        struct {
            uint64_t tmdAddr;
        }f;
    }ddword3;
    union {
        uint64_t all;
        struct {
            uint64_t reserved0;
        }f;
    }ddword4;
    union {
        uint64_t all;
        struct {
            uint64_t reserved1;
        }f;
    }ddword5;
    union {
        uint64_t all;
        struct {
            uint64_t reserved2;
        }f;
    }ddword6;
    union {
        uint64_t all;
        struct {
            uint64_t reserved3;
        }f;
    }ddword7;
} Cjobd;

typedef struct {
    union {
        uint64_t all;
        struct {
            uint64_t totalTlrSize : 7;
            uint64_t instCnt : 24;
            uint64_t bsharpCnt : 5;
            uint64_t usharpCnt : 9;
            uint64_t cnstCnt : 8;
            uint64_t cnstLayout : 1;
            uint64_t usharpOffsetSel : 2;
            uint64_t reserved : 8;
        }f;
    }ddword0;
    union {
        uint64_t all;
        struct {
            uint64_t pc;
        }f;
    }ddword1;
    union {
        uint64_t all;
        struct {
            uint64_t bsharpAddr;
        }f;
    }ddword2;
    union {
        uint64_t all;
        struct {
            uint64_t usharpAddr;
        }f;
    }ddword3;
    union {
        uint64_t all;
        struct {
            uint64_t cnstAddr;
        }f;
    }ddword4;
    union {
        uint64_t all;
        struct {
            uint64_t reserved0;
        }f;
    }ddword5;
    union {
        uint64_t all;
        struct {
            uint64_t reserved1;
        }f;
    }ddword6;
    union {
        uint64_t all;
        struct {
            uint64_t reserved2;
        }f;
    }ddword7;
} Cud;

typedef struct {
    union {
        uint64_t all;
        struct {
            uint64_t tlmBaseAddr;
        }f;
    }ddword0;
    union {
        uint64_t all;
        struct {
            uint64_t gsmBaseAddr;
        }f;
    }ddword1;
    union {
        uint64_t all;
        struct {
            uint64_t tlmSize : 5;
            uint64_t atomicEn : 1;
            uint64_t gsmSize : 5;
            uint64_t tgSlots : 4;
            uint64_t gsmPartition : 3;
            uint64_t reserved0 : 46;
        }f;
    }ddword2;
    union {
        uint64_t all;
        struct {
            uint64_t reserved1;
        }f;
    }ddword3;
} Tmd;

typedef struct {
    union {
        uint64_t all;
        struct {
            uint64_t address;
        }f;
    }ddword0;
    union {
        uint64_t all;
        struct {
            uint64_t size : 32;
            uint64_t reserved0 : 32;
        }f;
    }ddword1;
} Bsharp;

typedef struct {
    union {
        uint64_t all;
        struct {
            uint64_t address;
        }f;
    }ddword0;
    union {
        uint64_t all;
        struct {
            uint64_t viewType : 3;
            uint64_t viewFormat : 8;
            uint64_t viewImageLayout : 3;
            uint64_t dimension : 2;
            union {
                struct {
                    uint64_t size : 28;
                    uint64_t reserved0 : 14;
                }ssboFormatDimension;
                struct {
                    uint64_t widthC : 16;
                    uint64_t heightC : 16;
                    uint64_t depthC : 10;
                }colorFormatDimension;
                struct {
                    uint64_t widthT : 13;
                    uint64_t heightT : 13;
                    uint64_t depthT : 13;
                    uint64_t reserved1 : 3;
                }tensorFormatDimension;
            }u;
            uint64_t reserved2 : 6;
        }f;
    }ddword1;
    union {
        uint64_t all;
        struct {
            uint64_t numSubUSharp : 10;
            uint64_t padBaseOffset : 13;
            uint64_t padSize : 12;
            uint64_t reserved3 : 4;
            uint64_t l15Mode : 2;
            uint64_t isNuma : 1;
            uint64_t pixelInterleaveDisabled : 1;
            uint64_t embeddingTableEntrySize : 10;
            uint64_t slsAlignment : 2;
            uint64_t reserved4 : 9;
        }f;
    }ddword2;
    union {
        uint64_t all;
        struct {
            uint64_t reserved5;
        }f;
    }ddword3;
} Usharp;

#endif //_BR_DESCRIPTORS_H_
