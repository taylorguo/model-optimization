/**
 * br_packets_driver.h header file generated from an excel file.
 * Copyright 2020, Biren Technologies Inc.
 * All rights reserved.
 */

#ifndef _BR_PACKETS_DRIVER_H_
#define _BR_PACKETS_DRIVER_H_

#include <stdint.h>

#define VERSION 0.7

enum CMDHEADER_CPTYPEVALUE {
    INACTIVE = 0,
    REGULAR_CMD_PKT = 1,
    MESSAGE = 2
}; // CMDHEADER_CPTYPEVALUE

enum CMDHEADER_CPOPERATORVALUE {
    CP_NOP = 0,
    HW_CONFIGURATION = 1,
    CP_LDS = 5,
    BIND_HCQD = 8,
    RELEASE_HCQD = 9,
    FREE_HCQD = 10,
    SUBMIT_JD = 16,
    SUBMIT_IB = 17,
    SUBMIT_COND = 18,
    SUBMIT_DMA = 19,
    SUBMIT_CC = 20,
    SET_MMIO_REGISTER = 32,
    STORE_MMIO_REGISTER = 33,
    LOAD_MMIO_REGISTER = 34,
    RESET_MMIO_REGISTER = 35,
    ATOMIC_MEM = 48,
    EVENT_PIPELINE_CONTROL = 49,
    EVENT_SINGNAL = 50,
    EVENT_WAIT = 51,
    CSW_SAVE = 52,
    CSW_RESTORE = 53
}; // CMDHEADER_CPOPERATORVALUE

enum CMDATOMICMEM_ATOMICOPVALUE {
    ATOMIC_SWAP_U = 0,
    ATOMIC_CMPSWAP_U = 1,
    ATOMIC_INC_U = 2,
    ATOMIC_DEC_U = 3,
    ATOMIC_ADD_U = 4,
    ATOMIC_SUB_U = 5,
    ATOMIC_AND_U = 6,
    ATOMIC_OR_U = 7,
    ATOMIC_XOR_U = 8,
    ATOMIC_MAX_U = 9,
    ATOMIC_MIN_U = 10,
    ATOMIC_SWAP_U = 16,
    ATOMIC_CMPSWAP_U = 16,
    ATOMIC_INC_I = 18,
    ATOMIC_DEC_I = 19,
    ATOMIC_ADD_I = 20,
    ATOMIC_MAX_I = 21,
    ATOMIC_MIN_I = 22,
    READ = 32,
    WRITE = 33
}; // CMDATOMICMEM_ATOMICOPVALUE

enum CMDATOMICMEM_OVFMODEVALUE {
    CLAMP = 0,
    WRAP = 1
}; // CMDATOMICMEM_OVFMODEVALUE

enum CMDSUBMITDMA_SRCSELVALUE {
    DEVICE_MEM = 0,
    L2_CACHE = 1,
    CONSTANT_DATA = 2
}; // CMDSUBMITDMA_SRCSELVALUE

enum CMDSUBMITDMA_DSTSELVALUE {
    DEVICE_MEM = 0,
    L2_CACHE = 1
}; // CMDSUBMITDMA_DSTSELVALUE

enum CMDSUBMITJD_SUBMITMODEVALUE {
    DEFAULT = 0,
    FORCE_MODE = 1,
    MULTI_CAST = 2
}; // CMDSUBMITJD_SUBMITMODEVALUE

enum CMDSUBMITJD_MCDEVICECONFIGVALUE {
    NONE = 0,
    MODE_48_SPC = 1,
    MODE_24_SPC = 2,
    MODE_16_SPC = 3,
    MODE_12_SPC = 4,
    MODE_8_SPC = 5,
    MODE_6_SPC = 6
}; // CMDSUBMITJD_MCDEVICECONFIGVALUE

enum CMDSUBMITJD_MCVMCCONFIGVALUE {
    NONE = 0,
    CONFIG_VMC_SPC = 1
}; // CMDSUBMITJD_MCVMCCONFIGVALUE

enum CMDSUBMITJD_MCPEERCONFIGVALUE {
    NONE = 0,
    MODE_48_SPC = 1,
    MODE_24_SPC = 2,
    MODE_16_SPC = 3,
    MODE_12_SPC = 4,
    MODE_8_SPC = 5,
    MODE_6_SPC = 6
}; // CMDSUBMITJD_MCPEERCONFIGVALUE

enum CMDSUBMITJD_MCSPCCONFIGVALUE {
    CONFIG_24TO48_SPC = 0,
    CONFIG_16TO24_SPC = 1,
    CONFIG_12TO16_SPC = 2,
    CONFIG_8TO12_SPC = 3,
    CONFIG_6TO8_SPC = 4,
    CONFIG_4TO6_SPC = 5
}; // CMDSUBMITJD_MCSPCCONFIGVALUE

enum CMDHWCONFIGURATION_GPUMODEVALUE {
    SINGLE_GPU = 0,
    TIMESLICED_VGPU = 1,
    HWSLICED_VGPU = 2
}; // CMDHWCONFIGURATION_GPUMODEVALUE

enum CMDRELEASEHCQD_RELEASEMODEVALUE {
    RESERVED = 0,
    FLUSH = 1,
    ABORT = 2,
    PREEMPTION = 3
}; // CMDRELEASEHCQD_RELEASEMODEVALUE

enum CMDFREEHCQD_FREEMODEVALUE {
    RESERVED = 0,
    FLUSH = 1,
    ABORT = 2,
    PREEMPTION = 3
}; // CMDFREEHCQD_FREEMODEVALUE

typedef struct {
    uint32_t cpType : 2;
    uint32_t cpOperator : 8;
    uint32_t bodySize : 6;
    uint32_t reserved : 16;
} CmdHeader;

typedef struct {
    CmdHeader header;
    uint32_t paddingDW0;
} CmdCpNop;

typedef struct {
    CmdHeader header;
    uint32_t atomicOp : 7;
    uint32_t isLoopAtomic : 1;
    uint32_t rtnEnable : 1;
    uint32_t ovfMode : 1;
    uint32_t loopStep : 22;
    uint32_t destAddrl;
    uint32_t destAddrh : 17;
    uint32_t reserved : 15;
    uint32_t src;
    uint32_t cmpData;
} CmdAtomicMem;

typedef struct {
    CmdHeader header;
    uint32_t srcSel : 3;
    uint32_t dstSel : 3;
    uint32_t dmaSize : 25;
    uint32_t wrConfirm : 1;
    uint32_t srcAddressl;
    uint32_t srcAddressh;
    uint32_t dstAddressl;
    uint32_t dstAddressh;
} CmdSubmitDma;

typedef struct {
    CmdHeader header;
    uint32_t ibActive : 1;
    uint32_t ibSize : 26;
    uint32_t swapMode : 2;
    uint32_t reserved : 3;
    uint32_t ibStartAddressl;
    uint32_t ibStartAddressh;
} CmdSubmitIb;

typedef struct {
    CmdHeader header;
    uint32_t jdAddressL;
    uint32_t jdAddressH;
    uint32_t block : 1;
    uint32_t submitMode : 2;
    uint32_t mcDeviceConfig : 4;
    uint32_t mcVmcConfig : 4;
    uint32_t mcPeerConfig : 4;
    uint32_t mcSpcConfig : 4;
    uint32_t reserved : 13;
    uint32_t spcMask0;
    uint32_t spcMask1;
    uint32_t preEvent;
    uint32_t postEvent;
} CmdSubmitJd;

typedef struct {
    CmdHeader header;
    uint32_t gpuMode : 2;
    uint32_t hvmid : 4;
    uint32_t hcidMask : 16;
    uint32_t timeStep : 5;
    uint32_t idleStep : 5;
    uint32_t mcqdP0Caps : 16;
    uint32_t mcqdP0Number : 16;
    uint32_t mcqdP0BufferBasel;
    uint32_t mcqdP0BufferBaseh;
    uint32_t mcqdP1Caps : 16;
    uint32_t mcqdP1Number : 16;
    uint32_t mcqdP1BufferBasel;
    uint32_t mcqdP1BufferBaseh;
    uint32_t mcqdP2Caps : 16;
    uint32_t mcqdP2Number : 16;
    uint32_t mcqdP2BufferBasel;
    uint32_t mcqdP2BufferBaseh;
    uint32_t mcqdP3Caps : 16;
    uint32_t mcqdP3Number : 16;
    uint32_t mcqdP3BufferBasel;
    uint32_t mcqdP3BufferBaseh;
} CmdHwConfiguration;

typedef struct {
    CmdHeader header;
    uint32_t hvmid : 5;
    uint32_t numberQueue : 3;
    uint32_t hasid : 20;
    uint32_t reserved : 4;
    uint32_t commandQueueId;
    uint32_t mcqdAddressl;
    uint32_t mcqdAddressh : 17;
    uint32_t mcqdPriority : 4;
    uint32_t mcqdHcid : 4;
    uint32_t hcqdid : 5;
    uint32_t updateMode : 2;
    uint32_t wpointerAddressl;
    uint32_t wpointerAddressh;
    uint32_t rpointerAddressl;
    uint32_t rpointerAddressh;
    uint32_t rbBasel;
    uint32_t rbBaseh;
    uint32_t rbSize;
    uint32_t rbReadpointer;
} CmdBindHcqd;

typedef struct {
    CmdHeader header;
    uint32_t hvmid : 5;
    uint32_t hcid : 4;
    uint32_t releaseMode : 2;
    uint32_t numberQueue : 2;
    uint32_t reserved : 19;
    uint32_t commandQueueID;
} CmdReleaseHcqd;

typedef struct {
    CmdHeader header;
    uint32_t hvmid : 5;
    uint32_t hcid : 4;
    uint32_t freeMode : 2;
    uint32_t numberQueue : 2;
    uint32_t reserved : 19;
    uint32_t commandQueueID;
    uint32_t mcqdAddressl;
    uint32_t mcqdAddressh;
} CmdFreeHcqd;

typedef struct {
    CmdHeader header;
    uint32_t mmioAddress;
    uint32_t mmioRegsiter;
} CmdSetMmioRegister;

typedef struct {
    CmdHeader header;
    uint32_t mmioAddress;
    uint32_t size;
    uint32_t scmemAddressL;
    uint32_t scmemAddressH : 18;
    uint32_t reserved0 : 14;
} CmdLoadMmioRegister;

#endif //_BR_PACKETS_DRIVER_H_
