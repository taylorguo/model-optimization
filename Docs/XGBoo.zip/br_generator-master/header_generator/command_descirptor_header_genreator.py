import argparse
import math
import os
import xlrd


descriptor_file = "br100_descriptors.xlsx"
packet_file = "BR100_CP_Command_Packet.xlsx"
header_files_folder = "./header/"
descriptor_header_file_name = "br_descriptors.h"
descriptor_header_file_name_for_driver = "br_descriptors_driver.h"
packet_header_file_name = "br_packets.h"
packet_header_file_name_for_driver = "br_packets_driver.h"


def generate_descriptor_header_file(sheets, output_folder):
    if not os.path.exists(header_files_folder):
        os.mkdir(header_files_folder)
    file_path = os.path.join(header_files_folder, descriptor_header_file_name)
    with open(file_path, "w") as f:
        f.write("/**\n")
        f.write(" * br_descriptor.h header file generated from "
                "an excel file.\n")
        f.write(" * Copyright 2020, Biren Technologies Inc.\n")
        f.write(" * All rights reserved.\n")
        f.write(" */\n")
        f.write("\n")
        f.write("#ifndef _BR_DESCRIPTORS_H_\n")
        f.write("#define _BR_DESCRIPTORS_H_\n")
        f.write("\n")
        f.write("#include <stdint.h>\n")
        f.write("\n")

        write_first_level_structures(sheets, f)

        f.write("\n")
        f.write("#endif //_BR_DESCRIPTORS_H_\n")


def get_sheet_version(sheets, packet=False):
    version = None
    names = sheets.sheet_names()
    if (names[0].lower() == "edit history" or
            names[0].lower() == "version"):
        version_sheet = sheets.sheet_by_name(names[0])
        if packet:
            row = version_sheet.row(0)
        else:
            row = version_sheet.row(1)
        version = str(row[1].value).upper()

    return version


def generate_enum_definition(names, sheets, file):
    for name in names:
        sheet = sheets.sheet_by_name(name)
        first = True
        enum_name = ""
        for i in range(sheet.nrows):
            row = sheet.row(i)
            if row[0].value.upper() == 'VALUE':
                if first:
                    prev_row = sheet.row(i - 1)
                    enum_name = name + "_" + prev_row[1].value + "value"
                    enum_name = enum_name.upper()
                    file.write("\nenum {} {}\n".format(enum_name, "{"))
                # print(row[1].value)
                # if "reserved" in row[1].value.lower():
                #    continue
                field_name = row[1].value
                left, right = field_name.split("=")
                left = left.strip(" ")
                right = right.strip(" ")
                if left.isdigit():
                    temp = left
                    left = right
                    right = temp
                field_name = left + " = " + right
                # print(left, right)
                if field_name[0].isdigit():
                    field_name = "V_" + field_name.upper()
                else:
                    field_name = field_name.upper()
                # print("enum_name is: ", enum_name)
                # print("field_name is: ", field_name)
                if "RESERVED" in right.upper():
                    continue
                if not first:
                    file.write(",\n    {}".format(field_name))
                else:
                    file.write("    {}".format(field_name))
                first = False
            elif row[0].value.upper() != 'VALUE':
                if not first:
                    file.write("\n{}; // {}\n".format("}", enum_name))
                first = True


def check_if_new_dword_or_ddword_start(member_desc, unit_len=32):
    start_field = int(member_desc[0] % unit_len)
    if start_field == 0:
        return True
    else:
        return False


def write_first_level_structure_header(file,  unit_len=32):
    word_type = "uint32_t" if unit_len == 32 else "uint64_t"
    file.write("\n")
    file.write("    {} all;".format(word_type))
    file.write("\n    struct {}".format("{"))


def write_first_level_member(x, file, unit_len=32):
    whole_unit = int(x[1] % unit_len)
    word_type = "uint32_t" if unit_len == 32 else "uint64_t"
    var_name = convert_to_hump_excep_fist_word(x[2])
    if whole_unit == 0:
        file.write("\n        {} {};".format(word_type, var_name))
    else:
        file.write("\n        {} {} : {};".format(word_type, var_name,
                                                      x[1]))


def check_if_new_dword_or_ddword_end(member_desc, unit_len=32):
    end_field = int((member_desc[0] + member_desc[1]) % unit_len)
    if end_field == 0:
        return True
    else:
        return False


def write_first_level_structure_end(file, dword_num, unit_len=32):
    file.write("\n    {}f;".format("}"))


def convert_to_hump(one_string):
    hump_string = ""
    # if "_" not in str(one_string):
    one_string = camel_to_underscore(one_string)

    string_list = str(one_string).split("_")

    others = string_list[0:]
    others_capital = [word.capitalize() for word in others]

    hump_string = ''.join(others_capital)

    return hump_string


def write_second_level_structure_header(file,  unit_len=32):
    word_type = "uint32_t" if unit_len == 32 else "uint64_t"
    file.write("\n")
    file.write("    union {}\n        {} all;".format("{", word_type))
    file.write("\n        struct {}".format("{"))


def write_second_level_member(x, file, unit_len=32):
    whole_unit = int(x[1] % unit_len)
    word_type = "uint32_t" if unit_len == 32 else "uint64_t"
    var_name = convert_to_hump_excep_fist_word(x[2])
    if whole_unit == 0:
        file.write("\n            {} {};".format(word_type, var_name))
    else:
        file.write("\n            {} {} : {};".format(word_type, var_name,
                                                      x[1]))


def write_second_level_structure_end(file, dword_num, unit_len=32):
    file.write("\n        {}f;".format("}"))
    if unit_len == 32:
        file.write("\n    {}dword{};".format("}", dword_num))
    else:
        file.write("\n    {}ddword{};".format("}", dword_num))


def write_third_level_union_header(file):
    file.write("\n")
    file.write("            union {}".format("{"))


def write_third_level_struct_header(file):
    file.write("\n                struct {}".format("{"))


def camel_to_underscore(one_string):
    lst = []
    for index, char in enumerate(one_string):
        # if one_string == "workgroupOffsetY_L":
        #    print("index is {} and char is {}", index, char)
        if char.isupper() and index != 0:
            if one_string[index - 1] != "_":
                lst.append("_")
        lst.append(char)
    return "".join(lst).lower()


def convert_to_hump_excep_fist_word(one_string):
    hump_string = ""
    # if "_" not in str(one_string):
    one_string = camel_to_underscore(one_string)
    # print("one_string is ", one_string)
    string_list = str(one_string).split("_")
    first = string_list[0].lower()

    others = string_list[1:]
    others_capital = [word.capitalize() for word in others]
    others_capital[0:0] = [first]

    hump_string = "".join(others_capital)

    return hump_string


def write_third_level_member(x, file, unit_len=32):
    whole_unit = int(x[1] % unit_len)
    word_type = "uint32_t" if unit_len == 32 else "uint64_t"
    var_name = convert_to_hump_excep_fist_word(x[2])
    if whole_unit == 0:
        file.write("\n                    {} {};".format(word_type, var_name))
    else:
        file.write("\n                    {} {} : {};".format(word_type,
                                                              var_name,
                                                              x[1]))


def write_third_level_struct_end(file, name):
    file.write("\n                {}{};".format("}", name))


def write_third_level_union_end(file, name):
    file.write("\n            {}u;".format("}"))


def write_third_level_struct_member(x, file, dword_num, prev_x, next_x):
    # print("write_second_level_struct_member")
    keys = x.keys()
    # print(keys)
    for key in keys:
        values = x[key]
        if not isinstance(prev_x, dict):
            write_third_level_union_header(file)

        write_third_level_struct_header(file)
        for xx in values:
            write_third_level_member(xx, file, 64)

        write_third_level_struct_end(file, key)
        if not isinstance(next_x, dict):
            write_third_level_union_end(file, key)


def get_desc_definition(table_name, sheets):
    sheet = sheets.sheet_by_name(table_name)
    # print("table_name is: ", table_name)
    desc = []
    struct_name = ''
    struct_fields = []
    for i in range(sheet.nrows):
        row = sheet.row(i)
        if row[0].value.upper() == 'U_STRUCT':
            struct_name = row[1].value
            struct_fields = []
        elif row[0].value.upper() == 'U_STRUCT_END':
            # print(struct_fields)
            desc.append({struct_name: struct_fields})
            # print(desc)
            struct_name = ''
        field_type = row[0].value.upper()
        type = field_type.strip(" ")
        if (type == 'FIELD' or type == 'FILED' or type == 'U_TYPE'):
            start_bit = math.trunc(row[5].value)
            bit_len = math.trunc(row[3].value)
            field_name = row[1].value
            # print("field name is:", field_name)
            if struct_name != '':
                struct_fields.append((start_bit, bit_len, field_name))
            else:
                # print(field_name)
                desc.append((start_bit, bit_len, field_name))
    # sorted_desc = sorted(desc, key=operator.itemgetter(0))
    # print(desc)
    return desc


def generate_packet_header_file(sheets, output_folder):
    if not os.path.exists(header_files_folder):
        os.mkdir(header_files_folder)
    file_path = os.path.join(header_files_folder, packet_header_file_name)
    with open(file_path, "w") as f:
        f.write("/**\n")
        f.write(" * br_packets.h header file generated from "
                "an excel file.\n")
        f.write(" * Copyright 2020, Biren Technologies Inc.\n")
        f.write(" * All rights reserved.\n")
        f.write(" */\n")
        f.write("\n")
        f.write("#ifndef _BR_PACKETS_H_\n")
        f.write("#define _BR_PACKETS_H_\n")
        f.write("\n")
        f.write("#include <stdint.h>\n")
        f.write("\n")

        write_first_level_structures(sheets, f, True)

        f.write("\n")
        f.write("#endif //_BR_PACKETS_H_\n")


def write_first_level_structures(sheets, file, packet=False):
    bit_width = 32 if packet else 64
    names = sheets.sheet_names()
    version = get_sheet_version(sheets, packet)
    if get_sheet_version(sheets, packet):
        file.write("#define VERSION {}\n".format(version))
        # Remove the Edit History sheet from the list.
        names.pop(0)

    generate_enum_definition(names, sheets, file)

    for name in names:
        lower_struct_name = name
        if name.lower() == "cmdheader":
            file.write("\ntypedef union {}".format("{"))
        else:
            file.write("\ntypedef struct {}".format("{"))
        desc = get_desc_definition(table_name=name, sheets=sheets)
        # print(desc)
        dword_num = 0
        # isUnion = False
        i = 0
        for x in desc:
            if name.lower() == "cmdheader":
                if check_if_new_dword_or_ddword_start(x, bit_width):
                    write_first_level_structure_header(file, bit_width)
                write_first_level_member(x, file, bit_width)
                if check_if_new_dword_or_ddword_end(x, bit_width):
                    write_first_level_structure_end(file,
                                                    dword_num, bit_width)
                continue
            if not isinstance(x, dict):
                if x[2].lower() == "cmdheader":
                    dword_num += 1
                    type_name = convert_to_hump(x[2])
                    file.write("\n    {} header;".format(type_name))
                else:
                    if check_if_new_dword_or_ddword_start(x, bit_width):
                        write_second_level_structure_header(file, bit_width)

                    write_second_level_member(x, file, bit_width)

                    if check_if_new_dword_or_ddword_end(x, bit_width):
                        write_second_level_structure_end(file,
                                                         dword_num, bit_width)
                        dword_num += 1
            else:
                # if check_if_a_union_in_desc(x):
                # write_third_level_union_header(file)
                next_x = desc[i + 1]
                prev_x = desc[i - 1]
                write_third_level_struct_member(x, file, dword_num, prev_x,
                                                next_x)
                # write_third_level_union_end(file, keys[0])
            i += 1

        struct_name = convert_to_hump(lower_struct_name)
        file.write("\n{} {};".format("}", struct_name))
        file.write("\n")


def write_second_level_member_for_driver(x, file, unit_len=32):
    whole_unit = int(x[1] % unit_len)
    word_type = "uint32_t" if unit_len == 32 else "uint64_t"
    var_name = convert_to_hump_excep_fist_word(x[2])
    if whole_unit == 0:
        file.write("\n    {} {};".format(word_type, var_name))
    else:
        file.write("\n    {} {} : {};".format(word_type, var_name, x[1]))


def write_third_level_union_header_for_driver(file):
    file.write("\n")
    file.write("    union {}".format("{"))


def write_third_level_struct_header_for_driver(file):
    file.write("\n        struct {}".format("{"))


def write_third_level_member_for_driver(x, file, unit_len=32):
    whole_unit = int(x[1] % unit_len)
    word_type = "uint32_t" if unit_len == 32 else "uint64_t"
    var_name = convert_to_hump_excep_fist_word(x[2])
    if whole_unit == 0:
        file.write("\n            {} {};".format(word_type, var_name))
    else:
        file.write("\n            {} {} : {};".format(word_type, var_name,
                                                      x[1]))


def write_third_level_struct_end_for_driver(file, name):
    file.write("\n        {}{};".format("}", name))


def write_third_level_union_end_for_driver(file, name):
    file.write("\n    {}u;".format("}"))


def write_third_level_struct_member_for_driver(x, file, prev_x, next_x):
    # print("write_second_level_struct_member")
    keys = x.keys()
    # print(keys)
    for key in keys:
        values = x[key]
        if not isinstance(prev_x, dict):
            write_third_level_union_header_for_driver(file)

        write_third_level_struct_header_for_driver(file)
        for xx in values:
            write_third_level_member_for_driver(xx, file, 64)

        write_third_level_struct_end_for_driver(file, key)
        if not isinstance(next_x, dict):
            write_third_level_union_end_for_driver(file, key)


def generate_packet_header_file_for_driver(sheets, output_folder):
    if not os.path.exists(header_files_folder):
        os.mkdir(header_files_folder)
    file_path = os.path.join(header_files_folder,
                             packet_header_file_name_for_driver)
    with open(file_path, "w") as f:
        f.write("/**\n")
        f.write(" * br_packets_driver.h header file generated from "
                "an excel file.\n")
        f.write(" * Copyright 2020, Biren Technologies Inc.\n")
        f.write(" * All rights reserved.\n")
        f.write(" */\n")
        f.write("\n")
        f.write("#ifndef _BR_PACKETS_DRIVER_H_\n")
        f.write("#define _BR_PACKETS_DRIVER_H_\n")
        f.write("\n")
        f.write("#include <stdint.h>\n")
        f.write("\n")

        write_first_level_structures_for_driver(sheets, f, True)

        f.write("\n")
        f.write("#endif //_BR_PACKETS_DRIVER_H_\n")


def write_first_level_structures_for_driver(sheets, file, packet=False):
    names = sheets.sheet_names()
    bit_width = 32 if packet else 64
    version = get_sheet_version(sheets, packet)
    if get_sheet_version(sheets, packet):
        file.write("#define VERSION {}\n".format(version))
        # Remove the Edit History sheet from the list.
        names.pop(0)

    generate_enum_definition(names, sheets, file)

    for name in names:
        lower_struct_name = name
        file.write("\ntypedef struct {}".format("{"))
        desc = get_desc_definition(table_name=name, sheets=sheets)
        i = 0
        for x in desc:
            if not isinstance(x, dict):
                if x[2] == "cmdHeader":
                    type_name = convert_to_hump(x[2])
                    file.write("\n    {} header;".format(type_name))
                else:
                    write_second_level_member_for_driver(x, file, bit_width)
            else:
                # if check_if_a_union_in_desc(x):
                # write_third_level_union_header(file)
                next_x = desc[i + 1]
                prev_x = desc[i - 1]
                write_third_level_struct_member_for_driver(x, file, prev_x,
                                                           next_x)
            i += 1
        struct_name = convert_to_hump(lower_struct_name)
        file.write("\n{} {};".format("}", struct_name))
        file.write("\n")


def generate_descriptor_header_file_for_driver(sheets, output_folder):
    if not os.path.exists(header_files_folder):
        os.mkdir(header_files_folder)
    file_path = os.path.join(header_files_folder,
                             descriptor_header_file_name_for_driver)
    with open(file_path, "w") as f:
        f.write("/**\n")
        f.write(" * br_descriptor_driver.h header file generated from "
                "an excel file.\n")
        f.write(" * Copyright 2020, Biren Technologies Inc.\n")
        f.write(" * All rights reserved.\n")
        f.write(" */\n")
        f.write("\n")
        f.write("#ifndef _BR_DESCRIPTORS_DRIVER_H_\n")
        f.write("#define _BR_DESCRIPTORS_DRIVER_H_\n")
        f.write("\n")
        f.write("#include <stdint.h>\n")
        f.write("\n")

        write_first_level_structures_for_driver(sheets, f)

        f.write("\n")
        f.write("#endif //_BR_DESCRIPTORS_DRIVER_H_\n")


def get_current_folder(file_name=None):
    if file_name is None:
        file_name = __file__
    current_folder = os.path.split(os.path.realpath(file_name))[0]
    return current_folder


def open_desc_file(file_name):
    current = get_current_folder()
    file_path = os.path.join(current, file_name)
    # print("file_path is ", file_path)
    if not os.path.exists(file_path):
        print("Please copy the descriptor file to current working directory!")
        return
    desc_sheets = xlrd.open_workbook(file_path)
    return desc_sheets


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('--input_folder', '-i')
    parser.add_argument('--output_folder', '-o')
    parser.add_argument('--option', '-O')
    parser.add_argument("-p", "--packet", help="generate command packet header",
                        action="store_true")
    parser.add_argument("-d", "--descriptor", help="generate descriptor header",
                        action="store_true")
    args = parser.parse_args()

    descriptor_sheets = open_desc_file(descriptor_file)
    if descriptor_sheets is None:
        return
    packet_sheets = open_desc_file(packet_file)
    if packet_sheets is None:
        return

    if args.packet:
        generate_packet_header_file(packet_sheets, args.output_folder)
        generate_packet_header_file_for_driver(packet_sheets, args.output_folder)
        if args.output_folder is not None:
            print("generated command packet header at ", args.output_folder)
        else:
            print("generated command packet header at ./header/")
    elif args.descriptor:
        generate_descriptor_header_file(descriptor_sheets, args.output_folder)
        generate_descriptor_header_file_for_driver(descriptor_sheets, args.output_folder)
        if args.output_folder is not None:
            print("generated descriptor header at ", args.output_folder)
        else:
            print("generated descriptor header at ./header/")
    else:
        generate_packet_header_file(packet_sheets, args.output_folder)
        generate_packet_header_file_for_driver(packet_sheets, args.output_folder)
        generate_descriptor_header_file(descriptor_sheets, args.output_folder)
        generate_descriptor_header_file_for_driver(descriptor_sheets, args.output_folder)
        if args.output_folder is not None:
            print("generated descriptor header at ", args.output_folder)
        else:
            print("generated descriptor header at ./header/")
        if args.output_folder is not None:
            print("generated command packet header at ", args.output_folder)
        else:
            print("generated command packet header at ./header/")


if __name__ == '__main__':
    main()