1. Copy the latest descriptor excel files to this folder. The name must be the same as the existing one.
2. Run command "Python3 command_descirptor_header_genreator.py -p" to generate command packet header files.
3. Run command "Python3 command_descirptor_header_genreator.py -d" to generate descriptor header files.
4. Run command "Python3 command_descirptor_header_genreator.py" to generate descriptor header files and command packet header files.