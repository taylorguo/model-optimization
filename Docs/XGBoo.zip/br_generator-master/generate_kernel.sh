#!/bin/bash

echo $BASH_SOURCE
if [ $# == 0 ]
  then
  python3 $(dirname $BASH_SOURCE)/test_generator/generate_kernel.py -c
  python3 $(dirname $BASH_SOURCE)/test_generator/generate_kernel.py -g 
  python3 $(dirname $BASH_SOURCE)/command_generator/make_vectors.py -d
  python3 $(dirname $BASH_SOURCE)/test_generator/generate_kernel.py -m 

  elif [ $# == 1 ]
    then
    if [ "$1" == "-c" ]
      then
      echo "$1"
      python3 $(dirname $BASH_SOURCE)/test_generator/generate_kernel.py -c
      
      elif [ "$1" == "-m" ]
      then
      echo "$1"
      python3 $(dirname $BASH_SOURCE)/test_generator/generate_kernel.py -m

      elif [ "$1" == "-g" ]
      then
      echo "$1"
      python3 $(dirname $BASH_SOURCE)/test_generator/generate_kernel.py -g

      else
      echo "$1"
      python3 $(dirname $BASH_SOURCE)/test_generator/generate_kernel.py -c
      python3 $(dirname $BASH_SOURCE)/test_generator/generate_kernel.py -g 
      python3 $(dirname $BASH_SOURCE)/command_generator/make_vectors.py -d
      python3 $(dirname $BASH_SOURCE)/test_generator/generate_kernel.py -m $1
    fi
  
  elif [ $# == 2 ]
    then
    if [ "$1" == "-c" -o "$2" == "-c" ]
      then
      python3 $(dirname $BASH_SOURCE)/test_generator/generate_kernel.py -c $2
      
      elif [ "$1" == "-m" -o "$2" == "-m" ]
      then
      python3 $(dirname $BASH_SOURCE)/test_generator/generate_kernel.py -m $2

      else
      echo "Wrong argument! Please check your input"
      echo "  -c:   construct folder for each assembly file"
      echo "  -m:   move kernels to destination folder"
      echo "  [dest_path]:    destination path"
    fi
fi