import os
import shutil
import sys
from command_generator import refresh_readme as rr


dest_path = '/opt/vector/test_br100/unit/'


def remove(test_path):
    if not os.path.isdir(test_path):
        print("Error: test not found inserver: ", test_path)
        return

    parent_folder_path = os.path.abspath(os.path.dirname(test_path))
    test_name = test_path.split(os.sep)[-1]
    readme_path = os.path.join(parent_folder_path, 'readme.txt')
    dic = rr.txt_to_dic(readme_path)
    os.remove(readme_path)
    new_dic = {}
    for key in dic.keys():
        if dic[key] != test_name:
            new_dic[key] = dic[key]
    rr.dic_to_txt(new_dic, readme_path)

    shutil.rmtree(test_path)


def main():
    if len(sys.argv) == 1:
        print("Error: no target test.")
        exit(-1)
    else:
        for index in range(1, len(sys.argv)):
            file_path = os.path.join(dest_path, sys.argv[index])
            remove(file_path)


if __name__ == '__main__':
    main()