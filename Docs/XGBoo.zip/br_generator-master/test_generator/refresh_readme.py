import collections
import os, re
from command_generator import io_handler as ioh


def txt_to_dic(file_path):
    dic = {}
    with open(file_path, 'r') as file:
        find_lines = file.readlines()

    if not find_lines:
        print("Error: file not found: ", file_path)
        return dic

    for line in find_lines:
        kv = line.split(':')
        dic[kv[-1].strip()] = kv[0].strip()
    return dic


def txt_to_dic_with_params(file_path):
    dic = {}
    with open(file_path, 'r') as file:
        find_lines = file.readlines()

    if not find_lines:
        print("Error: file not found: ", file_path)
        return dic

    for line in find_lines:
        kv = line.split(';')[0].split(':')
        dic[kv[-1].strip()] = kv[0].strip()
    return dic


def dic_to_txt(new_dic, readme_path):
    dic = {}
    for key in sorted(new_dic.keys()):
        dic[key] = new_dic[key]
    file = open(readme_path, 'w')
    for old_name in new_dic.keys():
        line = dic[old_name] + ': ' + old_name + '\n'
        file.write(line)
    file.close()


def sort_with_index(find_lines):
    bpa_arr = {}
    bpw_arr = {}
    fwd_arr = {}
    for line in find_lines:
        if line[:3] == "bpa":
            index = int(re.findall(r'\d+\.?\d*', line)[0])
            bpa_arr[index] = line
        elif line[:3] == "bpw":
            index = int(re.findall(r'\d+\.?\d*', line)[0])
            bpw_arr[index] = line
        elif line[:3] == "fwd":
            index = int(re.findall(r'\d+\.?\d*', line)[0])
            fwd_arr[index] = line

    find_lines = []
    for key in sorted(bpa_arr.keys()):
        find_lines.append(bpa_arr[key])
    for key in sorted(bpw_arr.keys()):
        find_lines.append(bpw_arr[key])
    for key in sorted(fwd_arr.keys()):
        find_lines.append(fwd_arr[key])
    return find_lines


def get_params(folder_path):
    # folder_path = os.path.abspath(os.path.dirname(isa_path))
    folder_name = folder_path.split(os.sep)[-1]
    if folder_name == 'input':
        dic = ioh.load_json_to_dict(folder_path, '', "isa_params.json")
    else:
        dic = ioh.load_json_to_dict(os.path.join(folder_path, 'input'), '', "isa_params.json")
    if not dic:
        return None, None, None, None

    params_line = ''
    for key in dic.keys():
        if key == 'block0_0':
            sub_dic = dic[key]
            for key2 in sub_dic.keys():
                if key2 == 'PSR 0':
                    target_dic = sub_dic[key2]
                    if 'Padx' in target_dic.keys() and \
                        'Pady' in target_dic.keys() and \
                        'Stride' in target_dic.keys() and \
                        "Dilation" in target_dic.keys():
                        params_line += 'Padx: ' + target_dic['Padx'] + \
                                       " Pady: " + target_dic['Pady'] + \
                                       " Stride: " + target_dic['Stride'] + \
                                       " Dilation: " + target_dic['Dilation']
                        return target_dic['Dilation'], target_dic['Stride'], target_dic['Padx'], target_dic['Pady']
                    else:
                        return None, None, None, None


def make_sub_readme(test_path, new_path, local=False):
    if local:
        readme_path = os.path.join(test_path, 'readme.txt')
    else:
        readme_path = os.path.join(new_path, 'readme.txt')

    dilation, stride, padx, pady = get_params(test_path)
    new_name = new_path.split('/')[-1]
    old_name = test_path.split(os.sep)[-1]
    line_1 = new_name + ": " + old_name
    if dilation:
        line_2 = 'Padx: ' + padx + \
               " Pady: " + pady + \
               " Stride: " + stride + \
               " Dilation: " + dilation
        file = open(readme_path, 'w')
        file.write(line_1)
        file.write('\n')
        file.write(line_2)
        file.close()
    else:
        file = open(readme_path, 'w')
        file.write(line_1)
        file.close()


def append_readme(new_path, readme_path):
    sub_readme = os.path.join(new_path, 'readme.txt')
    new_line = ''
    with open(sub_readme, 'r') as file:
        sub_lines = file.readlines()
        for line in sub_lines:
            if line[-1] == '\n':
                line = line[:-1]
            new_line += line
            new_line += '; '
    if not new_line:
        print("Error: %s does not exist!!!" % sub_readme)
        return

    replace_lines = []
    with open(readme_path, 'r') as file1:
        find_lines = file1.readlines()
        for line in find_lines:
            if line != '\n':
                replace_lines.append(line)
        replace_lines.append(new_line)
    if not replace_lines:
        print("Error: %s does not exist!!!" % readme_path)
        return

    os.remove(readme_path)
    file2 = open(readme_path, 'w')
    for line in sort_with_index(replace_lines):
        if line[-1] != '\n':
            line += '\n'
        file2.write(line)
    file2.close()
