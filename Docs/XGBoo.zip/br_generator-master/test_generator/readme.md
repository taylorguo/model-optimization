# Sample command line for Code Gen to generate a complete command packet

## Forward convolution

### How to generate an reduction stride1 unit case for single convolution operator:
python make_simple_conv.py 1x32x8x8 1x32x1x1 --padx=0 --pady=0 --stride=1 --reduction=1

### How to generate an reduction stride2 unit case for single convolution operator:
python make_simple_conv.py 1x32x8x8 1x32x1x1 --padx=0 --pady=0 --stride=2 --reduction=1

### How to generate an reduction stride2 unit case for single convolution operator:
python make_simple_conv.py 1x32x8x8 1x32x1x1 --padx=0 --pady=0 --stride=2 --reduction=1 --gmb=1

### How to generate an reduction unit case for single convolution operator with designated data cleared:
python make_simple_conv.py 1x32x8x8 1x32x1x1 --reduction=1 --clear=[u1,u2]

### How to generate an reduction unit case for single convolution operator comparing designated data:
python make_simple_conv.py 1x32x8x8 1x32x1x1 --reduction=1 --compare=[u1,u2]

### How to generate an reduction unit case for single convolution operator clearing and comparing designated data:
python make_simple_conv.py 1x32x8x8 1x32x1x1 --reduction=1 --compare=[u1,u2] --clear=[u0]
python make_simple_conv.py 2x3x224x224 8x3x7x7 --padx=3 --pady=3 --stride=2 --reduction=1

### How to generate an unit case for single convolution operator with different data type:
python make_simple_conv.py 1x32x8x8 1x32x1x1 -idt=bf16 -wdt=bf16 -odt=bf16
python make_simple_conv.py 1x32x8x8 1x32x1x1 -idt=fp32 -wdt=fp32 -odt=fp32
python make_simple_conv.py 1x32x8x8 1x32x1x1 -idt=s8 -wdt=s8
python make_simple_conv.py 1x32x8x8 1x32x1x1 -idt=u8 -wdt=u8

### Special case for EfficientNet case:
python make_simple_conv.py 1x24x60x60 144x24x1x1 --padx=0 --pady=0 --stride=1

## Normal MMA case

### How to generate a normal mma test vector for single mma operator:
python make_simple_mma.py 32x32 32x32

## Normal DWC case

### How to generate a normal dwc test vector for single mma operator:
python make_simple_dwc.py 2x8x8x8 8x1x3x3 --padx=1 --pady=1 --stride=1 --dilation=1

## Normal Maxpooling case

### How to generate a normal Maxpooling test vector for single mma operator:
python make_simple_maxpooling.py 1x32x16x16 3x3 --padx=1 --pady=1 --stride=1 --dilation=1

## Normal Batchnorm case

### How to generate a normal Maxpooling test vector for single mma operator:
python make_simple_bn.py 1x32x4x8 32x4x1x1 --relu_on=True --force_ackgmb=False
