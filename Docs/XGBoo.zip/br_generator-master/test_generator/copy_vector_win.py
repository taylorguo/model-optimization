import shutil
import socket
import stat
import paramiko
from scp import SCPClient
import os
import re


ip = "10.10.16.32"
port = 22


def get_host_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', port))
        ip = s.getsockname()[0]
    finally:
        s.close()
    print('local host ip is: ', ip)
    return ip


def check_empty_on_server(folder, username, password):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(ip, port, username, password)
    command = 'ls ' + folder
    stdin, stdout, stderr = ssh.exec_command(command)
    if stdout.readline() == '':
        ssh.close()
        return True
    else:
        ssh.close()
        return False


def remove_server_file(path, username, password):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(ip,port, username, password)
    command = 'rm -rf ' + path + '/*'
    stdin, stdout, stderr = ssh.exec_command(command)
    print("remove all files in ", path)
    ssh.close()


def download(dest_path, local_path, username, password):
    def walk_folder(dest_path, local_path):
        try:
            sub_folder_names = sftp.listdir(dest_path)
            for folder in sub_folder_names:
                remote_folder_path = dest_path + '/' + folder
                local_folder_path = os.path.join(local_path, folder)
                if len(folder.split('.')) == 2:
                    open(local_folder_path, 'w')
                else:
                    os.mkdir(local_folder_path)
                walk_folder(remote_folder_path, local_folder_path)
        except Exception:
            print("local path is ", local_path)
            print("remote path is ", dest_path)
            sftp.get(dest_path, local_path)

    clear_local(local_path)
    t = paramiko.Transport((ip, port))
    t.connect(username=username, password=password)
    sftp = paramiko.SFTPClient.from_transport(t)
    walk_folder(dest_path, local_path)
    t.close()
    print('Download finished')


def upload(local_mid_path, dest_path, username, password):
    def walk_folder(local_mid_path, dest_path):
        if os.path.isdir(local_mid_path):
            sub_folder_names = os.listdir(local_mid_path)
            for folder in sub_folder_names:
                remote_folder_path = dest_path + '/' + folder
                local_folder_path = os.path.join(local_mid_path, folder)
                # print("folder: ", folder, len(folder.split('.')))
                if len(folder.split('.')) != 2:
                    command = 'mkdir ' + remote_folder_path
                    ssh.exec_command(command)
                    mode_command = 'chmod -R 777 ' + remote_folder_path
                    ssh.exec_command(mode_command)

                walk_folder(local_folder_path, remote_folder_path)
        else:
            print("local path is ", local_mid_path)
            print("remote path is ", dest_path)
            sftp.put(local_mid_path, dest_path)

    t = paramiko.Transport((ip, port))
    t.connect(username=username, password=password)
    sftp = paramiko.SFTPClient.from_transport(t)
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(ip, port, username, password)

    walk_folder(local_mid_path, dest_path)
    t.close()
    ssh.close()
    print('upload finished')


def clear_local(local_path):
    if not os.path.exists(local_path):
        return

    folders = os.listdir(local_path)
    for folder in folders:
        folder_path = os.path.join(local_path, folder)
        if folder == 'readme.txt':
            os.remove(folder_path)
        else:
            shutil.rmtree(folder_path)


def change_mode(folder_path):
    for root, dirs, filename in os.walk(folder_path):
        for dir in dirs:
            dir_path = os.path.join(root, dir)
            command = 'cacls ' + dir_path + ' /e /p everyone:f'
            #os.system(command)
            os.chmod(dir_path, stat.S_IRWXO + stat.S_IRWXG + stat.S_IRWXU)
        for file in filename:
            file_path = os.path.join(root, file)
            command = 'cacls ' + file_path + ' /e /p everyone:f'
            #os.system(command)
            os.chmod(file_path, stat.S_IRWXO + stat.S_IRWXG + stat.S_IRWXU)

