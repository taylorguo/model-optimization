from test_generator import make_golden as mg
from command_generator import utils
import os, sys


dest_path = os.path.join('command_generator', 'vectors', 'unit', 'test_case')


Cjobd = {
    "workMode": 0,
    "numCwarp": 0,
    "taskSplit": 11,
    "reserved3": 0,
    "ggg": 0
}

Cud = {
    "kernel_name": "test",
    "usharpOffsetSel": 0,
    "reserved_0": 0,
    "pc": "0x0000000000000001",
    "bsharpAddr": 0,
    "cnstAddr": 0,
    "reserved0": 0,
    "reserved1": 0,
    "reserved2": 0
}

Tmd = {
    "tlmBaseAddr": 0,
    "gsmBaseAddr": 0,
    "tlmSize": 0,
    "atomicEn": 0,
    "gsmSize": 0,
    "tgSlots": 0,
    "gsmPartition": 0,
    "reserved0": 0,
    "reserved1": 0
}

Usharp = [
    {
        "file_name": "br-unit-fwd-U0-conv0-W-4DW-1x8x1x1-BF16.bin",
        "id": 0,
        "address": "0x0000000000000002",
        "viewType": '1D',
        "viewFormat": 'BF16',
        "viewImageLayout": 'linear',
        "tensorFormatDimension": {
            "widthT": 8,
            "heightT": 8,
            "depthT": 8,
            "reserved1": 0
        },
        "reserved2": 0,
        "numSubUSharp": 1,
        "padBaseOffset": 0,
        "padSize": 0,
        "Reserved5": 0
    },
    {
        "file_name": "br-unit-fwd-U1-conv0-A-3DA-1x8x8x8-BF16.bin",
        "id": 1,
        "address": "0x00000012290000000001",
        "viewType": "2D",
        "viewFormat": "BF16",
        "viewImageLayout": "2DW",
        "tensorFormatDimension": {
            "widthT": 8,
            "heightT": 8,
            "depthT": 32,
            "reserved1": 0
        },
        "reserved2": 0,
        "numSubUSharp": 1,
        "padBaseOffset": 0
    },
    {
        "file_name": "br-unit-fwd-U2-conv0-A-3DA-1x1x4x4-BF16.bin",
        "id": 2,
        "address": "0x00000000000",
        "viewType": "1D",
        "viewFormat": "BF16",
        "viewImageLayout": "2DA",
        "tensorFormatDimension": {
            "widthT": 1,
            "heightT": 8,
            "depthT": 32,
            "reserved1": 0
        },
        "reserved2": 0,
        "numSubUSharp": 1,
        "l15Mode": 3,
        "is_numa": 5
    }
]


desc = {
    "Cjobd": Cjobd,
    "Cud": Cud,
    "Tmd": Tmd,
    "Usharp": Usharp
}


def main():
    if len(sys.argv) == 1:
        mg.execute_task(desc)
    elif sys.argv[1] == '-c':
        utils.make_struct(dest_path)
    else:
        mg.execute_task(desc, name=sys.argv[1])


if __name__ == '__main__':
    main()
