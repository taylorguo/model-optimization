import os
from command_generator import utils 


bpa_names = []
bpw_names = []
fwd_names = []
bpa_new_name = []
bpw_new_name = []
fwd_new_name = []


def find_folders(path):
    g = os.walk(path)
    for dirpath, dirname, filenames in g:
        pre_folder = dirpath.split(os.sep)[-1]
        if pre_folder[:4] == 'bpa_':
            bpa_names.append(pre_folder)
        elif pre_folder[:4] == 'bpw_':
            bpw_names.append(pre_folder)
        elif pre_folder[:4] == 'fwd_':
            fwd_names.append(pre_folder)


def read_readme(file_path):
    dic = {}
    with open(file_path, 'r') as file:
        find_lines = file.readlines()
        for line in find_lines:
            kv = line.split(':')
            dic.update({kv[0].strip(): kv[1].strip()})
    return dic


def convert_to_new_name(ori_name, bpa_not_index, bpw_not_index, fwd_not_index):
    if ori_name[:4] == 'bpa_':
        index = 0
        while index in bpa_not_index:
            index += 1
        new_name = 'bpa' + str(index)
        return utils.reset_name(new_name)
    elif ori_name[:4] == 'bpw_':
        index = 0
        while index in bpw_not_index:
            index += 1
        new_name = 'bpw' + str(index)
        return utils.reset_name(new_name)
    elif ori_name[:4] == 'fwd_':
        index = 0
        while index in fwd_not_index:
            index += 1
        new_name = 'fwd' + str(index)
        return utils.reset_name(new_name)
