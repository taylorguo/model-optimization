#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import os
import shutil
import urllib
from golden_generator.mini_test import simple_mma
from command_generator import utils
from command_generator import io_handler as ioh
import code_generator.share.br_defined_print as bdp
import code_generator.share.br_const_defs as cst
from parser import parser_utils
from tests.code_gen import br_test_utils as test_utils
from code_generator.tcore import br_tcore_mma as mma
from golden_generator.mini_test import simple_conv
from golden_generator.mini_test import simple_bn
from golden_generator.mini_test import simple_bnrelu
from golden_generator.mini_test import simple_maxpool
from golden_generator.mini_test import simple_dwc
from golden_generator.mini_test import simple_addrelu
from code_generator.tcore import br_tcore_fwd_conv as tfc
from code_generator.tcore import br_tcore_bpa_conv as tbc
from code_generator import br_code_gen_interface as bcgi
from command_generator import br_command_gen_interface
from command_generator import make_descriptors as md


cwd = os.path.abspath(os.path.dirname(__file__))
id_file = "manifest.xml"


def convert_to_1d(csr_table):
    new_list = []
    for l in csr_table:
        for ele in l:
            new_list.append(ele)
    return new_list


def update_version_file(case_folder):
    brgen_root = utils.brgen_root
    parent = os.path.abspath(os.path.dirname(brgen_root))
    asm_path = os.path.join(parent, "br_assembler",
                            utils.check_linux_type())
    id_file_path = os.path.join(asm_path, id_file)
    if os.path.exists(id_file_path):
        shutil.copy(id_file_path, os.path.join(case_folder, id_file))
    else:
        asm_path = os.path.join(os.environ['HOME'] , 'biren_tools',
                                utils.check_linux_type())
        id_file_path = os.path.join(asm_path, id_file)
        if os.path.exists(id_file_path):
            shutil.copy(id_file_path, os.path.join(case_folder, "manifest_assembler.xml"))
        cmodel_path = os.path.join(os.environ['HOME'] , 'cmodel_release',
                                utils.check_linux_type())
        id_file_path = os.path.join(cmodel_path, id_file)
        if os.path.exists(id_file_path):
            shutil.copy(id_file_path, os.path.join(case_folder, "manifest_cmodel.xml"))
    

class br_simple_conv():
    def __init__(self, ishape, wshape, dilation_value,
                 stride_value, padding_value, type, clear, compare,
                 cmd_packet_type="Submit_JD",
                 weight_dt='bf16', input_dt='bf16', output_dt='bf16',
                 bpw_index=0, test_addr=None, ass=False, desc=False,
                 cmd_packet=False, all=False, get_input=False, reduction=0,
                 gmb=0, hwshape=None, extension=False, unroll_disable=False,
                 replace_kernel=False, backend=False):
        self.ishape = ishape
        self.wshape = wshape
        self.dilation_value = dilation_value
        self.stride_value = stride_value
        self.padding_value = padding_value
        self.type = type
        self.weight_dt = weight_dt
        self.input_dt = input_dt
        self.output_dt = output_dt
        self.bpw_index = bpw_index
        self.cmd_packet_type = cmd_packet_type
        self.test_addr = test_addr
        self.ass = ass
        self.desc = desc
        self.cmd_packet = cmd_packet
        self.all = all
        self.reduction = True if reduction == "1" else False
        self.red_mode = "ssq" if self.reduction else "roff"
        self.gmb = int(gmb)
        self.hwshape = hwshape
        self.extension = extension
        self.clear = clear
        self.compare = compare
        self.unroll_disable = unroll_disable
        self.replace_kernel = replace_kernel
        self.backend = backend

    def gen_assembly(self, output_folder=None):
        dt = (self.weight_dt, self.input_dt, self.output_dt)
        if output_folder:
            bdp.set_output_file("kernel.s", output_folder)
        else:
            bdp.set_output_file("kernel.s")

        usharps0 = {
            "tensor_a": {"usharp": 0},
            "tensor_b": {"usharp": 1},
            "tensor_o": {"usharp": 2},
            "reduce": {"usharp": 3}
        }

        if self.replace_kernel == "True":
            bdp.set_enable_kernel_replace(True)

        if self.backend == "True":
            bdp.enable_backend(True)

        cst.set_code_style(0)
        if self.hwshape is not None:
            print("PYN hwshape")
            if self.type == 'fwd':
                conv1 = bcgi.br_fwd_conv(
                    self.ishape, self.wshape, dt, stride=self.stride_value,
                    dilation=self.dilation_value, padx=self.padding_value[0],
                    red_mode=self.red_mode, pady=self.padding_value[1],
                    usharps=usharps0, hwshape=self.hwshape, unroll_disable=self.unroll_disable
                )
            elif self.type == 'bpa':
                print("PYN gen ass ishape wshape",self.ishape, self.wshape)
                print("PYN gen ass stride dilation and padding",self.stride_value, self.dilation_value, self.padding_value)
                conv1 = bcgi.br_bpa_conv(
                    self.ishape, self.wshape, dt, stride=self.stride_value,
                    dilation=self.dilation_value, padx=self.padding_value[0],
                    red_mode=self.red_mode, pady=self.padding_value[1],
                    usharps=usharps0, hwshape=self.hwshape
                )
        elif self.extension:
            if self.type == 'fwd':
                conv1 = bcgi.br_fwd_conv(
                    self.ishape, self.wshape, dt, stride=self.stride_value,
                    dilation=self.dilation_value, red_mode=self.red_mode,
                    padx=self.padding_value[0], pady=self.padding_value[1],
                    usharps=usharps0, extension=self.extension,
                    unroll_disable=self.unroll_disable
                )
            elif self.type == 'bpa':
                conv1 = bcgi.br_bpa_conv(
                    self.ishape, self.wshape, dt, stride=self.stride_value,
                    dilation=self.dilation_value, padx=self.padding_value[0],
                    red_mode=self.red_mode, pady=self.padding_value[1],
                    usharps=usharps0, hwshape=self.hwshape
                )
        else:
            if self.type == "fwd":
                conv1 = bcgi.br_fwd_conv(
                    self.ishape, self.wshape, dt, stride=self.stride_value,
                    dilation=self.dilation_value, red_mode=self.red_mode,
                    padx=self.padding_value[0], pady=self.padding_value[1],
                    usharps=usharps0, unroll_disable=self.unroll_disable
                )
            elif self.type == 'bpa':
                conv1 = bcgi.br_bpa_conv(
                    self.ishape, self.wshape, dt, stride=self.stride_value,
                    dilation=self.dilation_value, padx=self.padding_value[0],
                    red_mode=self.red_mode, pady=self.padding_value[1],
                    usharps=usharps0, hwshape=self.hwshape
                )
        wsr_num = conv1.get_required_wsr()
        csr_table = bcgi.br_get_csr_table()
        conv1.generate()
        conv1.flush()
        return csr_table

    def execute_task(self):
        print("\nStart making convolution golden!")
        csr_table = None
        if self.type == 'fwd':
            folder_path = os.path.join(self.test_addr, 'input')
            if self.ass or self.all:
                # ihsape="1x8x8x8"
                simple_conv.gen_simple_conv(self.ishape, self.wshape, self.dilation_value,
                                    self.stride_value, self.padding_value, self.weight_dt,
                                    self.input_dt, self.output_dt, self.type, dest_path=self.test_addr,
                                    wred=self.reduction)
                csr_table = self.gen_assembly(output_folder=folder_path)

                if self.ass:
                    utils.exact_file_to_parent_folder(folder_path)
                    return folder_path
            if self.all:
                assfile = utils.get_desired_file(folder_path, '.s')
                dest_path = os.path.join(folder_path, assfile)
                test_utils.gen_dummy_cwarp(dest_path, "conv")
            if self.desc or self.all:
                if self.desc:
                    utils.exact_file_to_parent_folder(self.test_addr, input=True)
                parser_utils.make_program(folder_path)
                case_path = os.path.abspath(os.path.dirname(folder_path))
                if not csr_table:
                    csr_table = 0
                dic, path= md.make_desc_dic(case_path, 'br-', csr=csr_table, cnstLayout=1, 
                                            cmd_packet=self.cmd_packet_type, gmb=self.gmb)
                br_command_gen_interface.br_gen_descriptor(dic, target_path=path, finished=True)
                if self.desc:
                    utils.exact_file_to_parent_folder(folder_path)
                    return folder_path
            if self.cmd_packet or self.all:
                if self.cmd_packet:
                    files = os.listdir(self.test_addr)
                    for file in files:
                        if file != 'descriptors.json' and file != 'usharp_mapping.json' and \
                                (not file.endswith(".bin")) and (not file.endswith(".s")) \
                                and file != "csim":
                            os.remove(os.path.join(self.test_addr, file))
                    utils.exact_file_to_parent_folder(self.test_addr, input=True)
                parser_utils.make_program(folder_path)
                case_path = os.path.abspath(os.path.dirname(folder_path))
                br_command_gen_interface.br_gen_cmd_packet(case_path, self.clear, self.compare)
                utils.rm_io(self.test_addr)
            update_version_file(self.test_addr)
        elif self.type == 'bpa':
            folder_path = os.path.join(self.test_addr, 'input')
            if self.ass or self.all:
                if self.type == 'bpa':
                    nc, cin, ih, iw = self.ishape
                    wcout, wcin, wh, ww = self.wshape
                    padx = self.padding_value[0]
                    pady = self.padding_value[1]
                    stride = self.stride_value
                    ow = int((iw - ww + 2*padx) / stride) + 1
                    oh = int((ih - wh + 2*pady) / stride) + 1
                    bpaishape = (nc, wcout, oh, ow)
                    bpapadx = int(((iw - 1) * 1 + ww - (ow - 1) * stride - 1) / 2)
                    bpapady = int(((ih - 1) * 1 + wh - (oh - 1) * stride - 1) / 2)
                    self.ishape = bpaishape
                    #self.wshape = (wcin, wcout, wh, ww)
                    self.padding_value = (bpapadx, bpapady)
                    print("bpa in shape",self.ishape)
                    print("bpa w shape, bpa padx bpa pad y", self.wshape, bpapadx, bpapady)
                simple_conv.gen_simple_conv(self.ishape, self.wshape, self.dilation_value,
                                    self.stride_value, self.padding_value, self.weight_dt,
                                    self.input_dt, self.output_dt, self.type, dest_path=self.test_addr,
                                    wred=self.reduction, fwd_ih_iw=(ih, iw))
                if self.type == 'bpa':
                    wcout, wcin, wh, ww = self.wshape
                    self.wshape = (wcin, wcout, wh, ww)

                csr_table = self.gen_assembly(output_folder=folder_path)

                if self.ass:
                    utils.exact_file_to_parent_folder(folder_path)
                    return folder_path
            if self.all:
                assfile = utils.get_desired_file(folder_path, '.s')
                dest_path = os.path.join(folder_path, assfile)
                test_utils.gen_dummy_cwarp(dest_path, "conv")
            if self.desc or self.all:
                if self.desc:
                    utils.exact_file_to_parent_folder(self.test_addr, input=True)
                parser_utils.make_program(folder_path)
                case_path = os.path.abspath(os.path.dirname(folder_path))
                if not csr_table:
                    csr_table = 0
                dic, path= md.make_desc_dic(case_path, 'br-', csr=csr_table, cnstLayout=1, 
                                            cmd_packet=self.cmd_packet_type, gmb=self.gmb)
                br_command_gen_interface.br_gen_descriptor(dic, target_path=path, finished=True)
                if self.desc:
                    utils.exact_file_to_parent_folder(folder_path)
                    return folder_path
            if self.cmd_packet or self.all:
                if self.cmd_packet:
                    files = os.listdir(self.test_addr)
                    for file in files:
                        if file != 'descriptors.json' and file != 'usharp_mapping.json' and \
                                 (not file.endswith(".bin")) and (not file.endswith(".s")):
                            os.remove(os.path.join(self.test_addr, file))
                    utils.exact_file_to_parent_folder(self.test_addr, input=True)
                parser_utils.make_program(folder_path)
                case_path = os.path.abspath(os.path.dirname(folder_path))
                br_command_gen_interface.br_gen_cmd_packet(case_path, self.clear, self.compare)
                utils.rm_io(self.test_addr)
            update_version_file(self.test_addr) 
            return folder_path


class br_simple_mma():
    def __init__(self, ishape, wshape, clear, compare, 
                    weight_dt='bf16', input_dt='bf16', output_dt='bf16',
                    dest_path=None, ass=False, desc=False, 
                    cmd_packet=False, all=False, get_input=False, unroll_disable=False):
        self.ishape = ishape
        self.wshape = wshape
        self.weight_dt = weight_dt
        self.input_dt = input_dt
        self.output_dt = output_dt
        self.dest_path = dest_path
        self.ass = ass
        self.desc = desc
        self.cmd_packet = cmd_packet
        self.all = all
        self.clear = clear
        self.compare = compare
        self.unroll_disable = unroll_disable

    def gen_assembly(self, output_folder=None):
        dt = (self.weight_dt, self.input_dt, self.output_dt)
        if output_folder:
            bdp.set_output_file("kernel.s", output_folder)
        else:
            bdp.set_output_file("kernel.s")

        matb_h_unit, matb_w_unit = mma.find_best_buffer_b_load_size(
            self.ishape)
        mata_h_unit = mma.find_best_buffer_a_load_size(self.wshape)
        mata_w_unit = matb_h_unit

        mata_h_iter, mata_w_iter = mma.calculate_load_iterations(
            self.wshape, mata_h_unit, mata_w_unit)
        matb_h_iter, matb_w_iter = mma.calculate_load_iterations(
            self.ishape, matb_h_unit, matb_w_unit)

        if (mata_w_iter != matb_h_iter or mata_w_unit != matb_h_unit):
            print("Error: The column size of matrix a does not match with "
                  "the row size of matrix b")
            exit()
        else:
            common_iter = mata_w_iter
            common_unit = mata_w_unit

        loop_config_ldmma0 = [
            # name,   iterations, unrolls, incremental unit
            ("bufa_mma_sync", 1, 1, 1,
                {"wset": [48], "sset": [32]}),
            ("row_a", mata_h_iter, 1, mata_h_unit),
            ("common", common_iter, common_iter, common_unit)]

        loop_config_ldmma1 = [
            # name,   iterations, unrolls, incremental unit
            ("col_b", matb_w_iter, 1, matb_w_unit),
            ("common", common_iter, common_iter, common_unit)]

        loop_config_mma = [
            #   name,   iterations, unrolls, incremental unit
            # name,   iterations, unrolls, incremental unit
            ("bufa_mma_sync", 1, 1, 1, {"wset": [32], "sset": [48]}),
            ("row_a", mata_h_iter, 1, mata_h_unit),
            ("col_b", matb_w_iter, 1, matb_w_unit),
            ("common", common_iter, common_iter, common_unit)]

        loop_configs = [loop_config_ldmma0, loop_config_ldmma1,
                        loop_config_mma]

        usharps0 = {
            "tensor_a": {"usharp": 0},
            "tensor_b": {"usharp": 1},
            "tensor_o": {"usharp": 2}}

        cst.set_code_style(0)
        print(self.wshape, self.ishape)
        mma0 = bcgi.br_mma(self.wshape, self.ishape, dt, usharps=usharps0,
                           loop_configs=loop_configs, unroll_disable=self.unroll_disable)
        wsr_num = mma0.get_required_wsr()
        csr_table = bcgi.br_get_csr_table()
        mma0.generate()
        mma0.flush()
        return csr_table

    def execute_task(self):
        print("Start making MMA golden!")
        if os.path.exists(self.dest_path):
            shutil.rmtree(self.dest_path)
        csr_table = None
        folder_path = os.path.join(self.dest_path, 'input')
        if self.ass or self.all:
            br_root = utils.brgen_root
            simple_mma.gen_simple_mma(input_shape=self.ishape, weight_shape=self.wshape,
                weight_dt=self.weight_dt, input_dt=self.input_dt, output_dt=self.output_dt,
                target_addr=self.dest_path)

            csr_table = self.gen_assembly(folder_path)
            if self.ass:
                utils.exact_file_to_parent_folder(folder_path)
                return folder_path

        if self.all:
            assfile = utils.get_desired_file(folder_path, '.s')
            dest_path = os.path.join(folder_path, assfile)
            test_utils.gen_dummy_cwarp(dest_path, "mma")
        if self.desc or self.all:
            if self.desc:
                utils.exact_file_to_parent_folder(self.dest_path, input=True)
            parser_utils.make_program(folder_path)
            case_path = os.path.abspath(os.path.dirname(folder_path))
            if not csr_table:
                csr_table = 0
            dic,path = md.make_desc_dic(case_path, 'br-', csr=csr_table)
            br_command_gen_interface.br_gen_descriptor(dic, 
                                    target_path=path, finished=True)
            if self.desc:
                utils.exact_file_to_parent_folder(folder_path)
                return folder_path
        if self.cmd_packet or self.all:
            if self.cmd_packet:
                files = os.listdir(self.dest_path)
                for file in files:
                    if (file != 'descriptors.json' and 
                        file != 'usharp_mapping.json' and
                        (not file.endswith(".bin")) and 
                        (not file.endswith(".s"))):
                        os.remove(os.path.join(self.dest_path, file))
                utils.exact_file_to_parent_folder(self.dest_path, input=True)
            parser_utils.make_program(folder_path)
            case_path = os.path.abspath(os.path.dirname(folder_path))
            br_command_gen_interface.br_gen_cmd_packet(case_path, 
                                            self.clear, self.compare)
            utils.rm_io(self.dest_path)
        update_version_file(self.dest_path)
        return folder_path


class br_simple_bn():
    def __init__(
            self, ishape, wshape, 
            bshape, dest_path,
            clear, compare,
            vgpr_range=[156, 256],
            idt="bf16", wdt="fp32",
            odt="bf16", 
            withrelu=False,
            force_ackgmb=True, 
            is_ut=True,
            loop_config=None,
            tensor_pattern="fixed"):
        self.ishape = ishape
        self.wshape = wshape
        self.bshape = bshape
        self.idt = idt
        self.wdt = wdt
        self.odt = odt
        self.dest_path = dest_path
        self.vgpr_range = vgpr_range
        self.withrelu = withrelu
        self.force_ackgmb = force_ackgmb
        self.is_ut = is_ut
        self.tensor_pattern = tensor_pattern
        self.clear = clear
        self.compare = compare
        self.loop_config = loop_config

    def gen_assembly(self, dst_path):
        assert dst_path is not None, "Input is None!"
        bdp.set_output_file("kernel.s", dst_path)
        cst.set_code_style(0)

        bn0 = bcgi.br_fwd_bn(
            warpid=0, 
            vgpr_start=self.vgpr_range[0], 
            vgpr_end=self.vgpr_range[1],
            usharp_0=[0, self.ishape],
            usharp_1=[1, self.wshape],
            usharp_2=[2, self.ishape],
            usharp_3=[3, self.ishape],
            options=[0], layerid=0, layernum=1,
            withrelu=self.withrelu,
            loop_config=self.loop_config,
            force_ackgmb=self.force_ackgmb)

        bn0.generate()
        bn0.flush()
        if self.is_ut:
            outputfile = os.path.join(dst_path, "kernel.s")
            test_utils.gen_dummy_cwarp(outputfile)

    def execute_task(self, do_assembly=False, do_all=False):
        if self.withrelu:
            iact = simple_bnrelu.construct_fake_tensor_batch(self.ishape, self.tensor_pattern)
            folder_path = simple_bnrelu.gen_simple_bn2relu(iact, self.wshape, self.bshape, dest_path=self.dest_path)
        else:
            iact = simple_bn.construct_fake_tensor_batch(self.ishape, self.tensor_pattern)
            folder_path = simple_bn.gen_simple_bn2d(iact, self.wshape, self.bshape, dest_path=self.dest_path)
        if do_assembly or do_all:
            self.gen_assembly(folder_path)
            if do_assembly:
                utils.exact_file_to_parent_folder(folder_path)
                return folder_path

        if do_all:
            assfile = utils.get_desired_file(folder_path, '.s')
            dest_path = os.path.join(folder_path, assfile)

        parser_utils.make_program(folder_path)
        case_path = os.path.abspath(os.path.dirname(folder_path))
        dic,path=md.make_desc_dic(case_path, 'br-')
        br_command_gen_interface.br_gen_descriptor(dic, target_path=path, finished=True)    
        br_command_gen_interface.br_gen_cmd_packet(case_path, self.clear, self.compare)
        utils.rm_io(self.dest_path)
        update_version_file(self.dest_path)
        return folder_path


def execute_task(desc, name=None, asmfile=None):
    if name is None:
        abs_path = os.path.join(cwd, "vector")
        if not os.path.exists(abs_path):
            ioh.biren_mkdir(abs_path)

        case_path = os.path.join(abs_path, 'test')
        br_command_gen_interface.br_gen_descriptor(desc)
        if asmfile:
            asm_path = os.path.join(case_path, 'input', asmfile)
        else:
            asm_path = os.path.join(case_path, 'input')
        parser_utils.make_program(asm_path)
        br_command_gen_interface.br_gen_cmd_packet(case_path)
    else:
        if not os.path.exists(name):
            ioh.biren_mkdir(name)
        if not os.path.isabs(name):
            name = os.path.join(cwd, name)
        case_path = name #os.path.abspath(os.path.dirname(name))
        br_command_gen_interface.br_gen_descriptor(desc)
        br_command_gen_interface.br_gen_descriptor(desc)
        br_command_gen_interface.br_gen_descriptor(desc)
        if asmfile:
            asm_path = os.path.join(case_path, 'input', asmfile)
        else:
            asm_path = os.path.join(case_path, 'input')
        parser_utils.make_program(asm_path)
        br_command_gen_interface.br_gen_cmd_packet(os.path.join(cwd, case_path))



class br_simple_maxpooling():
    def __init__(
            self, ishape, khw, 
            stride, padding, dest_path,
            clear, compare,
            vgpr_range=[156, 256],
            dilation=1,
            idt="bf16", wdt="fp32",
            odt="bf16", 
            bn_before=False,
            withrelu=False,
            force_ackgmb=True, 
            is_ut=True,
            tensor_pattern="fixed"):
        self.ishape = ishape
        self.khw = khw
        self.stride = stride
        self.padding = padding
        self.idt = idt
        self.wdt = wdt
        self.odt = odt
        self.dilation = dilation
        self.dest_path = dest_path
        self.vgpr_range = vgpr_range
        self.withrelu = withrelu
        self.bn_before = bn_before
        self.force_ackgmb = force_ackgmb
        self.is_ut = is_ut
        self.tensor_pattern = tensor_pattern
        self.clear = clear
        self.compare = compare


    def gen_assembly(self, dst_path):
        assert dst_path is not None, "Input is None!"
        print("output_folder is (assembly)", dst_path)
        bdp.set_output_file("kernel.s", dst_path)
        cst.set_code_style(0)

        oshape = self.ishape
        if self.stride == 2:
            oshape = (self.ishape[0], self.ishape[1], int(self.ishape[2]/2), int(self.ishape[3]/2))
        maxpooling0 = bcgi.br_fwd_maxpooling(
            warpid=0, 
            vgpr_start=self.vgpr_range[0], 
            vgpr_end=self.vgpr_range[1],
            usharp_0=[0, self.ishape],
            usharp_1=[1, oshape],
            options=[self.khw[0], self.khw[1], self.padding[0], 
                    self.padding[1], 
                    (1 if self.stride == 2 else 0), 
                    (1 if self.bn_before else 0),
                    (1 if self.withrelu else 0),
                    1], # mate mode is max
            layerid=0, layernum=1,
            withrelu=False,
            force_ackgmb=self.force_ackgmb)

        #print("\n[WSR] required wsr is: ", maxpooling0.get_required_wsr())
        maxpooling0.generate()
        maxpooling0.flush()
        if self.is_ut:
            outputfile = os.path.join(dst_path, "kernel.s")
            test_utils.gen_dummy_cwarp(outputfile)

    def execute_task(self, do_assembly=False, do_all=False):
        iact = simple_maxpool.construct_fake_tensor(self.ishape, self.tensor_pattern)
        folder_path = simple_maxpool.test_br_maxpool2d(
            iact, self.khw, self.stride, (self.padding[1], self.padding[0]), self.dilation, dest_path=self.dest_path)
        if do_assembly or do_all:
            self.gen_assembly(folder_path)
            if do_assembly:
                utils.exact_file_to_parent_folder(folder_path)
                return folder_path

        if do_all:
            assfile = utils.get_desired_file(folder_path, '.s')
            dest_path = os.path.join(folder_path, assfile)

        parser_utils.make_program(folder_path)
        case_path = os.path.abspath(os.path.dirname(folder_path))
        dic,path=md.make_desc_dic(case_path, 'br-')
        br_command_gen_interface.br_gen_descriptor(dic, target_path=path, finished=True)
        br_command_gen_interface.br_gen_cmd_packet(case_path, self.clear, self.compare)
        utils.rm_io(self.dest_path)
        update_version_file(self.dest_path)
        return folder_path


class br_simple_dwc():
    def __init__(
            self, ishape, khw, 
            stride, padding, dest_path,
            vgpr_range=[156, 256],
            dilation=1,
            idt="bf16", wdt="bf16",
            odt="bf16", 
            force_ackgmb=True, 
            is_ut=True,
            tensor_pattern="fixed"):
        self.ishape = ishape
        self.khw = khw
        self.stride = stride
        self.padding = padding
        self.idt = idt
        self.wdt = wdt
        self.odt = odt
        self.dilation = dilation
        self.dest_path = dest_path
        self.vgpr_range = vgpr_range
        self.force_ackgmb = force_ackgmb
        self.is_ut = is_ut
        self.tensor_pattern = tensor_pattern


    def gen_assembly(self, dst_path):
        assert dst_path is not None, "Input is None!"
        print("output_folder is (assembly)", dst_path)
        bdp.set_output_file("kernel.s", dst_path)
        cst.set_code_style(0)

        oshape = self.ishape
        if self.stride == 2:
            oshape = (self.ishape[0], self.ishape[1], int(self.ishape[2]/2), int(self.ishape[3]/2))
        dwc0 = bcgi.br_fwd_dwc(
            warpid=0, 
            vgpr_start=self.vgpr_range[0], 
            vgpr_end=self.vgpr_range[1],
            usharp_0=[0, self.ishape],
            usharp_1=[1, self.khw],
            usharp_2=[2, oshape],
            options=[self.khw[2], self.khw[3], self.padding[0], 
                    self.padding[1], 
                    (1 if self.stride == 2 else 0), 
                    0,
                    0,
                    0], # mate mode is max
            layerid=0, layernum=1,
            force_ackgmb=self.force_ackgmb,
            idtype=self.idt,
            wdtype=self.wdt,
            odtype=self.odt)

        #print("\n[WSR] required wsr is: ", maxpooling0.get_required_wsr())
        dwc0.generate()
        dwc0.flush()
        if self.is_ut:
            outputfile = os.path.join(dst_path, "kernel.s")
            test_utils.gen_dummy_cwarp(outputfile)

    def execute_task(self, do_assembly=False, do_all=False):
        # ret = gen_simple_dwc(input_shape, weight_shape, dilation_value, stride_value, padding_value)
        folder_path = simple_dwc.gen_simple_dwc(
             self.ishape, 
             self.khw, 
             self.dilation, 
             self.stride, 
             (self.padding[1], self.padding[0]), 
             self.dest_path,
             self.idt,  
             self.wdt,
             self.odt)
        if do_assembly or do_all:
            self.gen_assembly(folder_path)
            if do_assembly:
                utils.exact_file_to_parent_folder(folder_path)
                return folder_path

        if do_all:
            assfile = utils.get_desired_file(folder_path, '.s')
            dest_path = os.path.join(folder_path, assfile)

        parser_utils.make_program(folder_path)
        case_path = os.path.abspath(os.path.dirname(folder_path))
        dic,path=md.make_desc_dic(case_path, 'br-')
        br_command_gen_interface.br_gen_descriptor(dic, target_path=path, finished=True)
        br_command_gen_interface.br_gen_cmd_packet(case_path, ["U2"], ["U2"])
        utils.rm_io(self.dest_path)
        update_version_file(self.dest_path)
        return folder_path


class br_simple_add_relu():
    def __init__(
            self, ishape_0, ishape_1, ishape_2, relu_on,
            dest_path, clear, compare, vgpr_range=[156, 256],
            input_dtype="bf16", output_dtype="bf16", 
            force_ackgmb=True,
            is_ut=True, 
            tensor_pattern="fixed"):

        self.ishape_0 = ishape_0
        self.ishape_1 = ishape_1
        self.ishape_2 = ishape_2
        self.relu_on = relu_on
        self.dest_path = dest_path
        self.clear = clear
        self.compare = compare
        self.vgpr_range = vgpr_range
        self.input_dtype = input_dtype
        self.output_dtype = output_dtype
        self.force_ackgmb = force_ackgmb
        self.is_ut = is_ut
        self.tensor_pattern = tensor_pattern
    
    def gen_assembly(self, dst_path):
        assert dst_path is not None, "Input is None!"
        bdp.set_output_file("kernel.s", dst_path)
        cst.set_code_style(0)
        print(dst_path)
        bn0 = bcgi.br_fwd_add_relu(
            warpid=0, 
            vgpr_start=self.vgpr_range[0], 
            vgpr_end=self.vgpr_range[1],
            usharp_0=[0, self.ishape_0],
            usharp_1=[1, self.ishape_1],
            usharp_2=[2, self.ishape_2],
            options=[0], layer_id=0, layer_num=1,
            relu_on=self.relu_on , force_ackgmb=self.force_ackgmb)

        bn0.generate()
        bn0.flush()
        if self.is_ut:
            outputfile = os.path.join(dst_path, "kernel.s")
            test_utils.gen_dummy_cwarp(outputfile)

    def execute_task(self, do_assembly=False, do_all=False):
        if self.relu_on:
            iact = simple_addrelu.construct_fake_tensor(self.ishape_0, self.tensor_pattern)
            folder_path = simple_addrelu.gen_simple_addrelu(self.ishape_0, dest_path=self.dest_path)
        else:
            iact = simple_addrelu.construct_fake_tensor(self.ishape_0, self.tensor_pattern)
            folder_path = simple_addrelu.gen_simple_addrelu(self.ishape_0, dest_path=self.dest_path)
        if do_assembly or do_all:
            self.gen_assembly(folder_path)
            if do_assembly:
                utils.exact_file_to_parent_folder(folder_path)
                return folder_path

        if do_all:
            assfile = utils.get_desired_file(folder_path, '.s')
            dest_path = os.path.join(folder_path, assfile)

        parser_utils.make_program(folder_path)
        case_path = os.path.abspath(os.path.dirname(folder_path))
        dic,path=md.make_desc_dic(case_path, 'br-')
        br_command_gen_interface.br_gen_descriptor(dic, target_path=path, finished=True)
        #only compare relu output
        br_command_gen_interface.br_gen_cmd_packet(case_path, self.clear, self.compare)
        utils.rm_io(self.dest_path)
        update_version_file(self.dest_path)
        return folder_path

