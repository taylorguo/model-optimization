#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import os
import argparse
import shutil
import sys

from test_generator import make_golden as mg
from command_generator import utils

clear = ["U2"]
compare = ["U2"]


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        'input', default='32x32x3x3',
        help='Specify the input tenosr shape with format NxCxHxW,'
             ' for example: 1x32x8x8.')

    parser.add_argument(
        'weight', default='32x32x3x3',
        help='Specify the weight tensor shape with format OxIxKHxKW,'
             ' for example: 8x32x3x3.')

    parser.add_argument(
        '--dilation', default='1',
        help='Specify the dilation,'
             ' for example: 1.')

    parser.add_argument(
        '--stride', default='1',
        help='Specify the stride,'
             ' for example: 1.')

    parser.add_argument(
        '--padx', default='0',
        help='Specify the padx,'
             ' for example: 1.')

    parser.add_argument(
        '--pady', default='0',
        help='Specify the pady,'
             ' for example: 1.')

    parser.add_argument(
        '--weight_data_type', '-wdt', default='bf16',
        choices=utils.data_types,
        help='Specify the weight data type, for example: bf16.')

    parser.add_argument(
        '--input_data_type', '-idt', default='bf16',
        choices=utils.data_types,
        help='Specify the input data type, for example: bf16.')

    parser.add_argument(
        '--output_data_type', '-odt', default='bf16',
        choices=utils.data_types,
        help='Specify the output data type, for example: bf16.')

    parser.add_argument(
        '--type', '-t', default="fwd", choices=["fwd", "bpa", "bpw"],
        help='Specify the operator type currently,'
             ' only support fwd, bpa, bpw')

    parser.add_argument(
        '--style', default=0,
        help='Specify the style, for example: 0.')

    parser.add_argument(
        '--debug', default=0,
        help='Specify the debug, for example: 0.')

    parser.add_argument(
        '--ass', default=False,
        help='Specify whether getting assembly code only')

    parser.add_argument(
        '--index', default=0,
        help='only for bpw')

    parser.add_argument(
        '--address', default=os.path.join(os.path.dirname(__file__), "vector"),
        help='address under tests/code_gen/golden')

    parser.add_argument(
        '--packet', default="Submit_JD",
        help='designate a command packet, the default value is Submit_JD')

    parser.add_argument(
        '--reduction', default=0,
        help='reduction')

    parser.add_argument(
        '--gmb', default=0,
        help='L1.5 wapping')

    parser.add_argument(
        '--clear', default=clear,
        help='Clear the data')

    parser.add_argument(
        '--compare', default=compare,
        help='Compare the output with cmodel result')

    parser.add_argument(
        '--timeout', default=None,
        help='Specify the timeout when running cmodel,'
            ' for example: --timeout=10')

    parser.add_argument(
        '--hwshape', default='2x32x56x28',
        help='Specify the hwshape type,'
            ' for example: --hwshap=2x32x56x28')

    parser.add_argument(
        '--unroll_disable', default=False,
        help='Specify the unroll_disable type,'
            ' for example: --unroll_disable=True')

    parser.add_argument(
        '--replace_kernel', default=False,
        help='Specify replace kernel for opt pass type,'
            ' for example: --unroll_disable=True')

    parser.add_argument(
        '--backend', default=False,
        help='Specify replace kernel for enable opt pass,'
            ' for example: --backend=True')

    return parser.parse_args()


def main():
    args = get_args()
    input_shape = [int(e) for e in args.input.split("x")]
    weight_shape = [int(e) for e in args.weight.split("x")]
    hw_shape = [int(e) for e in args.hwshape.split("x")]
    ishape = tuple(input_shape)
    wshape = tuple(weight_shape)
    hwshape = tuple(hw_shape)
    dilation_value = 1 if args.dilation is None else int(args.dilation)
    stride_value = 1 if args.stride is None else int(args.stride)
    padx_value = 0 if args.padx is None else int(args.padx)
    pady_value = 0 if args.pady is None else int(args.pady)
    padding_value = (padx_value, pady_value)
    type = 'fwd' if args.type is None else args.type
    weight_dt = args.weight_data_type
    input_dt = args.input_data_type
    output_dt = args.output_data_type
    bpw_index = None if args.index is None else int(args.index)
    test_addr = None if args.address is None else args.address
    reduction = args.reduction
    cmd_packet = args.packet
    gmb = args.gmb
    clear = args.clear
    compare = args.compare
    urdis = args.unroll_disable
    replace = args.replace_kernel
    backend = args.backend

    if not isinstance(clear, list):
        clear = utils.string_to_list(clear)
    if not isinstance(compare, list):
        compare = utils.string_to_list(compare)

    msc = mg.br_simple_conv(ishape, wshape, dilation_value,
                         stride_value, padding_value, type, clear, compare,
                         cmd_packet_type=cmd_packet, 
                         weight_dt=weight_dt, input_dt=input_dt, output_dt=output_dt,
                         bpw_index=bpw_index, test_addr=test_addr, all=True, reduction=reduction,
                         gmb=gmb, hwshape=hwshape, unroll_disable=urdis, replace_kernel=replace, backend=backend)

    msc.execute_task()


if __name__ == '__main__':
    main()
