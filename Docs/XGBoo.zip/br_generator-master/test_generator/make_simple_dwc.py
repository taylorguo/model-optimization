#! /usr/bin/python3
# coding:utf-8

# Time      : 2020/12/30
# Author    : e00295
# File      : make_simple_dwc.py
# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import argparse
import os
import shutil
import sys

from  tests.code_gen import br_test_base

def get_args():
    parser = argparse.ArgumentParser(description='Generate simple dwc case')
    parser.add_argument(
        'input', default='2x8x8x8',
        help='Specify the input tenosr shape with format NxCxHxW'
    )
    parser.add_argument(
        'weight', default='8x1x3x3',
        help='Specify the weight tensor shape with format OxIxKHxKW,'
    )
    parser.add_argument(
        '--padx', default='0',
        help='Specify the padx,'
             ' for example: 1.'
    )
    parser.add_argument(
        '--pady', default='0',
        help='Specify the pady,'
             ' for example: 1.'
    )
    parser.add_argument(
        '--stride', default='1',
        help='Specify the stride,'
             ' for example: 1.'
    )
    parser.add_argument(
        '--dilation', default='1',
        help='Specify the dilation,'
             ' for example: 1.'
    )
    
    parser.add_argument(
        '--idtype', default='bf16',
        help='Specify the idtype,'
             ' for example: bf16.'
    )
    parser.add_argument(
        '--wdtype', default='bf16',
        help='Specify the wdtype,'
             ' for example: bf16.'
    )
    parser.add_argument(
        '--odtype', default='bf16',
        help='Specify the odtype,'
             ' for example: bf16.'
    )
    return parser.parse_args()


def main():
    args = get_args()
    case_name = "fwd_dwc_in_" + args.input + "_khw_" + args.weight + "_px" + args.padx + "_py" + args.pady + "_s" + args.stride
    input_shape = [int(e) for e in args.input.split("x")]
    weight_shape = [int(e) for e in args.weight.split("x")]
    ishape = tuple(input_shape)
    wshape = tuple(weight_shape)
    dilation_value = 1 if args.dilation is None else int(args.dilation)
    stride_value = 1 if args.stride is None else int(args.stride)
    padx_value = 0 if args.padx is None else int(args.padx)
    pady_value = 0 if args.pady is None else int(args.pady)
    padding_value = (padx_value, pady_value)

    idtype = "bf16" if args.idtype is None else args.idtype
    wdtype = "bf16" if args.wdtype is None else args.wdtype
    odtype = "bf16" if args.odtype is None else args.odtype
    runCfg = {
            "case_name": case_name,
            "ishape": ishape,
            "khw": wshape,
            "padding": padding_value,
            "stride": stride_value,
            "dilation":dilation_value,
            "idtype":idtype,
            "wdtype":wdtype,
            "odtype":odtype
        }
    print(runCfg)
    gen_simple_dwc = br_test_base.test_base()
    gen_simple_dwc.gen_dwc(runCfg)


if __name__ == '__main__':
    main()