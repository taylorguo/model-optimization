import os
import shutil
import sys
from command_generator import io_handler as ioh
from command_generator import utils
from parser import parser_utils


sample_desc_name = 'descriptors_for_gen_kernel.json'
dest_path = r'/opt/vector_backup/rtg/'


def get_kernel_name(working_folder):
    filenames = os.listdir(working_folder)
    dic = {}
    kernel_name = ''
    for file in filenames:
        file_name = file.split('.')[0]
        file_suffix = file.split('.')[1]
        if file_name not in dic.keys():
            dic[file_name] = 1
        else:
            value = dic[file_name] + 1
            dic[file_name] = value
            return file_name


def get_instcnt(working_folder):
    kernel_name = get_kernel_name(working_folder)
    json_name = kernel_name + '.json'
    dic = ioh.load_json_to_dict(working_folder, '', json_name)
    kernel_arr = dic['Kernels']
    output_arr = []

    for sub_dic in kernel_arr:
        output_arr.append(sub_dic['InstrSizeInByte'])
    print("output cnt is ", output_arr)
    return output_arr


def modify_desc(desc_path):
    working_folder = os.path.abspath(os.path.dirname(desc_path))
    input_file = desc_path.split(os.sep)[-1]
    json_arr = ioh.load_json_to_dict(working_folder, '', input_file)

    for dic in json_arr:
        size = 0
        size_arr = get_instcnt(working_folder)
        if len(size_arr) == 1:
            size = size_arr[0] // 512
            size += 1
        else:
            print("Error: there are more than 1 instCnt!!!!!")
        sub_dic = dic['Cud']
        sub_dic['instCnt'] = size
        sub_dic['kernel_name'] = get_kernel_name(working_folder)
        sub_dic['pc'] = sub_dic['kernel_name'] + '.bin'
    ioh.generate_json_file(json_arr, input_file, working_folder)
    print("modified descriptors.json")


def reset_name(num):
    if len(num) == 1:
        new_num = '00' + num
    elif len(num) == 2:
        new_num = '0' + num
    else:
        new_num = num
    return new_num


def move_cases(path, target_path=None):
    if target_path is None:
        target_path = dest_path

    g = os.walk(path)
    for root, dirs, filenames in g:
        root_name = root.split(os.sep)[-1]
        parent_folder = os.path.abspath(os.path.dirname(root))
        temp_root = os.path.abspath(os.path.dirname(parent_folder))
        case_name = root.split(os.sep)[-2].split('_')

        if root_name == 'vector':
            print("case name is ", case_name)
            if len(case_name) ==3:
                type_0 = case_name[0] 
                type_1 = case_name[1]
                type_2 = case_name[2]
            elif len(case_name) == 2:
                type_0 = 'simt'
                type_1 = case_name[0] 
                type_2 = case_name[1] 
            elif len(case_name) == 1:
                type_0 = 'simt'
                type_1 = 'lsa'
                type_2 = case_name[0]
            dest_folder = os.path.join(target_path, type_0, type_1, type_2)
            if os.path.exists(dest_folder):
                shutil.rmtree(dest_folder)
            ioh.biren_mkdir(dest_folder)
            for name in filenames:
                source_file = os.path.join(root, name)
                dest_file = os.path.join(target_path, type_0, type_1, type_2, name)
                shutil.copyfile(source_file, dest_file)
                # os.remove(source_file)\
            shutil.rmtree(parent_folder)
        if not os.listdir(temp_root):
            shutil.rmtree(temp_root)


def find_case(path):
    g = os.walk(path)
    for root, dirs, filenames in g:
        root_name = root.split(os.sep)[-1]
        if root_name == 'input':
            asm = utils.get_desired_file(root, '.s')
            parser_utils.make_program(os.path.join(root, asm))
            desc_path = os.path.join(root, 'descriptors.json')
            br_gen_path = utils.brgen_root
            sample_desc_path = os.path.join(br_gen_path, 'command_generator', sample_desc_name)
            shutil.copyfile(sample_desc_path, desc_path)
            modify_desc(desc_path)


def execute_task(path):
    if len(sys.argv) == 1:
        print("Error: need a parameter")
    elif len(sys.argv) == 2:
        if sys.argv[1] == '-c':
            utils.make_struct(path)
        elif sys.argv[1] == '-m':
            move_cases(path)
        elif sys.argv[1] == '-g':
            find_case(path)
        else:
            print('Error parameter')
    elif  len(sys.argv) == 3:
        dest_path = sys.argv[2]
        if not os.path.exists(dest_path):
            ioh.biren_mkdir(dest_path)

        if sys.argv[1] == '-c':
            utils.make_struct(path)
        elif sys.argv[1] == '-m':
            move_cases(path, dest_path)
        else:
            print('Error parameter')


def main():
    path = os.getcwd()
    print("working path is ", path)
    execute_task(path)


if __name__ == '__main__':
    main()
