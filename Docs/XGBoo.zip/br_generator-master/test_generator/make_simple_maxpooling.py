#! /usr/bin/python3
# coding:utf-8

# Time      : 2020/12/30
# Author    : e00295
# File      : make_simple_maxpooling.py
# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import argparse
import os
import shutil
import sys

from  tests.code_gen import br_test_base

def get_args():
    parser = argparse.ArgumentParser(description='Generate simple dwc case')
    parser.add_argument(
        'input', default='1x32x4x8',
        help='Specify the input tenosr shape with format NxCxHxW'
    )
    parser.add_argument(
        'weight', default='3x3',
        help='Specify the weight tensor shape with format KHxKW,'
    )
    parser.add_argument(
        '--padx', default='0',
        help='Specify the padx,'
             ' for example: 1.'
    )
    parser.add_argument(
        '--pady', default='0',
        help='Specify the pady,'
             ' for example: 1.'
    )
    parser.add_argument(
        '--stride', default='1',
        help='Specify the stride,'
             ' for example: 1.'
    )
    parser.add_argument(
        '--dilation', default='1',
        help='Specify the dilation,'
             ' for example: 1.'
    )
    return parser.parse_args()


def main():
    args = get_args()
    case_name = "fwd_maxpooling_in_" + args.input + "_khw_" + args.weight + "_px" + args.padx + "_py" + args.pady + "_s" + args.stride
    input_shape = [int(e) for e in args.input.split("x")]
    weight_shape = [int(e) for e in args.weight.split("x")]
    ishape = tuple(input_shape)
    wshape = tuple(weight_shape)
    dilation_value = 1 if args.dilation is None else int(args.dilation)
    stride_value = 1 if args.stride is None else int(args.stride)
    padx_value = 0 if args.padx is None else int(args.padx)
    pady_value = 0 if args.pady is None else int(args.pady)
    padding_value = (padx_value, pady_value)
    runCfg = {
            "case_name": case_name,
            "ishape": ishape,
            "khw": wshape,
            "padding": padding_value,
            "stride": stride_value,
            "dilation":dilation_value
        }
    print(runCfg)
    gen_simple_maxpooling = br_test_base.test_base()
    gen_simple_maxpooling.gen_maxpooling(runCfg)


if __name__ == '__main__':
    main()