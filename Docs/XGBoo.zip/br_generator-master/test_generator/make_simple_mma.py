import os, argparse, shutil, sys
from test_generator import make_golden as mg
from command_generator import utils


def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        'input', default='32x32x3x3',
        help='Specify the input tenosr shape with format NxCxHxW,'
             ' for example: 1x32x8x8.')

    parser.add_argument(
        'weight', default='32x32x3x3',
        help='Specify the weight tensor shape with format OxIxKHxKW,'
             ' for example: 8x32x3x3.')
    parser.add_argument(
        '--address', default=os.path.join(os.path.dirname(__file__), "vector"),
        help='address under current working directory')
    
    parser.add_argument(
        '--weight_data_type', '-wdt', default='bf16',
        choices=utils.data_types,
        help='Specify the weight data type, for example: bf16.')

    parser.add_argument(
        '--input_data_type', '-idt', default='bf16',
        choices=utils.data_types,
        help='Specify the input data type, for example: bf16.')

    parser.add_argument(
        '--output_data_type', '-odt', default='bf16',
        choices=utils.data_types,
        help='Specify the output data type, for example: bf16.')

    parser.add_argument(
        '--clear', default=["U2"],
        help='Clear the data')

    parser.add_argument(
        '--compare', default=["U2"],
        help='Compare the output with cmodel result')

    parser.add_argument(    
        '--timeout', default=None,
        help='Specify the timeout when running cmodel,'
            ' for example: --timeout=10')
    return parser.parse_args()


def main():
    args = get_args()
    input_shape = [int(e) for e in args.input.split("x")]
    weight_shape = [int(e) for e in args.weight.split("x")]
    ishape = tuple(input_shape)
    wshape = tuple(weight_shape)
    weight_dt = args.weight_data_type
    input_dt = args.input_data_type
    output_dt = args.output_data_type
    address = args.address
    clear = args.clear
    compare = args.compare
    if not isinstance(clear, list):
        clear = utils.string_to_list(clear)
    if not isinstance(compare, list):
        compare = utils.string_to_list(compare)

    msm = mg.br_simple_mma(ishape, wshape, clear, compare,
                            weight_dt=weight_dt, input_dt=input_dt, output_dt=output_dt, 
                            dest_path=address, all=True)
    msm.execute_task()


if __name__ == '__main__':
    main()