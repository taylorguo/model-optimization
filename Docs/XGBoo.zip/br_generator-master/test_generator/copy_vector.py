import os
import re
import shutil
import simplify_folder_name as sim
import copy_vector_win as copywin
import refresh_readme as rr
import sys
from command_generator import utils


ip = "10.10.16.34"
port = 22
source_path = os.getcwd()
dest_path = '/home/s00002/vector/unit'
local_path = r'D:\download_test'


def check_if_empty(path):
    if not os.listdir(path):
        # empty
        return True
    return False


def get_exist_index(readme_path):
    if not os.path.exists(readme_path):
        open(readme_path, 'w')

    bpa_not_index = []
    bpw_not_index = []
    fwd_not_index = []
    with open(readme_path, 'r') as file:
        find_lines = file.readlines()
        for line in find_lines:
            if line and line != '\n':
                kv_pair = line.split(':')
                # dic_old_names.update({kv_pair[1].strip(): kv_pair[0].strip()})
                index = int(re.findall(r'\d+\.?\d*', kv_pair[0])[0])

                if re.search('bpa', kv_pair[0]):
                    if index not in bpa_not_index:
                        bpa_not_index.append(index)
                elif re.search('bpw', kv_pair[0]):
                    if index not in bpw_not_index:
                        bpw_not_index.append(index)
                elif re.search('fwd', kv_pair[0]):
                    if index not in fwd_not_index:
                        fwd_not_index.append(index)

    return bpa_not_index, bpw_not_index, fwd_not_index


def copy_to_br100(source_path, dest_path):
    file_names = os.listdir(source_path)
    for file_name in file_names:
        source_folder_path = os.path.join(source_path, file_name)
        dest_folder_path = os.path.join(dest_path, file_name)
        if os.path.exists(dest_folder_path):
            os.remove(dest_folder_path)

        shutil.copyfile(source_folder_path, dest_folder_path)


def syn_local(dest_path, source_path):
    # local
    released_unit = source_path
    # utils.clear_all_files(released_unit)
    dic = {}
    folders = os.listdir(dest_path)
    for file in folders:
        file_path = os.path.join(dest_path, file)
        if os.path.isfile(file_path):       # readme.txt
            shutil.copyfile(file_path, os.path.join(released_unit, file))
            dic = rr.txt_to_dic_with_params(file_path)

    local_test_folders = os.listdir(released_unit)
    for file in local_test_folders:
        file_path = os.path.join(released_unit, file)
        if os.path.isdir(file_path):
            if file in dic.keys():
                old_folder_name = file_path
                new_folder_name = os.path.join(released_unit, dic[file])
                os.rename(old_folder_name, new_folder_name)


def update(source_path):
    test_paths = utils.get_test_name(source_path)
    if ip == copywin.get_host_ip():
        for test_path in test_paths:
            update_server(test_path)
    else:
        username = input("User ID: ")
        password = input("Password: ")
        for test_path in test_paths:
            copywin.update_win(test_path, username, password)


def update_server(test_path):
    ori_name = test_path.split(os.sep)[-1]
    sim_name = utils.check_test_exist(dest_path, ori_name)
    if sim_name:
        print("%s has already existed, the old case will be overwritten." % ori_name)
        new_path = os.path.join(dest_path, sim_name)
        utils.clear_all_files(new_path, 'readme.txt')
        source_file_path = os.path.join(test_path, 'vector')
        copy_to_br100(source_file_path, new_path)

    else:
        print("A new case, %s, is added." % ori_name)
        readme_path = os.path.join(dest_path, 'readme.txt')
        bpa_not_index, bpw_not_index, fwd_not_index = get_exist_index(readme_path)
        sim_name = sim.convert_to_new_name(ori_name, bpa_not_index, bpw_not_index, fwd_not_index)
        new_path = os.path.join(dest_path, sim_name)
        os.mkdir(new_path)
        rr.make_sub_readme(test_path, new_path)
        rr.append_readme(new_path, readme_path)
        source_file_path = os.path.join(test_path, 'vector')
        copy_to_br100(source_file_path, new_path)

    parent_folder = os.path.abspath(os.path.dirname(test_path))
    old_name_path = os.path.join(test_path)
    new_name_path = os.path.join(parent_folder, sim_name)
    os.rename(old_name_path, new_name_path)
    readme_path = os.path.join(dest_path, 'readme.txt')
    replaced_readme = os.path.join(parent_folder, 'readme.txt')
    shutil.copyfile(readme_path, replaced_readme)


def update_win(test_path, username, password):
    copywin.change_mode(local_path)
    if not check_if_empty(local_path):
        utils.clear_all_files(local_path)

    ori_name = test_path.split(os.sep)[-1]
    remote_readme_path = dest_path + '/readme.txt'
    local_readme_path = os.path.join(local_path, 'readme.txt')
    copywin.download(remote_readme_path, local_readme_path, username, password)
    if not check_if_empty(local_path):
        sim_name = utils.check_test_exist(local_path, ori_name)
        if sim_name:
            print("%s has already existed, the old case will be overwritten." % ori_name)
            remote_case_path = dest_path + '/' + sim_name
            local_case_path = os.path.join(local_path, sim_name)
            copywin.download(remote_case_path, local_case_path, username, password)
            new_path = os.path.join(dest_path, sim_name)
            local_case_path = os.path.join(local_path, sim_name)
            utils.clear_all_files(local_case_path, 'readme.txt')
            source_file_path = os.path.join(test_path, 'vector')
            copy_to_br100(source_file_path, local_case_path)

    else:
        print("A new case, %s, is added." % ori_name)
        bpa_not_index, bpw_not_index, fwd_not_index = get_exist_index(local_readme_path)
        sim_name = sim.convert_to_new_name(ori_name, bpa_not_index, bpw_not_index, fwd_not_index)
        new_path = dest_path + '/' + sim_name
        rr.make_sub_readme(test_path, new_path, local=True)
        rr.append_readme(test_path, local_readme_path)
        copywin.upload(os.path.join(test_path, 'readme.txt'), new_path, username, password)
        copywin.upload(local_readme_path, dest_path, username, password)
        copywin.upload(os.path.join(test_path, 'vector'), new_path, username, password)


def execute_task(input_folder, all_tests=False):
    if all_tests:
        update(input_folder)
    else:
        tests_name = os.listdir(input_folder)
        for name in tests_name:
            test_path = os.path.join(input_folder, name)
            update(test_path)
    local = check_whether_to_syn(input_folder)


def check_whether_to_syn(folder_path):
    folders = os.listdir(folder_path)
    for folder_name in folders:
        if folder_name == 'input' or folder_name == 'output' or folder_name == 'vector':
            return os.path.abspath(os.path.dirname(folder_path))
    return folder_path


def main():
    argument_count = len(sys.argv) - 1
    if argument_count == 0:
        print("no specified arguments")
        #print(source_path)
        choose = input("Are you sure to update ALL tests in current folder? (Y or N)")
        choose = choose.upper()
        #print("your input is ", choose)
        if choose == 'Y' or choose == 'YES':
            print("start copy tests......")
            update(source_path)
        else:
            exit(-1)

    elif argument_count == 1:
        if sys.argv[1] == '-h' or sys.argv[1] == '--help':
            print("help")
        else:
            if sys.argv[1][-1] == os.sep:
                cut_test_name = sys.argv[1][:-1]

            if os.path.isdir(cut_test_name):
                folder_path = cut_test_name
            else:
                folder_path = os.path.join(source_path, cut_test_name)

            if not os.path.exists(folder_path):
                print("Error: the test doesn't exist! Please check your input.")
                exit(-1)

            test_name = folder_path.split(os.sep)[-1]
            temp = input('Are you sure to update %s? (Y or N)' % test_name)
            temp = temp.upper()
            #print("your input is ", temp)
            if temp == 'Y' or temp == 'YES':
                update(folder_path)
            else:
                exit(-1)

    else:
        all_flag = False
        tests = []
        for i in range(1, len(sys.argv)):
            tests.append(sys.argv[i])

        #print("argument list: ", tests)
        # print(len(sys.argv))
        for i in range(1, len(sys.argv)):
            if os.path.isdir(sys.argv[i]):
                folder_path = sys.argv[i]
            else:
                folder_path = os.path.join(source_path, sys.argv[i])
            #print(folder_path)
            if not os.path.isdir(folder_path):
                print("Error: the test doesn't exist! Please check your input.")
                #print(folder_path)
                exit(-1)
            if not all_flag:
                test_name = folder_path.split(os.sep)[-1]
                temp = input('Are you sure to update %s? (Y or N or ALL)' % test_name)
                temp = temp.upper()
                #print("your input is ", temp)
                if temp == 'Y' or temp == 'YES':
                    update(folder_path)
                elif temp == 'A' or temp == 'ALL':
                    all_flag = True
                    update(folder_path)
                else:
                    exit(-1)
            else:
                index = i
                for ii in range(index, len(sys.argv)):
                    folder_path = os.path.join(source_path, sys.argv[ii])
                    update(folder_path)


if __name__ == '__main__':
    main()
