#! /usr/bin/python3
# coding:utf-8

# Time      : 2020/12/30
# Author    : e00295
# File      : make_simple_bn.py
# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import argparse
import os
import shutil
import sys

from  tests.code_gen import br_test_base

def get_args():
    parser = argparse.ArgumentParser(description='Generate simple dwc case')
    parser.add_argument(
        'ishape', default='1x32x4x8',
        help='Specify the ishape with format NxCxHxW'
    )
    parser.add_argument(
        'wshape', default='32x4x1x1',
        help='Specify the w&bshape with format OxIxKHxKW'
    )
    parser.add_argument(
        '--relu_on', default='False',
        help='Specify the relu_on,'
             ' for example: False.'
    )
    parser.add_argument(
        '--force_ackgmb', default='True',
        help='Specify the force_ackgmb,'
             ' for example: True.'
    )
    return parser.parse_args()


def main():
    args = get_args()
    case_name = "fwd_bn_in_" + args.ishape + "_cache_w_" + args.wshape
    input_shape = [int(e) for e in args.ishape.split("x")]
    weight_shape = [int(e) for e in args.wshape.split("x")]
    ishape = tuple(input_shape)
    wshape = tuple(weight_shape)
    bshape = wshape
    relu_on = False if args.relu_on is None else args.relu_on
    force_ackgmb = True if args.force_ackgmb is None else args.force_ackgmb
    runCfg = {
            "case_name": case_name,
            "ishape": ishape,
            "wshape": wshape,
            "bshape": bshape,
            "relu_on": relu_on,
            "force_ackgmb":force_ackgmb
        }
    print(runCfg)
    gen_simple_bn = br_test_base.test_base()
    gen_simple_bn.gen_bn(runCfg)


if __name__ == '__main__':
    main()