#!/bin/bash
echo $BASH_SOURCE
if [ $# == 0 ]
  then
  echo "Doing make_descriptors.py"
  python3 $(dirname $BASH_SOURCE)/command_generator/make_descriptors.py
  echo "Doing make_vectors.py"
  python3 $(dirname $BASH_SOURCE)/command_generator/make_vectors.py
elif [ $# == 1 ] 
  then
  if [ "$1" == "-d" ]
    then
    echo "Doing make_vectors.py"
    python3 $(dirname $BASH_SOURCE)/command_generator/make_vectors.py 
  else
    echo "Wrong argument! Please check your input"
    echo "  -d:   will not regenerate descriptors"
  fi
fi
