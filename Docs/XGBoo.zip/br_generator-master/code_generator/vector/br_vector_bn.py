#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import math, copy
from code_generator.vector.br_vector_standalone_operator import standalone_operator
import code_generator.share.br_const_defs as bcd
from code_generator.vector.common.funcgen import FuncGenHandler
import code_generator.vector.common.hwCaps as hwCaps
import code_generator.vector.common.funcLib as funcLib
import code_generator.vector.common.kernelLib as kernelLib


class bn(standalone_operator):

    def __init__(self, warpid, vgpr_start, vgpr_end,
                 usharp_0, usharp_1, usharp_2, usharp_3=None,
                 withrelu=False, layerid=0, layernum=1,
                 force_ackgmb=False, sync_layer=False,
                 loop_config=None, options=None, 
                 syncid_with_maxpool=None, micro_batch_mode=False):

        super().__init__(
            usharp_0[1][0],  usharp_0[1][1], usharp_0[1][2], usharp_0[1][3], 
            [vgpr_start, vgpr_end])

        if withrelu:
            assert (usharp_3 is not None), "Relu usharp is missing!"
            self.usharp_info = [
                    [usharp_0[0], "3d Activation",  usharp_0[1][0],  usharp_0[1][1], usharp_0[1][2], usharp_0[1][3], "input, 3d activation"],
                    [usharp_1[0], "1d Vector",      1, 1, 1,  usharp_0[1][1]*4, "input 2gamma/2beta per 2c, output 2sum/2ssum per 2c, 1d vector"],
                    [usharp_2[0], "3d Activation",  usharp_2[1][0],  usharp_2[1][1], usharp_2[1][2], usharp_2[1][3], "bn output, 3d activation"],
                    [usharp_3[0], "3d Activation",  usharp_3[1][0],  usharp_3[1][1], usharp_3[1][2], usharp_3[1][3], "relu output, 3d activation"]
                ]
        else:
            self.usharp_info = [
                    [usharp_0[0], "3d Activation",  usharp_0[1][0],  usharp_0[1][1], usharp_0[1][2], usharp_0[1][3], "input, 3d activation"],
                    [usharp_1[0], "1d Vector",      usharp_1[1][0],  usharp_1[1][1], usharp_1[1][2], usharp_1[1][3], "input gamma/beta, 1d vector"],
                    [usharp_2[0], "3d Activation",  usharp_2[1][0],  usharp_2[1][1], usharp_2[1][2], usharp_2[1][3], "bn output, 3d activation"]
                ]
                
        if layerid is not None:
            self.layer_id = layerid
        if layernum is not None:
            self.layer_num = layernum
        self.loop_config = loop_config
        self.warp_id = warpid
        self.operator_name = "Batchnorm"
        self.usharpid_input_4d_activation = usharp_0[0]
        self.usharpid_gamma_beta_sum_ssum = usharp_1[0]
        self.usharpid_output_4d_activation = usharp_2[0]
        self.enable_relu = withrelu
        self.force_ackgmb = force_ackgmb
        self.sync_layer = sync_layer
        self.syncid_with_maxpool = syncid_with_maxpool
        self.init_tcore_producer = False
        self.init_reduce_producer = False
        self.micro_batch_mode = micro_batch_mode
        if withrelu:
            self.usharpid_output_4d_activation_relu = usharp_3[0]
            
        sample_number = 1
        if not self.micro_batch_mode:
            sample_number = self.src_sample
        self.scaling_global_surface_area = 1 / self.src_height / self.src_width / sample_number

        #TODO: expose or move to const def if this is a global issue
        self.ENABLE_FMAD_BURST = False # should't be enable, seems cmodel does not support
        self.ENABLE_MACRO = True
        #coupled with self.ENABLE_MACRO=True
        self.ENABLE_INPLACE_MACRO = self.ENABLE_MACRO and True
        #coupled with self.ENABLE_INPLACE_MACRO=True
        self.ENABLE_SGPR_TO_IMM = self.ENABLE_INPLACE_MACRO and True
        #fmad.v4 to fmul and fadd, exclusive to self.ENABLE_FMAD_BURST=True
        self.ENABLE_FMAD_TO_FADD_AND_FMUL_BURST = (not self.ENABLE_FMAD_BURST) and True
        self.ENABLE_STM_EXTRA_BUNDLE = self.ENABLE_FMAD_TO_FADD_AND_FMUL_BURST and True
        self.OC_ALIGNMENT_FOR_SUM_SSQ_DATA = 64
        

    def _gen_main_kernel(self):
        self._init_bn_bar_kernel()
        self._gen_euid_kernel()
        self._init_common_vgpr_bases()
        self._process_channel_loop()

    def _gen_sub_kernel(self):
        if not self.ENABLE_MACRO:
            self._create_all_subfuncs()
        else:
            self._create_all_macros()
        if self.syncid_with_maxpool is not None:
            self.bar.generate(
                indent=self._get_indent(), 
                scope="tg", mode="pass",
                src1=self.syncid_with_maxpool,
                src2=bcd.BAR_CHANNELS_WITHIN_VECTOR,
                comment="// Send pass to notify maxpool to start")

    def _calculate_block_size_from_vgpr(self):
        pingpong_buffer_num = 2
        vgpr_number = int(self.vgpr_num / pingpong_buffer_num)
        self.block_size_y = math.floor(math.sqrt(vgpr_number))
        #set block_size_y to 8 for ldm burst
        #TODO: conservative policy, only handle near 8 cases now
        self.block_size_y = 8 if (8 - self.block_size_y) <= 2 else self.block_size_y
        iteration = 0
        while (iteration < 2):
            if (self.block_size_y > self.TILE_SIZE_X):
                self.block_size_y = int(self.block_size_y / hwCaps.MaxLoadGranule()
                                    ) * hwCaps.MaxLoadGranule()
            if (self.block_size_y > self.tile_num_y):
                self.block_size_y = self.tile_num_y

            self.vgpr_stride = self.block_size_y
            self.block_size_x = math.floor(vgpr_number / self.vgpr_stride)

            refit_y = False
            if self.block_size_x > self.tile_num_x:
                self.block_size_x = self.tile_num_x
                refit_y = True
            if refit_y:
                self.block_size_y = math.floor(math.floor(vgpr_number/self.block_size_x))
                iteration += 1
                if self.block_size_y > self.tile_num_y:
                    self.block_size_y = self.tile_num_y
            else:
                break
            self.vgpr_stride = self.block_size_y

        self.buffer_num = pingpong_buffer_num

    def _calculate_surface_partition(self):
        if self.block_size_x == 0 or self.block_size_y == 0:
            assert False, "No enough vgprs for a block to fit" \
                + str(self.vgpr_num)      

        y_align_size = int(self.tile_num_y / self.block_size_y) * self.block_size_y
        y_remainder = self.tile_num_y - y_align_size
        self.y_span_list = []
        if y_align_size != 0 and y_remainder == 0:
            y_remainder = self.block_size_y
            y_align_size -= self.block_size_y
        
        if y_align_size != 0:
            self.y_span_list.append({"SpanHeight": y_align_size, "BlockHeight": self.block_size_y, "BorderFlag": 0})
        
        self.y_span_list.append({"SpanHeight": y_remainder-1, "BlockHeight": y_remainder-1, "BorderFlag": 0})
        self.y_span_list[-1]["BorderFlag"] |= self.y_bottom_flag

        self.x_align_size = int(self.tile_num_x / self.block_size_x )* self.block_size_x
        self.partial_block_width = self.tile_num_x - self.x_align_size

        if self.partial_block_width == 0:
            self.partial_block_width = self.block_size_x
        else:
            self.x_align_size += self.block_size_x

        self.partial_block_width -= 1
        self.right_border_block_x = (self.x_align_size - self.block_size_x) * self.TILE_SIZE_X
        self.vgpr_step_back = self.block_size_x * self.buffer_num * self.vgpr_stride
        self.vgpr_index_end = self.vgpr_start + self.vgpr_step_back + self.vgpr_stride

    def _allocate_sgpr(self):
        self.w_axis_sgpr = self._alloc_wsr("sample_index")
        self.z_axis_sgpr = self._alloc_wsr("channel_index")
        #self.y_axis_sgpr = self._alloc_wsr("height_index")
        #self.x_axis_sgpr = self._alloc_wsr("width_index")
        self.eu_id_sgpr = self._alloc_wsr("eu_id")

        self.large_imm_sgpr = self._alloc_wsr("large_immediate_num")

        self.reduce_2_bn_barid_sgpr = self._alloc_wsr("barid_reduce2bn")
        self.bn_2_reduce_barid_sgpr = self._alloc_wsr("barid_bn2reduce")
        #can not allocated as pseudo register due to instruction bundle
        # self.load_in_x_axis_sgpr = self._alloc_wsr("load_in_x_axis")
        if not self.ENABLE_SGPR_TO_IMM:
            self.load_in_y_axis_sgpr = self._alloc_wsr("load_in_y_axis")
            self.alu_in_y_axis_sgpr = self._alloc_wsr("alu_in_y_axis")
            self.alu_in_x_axis_sgpr = self._alloc_wsr("alu_in_x_axis")
            self.vgpr_load_base_sgpr = self._alloc_wsr("vgpr_load_base")
            self.vgpr_alu_base_sgpr = self._alloc_wsr("vgpr_alu_base")
            self.load_in_x_axis_sgpr = self._alloc_wsr("load_in_x_axis")
        else:
            self.load_in_y_axis_sgpr = self._alloc_wsr_imm("load_in_y_axis", 0)
            # self.load_in_x_axis_sgpr = self._alloc_wsr_imm("load_in_x_axis", 0)
            self.alu_in_y_axis_sgpr = self._alloc_wsr_imm("alu_in_y_axis", 0)
            self.alu_in_x_axis_sgpr = self._alloc_wsr_imm("alu_in_x_axis", 0)
            self.vgpr_load_base_sgpr = self._alloc_wsr_imm("vgpr_load_base", 0)
            self.vgpr_alu_base_sgpr = self._alloc_wsr_imm("vgpr_alu_base", 0)
            self.load_in_x_axis_sgpr = self._alloc_wsr_imm("load_in_x_axis", 0)

        self.x_axis_sgpr = self.load_in_x_axis_sgpr # init with load in x axis

        # self.vgpr_load_base_sgpr = self._alloc_wsr("vgpr_load_base")
        # self.vgpr_alu_base_sgpr = self._alloc_wsr("vgpr_alu_base")

        self.x_sld_sgpr = self._alloc_wsr("sld_in_x")
        if not self.micro_batch_mode:
            self.params_flag_sgpr = self._alloc_wsr("params_calc_flag")


    def _calculate_available_vgprs(self):
        vgpr_temp_num = hwCaps.MaxLDMGranule() + 2 #2 extra tlr for _load_gamma_beta_sum_ssum
        if vgpr_temp_num < 8:
            vgpr_temp_num = 8
        coeff_vgpr_num = 2

        self.vgpr_num = self.vgpr_range[1] - self.vgpr_range[0]
        if self.vgpr_num <= (vgpr_temp_num + coeff_vgpr_num):
            assert False, "Not enough vgprs to hold temps"

        vgpr_start = self.vgpr_range[0]
        self.vgpr_temp_start = vgpr_start
        self.vgpr_num -= vgpr_temp_num
        vgpr_start += vgpr_temp_num
        self.coeff_vgpr_start_addr = vgpr_start
        self.vgpr_num -= coeff_vgpr_num
        vgpr_start += coeff_vgpr_num

        self.vgpr_start = vgpr_start

        self.const_base = self._alloc_addr_reg("iclr", "const_base")
        self.vgpr_base = self._alloc_addr_reg("itlr", "vgpr_base")
        self.sgpr_base = self._alloc_addr_reg("islr", "sgpr_base")

        self.x_sldm_vgpr = self.vgpr_temp_start + 2 #
        self.gamma_beta_vgpr_index = self.x_sldm_vgpr + 4
        self.sum_ssum_vgpr_index = self.x_sldm_vgpr

    def _load_gamma_beta_sum_ssum(self):
        K_SSHL_BITS = 1
        self.sshl.generate(
            indent_level=self._get_indent(),
            dst=self.x_sld_sgpr,
            src1=self.z_axis_sgpr,
            src2=K_SSHL_BITS,
            comment="// Calculate the 1d weight x axis")

        if not self.micro_batch_mode:
            self.smov.generate(
                indent_level=self._get_indent(),
                dst=self.params_flag_sgpr,
                src1=1,
                comment="// Turn on bn params calculation flag")

        can_use_imm = True
        aligned_channel_num = math.ceil(self.src_channel/self.OC_ALIGNMENT_FOR_SUM_SSQ_DATA)*self.OC_ALIGNMENT_FOR_SUM_SSQ_DATA
        if aligned_channel_num*2 >= self.MAX_OFFSET_FOR_SLD_MMAT1D:
            can_use_imm = False
            self.smov.generate(
                indent_level=self._get_indent(),
                dst=self.large_imm_sgpr,
                src1=aligned_channel_num*2,
                comment="// Move large imm sld offset to wsr")
        
        self.sldm_loader.generate(
            self._get_indent(), hwCaps.SurfaceFormatFP32(),
            self.x_sld_sgpr, self.gamma_beta_vgpr_index, 
            4, 0, 1, self.usharpid_gamma_beta_sum_ssum, 
            (self.w_axis_sgpr if self.micro_batch_mode else 0))

        self.sldm_loader.generate(
            self._get_indent(), hwCaps.SurfaceFormatFP32(),
            self.x_sld_sgpr, self.sum_ssum_vgpr_index,
            4, 0, 1, self.usharpid_gamma_beta_sum_ssum, 
            (self.w_axis_sgpr if self.micro_batch_mode else 0), 
            offset_info=[aligned_channel_num, self.large_imm_sgpr, can_use_imm])

    def _calculate_params_for_alu(self):
        if not self.micro_batch_mode:
            self.flow_man.start_if_loop(self.params_flag_sgpr, str(0), "!=", 0)
            self.smov.generate(
                indent_level=self._get_indent(), 
                dst=self.params_flag_sgpr, src1=0,
                comment="// Turn off the flag to calculate batch norm params")
        
        vgpr_start = self.vgpr_range[0]
        self.movi.generate(
            indent_level=self._get_indent(), 
            dst="r"+str(vgpr_start)+".f32",
            src1=self.scaling_global_surface_area,
            comment="// Scaling by 1/(H*W*N)")
        self.movi.generate(
            indent_level=self._get_indent(),
            dst="r"+str(vgpr_start+1)+".f32",
            src1='{:f}'.format(self.TOLERANCE_EPILSON),
            comment="// Handle rcp of 0 with epilson")
        self.fmul.generate(
            indent_level=self._get_indent(), 
            modifier="b32.v4", 
            dst="r"+str(vgpr_start+2),
            src1="r"+str(self.sum_ssum_vgpr_index)+".a",
            src2="r"+str(vgpr_start),
            comment="// Do scaling by 1/(H*W*N)")
        self.fmad.generate(
            indent_level=self._get_indent(),
            modifier="b32",
            dst="r"+str(vgpr_start+4)+"",
            src1="r"+str(vgpr_start+2)+".n",
            src2="r"+str(vgpr_start+2),
            src3="r"+str(vgpr_start+4),
            comment="// Calculate c0_sigma^2=1/m*c0_x^2_sum - (c0_u)^2")
        self.fmad.generate(
            indent_level=self._get_indent(),
            modifier="b32",
            dst="r"+str(vgpr_start+5)+"",
            src1="r"+str(vgpr_start+3)+".n",
            src2="r"+str(vgpr_start+3),
            src3="r"+str(vgpr_start+5),
            comment="// Calculate c1_sigma^2=1/m*c1_x^2_sum - (c1_u)^2")
        self.fmax.generate(
            indent_level=self._get_indent(),
            modifier="b32.v2",
            dst="r"+str(vgpr_start+4),
            src1="r"+str(vgpr_start+4)+".a",
            src2="0.0",
            comment="// Round to zeros if less than 0.0")
        # self.fmax.generate(
        #     indent_level=self._get_indent(),
        #     modifier="b32",
        #     dst="r"+str(vgpr_start+5),
        #     src1="r"+str(vgpr_start+5),
        #     src2="0.0",
        #     comment="// Round to zeros if less than 0.0")  
        self.fadd.generate(
            indent_level=self._get_indent(),
            modifier="b32.rsqrt",
            dst="r"+str(vgpr_start+4),
            src1="r"+str(vgpr_start+4),
            src2="r"+str(vgpr_start+1),
            comment="// Calculate 1/sqrt(c0_sigma^2+epsilon)")
        self.fadd.generate(
            indent_level=self._get_indent(),
            modifier="b32.rsqrt.sc3",
            dst="r"+str(vgpr_start+5),
            src1="r"+str(vgpr_start+5),
            src2="r"+str(vgpr_start+1),
            comment="// Calculate 1/sqrt(c0_sigma^2+epsilon)")  
        self.fmul.generate(
            indent_level=self._get_indent(), 
            modifier="b32.sc3", 
            dst="r"+str(vgpr_start),
            src1="r"+str(vgpr_start+4),
            src2="r"+str(self.gamma_beta_vgpr_index),
            comment="// Calculate c0_gamma/c0_sigma") 
        self.fmul.generate(
            indent_level=self._get_indent(), 
            modifier="b32", 
            dst="r"+str(vgpr_start+1),
            src1="r"+str(vgpr_start+5),
            src2="r"+str(self.gamma_beta_vgpr_index+1),
            comment="// Calculate c1_gamma/c1_sigma")       
        self.fmad.generate(
            indent_level=self._get_indent(),
            modifier="b32",
            dst="r"+str(vgpr_start+2)+"",
            src1="r"+str(vgpr_start+2)+".n",
            src2="r"+str(vgpr_start+4),
            src3="r"+str(self.gamma_beta_vgpr_index+2),
            comment="// Calculate -c0_gamma/c0_sigma*c0_u + c0_beta")
        self.fmad.generate(
            indent_level=self._get_indent(),
            modifier="b32",
            dst="r"+str(vgpr_start+4)+"",
            src1="r"+str(vgpr_start+3)+".n",
            src2="r"+str(vgpr_start+5),
            src3="r"+str(self.gamma_beta_vgpr_index+3),
            comment="// Calculate -c1_gamma/c1_sigma*c1_u + c1_beta")
        self.mov.generate(
            indent_level=self._get_indent(),
            dst="r"+str(vgpr_start+3)+".f32",
            src1="r"+str(vgpr_start+4)+".f32",
            comment="// Move r160 to r159 to benefit data burst")            
        self.mov.generate(
            indent_level=self._get_indent(),
            modifier="rdne.v4",
            dst="r"+str(self.coeff_vgpr_start_addr)+".f16",
            src1="r"+str(vgpr_start)+".a.f32",
            comment="// Pack fp32 data to fp16")
        if not self.micro_batch_mode:
            self.flow_man.close_if_loop()

    def _create_subfunc_call(
            self, func_type, y_border_flag, 
            y_block_height, sync_channel, x_border_flag):
        if func_type == self.FUNC_TYPE_LOAD:
            func_name = self.LOAD_FUNC_FORMAT.format(
                self.layer_id, self.warp_id, 
                str(y_border_flag), str(y_block_height),
                sync_channel, str(x_border_flag))
        elif func_type == self.FUNC_TYPE_ALU:
            func_name = self.ALU_FUNC_FORMAT.format(
                self.layer_id, self.warp_id, 
                str(y_border_flag), str(y_block_height),
                str(x_border_flag))
        new_sgpr_inused = [
            self.flow_man.get_temp_start(), 
            self.flow_man.get_stack_start()]
        self.fun_gen_handler.addFunction(func_name, new_sgpr_inused)
        self.flow_man.start_function_call(func_name)
        self.flow_man.end_function_call()

    def _create_macro_call(
            self, func_type, y_border_flag, 
            y_block_height, sync_channel, x_border_flag):
        if func_type == self.FUNC_TYPE_LOAD:
            func_name = self.LOAD_FUNC_FORMAT.format(
                self.layer_id, self.warp_id, 
                str(y_border_flag), str(y_block_height),
                sync_channel, str(x_border_flag))
        elif func_type == self.FUNC_TYPE_ALU:
            func_name = self.ALU_FUNC_FORMAT.format(
                self.layer_id, self.warp_id, 
                str(y_border_flag), str(y_block_height),
                str(x_border_flag))
        new_sgpr_inused = [
            self.flow_man.get_temp_start(), 
            self.flow_man.get_stack_start()]
        self.fun_gen_handler.addFunction(func_name, new_sgpr_inused)
        self.flow_man.start_macro_call(func_name, inplace=self.ENABLE_INPLACE_MACRO)
        if self.ENABLE_INPLACE_MACRO:
            sync_channel_ = int(sync_channel) if sync_channel else 0
            self._create_inplace_macro(func_type, y_border_flag,
            y_block_height, int(x_border_flag), sync_channel_)
            self.flow_man.end_macro_call(macro_name=func_name, inplace=True)
        else: 
            self.flow_man.end_macro_call(macro_name=func_name)          

    def _do_alu_tile_v(
        self, vgpr_address, vgpr_number, is_partial, type="bn"):
        size_list = funcLib.SplitRepeatIntoGroups(vgpr_number, hwCaps.MaxALUGranule())
        for i, this_array in enumerate(size_list):#for fadd or fmul bundle
            for ele in range(this_array[0]):
                vector_modifier = kernelLib.GetVectorModifier(this_array[1], "v")
                if type == "bn":
                    if self.ENABLE_FMAD_BURST:
                        self.fmad.generate(
                            indent_level=self._get_indent(),
                            # mask=1 if is_partial else 0,
                            modifier="b16"+vector_modifier,
                            dst="ir"+str(vgpr_address),
                            src1="ir"+str(vgpr_address)+".a",
                            src2="r"+str(self.coeff_vgpr_start_addr),
                            src3="r"+str(self.coeff_vgpr_start_addr+1),
                            comment="// Do final normalization")
                    else:
                        #fmad.v4 and v2 is not supported due to TLR read port/bank conflicts
                        if not self.ENABLE_FMAD_TO_FADD_AND_FMUL_BURST:
                            for i in range(this_array[1]):
                                self.fmad.generate(
                                    indent_level=self._get_indent(),
                                    # mask=1 if is_partial else 0,
                                    modifier="b16",
                                    dst="ir"+str(vgpr_address + i),
                                    src1="ir"+str(vgpr_address + i),
                                    src2="r"+str(self.coeff_vgpr_start_addr),
                                    src3="r"+str(self.coeff_vgpr_start_addr+1),
                                    comment="// Do final normalization")
                        else:
                            self.fmul.generate(
                                indent_level=self._get_indent(),
                                modifier="b16"+vector_modifier,
                                dst="ir"+str(vgpr_address),
                                src1="ir"+str(vgpr_address)+".a",
                                src2="r"+str(self.coeff_vgpr_start_addr),
                                comment="// Do final normalization")
                            self.fadd.generate(
                                indent_level=self._get_indent(),
                                modifier="b16"+vector_modifier,
                                dst="ir"+str(vgpr_address),
                                src1="ir"+str(vgpr_address)+".a",
                                src2="r"+str(self.coeff_vgpr_start_addr+1),
                                comment="// Do final normalization")

                else:
                     self.fmax.generate(
                        indent_level=self._get_indent(),
                        # mask=1 if is_partial else 0,
                        modifier="b16"+vector_modifier,
                        dst="ir"+str(vgpr_address),
                        src1="ir"+str(vgpr_address)+".a",
                        src2="0.0",
                        comment="// Do final relu operation")                   
                vgpr_address += this_array[1]

    def _store_tile_v(
        self, vector_size, vgpr_address, coordinate_sgpr_list, mmat3d, write_through, y_inc, x_inc, operation="bn"):

        mmat = ".mmat3d" if mmat3d is True else ".mmat2d"
        wt = ".wt" if write_through is True else ".nwt"
        modifier = "float.mb16.rb16" + mmat + kernelLib.GetVectorModifier(vector_size * 2, "e") + wt + ".gc" + str(4 + vector_size)
        usharp_id = self.usharpid_output_4d_activation if operation == "bn" else self.usharpid_output_4d_activation_relu
        self.stm.generate(
            indent_level=self._get_indent(),
            modifier=modifier,
            dst="g0",
            src1="g4",
            desc="u" + str(usharp_id),
            comment="// Store 1 tile")

        #if not bcd.BR_STM_G4_FEATURE_ENABLE:
        self.mov.generate(
            indent_level=self._get_indent(),
            parallel=1,
            modifier=kernelLib.GetVectorModifierWithoutDot(vector_size, "v"),
            dst="g4.f16" if not bcd.BR_STM_G4_FEATURE_ENABLE else "z0.f16",
            src1="ir" + str(vgpr_address) + ".f16.a",
            comment="// Assign vgpr address to g4")
        # else:
        #     self.fadd.generate(
        #         indent_level=self._get_indent(),
        #         parallel=1,
        #         modifier=kernelLib.GetVectorModifierWithoutDot(vector_size, "v")+".b16",
        #         dst="z0",
        #         src1="ir" + str(vgpr_address) + ".a",
        #         src2=0.0,
        #         comment="// Assign vgpr address to g4")

        for idx in range(len(coordinate_sgpr_list)):
            modifier = "eog" if idx == len(coordinate_sgpr_list) - 1 else ""
            if idx < len(coordinate_sgpr_list):
                if idx == 0:
                    self.adds.generate(
                        indent_level=self._get_indent(),
                        modifier="b32",
                        dst="g{}".format(idx),
                        src1=coordinate_sgpr_list[idx],
                        src2=str(x_inc),
                        comment="// Add g{}".format(idx))
                elif idx == 1:
                    self.saddg.generate(
                        indent_level=self._get_indent(),
                        modifier=modifier,
                        dst="g{}".format(idx),
                        src1=coordinate_sgpr_list[idx],
                        src2=str(y_inc),
                        comment="// Add g{}".format(idx))
                    #self.adds.generate(
                    #    indent_level=self._get_indent(),
                    #    modifier="b32",
                    #    dst="g{}".format(idx),
                    #    src1=coordinate_sgpr_list[idx],
                    #    src2=str(y_inc),
                    #    comment="// Add g{}".format(idx))
                else:
                    self.smovg.generate(
                        indent_level=self._get_indent(),
                        modifier=modifier,
                        dst="g{}".format(idx),
                        src1=coordinate_sgpr_list[idx],
                        comment="// Assign g{}".format(idx))
                    #self.mov.generate(
                    #    indent_level=self._get_indent(),
                    #    modifier="eog" if idx == 3 else None,
                    #    dst="g{}.u32".format(idx),
                    #    src1=coordinate_sgpr_list[idx]+".u32",
                    #    comment="// Assign g{}".format(idx))

    def _store_tile_v_bundle(
        self, vector_size, vgpr_address, coordinate_sgpr_list, mmat3d, write_through, y_inc, x_inc, operation="bn"):

        mmat = ".mmat3d" if mmat3d is True else ".mmat2d"
        wt = ".wt" if write_through is True else ".nwt"
        modifier = "float.mb16.rb16" + mmat + kernelLib.GetVectorModifier(vector_size * 2, "e") + wt + ".gc" + str(4 + vector_size)
        usharp_id = self.usharpid_output_4d_activation if operation == "bn" else self.usharpid_output_4d_activation_relu
        if not self.ENABLE_STM_EXTRA_BUNDLE and operation != "relu" and self.ENABLE_FMAD_TO_FADD_AND_FMUL_BURST:    
            self.fadd.generate(
                indent_level=self._get_indent(),
                modifier="b16"+kernelLib.GetVectorModifier(vector_size, "v"),
                dst="ir"+str(vgpr_address),
                src1="ir"+str(vgpr_address)+".a",
                src2="r"+str(self.coeff_vgpr_start_addr+1),
                comment="// Do final normalization")
        if self.ENABLE_STM_EXTRA_BUNDLE and operation == "relu":
            self.fadd.generate(
                indent_level=self._get_indent(),
                modifier="b16"+kernelLib.GetVectorModifier(vector_size, "v"),
                dst="ir"+str(vgpr_address),
                src1="ir"+str(vgpr_address)+".a",
                src2="r"+str(self.coeff_vgpr_start_addr+1),
                comment="// Do final normalization")
        self.stm.generate(
            indent_level=self._get_indent(),
            modifier=modifier,
            dst="g0",
            src1="g4",
            desc="u" + str(usharp_id),
            comment="// Store 1 tile")
        if not self.ENABLE_STM_EXTRA_BUNDLE and operation != "relu":
            self.mov.generate(
                indent_level=self._get_indent(),
                parallel=1,
                modifier=kernelLib.GetVectorModifierWithoutDot(vector_size, "v"),
                dst="g4.f16" if not bcd.BR_STM_G4_FEATURE_ENABLE else "z0.f16",
                src1="ir" + str(vgpr_address) + ".f16.a",
                comment="// Assign vgpr address to g4")
        elif self.ENABLE_STM_EXTRA_BUNDLE and operation == "bn":
            self.fadd.generate(
                indent_level=self._get_indent(),
                modifier="b16"+kernelLib.GetVectorModifier(vector_size, "v"),
                parallel=1,
                # dst="ir"+str(vgpr_address),
                dst="z0",
                src1="ir"+str(vgpr_address)+".a",
                src2="r"+str(self.coeff_vgpr_start_addr+1),
                comment="// Do final normalization")
        if operation == "relu":
            self.fmax.generate(
                indent_level=self._get_indent(),
                # mask=1 if is_partial else 0,
                modifier="b16"+kernelLib.GetVectorModifier(vector_size, "v"),
                # dst="ir"+str(vgpr_address),
                parallel=1,
                dst="z0",
                src1="ir"+str(vgpr_address)+".a",
                src2="0.0",
                comment="// Do final relu operation")  


        for idx in range(len(coordinate_sgpr_list)):
            modifier = "eog" if idx == len(coordinate_sgpr_list) - 1 else ""
            if idx < len(coordinate_sgpr_list):
                if idx == 0:
                    self.adds.generate(
                        indent_level=self._get_indent(),
                        modifier="b32",
                        dst="g{}".format(idx),
                        src1=coordinate_sgpr_list[idx],
                        src2=str(x_inc),
                        comment="// Add g{}".format(idx))
                elif idx == 1:
                    self.saddg.generate(
                        indent_level=self._get_indent(),
                        modifier=modifier,
                        dst="g{}".format(idx),
                        src1=coordinate_sgpr_list[idx],
                        src2=str(y_inc),
                        comment="// Add g{}".format(idx))
                else:
                    self.smovg.generate(
                        indent_level=self._get_indent(),
                        modifier=modifier,
                        dst="g{}".format(idx),
                        src1=coordinate_sgpr_list[idx],
                        comment="// Assign g{}".format(idx))


    def _store_tile_col(self, vgpr_address, vgpr_num, coord_sgpr_list, x_inc, operation="bn"):
        size_list = funcLib.SplitRepeatIntoGroups(vgpr_num, hwCaps.MaxSTMGranule())
        size_list_num = len(size_list)
        array_index = 0
        y_changed = 0
        accu = [0]
        for this_array in size_list:
            array_index += 1
            for z in range(this_array[0]):
                accu.append(this_array[1] * self.TILE_SIZE_Y)
                if len(accu) > 1:
                    accu[-1] += accu[-2]#add last two to current position, prefix sum
                self._store_tile_v(
                    vector_size=this_array[1], 
                    vgpr_address=vgpr_address,
                    coordinate_sgpr_list=coord_sgpr_list,
                    mmat3d=True, write_through=True, y_inc=accu[-2], x_inc=x_inc, operation=operation)

                vgpr_address += this_array[1]

                if ((array_index != size_list_num) or (z != (this_array[0] - 1))):
                    y_changed += this_array[1]
                    # self.sadd.generate(
                    #     indent_level=self._get_indent(),
                    #     dst=coord_sgpr_list[1],
                    #     src1=coord_sgpr_list[1],
                    #     src2=str(this_array[1] * self.TILE_SIZE_Y),
                    #     comment="// Increase Y axis")
        return y_changed

    def _do_core_alu_on_col(
        self, vgpr_address, vgpr_number, coord_sgpr_list, col_boder_type, x_inc=0):

        if self.enable_relu:
            vgpr_address_backup = copy.deepcopy(vgpr_address)

        is_row_partial = (col_boder_type & self.BORDER_TYPE_BOTTOM) and \
            (self.image_height_res != 0)
        if is_row_partial:
            vgpr_number -=1
        is_col_partial = (col_boder_type & self.BORDER_TYPE_RIGHT) and \
            (self.image_width_res !=0)
        
        alu_operations = ["bn", "relu"] if self.enable_relu else ["bn"]
        for a_op in alu_operations:
            if vgpr_number != 0:
                self._do_alu_tile_v(vgpr_address, vgpr_number, is_col_partial, a_op)
                
            if is_row_partial:
                self._do_alu_tile_v(vgpr_address+vgpr_number, 1, True, a_op)
                # restore total vgpr number
                vgpr_number += 1 
            
            y_changed = self._store_tile_col(
                vgpr_address=vgpr_address,vgpr_num=vgpr_number,
                coord_sgpr_list=coord_sgpr_list, x_inc=x_inc, operation=a_op)

            if self.enable_relu:
                vgpr_address = vgpr_address_backup
    
    def _store_tile_col_bundle(
        self, vgpr_address, vgpr_num, coord_sgpr_list, x_inc, is_row_partial=False, operation="bn"):
        vgpr_address_backup = copy.deepcopy(vgpr_address)
        #replace hwCaps.MaxALUGranule() for bundle
        size_list = funcLib.SplitRepeatIntoGroups(vgpr_num, hwCaps.MaxSTMGranule())
        accu = [0]
        for i, this_array in enumerate(size_list):#for fadd or fmul bundle
            for ele in range(this_array[0]):
                accu.append(this_array[1] * self.TILE_SIZE_Y)
                if len(accu) > 1:
                    accu[-1] += accu[-2]
                vector_modifier = kernelLib.GetVectorModifier(this_array[1], "v")
                if operation == "bn":
                    if self.ENABLE_FMAD_BURST:#To be dead code
                        self.fmad.generate(
                            indent_level=self._get_indent(),
                            # mask=1 if is_partial else 0,
                            modifier="b16"+vector_modifier,
                            dst="ir"+str(vgpr_address),
                            src1="ir"+str(vgpr_address)+".a",
                            src2="r"+str(self.coeff_vgpr_start_addr),
                            src3="r"+str(self.coeff_vgpr_start_addr+1),
                            comment="// Do final normalization")
                    else:
                        #fmad.v4 and v2 is not supported due to TLR read port/bank conflicts
                        if not self.ENABLE_FMAD_TO_FADD_AND_FMUL_BURST:
                            for i in range(this_array[1]):
                                self.fmad.generate(
                                    indent_level=self._get_indent(),
                                    # mask=1 if is_partial else 0,
                                    modifier="b16",
                                    dst="ir"+str(vgpr_address + i),
                                    src1="ir"+str(vgpr_address + i),
                                    src2="r"+str(self.coeff_vgpr_start_addr),
                                    src3="r"+str(self.coeff_vgpr_start_addr+1),
                                    comment="// Do final normalization")
                        else:
                            self.fmul.generate(
                                indent_level=self._get_indent(),
                                modifier="b16"+vector_modifier,
                                dst="ir"+str(vgpr_address),
                                src1="ir"+str(vgpr_address)+".a",
                                src2="r"+str(self.coeff_vgpr_start_addr),
                                comment="// Do final normalization")
                self._store_tile_v_bundle(
                    vector_size=this_array[1], 
                    vgpr_address=vgpr_address,
                    coordinate_sgpr_list=coord_sgpr_list,
                    mmat3d=True, write_through=True, 
                    y_inc=accu[-2], x_inc=x_inc, operation=operation)                   
                vgpr_address += this_array[1]
        vgpr_address = vgpr_address_backup
        # self._do_alu_tile_v(vgpr_address, vgpr_num, is_row_partial, operation)
        # self._store_tile_col(
        #     vgpr_address=vgpr_address,vgpr_num=vgpr_num,
        #     coord_sgpr_list=coord_sgpr_list, x_inc=x_inc, operation=operation)

    def _do_core_alu_on_col_bundle(
        self, vgpr_address, vgpr_number, coord_sgpr_list, col_boder_type, x_inc=0):
        if self.enable_relu:
            vgpr_address_backup = copy.deepcopy(vgpr_address)
        alu_operations = ["bn", "relu"] if self.enable_relu else ["bn"]

        for a_op in alu_operations: 
            self._store_tile_col_bundle(
                vgpr_address=vgpr_address,vgpr_num=vgpr_number,
                coord_sgpr_list=coord_sgpr_list, x_inc=x_inc, operation=a_op)

            if self.enable_relu:
                vgpr_address = vgpr_address_backup



    def _create_single_subfunc(
            self, func_type, y_border_type, 
            y_block_height, right_border_mode, sync_index):
        if func_type == self.FUNC_TYPE_LOAD:
            x_axis_sgpr = self.load_in_x_axis_sgpr
            y_axis_sgpr = self.load_in_y_axis_sgpr
            vgpr_base_sgpr = self.vgpr_load_base_sgpr
            loop_unroll_threshold = self.LOAD_LOOP_UNROLL_THRESHOLD
        else:
            x_axis_sgpr = self.alu_in_x_axis_sgpr
            y_axis_sgpr = self.alu_in_y_axis_sgpr
            vgpr_base_sgpr = self.vgpr_alu_base_sgpr
            loop_unroll_threshold = self.ALU_LOOP_UNROLL_THRESHOLD    
        
        if right_border_mode == 0:
            loop_col_num = self.block_size_x
        elif func_type == self.FUNC_TYPE_LOAD or \
                self.image_width_res == 0:
            loop_col_num = self.partial_block_width + 1
        else:
            loop_col_num = self.partial_block_width

        if loop_col_num == 0 or loop_col_num < loop_unroll_threshold:
            loop_mode = 0
        else:
            loop_mode = 1

        self.flow_man.start_if_loop(
            vgpr_base_sgpr, 
            str(self.vgpr_index_end-loop_col_num*self.vgpr_stride),
            ">=", 0, local_label=self.ENABLE_MACRO, local_label_value=0)
        self.smov.generate(
            indent_level=self._get_indent(),
            dst=vgpr_base_sgpr,
            src1=self.vgpr_start,
            comment="// Check vgpr base, wrap back if exceeding the range")

        self.flow_man.close_if_loop(local_label=self.ENABLE_MACRO, local_label_value=0)

        self.smovs.generate(
            indent_level=self._get_indent(),
            dst=self.vgpr_base,
            src1=vgpr_base_sgpr,
            comment="// Restore the vgpr base address")
        
        if loop_mode != 0:
            temp_x_index_sgpr = self._alloc_wsr("temp_x_index")
            self.smov.generate(
                indent_level=self._get_indent(),
                dst=temp_x_index_sgpr,
                src1=0,
                comment="// Set loop start from 0")
            if loop_col_num > 1:
                self.flow_man.for_loop_start(
                    "", str(loop_col_num-1), "1", temp_x_index_sgpr,
                    comment="// Loop in x direction")
            loop_unroll_num = 1
        else:
            loop_unroll_num = loop_col_num

        coord_sgpr_list = [
            x_axis_sgpr, y_axis_sgpr, 
            self.z_axis_sgpr, self.w_axis_sgpr]
        loop_row_size = y_block_height
        if y_border_type & self.BORDER_TYPE_BOTTOM:
            loop_row_size +=1
        x_inc = 0
        for ele in range(loop_unroll_num):
            if func_type == self.FUNC_TYPE_LOAD:
                self.activation_loader.generate(
                    indent_obj=self._get_indent(),
                    mem_format=hwCaps.SurfaceFormatFP16(),
                    gpr_format=hwCaps.SurfaceFormatFP16(),
                    coord_sgpr_list=coord_sgpr_list,
                    vgpr_address=-(ele*self.vgpr_stride + 1),
                    vgpr_num=loop_row_size,
                    sync_id=sync_index,
                    usharp_id=self.usharpid_input_4d_activation,
                    x_inc=x_inc)
            else:
                self._do_core_alu_on_col(ele*self.vgpr_stride, loop_row_size, coord_sgpr_list, y_border_type, x_inc=x_inc)
            x_inc += hwCaps.TileSizeX()

        self.sadd.generate(
            indent_level=self._get_indent(),
            dst=coord_sgpr_list[0],
            src1=coord_sgpr_list[0],
            src2=str(x_inc),
            comment="// Move to next func call col start ")

        if loop_mode != 0:
            self.sadda.generate(
                indent_level=self._get_indent(),
                dst=self.vgpr_base,
                src1=self.vgpr_base,
                src2=self.vgpr_stride,
                comment="// Increase vgpr base address")
            self.sadd.generate(
                indent_level=self._get_indent(),
                dst=vgpr_base_sgpr,
                src1=vgpr_base_sgpr,
                src2=self.vgpr_stride,
                comment="// Save vgpr base address to sgpr")
            if loop_col_num > 1:
                self.flow_man.for_loop_close()
            right_border_shift = 0
        else:
            right_border_shift = loop_unroll_num #0 if loop_unroll_num > 1 else loop_unroll_num

        if func_type != self.FUNC_TYPE_LOAD and \
            right_border_mode != 0 and \
            self.image_width_res != 0:
            right_border_type = self.BORDER_TYPE_RIGHT | y_border_type
            self._do_core_alu_on_col(
                right_border_shift*self.vgpr_stride, loop_row_size, 
                coord_sgpr_list, right_border_type)

        if loop_mode == 0:
            x_advance_step = 0
        else:
            x_advance_step = loop_col_num

        x_advance_step = self.block_size_x - x_advance_step
        vgpr_base_shift = self.vgpr_stride * x_advance_step

        if vgpr_base_shift != 0:
            self.sadd.generate(
                indent_level=self._get_indent(),
                dst=vgpr_base_sgpr,
                src1=vgpr_base_sgpr,
                src2=str(vgpr_base_shift),
                comment="// Adjust vgpr base, most time no need")

        if loop_mode != 0:
            self.resource_man.free_wsr(temp_x_index_sgpr)
            
    def _create_all_subfuncs(self):
        func_def_map = self.fun_gen_handler.getFuncDef()
        for x, y in func_def_map.items():
            func_keys = x.split("_")
            self.flow_man.start_function_def(x, False)
            self.flow_man.set_label_index(0)
            self.flow_man.set_label_suffix(x.upper())
            self.flow_man.set_temp_start(y[0])
            self.flow_man.set_stack_start(y[1])

            func_type = func_keys[5]
            y_border_type = int(func_keys[6])
            y_block_height = int(func_keys[7])
            if func_type == self.FUNC_TYPE_LOAD:
                sync_index = int(func_keys[8])
                right_border_mode = int(func_keys[9])
            else:
                sync_index = 0
                right_border_mode = int(func_keys[8])
            self._create_single_subfunc(
                func_type, y_border_type, y_block_height,
                right_border_mode, sync_index)

            self.flow_man.close_function_def(x, False)

    # def _create_single_macro(
    #         self, func_type, y_border_type, 
    #         y_block_height, right_border_mode, sync_index):
    #     if func_type == self.FUNC_TYPE_LOAD:
    #         x_axis_sgpr = self.load_in_x_axis_sgpr
    #         y_axis_sgpr = self.load_in_y_axis_sgpr
    #         vgpr_base_sgpr = self.vgpr_load_base_sgpr
    #         loop_unroll_threshold = self.LOAD_LOOP_UNROLL_THRESHOLD
    #     else:
    #         x_axis_sgpr = self.alu_in_x_axis_sgpr
    #         y_axis_sgpr = self.alu_in_y_axis_sgpr
    #         vgpr_base_sgpr = self.vgpr_alu_base_sgpr
    #         loop_unroll_threshold = self.ALU_LOOP_UNROLL_THRESHOLD    
        
    #     if right_border_mode == 0:
    #         loop_col_num = self.block_size_x
    #     elif func_type == self.FUNC_TYPE_LOAD or \
    #             self.image_width_res == 0:
    #         loop_col_num = self.partial_block_width + 1
    #     else:
    #         loop_col_num = self.partial_block_width

    #     if loop_col_num == 0 or loop_col_num < loop_unroll_threshold:
    #         loop_mode = 0
    #     else:
    #         loop_mode = 1

    #     self.flow_man.start_if_loop(
    #         vgpr_base_sgpr, 
    #         str(self.vgpr_index_end-loop_col_num*self.vgpr_stride),
    #         ">=", 0, local_label=True, local_label_value=0)
    #     self.smov.generate(
    #         indent_level=self._get_indent(),
    #         dst=vgpr_base_sgpr,
    #         src1=self.vgpr_start,
    #         comment="// Check vgpr base, wrap back if exceeding the range")

    #     self.flow_man.close_if_loop(local_label=True, local_label_value=0)

    #     self.smovs.generate(
    #         indent_level=self._get_indent(),
    #         dst=self.vgpr_base,
    #         src1=vgpr_base_sgpr,
    #         comment="// Restore the vgpr base address")
        
    #     if loop_mode != 0:
    #         temp_x_index_sgpr = self._alloc_wsr("temp_x_index")
    #         self.smov.generate(
    #             indent_level=self._get_indent(),
    #             dst=temp_x_index_sgpr,
    #             src1=0,
    #             comment="// Set loop start from 0")
    #         if loop_col_num > 1:
    #             self.flow_man.for_loop_start(
    #                 "", str(loop_col_num-1), "1", temp_x_index_sgpr,
    #                 comment="// Loop in x direction")
    #         loop_unroll_num = 1
    #     else:
    #         loop_unroll_num = loop_col_num

    #     coord_sgpr_list = [
    #         x_axis_sgpr, y_axis_sgpr, 
    #         self.z_axis_sgpr, self.w_axis_sgpr]
    #     loop_row_size = y_block_height
    #     if y_border_type & self.BORDER_TYPE_BOTTOM:
    #         loop_row_size +=1
    #     x_inc = 0
    #     for ele in range(loop_unroll_num):
    #         if func_type == self.FUNC_TYPE_LOAD:
    #             self.activation_loader.generate(
    #                 indent_obj=self._get_indent(),
    #                 mem_format=hwCaps.SurfaceFormatFP16(),
    #                 gpr_format=hwCaps.SurfaceFormatFP16(),
    #                 coord_sgpr_list=coord_sgpr_list,
    #                 vgpr_address=-(ele*self.vgpr_stride + 1),
    #                 vgpr_num=loop_row_size,
    #                 sync_id=sync_index,
    #                 usharp_id=self.usharpid_input_4d_activation,
    #                 x_inc=x_inc)
    #         else:
    #             self._do_core_alu_on_col(ele*self.vgpr_stride, loop_row_size, coord_sgpr_list, y_border_type, x_inc=x_inc)
    #         x_inc += hwCaps.TileSizeX()
        
    #     self.sadd.generate(
    #         indent_level=self._get_indent(),
    #         dst=coord_sgpr_list[0],
    #         src1=coord_sgpr_list[0],
    #         src2=str(x_inc),
    #         comment="// Move to next func call col start ")

    #     if loop_mode != 0:
    #         self.sadda.generate(
    #             indent_level=self._get_indent(),
    #             dst=self.vgpr_base,
    #             src1=self.vgpr_base,
    #             src2=self.vgpr_stride,
    #             comment="// Increase vgpr base address")
    #         self.sadd.generate(
    #             indent_level=self._get_indent(),
    #             dst=vgpr_base_sgpr,
    #             src1=vgpr_base_sgpr,
    #             src2=self.vgpr_stride,
    #             comment="// Save vgpr base address to sgpr")
    #         if loop_col_num > 1:
    #             self.flow_man.for_loop_close()
    #         right_border_shift = 0
    #     else:
    #         right_border_shift = loop_unroll_num #0 if loop_unroll_num > 1 else loop_unroll_num

    #     if func_type != self.FUNC_TYPE_LOAD and \
    #         right_border_mode != 0 and \
    #         self.image_width_res != 0:
    #         right_border_type = self.BORDER_TYPE_RIGHT | y_border_type
    #         self._do_core_alu_on_col(
    #             right_border_shift*self.vgpr_stride, loop_row_size, 
    #             coord_sgpr_list, right_border_type)

    #     if loop_mode == 0:
    #         x_advance_step = 0
    #     else:
    #         x_advance_step = loop_col_num

    #     x_advance_step = self.block_size_x - x_advance_step
    #     vgpr_base_shift = self.vgpr_stride * x_advance_step

    #     if vgpr_base_shift != 0:
    #         self.sadd.generate(
    #             indent_level=self._get_indent(),
    #             dst=vgpr_base_sgpr,
    #             src1=vgpr_base_sgpr,
    #             src2=str(vgpr_base_shift),
    #             comment="// Adjust vgpr base, most time no need")

    #     if loop_mode != 0:
    #         self.resource_man.free_wsr(temp_x_index_sgpr)

    def _create_inplace_macro(
            self, func_type, y_border_type, 
            y_block_height, right_border_mode, sync_index):
        if func_type == self.FUNC_TYPE_LOAD:
            x_axis_sgpr = self.load_in_x_axis_sgpr
            y_axis_sgpr = self.load_in_y_axis_sgpr
            vgpr_base_sgpr = self.vgpr_load_base_sgpr
            loop_unroll_threshold = self.LOAD_LOOP_UNROLL_THRESHOLD
        else:
            x_axis_sgpr = self.alu_in_x_axis_sgpr
            y_axis_sgpr = self.alu_in_y_axis_sgpr
            vgpr_base_sgpr = self.vgpr_alu_base_sgpr
            loop_unroll_threshold = self.ALU_LOOP_UNROLL_THRESHOLD    
        
        if right_border_mode == 0:
            loop_col_num = self.block_size_x
        elif func_type == self.FUNC_TYPE_LOAD or \
                self.image_width_res == 0:
            loop_col_num = self.partial_block_width + 1
        else:
            loop_col_num = self.partial_block_width

        if loop_col_num == 0 or loop_col_num < loop_unroll_threshold:
            loop_mode = 0
        else:
            loop_mode = 1

        #handle blts const
        pseudo_register = isinstance(vgpr_base_sgpr, str) and vgpr_base_sgpr.startswith("imm_")
        if not pseudo_register:
            self.flow_man.start_if_loop(
                vgpr_base_sgpr, 
                str(self.vgpr_index_end-loop_col_num*self.vgpr_stride),
                ">=", 0)
            self.smov.generate(
                indent_level=self._get_indent(),
                dst=vgpr_base_sgpr,
                src1=self.vgpr_start,
                comment="// Check vgpr base, wrap back if exceeding the range")

            self.flow_man.close_if_loop()
        else:
            v = self.resource_man.get_immediate_variable_value(vgpr_base_sgpr)
            if v >= self.vgpr_index_end-loop_col_num*self.vgpr_stride:
                self.resource_man.assign_immediate_variable(vgpr_base_sgpr, self.vgpr_start)

        self.smovs.generate(
            indent_level=self._get_indent(),
            dst=self.vgpr_base,
            src1=vgpr_base_sgpr,
            comment="// Restore the vgpr base address")
        
        if loop_mode != 0:
            temp_x_index_sgpr = self._alloc_wsr("temp_x_index")
            self.smov.generate(
                indent_level=self._get_indent(),
                dst=temp_x_index_sgpr,
                src1=0,
                comment="// Set loop start from 0")
            if loop_col_num > 1:
                self.flow_man.for_loop_start(
                    "", str(loop_col_num-1), "1", temp_x_index_sgpr,
                    comment="// Loop in x direction")
            loop_unroll_num = 1
        else:
            loop_unroll_num = loop_col_num

        coord_sgpr_list = [
            x_axis_sgpr, y_axis_sgpr, 
            self.z_axis_sgpr, self.w_axis_sgpr]
        loop_row_size = y_block_height
        if y_border_type & self.BORDER_TYPE_BOTTOM:
            loop_row_size +=1
        x_inc = 0
        for ele in range(loop_unroll_num):
            if func_type == self.FUNC_TYPE_LOAD:
                self.activation_loader.generate(
                    indent_obj=self._get_indent(),
                    mem_format=hwCaps.SurfaceFormatFP16(),
                    gpr_format=hwCaps.SurfaceFormatFP16(),
                    coord_sgpr_list=coord_sgpr_list,
                    vgpr_address=-(ele*self.vgpr_stride + 1),
                    vgpr_num=loop_row_size,
                    sync_id=sync_index,
                    usharp_id=self.usharpid_input_4d_activation,
                    x_inc=x_inc)
            else:
                self._do_core_alu_on_col_bundle(ele*self.vgpr_stride, loop_row_size, coord_sgpr_list, y_border_type, x_inc=x_inc)
            x_inc += hwCaps.TileSizeX()
        
        self.sadd.generate(
            indent_level=self._get_indent(),
            dst=coord_sgpr_list[0],
            src1=coord_sgpr_list[0],
            src2=str(x_inc),
            comment="// Move to next func call col start ")

        if loop_mode != 0:
            self.sadda.generate(
                indent_level=self._get_indent(),
                dst=self.vgpr_base,
                src1=self.vgpr_base,
                src2=self.vgpr_stride,
                comment="// Increase vgpr base address")
            self.sadd.generate(
                indent_level=self._get_indent(),
                dst=vgpr_base_sgpr,
                src1=vgpr_base_sgpr,
                src2=self.vgpr_stride,
                comment="// Save vgpr base address to sgpr")
            if loop_col_num > 1:
                self.flow_man.for_loop_close()
            right_border_shift = 0
        else:
            right_border_shift = loop_unroll_num #0 if loop_unroll_num > 1 else loop_unroll_num

        if func_type != self.FUNC_TYPE_LOAD and \
            right_border_mode != 0 and \
            self.image_width_res != 0:
            right_border_type = self.BORDER_TYPE_RIGHT | y_border_type
            self._do_core_alu_on_col_bundle(
                right_border_shift*self.vgpr_stride, loop_row_size, 
                coord_sgpr_list, right_border_type)

        if loop_mode == 0:
            x_advance_step = 0
        else:
            x_advance_step = loop_col_num

        x_advance_step = self.block_size_x - x_advance_step
        vgpr_base_shift = self.vgpr_stride * x_advance_step

        if vgpr_base_shift != 0:
            self.sadd.generate(
                indent_level=self._get_indent(),
                dst=vgpr_base_sgpr,
                src1=vgpr_base_sgpr,
                src2=str(vgpr_base_shift),
                comment="// Adjust vgpr base, most time no need")

        if loop_mode != 0:
            self.resource_man.free_wsr(temp_x_index_sgpr)
            
    def _create_all_macros(self):
        func_def_map = self.fun_gen_handler.getFuncDef()
        for x, y in func_def_map.items():
            func_keys = x.split("_")
            if not self.ENABLE_INPLACE_MACRO:
                self.flow_man.start_macro_def(x, False)
            self.flow_man.set_label_index(0)
            self.flow_man.set_label_suffix(x.upper())
            self.flow_man.set_temp_start(y[0])
            self.flow_man.set_stack_start(y[1])

            func_type = func_keys[5]
            y_border_type = int(func_keys[6])
            y_block_height = int(func_keys[7])
            if func_type == self.FUNC_TYPE_LOAD:
                sync_index = int(func_keys[8])
                right_border_mode = int(func_keys[9])
            else:
                sync_index = 0
                right_border_mode = int(func_keys[8])
            if not self.ENABLE_INPLACE_MACRO:
                self._create_single_subfunc(
                    func_type, y_border_type, y_block_height,
                    right_border_mode, sync_index)

                self.flow_man.close_macro_def(x, False)


    def _gen_channel_loop_header(self):
        # To keep compatible with UT cases
        if self.outer_oc_cfg is None and self.inner_oc_cfg is None:
            self.flow_man.for_loop_start(
                self.z_axis_sgpr, str(self.src_channel-self.CHANNEL_GRANDULE),
                str(self.CHANNEL_GRANDULE), self.z_axis_sgpr,
                comment="// Loop channel axis", accum_start_value=True)
            if not self.micro_batch_mode: 
                self.bar.generate(
                    indent=self._get_indent(), 
                    scope="tg", mode="sync",
                    src1=self.reduce_2_bn_barid_sgpr,
                    src2=bcd.BAR_CHANNELS_WITHIN_VECTOR,
                    comment="// Waiting for reduction buffer ready to use")

        if self.outer_oc_cfg is not None:
            self.flow_man.for_loop_start("", 
                str(self.outer_oc_cfg["max_value"]-self.outer_oc_cfg["inc"]),
                str(self.outer_oc_cfg["inc"]), self.outer_oc_cfg["sgpr"],
                comment="// Loop outer channel axis for pingpong")

        if self.inner_oc_cfg is not None:
            if not self.micro_batch_mode:
                self.bar.generate(
                    indent=self._get_indent(), 
                    scope="tg", mode="sync",
                    src1=self.reduce_2_bn_barid_sgpr,
                    src2=bcd.BAR_CHANNELS_WITHIN_VECTOR,
                    comment="// Waiting for reduction buffer ready to use")
            self.flow_man.for_loop_start(self.inner_oc_cfg["sgpr"], 
                str(self.inner_oc_cfg["max_value"] - self.inner_oc_cfg["inc"]),
                str(self.inner_oc_cfg["inc"]), self.inner_oc_cfg["sgpr"],
                comment="// Loop inner channel axis", accum_start_value=True) 
            if self.outer_oc_cfg is not None:
                self.sadd.generate(
                    indent_level=self._get_indent(),
                    dst=self.z_axis_sgpr,
                    src1=self.inner_oc_cfg["sgpr"],
                    src2=self.outer_oc_cfg["sgpr"],
                    comment="// Combine z index with eu id, loop index")           
            else:
                self.smov.generate(
                    indent_level=self._get_indent(),
                    dst=self.z_axis_sgpr,
                    src1=self.inner_oc_cfg["sgpr"],
                    comment="// Initialize z index with eu id")
            if self.inner_oc32_cfg is not None:
                assert self.inner_oc_cfg["inc"] == 64, "Inner oc inc should be 64"
                if self.micro_batch_mode and self.src_sample > 1:
                    self.flow_man.for_loop_start(
                        "", str(self.src_sample-1), str(1), 
                        self.w_axis_sgpr,
                        comment="// Loop sample axis")

                if self.micro_batch_mode:       
                    self.bar.generate(
                        indent=self._get_indent(), 
                        scope="tg", mode="sync",
                        src1=self.reduce_2_bn_barid_sgpr,
                        src2=bcd.BAR_CHANNELS_WITHIN_VECTOR,
                        comment="// Waiting for reduction buffer ready to use")

                    self._load_gamma_beta_sum_ssum()

                self.flow_man.for_loop_start("", 
                    str(self.inner_oc32_cfg["max_value"] - self.inner_oc32_cfg["inc"]),
                    str(self.inner_oc32_cfg["inc"]), self.inner_oc32_cfg["sgpr"],
                    comment="// Loop per every 32 oc per 64oc innermost")
                self.sadd.generate(
                    indent_level=self._get_indent(),
                    dst=self.z_axis_sgpr,
                    src1=self.z_axis_sgpr,
                    src2=self.inner_oc32_cfg["sgpr"],
                    comment="// Split 64oc to smaller 32oc, maybe unroll is better") 


    def __shift_channel_pingpong_status(self):
        self.bar.generate(
            indent=self._get_indent(),
            scope="tg", mode="pass",
            src1=self.bn_2_reduce_barid_sgpr,
            src2=bcd.BAR_CHANNELS_WITHIN_VECTOR,
            comment="// Inform reduce to start next")
        self.sxor.generate(
            indent_level=self._get_indent(),
            dst=self.bn_2_reduce_barid_sgpr,
            src1=self.bn_2_reduce_barid_sgpr,
            src2=1,
            comment="// Toggle bn->reduce bar id")
        self.sxor.generate(
            indent_level=self._get_indent(),
            dst=self.reduce_2_bn_barid_sgpr,
            src1=self.reduce_2_bn_barid_sgpr,
            src2=1,
            comment="// Toggle reduce->bn bar id")

    def _gen_channel_loop_tailer(self):
        if self.inner_oc_cfg is not None:
            if self.inner_oc32_cfg is not None:
                self.flow_man.for_loop_close()
                if self.micro_batch_mode and self.src_sample > 1:
                    self.__shift_channel_pingpong_status()
                    self.flow_man.for_loop_close()
            self.flow_man.for_loop_close()
            if not self.micro_batch_mode:
                self.__shift_channel_pingpong_status()
        if self.outer_oc_cfg is not None:
            self.flow_man.for_loop_close()

        if self.inner_oc_cfg is None and self.outer_oc_cfg is None:
            if not self.micro_batch_mode:
                self.__shift_channel_pingpong_status()
            self.flow_man.for_loop_close()  


    def _process_channel_loop(self):
        self._gen_channel_loop_header()
        
        if not self.micro_batch_mode:
            if self.src_sample <= 1:
                self.smov.generate(
                    indent_level=self._get_indent(),
                    dst=self.w_axis_sgpr,
                    src1=0,
                    comment="// Initialize sample index")
            self._load_gamma_beta_sum_ssum()

        if self.src_sample > 1 and (
            self.inner_oc32_cfg is None or (
                not self.micro_batch_mode)):
            self.flow_man.for_loop_start(
                "", str(self.src_sample-1), str(1), 
                self.w_axis_sgpr,
                comment="// Loop sample axis")
           
        self.smov.generate(
            indent_level=self._get_indent(),
            dst=self.load_in_y_axis_sgpr,
            src1=0,
            comment="// Initialize load's y coordinate")

        self.smov.generate(
            indent_level=self._get_indent(),
            dst=self.alu_in_y_axis_sgpr,
            src1=0,
            comment="// Initialize alu's y coordiate")

        has_parameters_calculated = False
        for y_span in self.y_span_list:
            y_span_height = y_span["SpanHeight"]
            y_block_height = y_span["BlockHeight"]
            y_border_flag = y_span["BorderFlag"]

            y_block_num = 1 if y_block_height == 0 else \
                            int(y_span_height / y_block_height)
            x_block_num = 1 if self.block_size_x == 0 else \
                            int(self.x_align_size / self.block_size_x)
            enable_height_unroll = True if y_block_num > 1 and y_block_num < self.HEIGHT_LOOP_UNROLL_THRESHOLD else False
            if y_block_num > 1 and y_block_num > self.HEIGHT_LOOP_UNROLL_THRESHOLD:
                y_sgpr = self._alloc_wsr("y_loop_sgpr")
                self.flow_man.for_loop_start(str(0), str(y_block_num-1), str(1), 
                    y_sgpr, comment="// Loop height/y axis")

            loop_num_in_x = (x_block_num - 3) >> 1
            if loop_num_in_x < 0:
                loop_num_in_x = 0
            x_block_remain_num = x_block_num - (loop_num_in_x << 1)
            for i in range(y_block_num if enable_height_unroll else 1):
                self.smov.generate(
                    indent_level=self._get_indent(), 
                    dst=self.load_in_x_axis_sgpr,
                    src1=0,
                    comment="// Initialize load's x coordinate")
                self.smov.generate(
                    indent_level=self._get_indent(),
                    dst=self.alu_in_x_axis_sgpr,
                    src1=0,
                    comment="// Initialize alu's x coordinate")
                if not self.ENABLE_MACRO:
                    self._create_subfunc_call(
                        "load", y_border_flag, y_block_height,
                        "1", str(1 if x_block_num == 1 else 0))
                else:
                    self._create_macro_call(
                        "load", y_border_flag, y_block_height,
                        "1", str(1 if x_block_num == 1 else 0))

                if x_block_num > 1:
                    if not self.ENABLE_MACRO:
                        self._create_subfunc_call(
                            "load", y_border_flag, y_block_height,
                            "2", str(1 if x_block_num == 2 else 0))
                    else:
                        self._create_macro_call(
                            "load", y_border_flag, y_block_height,
                            "2", str(1 if x_block_num == 2 else 0))
    
                self.nop.generate(
                    indent_level=self._get_indent(),
                    modifier="sc1",
                    comment="// Wait for sync channel 1")

                if not has_parameters_calculated:
                    self._calculate_params_for_alu()
                    has_parameters_calculated = True
                
                if loop_num_in_x > 1:
                    x_sgpr = self._alloc_wsr("x_loop_sgpr")
                    self.flow_man.for_loop_start(
                        str(0), str(loop_num_in_x-1), str(1), 
                        x_sgpr, 
                        comment="// Loop width axis")

                if loop_num_in_x > 0:
                    if not self.ENABLE_MACRO:
                        self._create_subfunc_call(
                            "alu", y_border_flag, y_block_height, "", 0)
                        self._create_subfunc_call(
                            "load", y_border_flag, y_block_height, "1", 0)
                    else:
                        self._create_macro_call(
                            "alu", y_border_flag, y_block_height, "", 0)
                        self._create_macro_call(
                            "load", y_border_flag, y_block_height, "1", 0)

                    self.nop.generate(
                        indent_level=self._get_indent(),
                        modifier="sc2",
                        comment="// Wait for sync channel 2")

                    if not self.ENABLE_MACRO:
                        self._create_subfunc_call(
                            "alu", y_border_flag, y_block_height, "", 0)
                        self._create_subfunc_call(
                            "load", y_border_flag, y_block_height, "2", 0)
                    else:
                        self._create_macro_call(
                            "alu", y_border_flag, y_block_height, "", 0)
                        self._create_macro_call(
                            "load", y_border_flag, y_block_height, "2", 0)
                    
                    self.nop.generate(
                        indent_level=self._get_indent(),
                        modifier="sc1",
                        comment="// Wait for sync channel 1")
                
                if loop_num_in_x > 1:
                    self.flow_man.for_loop_close()
                    self._free_wsr(x_sgpr)
                if not self.ENABLE_MACRO:
                    self._create_subfunc_call(
                        "alu", y_border_flag, y_block_height, "", 
                        str(1 if x_block_num == 1 else 0))
                else:
                    self._create_macro_call(
                        "alu", y_border_flag, y_block_height, "", 
                        str(1 if x_block_num == 1 else 0))

                if x_block_remain_num >= 3:
                    if not self.ENABLE_MACRO:
                        self._create_subfunc_call(
                            "load", y_border_flag, y_block_height, 
                            "1", str(1 if x_block_remain_num == 3 else 0))
                    else:
                        self._create_macro_call(
                            "load", y_border_flag, y_block_height, 
                            "1", str(1 if x_block_remain_num == 3 else 0))

                if x_block_num > 1:
                    self.nop.generate(
                        indent_level=self._get_indent(),
                        modifier="sc2",
                        comment="// Wait for sync channel 2")
                    if not self.ENABLE_MACRO:
                        self._create_subfunc_call(
                            "alu", y_border_flag, y_block_height,
                            "", str(1 if x_block_num == 2 else 0))
                    else:
                        self._create_macro_call(
                        "alu", y_border_flag, y_block_height,
                        "", str(1 if x_block_num == 2 else 0))                  
                
                    if x_block_remain_num >= 4:
                        if not self.ENABLE_MACRO:
                            self._create_subfunc_call(
                                "load", y_border_flag, y_block_height, 
                                "2", str(1))
                        else:
                            self._create_macro_call(
                            "load", y_border_flag, y_block_height, 
                            "2", str(1))

                    if x_block_remain_num >= 3:
                        self.nop.generate(
                            indent_level=self._get_indent(),
                            modifier="sc1",
                            comment="// Wait for sync channel 1")
                        if not self.ENABLE_MACRO:
                            self._create_subfunc_call(
                                "alu", y_border_flag, y_block_height, 
                                "", str(1 if x_block_num == 3 else 0))
                        else:
                            self._create_macro_call(
                                "alu", y_border_flag, y_block_height, 
                                "", str(1 if x_block_num == 3 else 0))

                    if x_block_remain_num >= 4:
                        self.nop.generate(
                            indent_level=self._get_indent(),
                            modifier="sc2",
                            comment="// Wait for sync channel 2")
                        if not self.ENABLE_MACRO:
                            self._create_subfunc_call(
                                "alu", y_border_flag, y_block_height, 
                                "", str(1))
                        else:
                            self._create_macro_call(
                                "alu", y_border_flag, y_block_height, 
                                "", str(1))

                if (y_border_flag & self.BORDER_TYPE_BOTTOM) == 0:
                    self.sadd.generate(
                        indent_level=self._get_indent(),
                        dst=self.load_in_y_axis_sgpr,
                        src1=self.load_in_y_axis_sgpr,
                        src2=y_block_height*self.TILE_SIZE_Y,
                        comment="// Adjust load y")
                    self.sadd.generate(
                        indent_level=self._get_indent(),
                        dst=self.alu_in_y_axis_sgpr,
                        src1=self.alu_in_y_axis_sgpr,
                        src2=y_block_height*self.TILE_SIZE_Y,
                        comment="// Adjust alu y")

            if y_block_num > 1 and y_block_num > self.HEIGHT_LOOP_UNROLL_THRESHOLD:
                self._alloc_wsr("y_loop_sgpr")
                self.flow_man.for_loop_close()

        if self.src_sample > 1 and (
            self.inner_oc32_cfg is None or (
                not self.micro_batch_mode)):
            self.flow_man.for_loop_close()
        
        self._gen_channel_loop_tailer()
        
