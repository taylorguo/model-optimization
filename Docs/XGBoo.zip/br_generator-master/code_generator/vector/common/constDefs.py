#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import code_generator.share.br_const_defs as cfgs
import code_generator.share.br_utils as utils

FuncType = {
    "load" : 0,
    "alu" : 1
}


AccumlationMode = {
    "accu" : 0,
    "add" : 1,
    "mov" : 2
}

##############################################################################
#bn funcs related consts
REDUCE_ON_INDEX = 6
RELU_ON_INDEX = 7

GAMMA_USHARP_INDEX = 1
BN_LOAD_LOOP_UNROLL_THRESHOLD = 2
BN_ALU_LOOP_UNROLL_THRESHOLD = 2

BUFFER_ROW_MODE_THRESHOLD_X = 8
BUFFER_ROW_MODE_THRESHOLD_Y = 3
BUFFER_BLOCK_MODE = 0
BUFFER_SURFACE_MODE = 1
BUFFER_ROW_MODE = 2
BUFFER_COL_MODE = 3

BORDER_TYPE_BOTTOM = 1
BORDER_TYPE_BOTTOM_PARTIAL = 2
BORDER_TYPE_TOP = 4
BORDER_TYPE_RIGHT = 8
BORDER_TYPE_LEFT = 16
BORDER_TYPE_RIGHT_PARTIAL = 32

BORDER_TYPE_ALL = BORDER_TYPE_BOTTOM | BORDER_TYPE_RIGHT | BORDER_TYPE_TOP
##############################################################################

#hwCaps related consts
WARP_SIMT_ID = 2

TILE_SIZE_X = 8
TILE_SIZE_Y = 4


SurfaceFormatType = {
    "float" : 0,
    "uint" : 1,
    "sint" : 2,
    "mask" : 3
}

SurfaceFormatBpp = {
    "mask" : 4,
    "16" : 4,
    "32" : 0
}

SurfaceType = {
    "1DVector" : 0,
    "2DWeight" : 1,
    "3DActivation" : 2,
    "4DWeight" : 3
}

SURFACE_FORMAT_FP16 = SurfaceFormatType.get("float") | SurfaceFormatBpp.get("16")
SURFACE_FORMAT_FP32 = SurfaceFormatType.get("float") | SurfaceFormatBpp.get("32")
SURFACE_FORMAT_UINT16 = SurfaceFormatType.get("uint") | SurfaceFormatBpp.get("16")
SURFACE_FORMAT_UINT32 = SurfaceFormatType.get("uint") | SurfaceFormatBpp.get("32")

MAX_LOAD_GRANULE = 4 # max tlr number burst together
MAX_STORE_GRANULE = 4 # max tlr numbfers burst together
MAX_LDM_GRANULE = 8
MAX_STM_GRANULE = 4
MAX_ALU_GRANULE = 8
MAX_MOV_GRANULE = 8
MAX_LLDW_GRANULE = 8
MAX_BN_GRANULE = 4
MAX_IMM = 127
##############################################################################

#Cwarp related configuration
CWARP_NUMBER = 5
CMD_INDEX = 0
UHSARP_INDEX = 1
VGPR_PARTITION_INDEX = 2
OPTIONS_INDEX = 3

REDUCE_2_BN_SYNC_BAR_ID = 8
BN_2_REDUCE_SYNC_BAR_ID = 6

ALL_SYNC_WBAR_ID = 1
DWC_LDDW_WBAR_ID = 2
CONV_2_REDUCE_WBAR_ID = 4
REDUCE_2_CONV_WBAR_ID = 6


#flowLib related consts
FLOW_NAME = " "
FLOW_DEFAULT_INDENT_STRING = ""
FLOW_TEMP_START_INDEX = 4
FLOW_STACK_START_INDEX = 31
INDENT_DEFAULT_SIZE = 4
VGPR_CAPCITY_SIZE = 256
COMMENT_POS = 64

#Usharp information
USHARP_SURF_ID_INDEX = 0
USHARP_SURF_COORD_SAMPLE_INDEX = 2
USHARP_SURF_COORD_CHAN_INDEX = 3
USHARP_SURF_COORD_Y_INDEX = 4
USHARP_SURF_COORD_X_INDEX = 5

LayerSubType = {
    "fc_fw1" : 0,
    "fc_fw2" : 1,
    "fc_bk1" : 2,
    "fc_bk2" : 3
}
