#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import vector.common.flowLib as flowLib
import vector.common.hwCaps as hwCaps
import vector.common.funcLib as funcLib
import vector.common.cwarp as cwarp

from code_generator.share.br_defined_print import br_print


def	get_accmulation_mode_mov():
  return 1


def	get_accmulation_mode_add():
  return 2


def	get_accmulation_mode_accu():
  return 0

####################################################
#


def GetSyncModifier(syncId):
  if (syncId == 0):
    syncStr = ""
  else:
    syncStr = ".sc" + str(syncId)

  return syncStr


def GetVectorModifier(vectorSize, typeChar):
  if vectorSize == 1:
    vectorStr = ""
  else:
    vectorStr = "." + typeChar + str(vectorSize)

  return vectorStr

def GetVectorModifierWithoutDot(vectorSize, typeChar):
  vectorStr = typeChar + str(vectorSize)
  return vectorStr


def GetGCModifier(count):
  return ".gc" + str(count)


def GetStrideEnableMask():
  return 1


def GetStrideGroupFlagXMask():
  return 2


def GetStrideGroupFlagYMask():
  return 4


# bit 0 indicates whether stride 2 is enabled
# bit 1 indicates x position
# bit 2 indicates y position
def GetStrideGroupModifier(stride2Flag):
  if ((stride2Flag & 1) == 0):
    return ""
  else:
    return ".grp" + str(stride2Flag >> 1)


def GetDataTypeModifier(dataFormat):
  dataType = hwCaps.GetSurfaceFormatType(dataFormat)

  if (dataType == hwCaps.SurfaceFormatTypeFloat()):
    return ".float"
  else:
    return ".uint"


# mdem comes from descriptor, so not needed at here per ISA
def GetFormatModifier_GPR(gprFormat):
  formatStr = GetDataTypeModifier(gprFormat)
  dataSize = hwCaps.GetSurfaceFormatBpp(gprFormat)

  if (dataSize == hwCaps.SurfaceFormatBPP16()):
    formatStr += ".rb16"
    elementPerVGPR = 2
  else:
    formatStr += ".rb32"
    elementPerVGPR = 1

  return (formatStr, elementPerVGPR)


def GetFormatModifier_Full(memFormat, gprFormat):
  memDataSize = hwCaps.GetSurfaceFormatBpp(memFormat)
  formatStr = GetDataTypeModifier(memFormat)

  if (memDataSize == hwCaps.SurfaceFormatBPP16()):
    formatStr += ".mb16"
    memElementPerVGPR = 2
  elif (memDataSize == hwCaps.SurfaceFormatBPP8()):
    formatStr += ".mb8"
    memElementPerVGPR = 4
  else:
    formatStr += ".mb32"
    memElementPerVGPR = 1

  gprDataSize = hwCaps.GetSurfaceFormatBpp(gprFormat)

  if (gprDataSize == hwCaps.SurfaceFormatBPP16()):
    formatStr += ".rb16"
  elif (gprDataSize == hwCaps.SurfaceFormatBPP8()):
    formatStr += ".rb8"
  else:
    formatStr += ".rb32"

  return (formatStr, memElementPerVGPR)


# TODO: to confirm with bozhan on the implementation
def GetLSFormatModifier(memFormat, gprFormat):
  memDataSize = hwCaps.GetSurfaceFormatBpp(memFormat)
  formatStr = GetDataTypeModifier(memFormat)

  if (memDataSize == hwCaps.SurfaceFormatBPP16()):
    formatStr += ".mb16"
    memElementPerVGPR = 2
  else:
    formatStr += ".mb32"
    memElementPerVGPR = 1

  gprDataSize = hwCaps.GetSurfaceFormatFloat(gprFormat)

  if (gprDataSize == hwCaps.SurfaceFormatFP16()):
    formatStr += ".float.rb16"
  else:
    formatStr += ".float.rb32"

  return (formatStr, memElementPerVGPR)


def GetStoreFormatModifier(memFormat):
  memDataSize = hwCaps.GetSurfaceFormatBpp(memFormat)
  formatStr = GetDataTypeModifier(memFormat)

  if (memDataSize == hwCaps.SurfaceFormatBPP16()):
    formatStr += ".mb16"
    scale = 2
  else:
    formatStr += ".mb32"
    scale = 1

  return (formatStr, scale)


def GetGPRFormatModifier(dataFormat):

  dataType = hwCaps.GetSurfaceFormatType(dataFormat)
  dataSize = hwCaps.GetSurfaceFormatBpp(dataFormat)

  if (dataType == hwCaps.SurfaceFormatTypeFloat()):
    formatStr = ".f"
  else:
    formatStr = ".u"

  if (dataSize == hwCaps.SurfaceFormatBPP16()):
    formatStr += "16"
    bpp = 2
  else:
    formatStr += "32"
    bpp = 4

  return (formatStr, bpp)


####################################################
#
def	jump_to_next_layer(layerId, layerNumber, warpId, indentstring):
  if layerNumber < 2:
    br_print (indentstring)
    funcLib.AlignPrint(indentstring + "bar.wtg.sync.cnt " + str(cwarp.GetAllSyncWBarId()) + ", " + str(cwarp.CWarpNumber() << 4), flowLib.GetCommentPos(), "//all warps sync at here before switch to next layer")
    br_print (indentstring + "jump.rel " + ("layer_" + str(layerId + 1) + "_warp_" + str(warpId) + "_main_kernel").upper(), comment="//current finish layer finishes, switch to next layer")


####################################################
#
# temp should be of the same size as src
# accumulate result will be written back to src
def	butterfly_sum(srcVGPRAddr, srcVGPRNumber, tempVGPRAddr, vgprLaneNumber, indentstring):

  if vgprLaneNumber == 1:
    return

  leadingOne = funcLib.GetLeadingOnePos(vgprLaneNumber)

  if (vgprLaneNumber != funcLib.AlignToPower2(vgprLaneNumber)):
    leadingOne += 1

  for butterflyIndex in range (leadingOne):
    for vgprIndex in range (srcVGPRNumber):
      thisSrcAddr = srcVGPRAddr + vgprIndex
      thisTempAddr = tempVGPRAddr + vgprIndex
      syncChannel = vgprIndex + 1
      br_print (indentstring + "mov g0.f32, r" + str(thisSrcAddr) + ".f32")
      br_print (indentstring + "shuff.bfly.rb32.sc" + str(syncChannel) + ".gc1 r" + str(thisTempAddr) + ", g0, " + str(1 << butterflyIndex))
    for vgprIndex in range (srcVGPRNumber):
      thisSrcAddr = srcVGPRAddr + vgprIndex
      thisTempAddr = tempVGPRAddr + vgprIndex
      syncChannel = vgprIndex + 1
      br_print (indentstring + "fadd.b32.sc" + str(syncChannel) + " r" + str(thisSrcAddr) + ", r" + str(thisSrcAddr) + ", r" + str(thisTempAddr))


####################################################
#
#  accmulateAddr  0 is the final result, rest used as temp buffer
#  it size needs to be at least 1 + (sourceNumber + 1) / 2
def	sum_vector(accumulateAddr, sourceAddr, sourceNumber, accumulationMode, formatStr, syncId, indentstring):

  syncStr = GetSyncModifier(syncId)

  if (sourceAddr < 0):
    vgprTypeStr = "ir"
    sourceAddr = -sourceAddr - 1
  else:
    vgprTypeStr = "r"

  if (accumulationMode == get_accmulation_mode_mov()):
    br_print (indentstring + "mov" + syncStr + " r" + str(accumulateAddr) + ".f32, " + vgprTypeStr + "0.f32")

  elif (accumulationMode == get_accmulation_mode_add()):
    br_print (indentstring + "fadd.b32" + syncStr + " " + vgprTypeStr + "0.f32, " + vgprTypeStr + "1.f32")

  else:
    addrOffset = 1

    while (1):
      if (sourceNumber == 1):
        break

      step = (sourceNumber + 1) >> 1
      vectorSize = (sourceNumber >> 1)

      if (addrOffset == 1):
        thisSrcHeader = vgprTypeStr
        thisSrcAddr = sourceAddr
      else:
        thisSrcHeader = "r"
        thisSrcAddr = accumulateAddr

      thisDstAddr = accumulateAddr + addrOffset

      sizeList = funcLib.SplitRepeatIntoGroups(vectorSize, hwCaps.MaxALUGranule())
      for thisSize in sizeList:
        for z in range(thisSize[0]):
          vectorModifier = GetVectorModifier(thisSize[1], "v")
          br_print (indentstring + "fadd" + formatStr + syncStr + vectorModifier + " r" + str(thisDstAddr) + ", " + thisSrcHeader + str(thisSrcAddr) + ".a, " + thisSrcHeader + str(thisSrcAddr + step) + ".a")
          syncStr = ""
          thisDstAddr += thisSize[1]
          thisSrcAddr += thisSize[1]

      sourceNumber = step

      if (addrOffset == 1):
        sourceNumber += 1
        addrOffset = 0


####################################################
#
#  accmulateAddr 0 is the final result, rest used as temp buffer
#  it size needs to be at least 1 + (sourceNumber + 1) / 2
def	sum_vector_to_vgpr(accumulateAddr, sourceAddr, sourceNumber, formatStr, syncId, indentstring):

  syncStr = GetSyncModifier(syncId)

  if (sourceAddr < 0):
    sourceTypeStr = "ir"
    sourceAddr = -sourceAddr - 1
  else:
    sourceTypeStr = "r"

  if (accumulateAddr < 0):
    accumTypeStr = "ir"
    accumulateAddr = -accumulateAddr - 1
  else:
    accumTypeStr = "r"

  while (sourceNumber > 1):
    step = (sourceNumber + 1) >> 1
    vectorSize = (sourceNumber >> 1)

    thisSrcAddr = sourceAddr
    thisDstAddr = sourceAddr

    sizeList = funcLib.SplitRepeatIntoGroups(vectorSize, hwCaps.MaxALUGranule())
    for thisSize in sizeList:
      for z in range(thisSize[0]):
        vectorModifier = GetVectorModifier(thisSize[1], "v")
        br_print (indentstring + "fadd" + formatStr + syncStr + vectorModifier + " " + sourceTypeStr + str(thisDstAddr) + ", " + sourceTypeStr + str(thisSrcAddr) + ".a, " + sourceTypeStr + str(thisSrcAddr + step) + ".a")
        syncStr = ""
        thisDstAddr += thisSize[1]
        thisSrcAddr += thisSize[1]

    sourceNumber = step

  br_print (indentstring + "fadd" + formatStr + syncStr + " " + accumTypeStr + str(accumulateAddr) + ", " + accumTypeStr + str(accumulateAddr) + ", " + sourceTypeStr + str(sourceAddr))

####################################################
#  sum exp needs special care, as exp (0) is 1
#
#  always f32
#
#  accmulateAddr  0 is the final result, rest used as temp buffer
#  it size needs to be at least 1 + sourceNumber


def	sum_vector_exp(accumulateAddr, sourceAddr, sourceNumber, accumulationMode, log2eVGPRAddr, lastVGPRLaneNumber, syncId, indentstring):

  syncStr = GetSyncModifier(syncId)

  if (sourceAddr < 0):
    vgprTypeStr = "ir"
    sourceAddr = -sourceAddr - 1
  else:
    vgprTypeStr = "r"

  if (accumulationMode == get_accmulation_mode_mov()):
    dstVGPROffset = 0
  else:
    dstVGPROffset = 1

  for z in range (sourceNumber):
    srcRegStr = vgprTypeStr + str(sourceAddr + z)
    br_print (indentstring + "fmul.b32.exp2" + syncStr + " r" + str(accumulateAddr + dstVGPROffset + z) + ", " + srcRegStr + ", r" + str(log2eVGPRAddr))
    syncStr = ""

  syncStr = ".sc3"

  if (lastVGPRLaneNumber != 0):
    funcLib.AlignPrint(indentstring + "smovs wm0, " + hex((0xffffffff << lastVGPRLaneNumber) & 0xffffffff), flowLib.GetCommentPos(), "// set m0 mask")
    funcLib.AlignPrint(indentstring + "m0.movi" + syncStr + " r" + str(accumulateAddr + dstVGPROffset + sourceNumber - 1) + ".f32, 0.0", flowLib.GetCommentPos(), "// clear last vgpr's invalid lanes to 0")
    funcLib.AlignPrint(indentstring + "smovs wm0, 0xffffffff", flowLib.GetCommentPos(), "// reset m0 mask")
    syncStr = ""

  if (accumulationMode == get_accmulation_mode_mov()):
    # already in accumulate, do nothing
    pass

  elif (accumulationMode == get_accmulation_mode_add()):
    br_print (indentstring + "fadd.b32" + syncStr + " r" + str(accumulateAddr) + ", r" + str(accumulateAddr + 1) + ".f32, " + ", r" + str(accumulateAddr + 2) + ".f32")
  else:
    addrOffset = 1

    while (1):
      if (sourceNumber == 1):
        break

      step = (sourceNumber + 1) >> 1

      for z in range (sourceNumber >> 1):
        dstOffset = accumulateAddr + z + addrOffset
        br_print (indentstring + "fadd.b32" + syncStr + " r" + str(dstOffset) + ", r" + str(dstOffset) + ", r" + str(dstOffset + step))
        syncStr = ""

      sourceNumber = step

      if (addrOffset == 1):
        sourceNumber += 1
        addrOffset = 0


####################################################
#
# address is in vgpr
#
def mov_imm_v(gprFormat, vgprAddr, vgprNumber, immValueStr, predicateStr, indentstring):

  if (gprFormat == hwCaps.SurfaceFormatFP16()):
    movFormatStr = ".f16"
  else:
    movFormatStr = ".f32"

  if vgprAddr < 0:
    vgprTypeStr = "ir"
    vgprAddr = -vgprAddr - 1
  else:
    vgprTypeStr = "r"

  sizeList = funcLib.SplitRepeatIntoGroups(vgprNumber, hwCaps.MaxMovGranule())

  for thisSize in sizeList:
    for z in range(thisSize[0]):
      vectorModifier = GetVectorModifier(thisSize[1], "v")
      br_print (indentstring + predicateStr + "movi" + vectorModifier + " " + vgprTypeStr + str(vgprAddr) + movFormatStr + ", " + immValueStr)

      vgprAddr += int (thisSize[1])

####################################################
#
# saclar load
# sld.mt2.ca.dt.mdem.rdem.sync.aa.org.dcnt.gcnt d, g0, desc;
# dcnt = e1/e2/e3/e4/e8
# mdem = mb32, rdem = rb32

# data number means how many data we want to load
# channel number means how many data we have per element
# if channel number is 0, don't update elementIndexSGPRStr

# x is an index to the 1d image. The image has a format.
# x refers to all components of the format. If the format is RG, x refers to 2 components. If the format is RGBA, x refers to 4 components."


def aligned_channel(value):
  ret = value if (value % 64) == 0 else (value + 64) / 64
  return ret


def scalar_load(gprFormat, elementIndexSGPRStr, sgprAddr, dataNumber, channelNumber, syncId, uSharpId, indentstring, sampleIndexSgpr, surfaceChannel=None, max_channel_sgpr=None):

  assert gprFormat == hwCaps.SurfaceFormatFP32(), "format not supported"

  ldFormatModifier = ".float.mb32.rb32"

  sizeList = funcLib.SplitRepeatIntoGroups(dataNumber, hwCaps.MaxLoadGranule())
  syncStr = GetSyncModifier(syncId)

  for thisSize in sizeList:
    for z in range(thisSize[0]):
      #br_print (indentstring + "sld.m1d" + ldFormatModifier + GetVectorModifier(thisSize[1], "e") + syncStr + " q" + str(sgprAddr) + ", g0, u" + str(uSharpId))
      br_print (indentstring + "sld.mmat1d" + ldFormatModifier + GetVectorModifier(thisSize[1], "e") + syncStr + ".gc2 q" + str(sgprAddr) + ", g0, u" + str(uSharpId))

      if surfaceChannel is not None:
        #br_print (indentstring + "saddg.eog g0, " + elementIndexSGPRStr + ", " + str((surfaceChannel)))
        src2_str = str((surfaceChannel*2))
        if surfaceChannel*2 >= 128:
            src2_str = max_channel_sgpr
        #br_print (indentstring + "adds.v1.b32.eog.lo g0, " + elementIndexSGPRStr + ", " + src2_str)
        br_print (indentstring + "adds.v1.b32.lo g0, " + elementIndexSGPRStr + ", " + src2_str)
        br_print (indentstring + "smovg.eog g1, " + "0", comment="// sample axis")
      else:
        #br_print (indentstring + "smovg.eog g0, " + elementIndexSGPRStr)
        #br_print (indentstring + "mov.rdne.v1.eog g0.u32, " + elementIndexSGPRStr + ".u32")
        br_print (indentstring + "mov.rdne.v1 g0.u32, " + elementIndexSGPRStr + ".u32")
        br_print (indentstring + "smovg.eog g1, " + "0", comment="// sample axis")

      if (channelNumber != 0):
        br_print (indentstring + "sadd " + elementIndexSGPRStr + ", " + elementIndexSGPRStr + ", " + str(int(surfaceChannel)))
      sgprAddr += thisSize[1]

def scalar_load_sldm(gprFormat, elementIndexSGPRStr, vgprAddr, dataNumber, channelNumber, syncId, uSharpId, indentstring, sampleIndexSgpr, surfaceChannel=None, max_channel_sgpr=None):

  assert gprFormat == hwCaps.SurfaceFormatFP32(), "format not supported"

  ldFormatModifier = ".float.mb32.rb32"

  sizeList = funcLib.SplitRepeatIntoGroups(dataNumber, hwCaps.MaxLoadGranule())
  syncStr = GetSyncModifier(syncId)

  for thisSize in sizeList:
    for z in range(thisSize[0]):
      e_size = thisSize[1]//2
      if thisSize[1] == 1:
        e_size = 1
      #br_print (indentstring + "sld.m1d" + ldFormatModifier + GetVectorModifier(thisSize[1], "e") + syncStr + " q" + str(sgprAddr) + ", g0, u" + str(uSharpId))
      br_print (indentstring + "sldm.mmat1d" + ldFormatModifier + GetVectorModifier(e_size, "e") + syncStr + ".gc2 r" + str(vgprAddr) + ", g0, u" + str(uSharpId))

      if surfaceChannel is not None:
        #br_print (indentstring + "saddg.eog g0, " + elementIndexSGPRStr + ", " + str((surfaceChannel)))
        src2_str = str((surfaceChannel*2))
        if surfaceChannel*2 >= 128:
            src2_str = max_channel_sgpr
        #br_print (indentstring + "adds.v1.b32.eog.lo g0, " + elementIndexSGPRStr + ", " + src2_str)
        br_print (indentstring + "adds.v1.b32.lo g0, " + elementIndexSGPRStr + ", " + src2_str)
        br_print (indentstring + "smovg.eog g1, " + "0", comment="// sample axis")
      else:
        #br_print (indentstring + "smovg.eog g0, " + elementIndexSGPRStr)
        #br_print (indentstring + "mov.rdne.v1.eog g0.u32, " + elementIndexSGPRStr + ".u32")
        br_print (indentstring + "mov.rdne.v1 g0.u32, " + elementIndexSGPRStr + ".u32")
        br_print (indentstring + "smovg.eog g1, " + "0", comment="// sample axis")

      if (channelNumber != 0):
        br_print (indentstring + "sadd " + elementIndexSGPRStr + ", " + elementIndexSGPRStr + ", " + str(int(surfaceChannel)))
      vgprAddr += (thisSize[1] + (thisSize[1] == 1)) 

####################################################
#
# lddw load
# each lddw loads 1 32b (e1) to each eu

# lddw.dt.mdem.rdem.sync.dcnt.gc d, g0, desc;
# dt = {int|float} // data type
# mdem = {mb8|mb16} // memory dem
# rdem = {rb8|rb16} // register dem
# mdem and rdem must have the same size. No conversion will be performed during the load.
# dcnt = {e1|e2|e4|e8|e16} // count in unit of 32 16-bit dems or 64 8-bit dems


def lddw_load(dataFormat, addrSGPRStr, csrAddr, csrNumber, syncId, uSharpId, indentstring):

  (ldFormatModifier, memElementPerVGPR) = GetFormatModifier_Full(dataFormat, dataFormat)
  sizeList = funcLib.SplitRepeatIntoGroups(csrNumber, hwCaps.MaxLLDWGranule())
  syncStr = GetSyncModifier(syncId)

  if (csrAddr < 0):
    csrTypeStr = "ic"
    csrAddr = -csrAddr - 1
  else:
    csrTypeStr = "c"

  for thisSize in sizeList:
    for z in range(thisSize[0]):
      br_print (indentstring + "lddw" + ldFormatModifier + GetVectorModifier(thisSize[1], "e") + syncStr + ".gc1 " + csrTypeStr + str(csrAddr) + ", g0, u" + str(uSharpId))
      br_print (indentstring + "& mov.eog g0.u32, " + addrSGPRStr + ".u32")
      br_print (indentstring + "sadd " + addrSGPRStr + ", " + addrSGPRStr + ", " + str(thisSize[1] << 6))
      csrAddr += (thisSize[1] >> 1)

####################################################
#
# address is in vgpr
# ld.mt2.ca.dt.mdem.rdem.sync.aa.org.dcnt.gcnt d, g0, desc
# ld.mbuf, ld.mtexel, ld.m1d, ld.m1da, ld.m2d, ld.m2da, ld.m3d:
# 	mdem is not needed. The memory object descriptor has the format which specifies the mdem.
#   dcnt = e1/e2/e3/e4


def load_1d_vector(memFormat, gprFormat, elementIndexVGPRStr, elementIndexStep, vgprAddr, vgprNumber, syncId, usharpId, indentstring):

  (ldFormatModifier, elementPerVGPR) = GetFormatModifier_GPR(gprFormat)

  syncStr = GetSyncModifier(syncId)

  if vgprAddr < 0:
    vgprTypeStr = "ir"
    vgprAddr = -vgprAddr - 1
  else:
    vgprTypeStr = "r"

  for z in range(vgprNumber):
    vectorModifier = GetVectorModifier(elementPerVGPR, "e")
    br_print (indentstring + "ld.m1d" + ldFormatModifier + syncStr + vectorModifier + ".gc1 " + vgprTypeStr + str(vgprAddr + z) + ", g0, u" + str(usharpId))

    br_print (indentstring + "mov.eog g0.u32, " + elementIndexVGPRStr + ".u32")

    br_print (indentstring + "addu.b32 " + elementIndexVGPRStr + ", " + elementIndexVGPRStr + ", " + str(elementIndexStep))

####################################################
# load same row to use burst
# if colIncStep is set, colSGPRStr will be advanced by colIncStep
# 2 row packed
# ldm.sync.dt.mdem.rdem.memtype.dcnt.gc d, g0, desc;
# mdem and rdem have the same dem size.
# dcnt = {e1|e2|e3|e4|e8|e16} // dem count
# memtype = {mmat2d|mmat3d} // memory type


def load_2d_weight(memFormat, gprFormat, rowSGPRStr, colSGPRStr, vgprAddr, colVGPRNumber, resetColIndexSGPR, syncId, usharpId, indentstring):
  (ldFormatModifier, elementPerVGPR) = GetFormatModifier_GPR(gprFormat)

  assert (memFormat == gprFormat), "not supported yet"

  syncStr = GetSyncModifier(syncId)

  if vgprAddr < 0:
    vgprTypeStr = "ir"
    vgprAddr = -vgprAddr - 1
  else:
    vgprTypeStr = "r"

  colElementNumber = colVGPRNumber * elementPerVGPR

  sizeList = funcLib.SplitRepeatIntoGroups(colElementNumber, hwCaps.MaxLDMGranule())

  incNumber = 0
  arraySizeListLen = len(sizeList)
  arrayIndex = 0

  for thisSize in sizeList:
    arrayIndex += 1

    for z in range(thisSize[0]):
      assert (thisSize[1] != 1 or elementPerVGPR == 1), "vector wrong"

      vectorModifier = GetVectorModifier(thisSize[1], "e")

      br_print (indentstring + "ldm" + ldFormatModifier + syncStr + vectorModifier + ".gc2 " + vgprTypeStr + str(vgprAddr) + ", g0, u" + str(usharpId))
      br_print (indentstring + "& mov g0.u32, " + colSGPRStr + ".u32")
      br_print (indentstring + "smovg.eog g1, " + rowSGPRStr)

      loadVGPRNumber = int (thisSize[1] / elementPerVGPR)
      vgprAddr += loadVGPRNumber

      if ((resetColIndexSGPR == 0) or (arrayIndex != arraySizeListLen) or (z != (thisSize[0] - 1))):
        incNumber += loadVGPRNumber
        br_print (indentstring + "sadd " + colSGPRStr + ", " + colSGPRStr + ", " + str(loadVGPRNumber << 5))

  if ((resetColIndexSGPR != 0) and (incNumber != 0)):
    br_print (indentstring + "sadd " + colSGPRStr + ", " + colSGPRStr + ", " + str(-incNumber * 32))

####################################################
# load a whole slice from a certain channel and certain sample
#
# def load_4d_activation(memFormat, gprFormat, channelSGPRStr, channelId, vgprAddr, memTileNumberX, memTileNumberY, vgprStride, syncId, usharpId, indentstring):
#
#  (dataSizeModifier, scale) = GetLoadDataSizeModifier(memFormat, gprFormat)
#
#  syncStr = GetSyncModifier(syncId)
#
#  if vgprAddr < 0:
#    vgprTypeStr = "ir"
#    vgprAddr = -vgprAddr - 1
#  else:
#    vgprTypeStr = "r"
#
#  sizeList = funcLib.SplitRepeatIntoGroups(memTileNumberY, hwCaps.MaxLDMGranule())
#
#  if (channelId > hwCaps.MaxIMM()):
#    br_print (indentstring + "movi " + channelSGPRStr + ".u32, " + str(channelId))
#    channelId = -1
#
#  for x in range (memTileNumberX):
#    y = 0
#    for thisSize in sizeList:
#      for z in range(thisSize[0]):
#        vectorModifier = GetVectorModifier(thisSize[1] * scale, "e")
#        br_print (indentstring + "ldm.float" + dataSizeModifier + syncStr + vectorModifier + ".gc4 " + vgprTypeStr + str(vgprAddr) + ", g0, u" + str(usharpId))
#        br_print (indentstring + "smovg g0, " + str(x * hwCaps.TileSizeX()))
#        br_print (indentstring + "smovg g1, " + str(y * hwCaps.TileSizeY()))
#
#        if (channelId > 0):
#          br_print (indentstring + "mov g2.u32, " + str(channelId))
#        else:
#          br_print (indentstring + "smovg g2, " + channelSGPRStr)
#
#        br_print (indentstring + "smovg.eog g3, 0")
#        vgprAddr += thisSize[1]
#        y += thisSize[1]
#
#    if (vgprStride > 0):
#      vgprAddr += vgprStride - memTileNumberY

####################################################
# burst load
# due to activation layout, that is y direction
# reset y coord in the end

# ldm.sync.dt.mdem.rdem.memtype.dcnt.gc d, g0, desc;
# mdem and rdem have the same dem size.
# dcnt = {e1|e2|e3|e4|e8|e16} // dem count
# memtype = {mmat2d|mmat3d} // memory type

def load_per_e(indentstring, elements, elementPerVGPR, ldFormatModifier, syncStr, 
               vgprTypeStr, vgprAddr, usharpId, coordSGPRStrList, process_last_row):
    if (coordSGPRStrList[3] == ""):
      gcCount = 3
      gcStr = ".gc3 "
    else:
      gcCount = 4
      gcStr = ".gc4 "

    vectorModifier = GetVectorModifier(elements, "e")
    br_print (indentstring + "ldm.mmat3d" + ldFormatModifier + syncStr + vectorModifier + gcStr + vgprTypeStr + str(vgprAddr) + ", g0, u" + str(usharpId))
    br_print (indentstring + "& mov g0.u32, " + coordSGPRStrList[0]+".u32")
    br_print (indentstring + "smovg g1, " + coordSGPRStrList[1])

    if (gcCount == 3):
      br_print (indentstring + "smovg.eog g2, " + coordSGPRStrList[2])
    else:
      br_print (indentstring + "smovg g2, " + coordSGPRStrList[2])
      br_print (indentstring + "smovg.eog g3, " + coordSGPRStrList[3])

    tileNumber = int (elements / elementPerVGPR)
    vgprAddr += tileNumber

    yInc = 0
    if not process_last_row:
      br_print (indentstring + "sadd " + coordSGPRStrList[1] + ", " + coordSGPRStrList[1] + ", " + str(tileNumber * hwCaps.TileSizeY()))
      yInc += tileNumber
    return yInc, vgprAddr

def split_oob_v(elements, elementPerVGPR):
  ele_list = []
  if int(elements/elementPerVGPR) == 4:
    ele_list = [elementPerVGPR, elementPerVGPR, 2*elementPerVGPR]
  elif int(elements/elementPerVGPR) == 2:
    ele_list = [elementPerVGPR, elementPerVGPR]
  else:
    ele_list = [elements]
  #print(int(elements/elementPerVGPR))
  #print("[split_oob_v] elements={}, elementPerVGPR={}, return_size={}".format(elements, elementPerVGPR, ele_list))
  return ele_list

def load_4d_activation(memFormat, gprFormat, coordSGPRStrList, vgprAddr, vgprNumber, syncId, usharpId, indentstring, handle_oob=False):

  assert (memFormat == gprFormat), "mdem and rdem have the same dem size"

  (ldFormatModifier, elementPerVGPR) = GetFormatModifier_Full(gprFormat, gprFormat)

  syncStr = GetSyncModifier(syncId)

  if vgprAddr < 0:
    vgprTypeStr = "ir"
    vgprAddr = -vgprAddr - 1
  else:
    vgprTypeStr = "r"

  elementNumber = vgprNumber * elementPerVGPR

  sizeList = funcLib.SplitRepeatIntoGroups(elementNumber, hwCaps.MaxLDMGranule())

  sizeNumber = len(sizeList)
  sizeIndex = 0
  yInc = 0

  is_process_first_row = True
  need_process_oob = False
  for thisSize in sizeList:
    sizeIndex += 1
    for z in range(thisSize[0]):
      process_last_row = True
      if ((sizeIndex != sizeNumber) or (z != (thisSize[0] - 1))):
        process_last_row = False

      if is_process_first_row and handle_oob: 
          is_process_first_row = False
          need_process_oob = True if thisSize[1] > elementPerVGPR else False

      if need_process_oob:
          need_process_oob = False
          cycle_list = split_oob_v(thisSize[1], elementPerVGPR)
          for ele in cycle_list:
            y_inc_e, vgprAddr = load_per_e(indentstring, ele, elementPerVGPR, ldFormatModifier, syncStr, 
                vgprTypeStr, vgprAddr, usharpId, coordSGPRStrList, False)
            yInc += y_inc_e
      else:
          y_inc_e, vgprAddr = load_per_e(indentstring, thisSize[1], elementPerVGPR, ldFormatModifier, syncStr, 
               vgprTypeStr, vgprAddr, usharpId, coordSGPRStrList, process_last_row)
          yInc += y_inc_e

  if (yInc != 0):
    br_print (indentstring + "sadd " + coordSGPRStrList[1] + ", " + coordSGPRStrList[1] + ", " + str(-yInc * hwCaps.TileSizeY()))

# def load_tile_cols_v(resetY, resetVgprBase, vgprStartIndex, vgprRowNumber, vgprColNumber, yStartOffset, vgprStride, isIndexed, clearColMinus1, syncId, funcParameterMap, indentstring):
#
#    # always reset y
#    # always reset vgprbase, i.e., no touch a1
#    # rowNumber - burstLen
#    # always 1 col
#    load_tile_cols_v(1, 1, (z+loopColStart)*vgprStride + loopRowStart, loopRowSize, 1, 0, vgprStride, 1, 0, syncIndex, funcParameterMap, flowHandler.getIndentStr())

#
#    load_tile_cols_v(1, 1, z*vgprStride,                                   rowSize, 1, 0, vgprStride, 1, 0, syncIndex, funcParameterMap, flowHandler.getIndentStr())
#    load_tile_cols_v(1, 1, (z+loopColStart)*vgprStride + loopRowStart, loopRowSize, 1, 0, vgprStride, 1, 0, syncIndex, funcParameterMap, flowHandler.getIndentStr())
#    load_tile_cols_v(1, 1, 0,                                              rowSize, 1, 0, vgprStride, 1, 0,         0, funcParameterMap, flowHandler.getIndentStr())
#    load_tile_cols_v(1, 1, z*vgprStride,                                         1, 1, 0, vgprStride, 1, 0,         1, funcParameterMap, indentstring)
#    load_tile_cols_v(1, 1, vgprStride + loopRowStart,                  loopRowSize, 1, 0, vgprStride, 1, 1,         1, funcParameterMap, indentstring)
#
#
#
#  syncStr = kernelLib.GetSyncModifier(syncId)
#
#  if (isIndexed == 0):
#    vgprStrPrefix = " r"
#    vgprStrPostfix = ""
#  else:
#    vgprStrPrefix = " ir"
#    vgprStrPostfix = ""
#
#  vgprIndex = vgprStartIndex
#
#  xSGPRStr = funcParameterMap["xCoord"]
#  ySGPRStr = funcParameterMap["yCoord"]
#  zSGPRStr = funcParameterMap["zCoord"]
#  wSGPRStr = funcParameterMap["wCoord"]
#  uSharpId = funcParameterMap["uSharpId"]
#
#  if (yStartOffset != 0):
#    br_print (indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(yStartOffset * hwCaps.TileSizeY()))
#
#  sizeList = funcLib.SplitRepeatIntoGroups(vgprRowNumber, MaxLDMGranule())
#
#  sizeListLen = len(sizeList)
#  ySizeIndex = 0
#  yChange = yStartOffset
#
#  for y in sizeList:
#    ySizeIndex += 1
#
#    vectorModifier = kernelLib.GetVectorModifier(y[1], "v")
#    vectorModifierLoad = kernelLib.GetVectorModifier(y[1] * 2, "e")
#    for z in range(y[0]):
#
#      if (clearColMinus1 != 0):
#        br_print (indentstring + "movi" + vectorModifier + vgprStrPrefix + str(vgprIndex-vgprStride) + vgprStrPostfix + ".u32, 0")
#
#      for x in range (vgprColNumber):
#        br_print (indentstring + "ldm" + syncStr + ".float.mb16.rb16" + vectorModifierLoad + ".gc4" + vgprStrPrefix + str(vgprIndex) + vgprStrPostfix + ", g0, " + str(uSharpId[0][0]))
#        br_print (indentstring + "smovg g0, " + xSGPRStr)
#        br_print (indentstring + "smovg g1, " + ySGPRStr)
#        br_print (indentstring + "smovg g2, " + zSGPRStr)
#        br_print (indentstring + "smovg.eog g3, " + wSGPRStr)
#
#        if (x != (vgprColNumber - 1)):
#          vgprIndex += vgprStride
#          br_print (indentstring + "sadd " + xSGPRStr + ", " + xSGPRStr + ", " + str(hwCaps.TileSizeX()))
#
#      if (vgprColNumber != 1):
#        vgprIndex -= (vgprColNumber - 1) * vgprStride
#        br_print (indentstring + "sadd " + xSGPRStr + ", " + xSGPRStr + ", " + str(-(vgprColNumber-1) * hwCaps.TileSizeX()))
#
#      vgprIndex += y[1]
#
#      if (ySizeIndex != sizeListLen or z != (y[0] - 1)):
#        yChange += y[1]
#        br_print (indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(y[1] * hwCaps.TileSizeY()))
#
#  if ((resetY != 0) and (yChange != 0)):
#    br_print (indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(-yChange * hwCaps.TileSizeY()))
#
#  if (resetVgprBase == 0):
#    vgprBaseStr = funcParameterMap["vgprBase"]
#    br_print (indentstring + "sadda " + vgprBaseStr + ", " + vgprBaseStr + ", " + str(vgprRowNumber))

####################################################
# will convert gprFormat to memFormat if they are different
# st.mt2.ca.dt.mdem.rdem.aa.org.dcnt.gcnt g0, gi, desc;


def store_1d_vector(memFormat, gprFormat, elementIndexVGPRStr, elementIndexStep, vgprAddr, vgprNumber, usharpId, indentstring):

  (stFormatModifier, dstElementPerVGPR) = GetFormatModifier_Full(memFormat, gprFormat)

  (srcDataFormatModifier, srcBpp) = GetGPRFormatModifier(gprFormat)

  if vgprAddr < 0:
    vgprTypeStr = "ir"
    vgprAddr = -vgprAddr - 1
  else:
    vgprTypeStr = "r"

  for z in range(vgprNumber):
    br_print (indentstring + "st.m1d" + stFormatModifier + ".e1" + ".gc2 " + " g0, g1, u" + str(usharpId))

    br_print (indentstring + "mov g0.u32, " + elementIndexVGPRStr + ".u32")

    br_print (indentstring + "mov.eog g1" + srcDataFormatModifier + ", " + vgprTypeStr + str(vgprAddr + z) + srcDataFormatModifier)

    if (elementIndexStep != 0):
      br_print (indentstring + "addu.b32 " + elementIndexVGPRStr + ", " + elementIndexVGPRStr + ", " + str(elementIndexStep))

####################################################
# burst store
# due to activation layout, that is y direction
# stm.dt.mdem.rdem.memtype.dcnt.wt.gc g0, gi, desc;
# mdem and rdem have the same dem size.
# will convert gprFormat to memFormat if they are different


def store_4d_activation(memFormat, gprFormat, coordSGPRStrList, vgprAddr, vgprNumber, usharpId, indentstring):

  assert (memFormat == gprFormat), "mdem and rdem have the same dem size"

  (stFormatModifier, elementPerVGPR) = GetFormatModifier_Full(gprFormat, gprFormat)
  (gprFormatModifier, srcBpp) = GetGPRFormatModifier(gprFormat)

  if vgprAddr < 0:
    vgprTypeStr = "ir"
    vgprAddr = -vgprAddr - 1
  else:
    vgprTypeStr = "r"

  elementNumber = vgprNumber * elementPerVGPR

  sizeList = funcLib.SplitRepeatIntoGroups(elementNumber, hwCaps.MaxLDMGranule())

  if (coordSGPRStrList[3] == ""):
    coordGCCount = 3
  else:
    coordGCCount = 4

  sizeNumber = len(sizeList)
  sizeIndex = 0
  yInc = 0

  for thisSize in sizeList:
    sizeIndex += 1
    for z in range(thisSize[0]):
      vectorModifier = GetVectorModifier(thisSize[1], "e")
      tileNumber = int (thisSize[1] / elementPerVGPR)
      gcCountModifier = GetGCModifier(coordGCCount + tileNumber)

      br_print (indentstring + "stm.mmat3d" + stFormatModifier + vectorModifier + gcCountModifier + " g0, g" + str(coordGCCount) + ", u" + str(usharpId))
      br_print (indentstring + "mov" + vectorModifier + " g" + str(coordGCCount) + gprFormatModifier + ", " + vgprTypeStr + str(vgprAddr) + gprFormatModifier)
      br_print (indentstring + "smovg g0, " + coordSGPRStrList[0])
      br_print (indentstring + "smovg g1, " + coordSGPRStrList[1])
      
      if (coordGCCount <= 3):
        br_print (indentstring + "smovg.eog g2, " + coordSGPRStrList[2])
      else:
        br_print (indentstring + "smovg g2, " + coordSGPRStrList[2])
        br_print (indentstring + "smovg.eog g3, " + coordSGPRStrList[3])

      vgprAddr += tileNumber

      if ((sizeIndex != sizeNumber) or (z != (thisSize[0] - 1))):
        br_print (indentstring + "sadd " + coordSGPRStrList[1] + ", " + coordSGPRStrList[1] + ", " + str(tileNumber * hwCaps.TileSizeY()))
        yInc += tileNumber

  if (yInc != 0):
    br_print (indentstring + "sadd " + coordSGPRStrList[1] + ", " + coordSGPRStrList[1] + ", " + str(-yInc * hwCaps.TileSizeY()))

  return

  (stFormatModifier, elementPerVGPR) = GetFormatModifier_Full(memFormat, memFormat)

  if dataVGPRAddr < 0:
    vgprTypeStr = "ir"
    dataVGPRAddr = -dataVGPRAddr - 1
  else:
    vgprTypeStr = "r"

  if (coordSGPRStrList[3] == ""):
    coordCount = 3
  else:
    coordCount = 4

  (srcDataFormatModifier, srcBpp) = GetGPRFormatModifier(gprFormat)
  (dstDataFormatModifier, dstBpp) = GetGPRFormatModifier(memFormat)

  srcDataFormatModifier += ".a"

  if (srcBpp > dstBpp):
    dataVGPRStep = int (srcBpp / dstBpp)
    finalVGPRNumber = int (dataVGPRNumber / dataVGPRStep)
  else:
    dataVGPRStep = 1
    finalVGPRNumber = dataVGPRNumber

  sizeList = funcLib.SplitRepeatIntoGroups(finalVGPRNumber, hwCaps.MaxStoreGranule())

  sizeNumber = len(sizeList)
  sizeIndex = 0
  yInc = 0

  for thisSize in sizeList:
    sizeIndex += 1
    for z in range(thisSize[0]):
      stVectorModifier = GetVectorModifier(thisSize[1] * scale, "e")
      gcModifier = GetGCModifier(coordCount + thisSize[1])

      br_print (indentstring + "stm.float" + stFormatModifier + stVectorModifier + gcModifier + " g0, g" + str(coordCount) + ", u" + str(usharpId))
      br_print (indentstring + "mov g0.u32, " + coordSGPRStrList[0]+".u32")
      br_print (indentstring + "smovg g1, " + coordSGPRStrList[1])
      br_print (indentstring + "smovg g2, " + coordSGPRStrList[2])

      if (coordCount == 4):
       br_print (indentstring + "smovg g3, " + coordSGPRStrList[3])

      if (srcBpp == dstBpp):
        mvVectorModifier = GetVectorModifier(thisSize[1] * scale, "v")
      elif (srcBpp == 4):
        # fp32 -> fp16
        mvVectorModifier = GetVectorModifier(thisSize[1] * scale, "v")
      else:
        assert False, "not supported yet"

      br_print (indentstring + "mov.eog" + mvVectorModifier + " g" + str(coordCount) + dstDataFormatModifier + ", " + vgprTypeStr + str(dataVGPRAddr) + srcDataFormatModifier)

      dataVGPRAddr += thisSize[1] * dataVGPRStep

      if ((incY != 0) or (sizeIndex != sizeNumber) or (z != (thisSize[0] - 1))):
        br_print (indentstring + "sadd " + coordSGPRStrList[1] + ", " + coordSGPRStrList[1] + ", " + str(thisSize[1] * hwCaps.TileSizeY()))
        yInc += thisSize[1]

  if (incY == 0 and yInc != 0):
    # reset y
    br_print (indentstring + "sadd " + coordSGPRStrList[1] + ", " + coordSGPRStrList[1] + ", " + str(-yInc * hwCaps.TileSizeY()))

########################################################################################################
#  below are WIP
########################################################################################################

####################################################
# load_tile4x8
#   load a tile, may or may not do bilinear, depends on mode (isAligned)
#   not in use at this moment
# def load_tile4x8(isAligned, vgprIndex, isIndexed, syncId, funcParameterMap, indentstring):
#
#  xSGPRStr = funcParameterMap["xCoord"]
#  ySGPRStr = funcParameterMap["yCoord"]
#  zSGPRStr = funcParameterMap["zCoord"]
#  wSGPRStr = funcParameterMap["wCoord"]
#  uSharpId = funcParameterMap["uSharpId"]
#
#  if (isIndexed == 0):
#    vgprStr = " r" + str(vgprIndex)
#  else:
#    vgprStr = " ir" + str(vgprIndex)
#
#  if (isAligned):
#    br_print (indentstring + "ldm" + kernelLib.GetSyncModifier(syncId) + ".float.mb16.rb16.e2.gc4"  + vgprStr + ", g0, " + str(uSharpId[0][0]))
#    br_print (indentstring + "smovg g0, " + xSGPRStr)
#    br_print (indentstring + "smovg g1, " + ySGPRStr)
#    br_print (indentstring + "smovg g2, " + zSGPRStr)
#    br_print (indentstring + "smovg.eog g3, " + wSGPRStr)
#  else:
#    br_print (indentstring + "call load_bilinear r" + str(vgprIndex) + ", u1#[y=???, x=0]")


####################################################
# load_tile4x8
#   load a tile, may or may not do bilinear, depends on mode (isAligned)
#   not in use at this moment
def	reduce_vector(vecUSharpID, vecSize, vecFormat, laneIDVGPRStr, operations, flowHandler):
  indentstring = flowHandler.getIndentStr()

  # vecSize = 1092

  if (vecFormat == hwCaps.GetSurfaceFormatFP16()):
    elementSizeShift = 1
    formatStr = ".b16"
    vgprRowSize = 64
    vecVGPRNumber = (vecSize + 63) >> 6
  else:
    elementSizeShift = 2
    formatStr = ".b32"
    vgprRowSize = 32
    vecVGPRNumber = (vecSize + 31) >> 5

  vecVGPRAddr = flowHandler.allocateVGPR(vecVGPRNumber)

####################################################
#  a general interleave load/alu function
#  take a class instance, which has load and alu
#  take a dict to pass parameter


def interleave_load_alu(vgprNumber, vgprGroupSize, noOOBAccess, partialMask, syncChannelNumber, classObj, parameterBank, flowHandler):

    groupNumber = int ((vgprNumber + vgprGroupSize - 1) / vgprGroupSize)

    # last group may be partial
    if (noOOBAccess != 0):
      vgprRemainNumber = vgprNumber % vgprGroupSize
    else:
      vgprRemainNumber = 0

    indentstring = flowHandler.getIndentStr()

    br_print (indentstring + "// vgpr number = " + str(vgprNumber))
    br_print (indentstring + "// group number = " + str(groupNumber))
    br_print (indentstring + "// vgpr remain number = " + str(vgprRemainNumber))

    # number of vgprs affects load, load might cross boundary, so has to take out of loop
    if (vgprRemainNumber != 0):
      groupNumber -= 1
      tailNumber = 1
    else:
      tailNumber = 0

    bodyNumber = 0
    if (groupNumber >= syncChannelNumber):
      headNumber = syncChannelNumber - 1
      tailNumber += (groupNumber - headNumber) % syncChannelNumber
      loopNumber = int ((groupNumber - headNumber) / syncChannelNumber)

      if (loopNumber != 0):
        bodyNumber = syncChannelNumber
    else:
      headNumber = groupNumber
      loopNumber = 0

    lastLoadIndex = headNumber + bodyNumber + tailNumber - 1
    expandNumber = headNumber + bodyNumber + tailNumber + headNumber

    # load takes headNumber + bodyNumber + tailNumber
    # alu starts from headNumber

    br_print (indentstring + "// loop number = " + str(loopNumber))
    br_print (indentstring + "// head: " + str(headNumber) + ", body: " + str(bodyNumber) + ", tail: " + str(tailNumber) + ", last vgpr valid lane number: " + str(lastVGPRLaneNumber))

    loadIndex = 0
    aluIndex = 0

    loadVGPRBaseSGPRStr = vgprBaseSGPRStr
    aluVGPRBaseSGPRStr = channelSGPRStr

    br_print (indentstring + "smov " + loadVGPRBaseSGPRStr + ", " + str(sourceVGPRAddr))
    br_print (indentstring + "smov " + aluVGPRBaseSGPRStr + ", " + str(sourceVGPRAddr))

    for z in range (expandNumber):

      if (z == headNumber and loopNumber > 1):
        br_print (indentstring)
        flowHandler.startForLoop("0", str(loopNumber), "1", -1, "")
        indentstring = flowHandler.getIndentStr()

      if (z <= lastLoadIndex):
        br_print (indentstring)
        if (z == lastLoadIndex and vgprRemainNumber != 0):
          loadVGPRNumber = vgprRemainNumber
        else:
          loadVGPRNumber = vgprGroupNumber

        funcLib.AlignPrint(indentstring + "smovs a1, " + loadVGPRBaseSGPRStr, GetCommentPos(), "// set load vgpr base")
        load_1d_vector(bOutputHalfFloat, addressVGPRStr, 64, loadVGPRNumber, -1, loadIndex + 1, usharpList[outputUSharpIndex][0], indentstring)
        funcLib.AlignPrint(indentstring + "sadd " + loadVGPRBaseSGPRStr + ", " + loadVGPRBaseSGPRStr + ", " + str(vgprGroupNumber), GetCommentPos(), "// advance load vgpr base")
        loadIndex = funcLib.IncAndWrap(loadIndex, syncChannelNumber)

      if (z >= headNumber):
        br_print (indentstring)
        syncId = aluIndex + 1
        funcLib.AlignPrint(indentstring + "smovs a1, " + aluVGPRBaseSGPRStr, GetCommentPos(), "// switch to alu vgpr base")
        if (z == expandNumber - 1 and vgprRemainNumber != 0):
          aluVGPRNumber = vgprRemainNumber
        else:
          aluVGPRNumber = vgprGroupNumber

        if (z == expandNumber - 1 and lastVGPRLaneNumber != 0):
          funcLib.AlignPrint(indentstring + "smovs wm0, " + hex((0xffffffff << lastVGPRLaneNumber) & 0xffffffff), GetCommentPos(), "// set m0 mask")
          funcLib.AlignPrint(indentstring + "m0.movi.sc" + str(syncId) + " ir" + str(aluVGPRNumber - 1) + ".f32, 0.0", GetCommentPos(), "// clear invalid lane to 0")
          syncId = 0

        kernelLib.sum_vector(accumulateVGPRAddr, -1, aluVGPRNumber, formatStr, syncId, indentstring)
        funcLib.AlignPrint(indentstring + "sadd " + aluVGPRBaseSGPRStr + ", " + aluVGPRBaseSGPRStr + ", " + str(vgprGroupNumber), GetCommentPos(), "// advance load vgpr base")
        aluIndex = funcLib.IncAndWrap(aluIndex, syncChannelNumber)

      if (z == (headNumber + bodyNumber - 1) and loopNumber > 1):
        flowHandler.closeForLoop("0", str(loopNumber), "1", -1)
        indentstring = flowHandler.getIndentStr()


####################################################
#
#  can't fit in vgpr
def	reduce_vector_e(vecUSharpID, vecSize, vecFormat, laneIDVGPRStr, operations, flowHandler):
  indentstring = flowHandler.getIndentStr()
#    vgprGroupNumber = 4
#    rowGroupNumber = int ((weightVGPRNumber + vgprGroupNumber - 1) / vgprGroupNumber)
#
#    if (rowGroupNumber > 2):
#      expandNumber = (rowGroupNumber - 2) % 3
#      loopNumber = int ((rowGroupNumber - 2) / 3)
#
#      if (loopNumber != 0):
#        expandNumber += 3
#    else:
#      expandNumber = 0
#      loopNumber = 0
#
#    br_print (indentstring + "// vgpr number = " + str(weightVGPRNumber))
#    br_print (indentstring + "// group number = " + str(rowGroupNumber))
#    br_print (indentstring + "// loop number = " + str(loopNumber))
#
#    # load 4 vgprs each time
#    reduceVGPRAddr = flowHandler.allocateVGPR(3 * vgprGroupNumber)
#    addressVGPRAddr = flowHandler.allocateVGPR(1)
#    accumulateVGPRAddr = flowHandler.allocateVGPR(2)
#
#    addressVGPRStr = "r" + str(addressVGPRAddr)
#
#    funcLib.AlignPrint(indentstring + "shl.b32 r" + str(addressVGPRAddr) + ", " + laneIdVGPRStr + ", " + str(elementSizeShift), GetCommentPos(), "// get byte address of each lane, assume r0 is lane id")
#
#    br_print (indentstring + "// initialize accumlate result")
#    br_print (indentstring + "movi r" + str(accumulateVGPRAddr) + ".u32, 0")
#
#    loadIndex = 0
#    aluIndex = 0
#
#    br_print (indentstring)
#    load_1d_vector(bOutputHalfFloat, addressVGPRStr, -1, 4, reduceVGPRAddr, loadIndex + 1, usharpList[outputUSharpIndex][0], indentstring)
#    loadIndex = funcLib.IncAndWrap(loadIndex, 3)
#
#    if (rowGroupNumber > 1):
#      br_print (indentstring)
#      thisLoadAddr = reduceVGPRAddr + loadIndex * vgprGroupNumber
#      load_1d_vector(bOutputHalfFloat, addressVGPRStr, -1, 4, thisLoadAddr, loadIndex + 1, usharpList[outputUSharpIndex][0], indentstring)
#      loadIndex = funcLib.IncAndWrap(loadIndex, 3)
#
#    if (loopNumber > 1):
#      br_print (indentstring)
#      flowHandler.startForLoop("0", str(loopNumber), "1", -1, "")
#      indentstring = flowHandler.getIndentStr()
#
#    for z in range (expandNumber):
#      br_print (indentstring)
#      thisLoadAddr = reduceVGPRAddr + loadIndex * vgprGroupNumber
#      load_1d_vector(bOutputHalfFloat, addressVGPRStr, -1, 4, thisLoadAddr, loadIndex + 1, usharpList[outputUSharpIndex][0], indentstring)
#      loadIndex = funcLib.IncAndWrap(loadIndex, 3)
#
#      br_print (indentstring)
#      thisAluAddr = reduceVGPRAddr + aluIndex * vgprGroupNumber
#      br_print (indentstring + "fadd" + formatStr + ".sc" + str(aluIndex + 1) + " r" + str(thisAluAddr) + ", r" + str(thisAluAddr) + ", r" + str(thisAluAddr+1))
#      br_print (indentstring + "fadd" + formatStr + " r" + str(thisAluAddr+2) + ", r" + str(thisAluAddr+2) + ", r" + str(thisAluAddr+3))
#      br_print (indentstring + "fadd" + formatStr + " r" + str(accumulateVGPRAddr) + ", r" + str(thisAluAddr) + ", r" + str(thisAluAddr+2))
#      aluIndex = funcLib.IncAndWrap(aluIndex, 3)
#
#      if (loopNumber > 1 and z == 2):
#        flowHandler.closeForLoop("0", str(loopNumber), "1", -1)
#        indentstring = flowHandler.getIndentStr()
#
#    if (rowGroupNumber > 1):
#      br_print (indentstring)
#      thisAluAddr = reduceVGPRAddr + aluIndex * vgprGroupNumber
#      br_print (indentstring + "fadd" + formatStr + ".sc" + str(aluIndex + 1) + " r" + str(thisAluAddr) + ", r" + str(thisAluAddr) + ", r" + str(thisAluAddr+1))
#      br_print (indentstring + "fadd" + formatStr + " r" + str(thisAluAddr+2) + ", r" + str(thisAluAddr+2) + ", r" + str(thisAluAddr+3))
#      br_print (indentstring + "fadd" + formatStr + " r" + str(accumulateVGPRAddr) + ", r" + str(thisAluAddr) + ", r" + str(thisAluAddr+2))
#      aluIndex = funcLib.IncAndWrap(aluIndex, 3)
#
#    br_print (indentstring)
#    thisAluAddr = reduceVGPRAddr + aluIndex * vgprGroupNumber
#
#    lastVGPRNumber = weightVGPRNumber % vgprGroupNumber
#    syncStr = ".sc" + str(aluIndex + 1)
#
#    if (lastVGPRNumber == 0):
#      lastVGPRNumber = vgprGroupNumber
#
#    lastVGPRElementNumber = weightRowNumber & (vgprRowSize - 1)
#    if (lastVGPRElementNumber != 0):
#      laneNumber = lastVGPRElementNumber
#      if (bOutputHalfFloat != 0):
#        laneNumber = (laneNumber + 1) >> 1
#
#      funcLib.AlignPrint(indentstring + "smovs wm0, " + hex((0xffffffff << laneNumber) & 0xffffffff), GetCommentPos(), "// set m0 mask")
#      br_print (indentstring + "m0.movi" + syncStr + " r" + str(thisAluAddr + lastVGPRNumber - 1) + ".u32, 0")
#      syncStr = ""
#
#    if (lastVGPRNumber == 1):
#      br_print (indentstring + "fadd" + formatStr + syncStr + " r" + str(accumulateVGPRAddr) + ", r" + str(accumulateVGPRAddr) + ", r" + str(thisAluAddr))
#    else:
#      br_print (indentstring + "fadd" + formatStr + syncStr + " r" + str(thisAluAddr) + ", r" + str(thisAluAddr) + ", r" + str(thisAluAddr+1))
#      if (lastVGPRNumber == 2):
#        br_print (indentstring + "fadd" + formatStr + " r" + str(accumulateVGPRAddr) + ", r" + str(accumulateVGPRAddr) + ", r" + str(thisAluAddr))
#      elif (lastVGPRNumber == 3):
#        br_print (indentstring + "fadd" + formatStr + " r" + str(accumulateVGPRAddr) + ", r" + str(thisAluAddr) + ", r" + str(thisAluAddr + 2))
#      else:
#        br_print (indentstring + "fadd" + formatStr + " r" + str(thisAluAddr+2) + ", r" + str(thisAluAddr+2) + ", r" + str(thisAluAddr+3))
#        br_print (indentstring + "fadd" + formatStr + " r" + str(accumulateVGPRAddr) + ", r" + str(thisAluAddr) + ", r" + str(thisAluAddr+2))
#
#    aluIndex = funcLib.IncAndWrap(aluIndex, 3)
#
#    flowHandler.closeIfLoop()
#    indentstring = flowHandler.getIndentStr()


def PrintUSharpList(usharpList, indentstring):
  br_print (indentstring + "// usharp info")
  br_print (indentstring + "// U#id         Type     O     D     H     W  Note")
  for usharp in usharpList:
    br_print (indentstring + "// " + "{:3d}".format(usharp[0]) + ", " + hwCaps.GetSurfaceType(usharp[1]) + ",{:5d}".format(usharp[2]) + ",{:5d}".format(usharp[3]) + ",{:5d}".format(usharp[4]) + ",{:5d}".format(usharp[5]) + ", " + usharp[6])
