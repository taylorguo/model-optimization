
#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import vector.common.constDefs as cfgs

def GetSurfUsharpIDIndex():
  return cfgs.USHARP_SURF_ID_INDEX

def GetSurfCoordSampleIndex():
  return cfgs.USHARP_SURF_COORD_SAMPLE_INDEX

def GetSurfCoordChannelIndex():
  return cfgs.USHARP_SURF_COORD_CHAN_INDEX

def GetSurfCoordYIndex():
  return cfgs.USHARP_SURF_COORD_Y_INDEX

def GetSurfCoordXIndex():
  return cfgs.USHARP_SURF_COORD_X_INDEX

def GetLayerSubtypeFcFw1():
  return cfgs.LayerSubType.get("fc_fw1")

def GetLayerSubtypeFcFw2():
  return cfgs.LayerSubType.get("fc_fw2")

def GetLayerSubtypeFcBk1():
  return cfgs.LayerSubType.get("fc_bk1")

def GetLayerSubtypeFcBk2():
  return cfgs.LayerSubType.get("fc_bk2")