#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import vector.common.constDefs as cfgs
import code_generator.share.br_utils as utils


def GetASMMode():
  return (not utils.get_code_sytle())
