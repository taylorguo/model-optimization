#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import copy
import code_generator.share.br_resource_manager as resource_man
import code_generator.share.br_utils as utils
import code_generator.share.br_defined_print as bdp
from code_generator.share.br_defined_print import br_print
from code_generator.share.br_defined_print import set_print_subfunc_stage
from code_generator.share.br_singleton_base import singleton

import code_generator.vector.common.funcLib as funcLib
import code_generator.vector.common.constDefs as cfgs


def	getIndentSize():
  return cfgs.INDENT_DEFAULT_SIZE


def	getVGPRCapcity():
  return cfgs.VGPR_CAPCITY_SIZE


def	GetCommentPos():
  return cfgs.COMMENT_POS


def get_flow_handler():
    flow_handler = FlowHandler(cfgs.FLOW_NAME, cfgs.FLOW_TEMP_START_INDEX,
                               cfgs.FLOW_STACK_START_INDEX, (not utils.get_code_sytle()))
    return flow_handler


class FlowHandler(singleton):
  __instance = None  # singlton class

  def __new__(cls, *args, **kwargs):

      if cls.__instance is None:
          cls.__instance = super(FlowHandler, cls).__new__(cls)
          cls.__instance.__initialized = False
      return cls.__instance

  def __init__(self, name, tempStart, stackStart, mode):
    if self.__initialized:
      return
    self.__initialized = True

    self.enableRelu = True
    self.name = name
    self.mode = mode
    self.qTempStart = tempStart
    self.qStackStart = stackStart
    self.vgprNumber = getVGPRCapcity()
    self.vgprAllocList = []

    self.flowDepth = 0

    self.labelIndex = 0
    self.labelDepth = 0
    self.labelVector = []
    self.indentString = ""

    self.saveQTempStart = tempStart
    self.saveQStackStart = stackStart
    self.local_wsr_used = 0
    self.peek_wsr_used = 0
    self.saveLabelIndex = 0
    self.saveLabelDepth = 0
    self.saveLabelVector = []
    self.saveIndentString = ""
    self.saveVGPRAllocList = []
    self.saveVGPRNumber = self.vgprNumber

  def saveState(self):
    self.saveQTempStart = self.qTempStart
    self.saveQStackStart = self.qStackStart
    self.saveFlowDepth = self.flowDepth

    self.saveLabelIndex = self.labelIndex
    self.saveLabelDepth = self.labelDepth
    self.saveLabelVector = self.labelVector
    self.saveIndentString = self.indentString

    self.saveVGPRAllocList = copy.deepcopy(self.vgprAllocList)
    self.saveVGPRNumber = self.vgprNumber

  def restoreState(self):
    self.qTempStart = self.saveQTempStart
    self.qStackStart = self.saveQStackStart
    self.flowDepth = self.saveFlowDepth

    self.labelIndex = self.saveLabelIndex
    self.labelDepth = self.saveLabelDepth
    self.labelVector = self.saveLabelVector
    self.indentString = self.saveIndentString

    self.vgprAllocList = copy.deepcopy(self.saveVGPRAllocList)
    self.vgprNumber = self.saveVGPRNumber

  ####################################################
  # indent handling
  def getIndentStr(self):
    return self.indentString

  def increaseIndent(self):
    self.flowDepth += 1
    self.indentString = self.indentString + str(' ' * getIndentSize())

  def decreaseIndent(self):
    assert (self.flowDepth > 0), "nested flow underflow"
    self.flowDepth -= 1
    self.indentString = self.indentString[:-getIndentSize()]

  ####################################################
  # label handling
  def increaseLabel(self, step):
    self.labelVector.append(self.labelIndex)
    self.labelDepth += 1
    self.labelIndex += step

  def decreaseLabel(self):
    assert (self.labelDepth > 0), "label underflow"
    self.labelVector = self.labelVector[:-1]
    self.labelDepth -= 1

  def getLabel(self, index):
    return "LABEL_" + self.name + "_" + str(self.labelVector[-1] + index)

  def setLabelSuffix(self, newLabelSuffix):
    self.name = newLabelSuffix.upper()

  def setLabelIndex(self, newLabelIndex):
    self.labelIndex = newLabelIndex

  ####################################################
  # sgpr handling
  def getQTempStart(self):
    return self.qTempStart

  def setQTempStart(self, newTempStart):

    self.qTempStart = newTempStart

  def getQStackStart(self):
    return self.qStackStart

  def setQStackStart(self, newStackStart):
    self.qStackStart = newStackStart

  def allocateSGPR(self, number):
    startIndex = cfgs.FLOW_TEMP_START_INDEX if \
      self.qTempStart < cfgs.FLOW_TEMP_START_INDEX \
      else self.qTempStart

    self.qTempStart += number
    # start_q = str(resource_man.wsr_alloc())
    # print("==========", start_q)
    # number -= 1
    # if number >= 1:
    #   while number > 0:
    #      resource_man.wsr_alloc()
    #      number -= 1
    # startIndex = start_q.split('q')[-1]
    # self.qTempStart = startIndex
    # qStack start from high, and qTemp starts from low
    self.local_wsr_used = 32 - self.qStackStart + self.qTempStart
    self.peek_wsr_used = max(self.local_wsr_used, self.peek_wsr_used)
    resource_man.set_req_wsr(self.peek_wsr_used)

    return startIndex

  def releaseSGPR(self, number):
    self.qTempStart -= number

    # while number > 0:
    #    resource_man.wsr_free("q"+str(self.qTempStart+number-1))
    #    number -= 1

  ####################################################
  # vgpr handling
  def getAvailVGPRNumber(self):
    return self.vgprNumber

  def reserveVGPR(self, start, number):
    index = 0
    assert self.vgprNumber >= number, "not enough vgprs to reserve"

    for x in self.vgprAllocList:
      if not (((x[0] + x[1]) <= start) or ((start + number) <= x[0])):
        assert False, " reserve vgpr fail, address [" + str(start) + ", " + str(start + number) + ") not free"
        return -1

      if (x[0] < start):
        index += 1

    self.vgprAllocList.insert(index, [start, number])

    self.vgprNumber -= number

    return start

  def allocateVGPR(self, number):
    assert self.vgprNumber >= number, "not enough vgprs to allocate"

    bestAddr = 0
    bestIndex = -1
    bestSpace = getVGPRCapcity() + 1

    lastAddr = 0
    index = 0

    for x in self.vgprAllocList:
      thisSpace = x[0] - lastAddr
      if (thisSpace >= number and thisSpace < bestSpace):
        bestIndex = index
        bestSpace = thisSpace
        bestAddr = lastAddr

      lastAddr = x[0] + x[1]
      index += 1

    if lastAddr != getVGPRCapcity():
      thisSpace = getVGPRCapcity() - lastAddr
      if (thisSpace >= number and thisSpace < bestSpace):
        bestIndex = index
        bestSpace = thisSpace
        bestAddr = lastAddr

    assert bestIndex >= 0, "no continous vgprs to allocate"

    self.vgprAllocList.insert(bestIndex, [bestAddr, number])
    self.vgprNumber -= number
    return bestAddr

  def releaseVGPR(self, addr):
    index = 0
    foundIndex = -1

    for x in self.vgprAllocList:
      if (x[0] == addr):
        self.vgprNumber += x[1]
        foundIndex = index
        break

      index += 1

    assert foundIndex >= 0, "vgpr not found in allocation list"
    del self.vgprAllocList[foundIndex]

  ####################################################
  # loop/if block handling
  def startForLoop(self, loopStart, loopValue, loopStep, qIndex, comment, qIndexStr=None):
    if (qIndex >= 0):
      qRegStr = "q" + str(qIndex)
    else:
      qRegStr = "q" + str(self.qTempStart)

    if qIndexStr is not None:
          qRegStr = qIndexStr

    indentstring = self.getIndentStr()

    if self.mode == 0:
      endClause = ")"
      if (loopStart == ""):
        funcLib.AlignPrint(indentstring + "for (, " + qRegStr + "<" + loopValue + ", " + qRegStr + "+=" + loopStep + ")", GetCommentPos(), "//" + comment)
        # br_print (self.getIndentStr() + "for (, " + qRegStr + "<" + loopValue + ", " + qRegStr + "+=" + loopStep + endClause)
      else:
        funcLib.AlignPrint(indentstring + "for (" + qRegStr + "=" + loopStart + ", " + qRegStr + "<" + loopValue + ", " + qRegStr + "+=" + loopStep + ")", GetCommentPos(), "//" + comment)
        # br_print (self.getIndentStr() + "for (" + qRegStr + "=" + loopStart + ", " + qRegStr + "<" + loopValue + ", " + qRegStr + "+=" + loopStep + endClause)
      br_print (self.getIndentStr() + "{")
      self.increaseIndent()
    else:
      self.increaseLabel(1)
      if (loopStart != ""):
        br_print (self.getIndentStr() + "smov " + qRegStr + ", " + loopStart)

      funcLib.AlignPrint(self.getLabel(0) + ":", GetCommentPos(), "// " + comment)

      # if (comment != ""):
      #  br_print (self.getLabel(0) + ":" + "\t\t\t// " + comment)
      # else:
      #  br_print (self.getLabel(0) + ":")

    if (qIndex < 0):
      self.qTempStart += 1

  def closeForLoop(self, loopStart, loopValue, loopStep, qIndex):
    if (qIndex < 0):
      self.qTempStart -= 1

    loopEndStr = loopValue

    if (self.mode != 0) and loopValue.isdigit():
      intVal = int (loopValue)
      if (intVal >= 64):
        loopEndStr = "q" + str(self.qTempStart + 1)
        br_print (self.getIndentStr() + "// move out of range imm to a sgpr")
        br_print (self.getIndentStr() + "smov " + loopEndStr + ", " + str(loopValue))
        self.qTempStart -= 1

    if self.mode == 0:
      self.decreaseIndent()
      br_print (self.getIndentStr() + "}")
    else:
      if (qIndex >= 0):
        qRegStr = "q" + str(qIndex)
      else:
        qRegStr = "q" + str(self.qTempStart)

      br_print (self.getIndentStr() + "sadd " + qRegStr + ", " + qRegStr + ", " + loopStep)
      br_print (self.getIndentStr() + "blts.rel " + qRegStr + ", " + loopEndStr + ", " + self.getLabel(0))
      self.decreaseLabel()

  # startIfLoop(spatialXSGPRStr, str(usharpList[fcActivationUSharpIndex][3]), ">=", 0)
  def startIfLoop(self, aSource, bSource, relation, hasElse):
    if self.mode == 0:
      br_print (self.getIndentStr() + "if (" + aSource + relation + bSource + ")")
      br_print (self.getIndentStr() + "{")
      self.increaseIndent()
    else:
      self.increaseLabel(2)

      tempQIndex = self.qTempStart

      if (aSource.isdigit()):
        aInt = int(aSource)
        if (aInt >= 64):
          aSource = "q" + str(tempQIndex)
          tempQIndex += 1
          br_print (self.getIndentStr() + "smov " + aSource + ", " + str(aInt))

      if (bSource.isdigit()):
        bInt = int(bSource)
        if (bInt >= 64):
          bSource = "q" + str(tempQIndex)
          br_print (self.getIndentStr() + "smov " + bSource + ", " + str(bInt))

      if (bSource == "0" and relation == "=="):
        relation = "nz"
        bSource = ""
      elif (relation == "=="):
        relation = "ne"
      elif (relation == "!="):
        relation = "eq"
      elif (relation == ">"):
        relation = "les"
      elif (relation == ">="):
        relation = "lts"
      else:
        if (relation == "<"):
          # proceed if a < b, jump if b>=a
          relation = "les"
        elif (relation == "<="):
          relation = "lts"
        else:
          assert False, " relation operation " + relation + " not supported yet"

        tempSrc = bSource
        bSource = aSource
        aSource = tempSrc

      if (bSource != ""):
        bSource = bSource + ", "

      br_print (self.getIndentStr() + "b" + relation + ".rel " + aSource + ", " + bSource + self.getLabel(1 - hasElse))

  def startElseLoop(self):
    if self.mode == 0:
      self.decreaseIndent()
      br_print (self.getIndentStr() + "}")
      br_print (self.getIndentStr() + "else")
      br_print (self.getIndentStr() + "{")
      self.increaseIndent()
    else:
      br_print (self.getIndentStr() + "jump " + self.getLabel(1))
      br_print (self.getLabel(0) + ":")

  def closeIfLoop(self):
    if self.mode == 0:
      self.decreaseIndent()
      br_print (self.getIndentStr() + "}")
    else:
      br_print (self.getLabel(1) + ":")
      self.decreaseLabel()

  ####################################################
  # function definition handling

  def startMainDef(self, functionName):
    if self.mode == 0:
      br_print (self.getIndentStr() + "main " + functionName)
      br_print (self.getIndentStr() + "{")
      self.increaseIndent()
    else:
      name = functionName.upper()
      br_print (".global " + name)
      br_print (".type " + name + ", @function")
      br_print (name + ":")
      self.increaseIndent()

  def closeMainDef(self):
    if self.mode == 0:
      self.decreaseIndent()
      br_print (self.getIndentStr() + "}")
    else:
      self.decreaseIndent()
      br_print (self.getIndentStr())
      br_print (self.getIndentStr())
      br_print (self.getIndentStr())

  def startFunctionDef(self, functionName, isCall):
    if isCall:
      set_print_subfunc_stage(start=True)

    if self.mode == 0:
      if (isCall == 0):
        br_print (self.getIndentStr() + "main " + functionName)
      else:
        br_print (self.getIndentStr() + "func " + functionName)
      br_print (self.getIndentStr() + "{")
      self.increaseIndent()
    else:
      if (isCall):
        labelName = "FUNC_" + functionName.upper()
        br_print (".local " + labelName, print_level=bdp.BR_PRINT_LEVEL_SUBFUNC_DECLARE)
        br_print (".type " + labelName + ", @function", print_level=bdp.BR_PRINT_LEVEL_SUBFUNC_DECLARE)

        br_print (".local " + labelName)
        br_print (".type " + labelName + ", @function")
        br_print ("FUNC_" + functionName.upper() + ":")
      else:
        br_print (functionName.upper() + ":")

      self.increaseIndent()
      if (isCall):
        self.qStackStart -= 1

  def markShaderSize(self, functionName, isCall):
    if self.mode != 0:
      if (isCall):
        labelName = "FUNC_" + functionName.upper()
      else:
        labelName = functionName.upper()

      br_print(labelName + "_END:")
      br_print(str(' ' * getIndentSize()) + ".size" + " " + labelName + ", " + labelName + "_END-" + labelName)

  def closeFunctionDef(self, functionName, isCall):
    if self.mode == 0:
      self.decreaseIndent()
      br_print (self.getIndentStr() + "}")
    else:
      if (isCall):
        self.qStackStart += 1
        br_print (self.getIndentStr() + "ret q" + str(self.qStackStart))

      self.decreaseIndent()

    br_print(self.getIndentStr())
    if (self.mode != 0 and isCall != 0):
      self.markShaderSize(functionName, isCall)

    br_print (self.getIndentStr())
    br_print(self.getIndentStr())

    if isCall:
      set_print_subfunc_stage(start=False)

  def startFunctionCall(self, functionName):
    if self.mode == 0:
      br_print (self.getIndentStr() + "call.rel " + functionName)
    else:
      br_print (self.getIndentStr() + "call.rel q" + str(self.qStackStart) + " FUNC_" + functionName.upper())
      self.qStackStart -= 1

  def endFunctionCall(self):
    if self.mode != 0:
      self.qStackStart += 1

  def reset(self):
      FlowHandler.__instance = None

