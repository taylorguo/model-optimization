#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import vector.common.constDefs as cfgs

def WarpSimtId():
  return cfgs.WARP_SIMT_ID

def TileSizeX():
  return cfgs.TILE_SIZE_X

def TileSizeY():
  return cfgs.TILE_SIZE_Y

def SurfaceFormatTypeMask():
  return cfgs.SurfaceFormatType.get("mask")

def SurfaceFormatTypeFloat():
  return cfgs.SurfaceFormatType.get("float")

def SurfaceFormatTypeUINT():
  return cfgs.SurfaceFormatType.get("unit")

def SurfaceFormatTypeSINT():
  return cfgs.SurfaceFormatType.get("sint")

def SurfaceFormatBPPMask():
  return cfgs.SurfaceFormatBpp.get("mask")

def SurfaceFormatBPP16():
  return cfgs.SurfaceFormatBpp.get("16")
def SurfaceFormatBPP8():
  return 8


def SurfaceFormatBPP32():
  return cfgs.SurfaceFormatBpp.get("32")

def GetSurfaceFormatBpp(surfFormat):
  return surfFormat & SurfaceFormatBPPMask()

def GetSurfaceFormatType(surfFormat):
  return surfFormat & SurfaceFormatTypeMask()

def GetSurfaceFormatFloat(surfFormat):
  return surfFormat & SurfaceFormatTypeFloat()


def SurfaceFormatSINT8():
  return SurfaceFormatTypeSINT() | SurfaceFormatBPP8()
def SurfaceFormatFP16():
  return SurfaceFormatTypeFloat() | SurfaceFormatBPP16()

def SurfaceFormatFP32():
  return SurfaceFormatTypeFloat() | SurfaceFormatBPP32()

def SurfaceFormatUINT16():
  return SurfaceFormatTypeUINT() | SurfaceFormatBPP16()

def SurfaceFormatUINT32():
  return SurfaceFormatTypeUINT() | SurfaceFormatBPP32()

def	SurfaceType1DVector():
  return cfgs.SurfaceType.get("1DVector")

def	SurfaceType2DWeight():
  return cfgs.SurfaceType.get("2DWeight")

def	SurfaceType3DActivation():
  return cfgs.SurfaceType.get("3DActivation")

def	SurfaceType4DWeight():
  return cfgs.SurfaceType.get("4DWeight")

def GetSurfaceType(surfaceType):
  if (surfaceType == SurfaceType1DVector()):
    return "1DVector    "
  elif (surfaceType == SurfaceType2DWeight()):
    return "2DWeight    "
  elif (surfaceType == SurfaceType3DActivation()):
    return "3DActivation"
  elif (surfaceType == SurfaceType4DWeight()):
    return "4DWeight    "
  else:
    return "Invalid"

# for load, sld with desc
# no mdem is needed
# sld might have a different one
#
def MaxLoadGranule():
  return cfgs.MAX_LOAD_GRANULE

# for st
def MaxStoreGranule():
  return cfgs.MAX_STORE_GRANULE

# should be 16, regardless of format
def MaxLDMGranule():
  return cfgs.MAX_LDM_GRANULE

# should be 16 for mdem 16bpp and 8 for mdem 32bpp
# unite to 8 vgpr
def MaxSTMGranule():
  return cfgs.MAX_STM_GRANULE

# unit is vgpr
def MaxALUGranule():
  return cfgs.MAX_ALU_GRANULE

def MaxBNGranule():
  return cfgs.MAX_BN_GRANULE

def MaxMovGranule():
  return cfgs.MAX_MOV_GRANULE

def MaxLLDWGranule():
  return cfgs.MAX_LLDW_GRANULE

def MaxIMM():
  return cfgs.MAX_IMM


