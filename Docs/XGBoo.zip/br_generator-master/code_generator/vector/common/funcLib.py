#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

from code_generator.share.br_defined_print import br_print

####################################################
#
#
def IsPower2(x):
  return (x & (x-1)) == 0

def AlignToPower2(x):
  if (x & (x-1)) == 0:
    return x
  else:
    msbBit = 0
    while (x!=0):
      x = x >> 1
      msbBit += 1

    return (1 << msbBit)

def AlignToUnit(x, unit):
  z = x & (unit - 1)

  if (z == 0):
    return x
  else:
    return x - z + unit
####################################################
#
#
def GetLeadingOnePos(x):
  bitPos = -1

  while (x!=0):
    x = x >> 1
    bitPos += 1

  return bitPos


####################################################
#
#
def IncAndWrap(x, bound):
  x += 1

  if (x == bound):
    return 0
  else:
    return x


####################################################
# find out how many threads are valid within h, w
# if inv is set, return thread mask not convered by h, w
# assume tile size is 4*8
def GetThreadActiveMask(h, w, inv):
  if (w == 0):
    mask = 255 # 0xff x direction 8
  else:
    mask = (1 << w) - 1

  if (h == 0):
    h = 4

  finalMask = 0

  for y in range (h):
    finalMask <<= 8
    finalMask |= mask

  if (inv != 0):
    # change the highest 1 bit into
    finalMask = ((~finalMask) & 0xffffffff)
    if finalMask >> 31:
        finalMask = -((~finalMask) & 0x7fffffff)

  return finalMask



####################################################
#
#
def AlignPrint(printstr, commentPosition, commentstr):
  if (commentstr == ""):
    br_print(printstr)
  else:
    textLen = len(printstr)
    if (textLen >= commentPosition):
      spaceNumber = 2
    else:
      spaceNumber = commentPosition - textLen

    br_print(printstr, comment=commentstr)



####################################################
#
#
def SplitRepeatIntoGroups(repeatSize, maxGranule):

  repeatSizeGroups = []

  curGranule = maxGranule

  while (repeatSize != 0):
    if (repeatSize >= maxGranule):
      granuleNumber = int(repeatSize/maxGranule)
      repeatSizeGroups.append([granuleNumber, maxGranule])
      repeatSize -= granuleNumber * maxGranule
    else:
      if (repeatSize & curGranule):
        repeatSizeGroups.append([1, curGranule])
        repeatSize -= curGranule

      curGranule = curGranule >> 1

  return repeatSizeGroups



####################################################
#
#
def convertHalfToFloat(inputStr):
  halfFloat = int(inputStr, 16) << 16
  dwData = pack('I', halfFloat)
  floatData = (unpack('f', dwData))[0]

  return floatData



