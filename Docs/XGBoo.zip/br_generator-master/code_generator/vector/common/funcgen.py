#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

####################################################
# collect function that is called at code gen time, with static parameters
#
#
class FuncGenHandler:
  def __init__(self):
    self.funcDefMap = {}

  def clear(self):
    self.funcDefMap = {}

  # return sgpr is used in both caller and callee
  # so this method does not work anymore
  def addFunction(self, functionName, newSGPRInUse):

    # stack top is reserved for return address
    newSGPRInUse[1] -= 1

    if (functionName in self.funcDefMap):
      sgprInUse = self.funcDefMap[functionName]
      update = 0

      if (sgprInUse[0] < newSGPRInUse[0]):
        sgprInUse[0] = newSGPRInUse[0]
        update = 1

      if (sgprInUse[1] > newSGPRInUse[1]):
        assert False, "wsr stack changes, should use indirect wsr, as wsr is used in both caller and callee"
        sgprInUse[1] = newSGPRInUse[1]
        update = 1

      if (update != 0):
        self.funcDefMap[functionName] = sgprInUse

    else:
      self.funcDefMap[functionName] = newSGPRInUse

  def getFuncDef(self):
    return self.funcDefMap
