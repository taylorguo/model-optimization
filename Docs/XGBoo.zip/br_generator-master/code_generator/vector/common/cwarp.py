#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

def CWarpNumber():
  return 5

def GetCMDIndex():
  return 0

def GetUSharpIndex():
  return 1

def GetVGPRPartitionIndex():
  return 2

def GetOptionsIndex():
  return 3

####################################################
# bar id

# 2 bars, ping-pong
def GetReduce2BNSyncBarId():
  return 4


# 2 bars, ping-pong
def GetBN2ReduceSyncBarId():
  return 6


####################################################
# wbar id

def GetAllSyncWBarId():
  return 1


def GetDWCLDDWWBarId():
  return 2


# 2 bars, ping-pong
def GetConv2ReduceWBarId():
  return 4


# 2 bars, ping-pong
def GetReduce2ConvWBarId():
  return 6

####################################################
# dtg bar id

def GetAllSynDWBarId():
  return 1