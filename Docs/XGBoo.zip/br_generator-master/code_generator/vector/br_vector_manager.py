#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
from code_generator.share.br_singleton_base import singleton
from code_generator.share.br_cwarp_man import cwarp_top
from code_generator.share.br_utils import Br_Indent
from code_generator.vector.br_vector_ops import bars_ini


class vector_top(singleton):
    __instance = None  # singlton class

    def __new__(cls, *args, **kwargs):
        if cls.__instance is None:
            cls.__instance = super(vector_top, cls).__new__(cls)
            cls.__instance.__initialized = False
        return cls.__instance

    def __init__(self):
        if(self.__initialized):
            return
        self.__initialized = True
        self.is_bar_inited = False
        self.bars_ini = bars_ini()

    def start_warp(self, warpid=3, 
        init_tcore_producer=True, init_reduce_producer=True):
        self.cwarp_man = cwarp_top()
        self.cwarp_man.start_warp(warpid)
        if self.cwarp_man.is_new_cwarp():
            # self.cwarp_man.gen_warp_header(warpid)
            if not self.is_bar_inited:
                self.bars_ini.generate(Br_Indent(), 
                    init_tcore_producer, init_reduce_producer)
                self.is_bar_inited = True

    def end_warp(self):
        self.cwarp_man.end_warp()
        
