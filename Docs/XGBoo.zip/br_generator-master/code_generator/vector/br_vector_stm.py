#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
from code_generator.vector.br_vector_cooperative_operator import co_operator
import code_generator.share.br_const_defs as bcd


class stm(co_operator):

    def __init__(
            self, warpid, usharpid, loopconfig,
            layerid=None, layernum=None, merge_reduce=False, sync_layer=False,
            wred_usharpid=None, wred_channelnum=None, force_ackgmb=False, 
            with_icpartition=False, with_extension=False, enable_8tlr_burst=False,
            micro_batch_mode=False):
        super().__init__()
        self.opname = "stm"

        self.sync_defs["bar_pass"]["comment"]["init"] = \
            "// Process stm->conv, init pass bar id"
        self.sync_defs["bar_pass"]["comment"]["produce"] = \
            "// Process stm->conv, inform conv to conitue"
        self.sync_defs["bar_csm"]["comment"]["init"] = \
            "// Process conv->stm, init csm bar id"
        self.sync_defs["bar_csm"]["comment"]["consume"] = \
            "// Process conv->stm, wait for signal from conv"

        self.base_reg = None
        self.merge_reduce = merge_reduce
        self.wred_usharpid = wred_usharpid
        self.wred_channelnum = wred_channelnum
        self.force_ackgmb = force_ackgmb
        self.sync_layer = sync_layer
        self.with_extension = with_extension

        self.layer_id = layerid
        self.layer_num = layernum
        self.warp_id = warpid
        self.usharpid = usharpid
        self.loopconfig = loopconfig
        self.enable_8tlr_burst = enable_8tlr_burst
        self.micro_batch_mode = micro_batch_mode

    def _generate_loop_body(self, epilog=None):
        if self.enable_8tlr_burst:
            self._gen_8tlr_burst_kernel(epilog)
        else:
            self._gen_no_burst_kernel(epilog)

    def _gen_8tlr_burst_kernel(self, epilog):
        stm_cfgs = []
        vgpr_stride = 4
        stm_modifier = "float.mb16.rb16.mmat3d.wt.e8.gc8"
        mov_modifier = "v4"
        mov_operands = "z0.f16, {}.f16.a"

        stm_cfgs.append([stm_modifier, mov_modifier, mov_operands.format('ir0')])

        if (self.outer_z is not None) and \
                (self.inner_z is not None):
            self.sadd.generate(
                self.flow_man.get_indent(),
                dst=self.inner_z,
                src1=self.inner_z,
                src2=self.z_offset,
                comment="// Calcluate z with euid included")

        if epilog is not None:
            self.op_mask.generate(
                self.flow_man.get_indent(), 0, int(epilog))

        if bcd.OC64_CONV_ROW64_MMA:
            vgpr_stride = 8
            stm_cfgs.append([stm_modifier, mov_modifier, mov_operands.format('ir4')])

        iter = -1
        for stm_cfg in stm_cfgs:
            iter += 1
            stm_modifier, mov_modifier, mov_operands = stm_cfg[0], stm_cfg[1], stm_cfg[2]
            self.stm.generate(
                self.flow_man.get_indent(),
                modifier=stm_modifier,
                operands="g0, g4, u{}".format(self.usharpid),
                comment="// Store data")

            self.mov.generate(
                self.flow_man.get_indent(),
                parallel=1,
                modifier=mov_modifier,
                operands=mov_operands,
                comment="// Assign data")

            if (self.outer_x is not None) and \
                    (self.x is not None):
                self.saddg.generate(
                    self.flow_man.get_indent(),
                    dst="g0", src1=self.outer_x,
                    src2=self.x,
                    comment="// Assign x")
            elif self.outer_x is not None:
                self.smovg.generate(
                    self.flow_man.get_indent(),
                    dst="g0", src1=self.outer_x,
                    comment="// assign x")
            elif self.x is not None:
                self.smovg.generate(
                    self.flow_man.get_indent(),
                    dst="g0", src1=self.x,
                    comment="// Assign x")
            else:
                self.smovg.generate(
                    self.flow_man.get_indent(),
                    dst="g0", src1=0,
                    comment="// Assign x")

            self.smovg.generate(
                self.flow_man.get_indent(),
                dst="g1",
                src1=self.y if self.y is not None else 0,
                comment="// Assign y")

            if (self.outer_z is not None) and \
                    (self.inner_z is not None):
                self.saddg.generate(
                    self.flow_man.get_indent(),
                    dst="g2", src1=self.outer_z,
                    src2=self.inner_z,
                    comment="// Assign z")
            elif self.outer_z is not None:
                self.saddg.generate(
                    self.flow_man.get_indent(),
                    dst="g2", src1=self.outer_z,
                    src2=self.z_offset,
                    comment="// Assign z")
            elif self.inner_z is not None:
                self.saddg.generate(
                    self.flow_man.get_indent(),
                    dst="g2", src1=self.inner_z,
                    src2=self.z_offset,
                    comment="// Assign z")
            else:
                self.smovg.generate(
                    self.flow_man.get_indent(),
                    dst="g2", src1=self.z_offset,
                    comment="// Assign z")

            src1 = self.w if self.w is not None else 0
            self.smovg.generate(
                self.flow_man.get_indent(),
                modifier="eog",
                dst="g3", 
                src1=src1, 
                comment="// Assign w")

            if bcd.OC64_CONV_ROW64_MMA:
                if iter == 0: # Go to next oc32
                    self.sadd.generate(
                        self.flow_man.get_indent(),
                        dst=self.z_offset,
                        src1=self.z_offset,
                        src2=32,
                        comment="// Accumate oc32 to update z axis")
                elif iter == 1: # Roll back to start of oc64
                    self.sadd.generate(
                        self.flow_man.get_indent(),
                        dst=self.z_offset,
                        src1=self.z_offset,
                        src2=-32,
                        comment="// Restore back oc32 to initial position")
                else:
                    assert False, "Internal error to handle oc64 in stm operator!"

        self.sadda.generate(
            self.flow_man.get_indent(),
            dst=self.base_reg,
            src1=vgpr_stride,
            src2=self.base_reg,
            comment="// Increase vgpr base")


    def _gen_no_burst_kernel(self, epilog):
        stm_cfgs = []
        vgpr_stride = 2
        stm_modifier = "float.mb16.rb16.mmat3d.wt.e4.gc6"
        mov_modifier = "v2"
        dst_op = "g4.f16, " if not bcd.BR_STM_G4_FEATURE_ENABLE else "z0.f16, "
        mov_operands = dst_op + "{}.f16.a" if not bcd.BR_STM_G4_FEATURE_ENABLE else dst_op + "{}.f16.a"
        if self.stm_no_burst:
            vgpr_stride = 1
            stm_modifier = "float.mb16.rb16.mmat3d.wt.e2.gc5"
            mov_modifier = "v1"
            mov_operands = dst_op + "{}.f16" if not bcd.BR_STM_G4_FEATURE_ENABLE else dst_op + "{}.f16"

        stm_cfgs.append([stm_modifier, mov_modifier, mov_operands.format('ir0')])

        if (self.outer_z is not None) and \
                (self.inner_z is not None):
            self.sadd.generate(
                self.flow_man.get_indent(),
                dst=self.inner_z,
                src1=self.inner_z,
                src2=self.z_offset,
                comment="// Calcluate z with euid included")

        if epilog is not None:
            self.op_mask.generate(
                self.flow_man.get_indent(), 0, int(epilog))

        if bcd.OC64_CONV_ROW64_MMA:
            vgpr_stride = 8 # For cbr_k7 only - ping:0,1;4,5;8,9... pong:2,3;6,7;10,11...
            stm_cfgs.append([stm_modifier, mov_modifier, mov_operands.format('ir4')])

        iter = -1
        for stm_cfg in stm_cfgs:
            iter += 1
            stm_modifier, mov_modifier, mov_operands = stm_cfg[0], stm_cfg[1], stm_cfg[2]
            self.stm.generate(
                self.flow_man.get_indent(),
                modifier=stm_modifier,
                operands="g0, g4, u{}".format(self.usharpid),
                comment="// Store data")

            #if not bcd.BR_STM_G4_FEATURE_ENABLE:
            self.mov.generate(
                self.flow_man.get_indent(),
                parallel=1,
                modifier=mov_modifier,
                operands=mov_operands,
                comment="// Assign data")
            # else:
            #     self.fadd.generate(
            #         indent_level=self._get_indent(),
            #         parallel=1,
            #         modifier=mov_modifier+".b16",
            #         operands=mov_operands + ", 0.0",
            #         comment="// Assign data")

            if (self.outer_x is not None) and \
                    (self.x is not None):
                if self.outer_x == "0":
                    self.smovg.generate(
                        self.flow_man.get_indent(),
                        dst="g0", src1=self.x,
                        comment="// Assign x")
                else:
                    self.saddg.generate(
                        self.flow_man.get_indent(),
                        dst="g0", src1=self.outer_x,
                        src2=self.x,
                        comment="// Assign x")                 
            elif self.outer_x is not None:
                self.smovg.generate(
                    self.flow_man.get_indent(),
                    dst="g0", src1=self.outer_x,
                    comment="// assign x")
            elif self.x is not None:
                self.smovg.generate(
                    self.flow_man.get_indent(),
                    dst="g0", src1=self.x,
                    comment="// Assign x")
            else:
                self.smovg.generate(
                    self.flow_man.get_indent(),
                    dst="g0", src1=0,
                    comment="// Assign x")

            src1 = self.y if self.y is not None else 0
            self.smovg.generate(
                self.flow_man.get_indent(),
                dst="g1", src1=src1,
                comment="// Assign y")

            merge_add_to_stage = False
            if (self.outer_z is not None) and \
                    (self.inner_z is not None):
                self.saddg.generate(
                    self.flow_man.get_indent(),
                    dst="g2", src1=self.outer_z,
                    src2=self.inner_z,
                    comment="// Assign z")
            elif self.outer_z is not None:
                self.saddg.generate(
                    self.flow_man.get_indent(),
                    dst="g2", src1=self.outer_z,
                    src2=self.z_offset,
                    comment="// Assign z")
            elif self.inner_z is not None:
                self.saddg.generate(
                    self.flow_man.get_indent(),
                    dst="g2", src1=self.inner_z,
                    src2=self.z_offset,
                    comment="// Assign z")
            else:
                if bcd.OC64_CONV_ROW64_MMA:
                    merge_add_to_stage = True
                    if iter == 0: # Go to next oc32
                        self.smovg.generate(
                            self.flow_man.get_indent(),
                            dst="g2", src1=self.z_offset,
                            comment="// Assign z")
                    elif iter == 1:
                        self.saddg.generate(
                            self.flow_man.get_indent(),
                            dst="g2", 
                            src1=self.z_offset,
                            src2=32,
                            comment="// Assign z")  
                else:
                        self.smovg.generate(
                            self.flow_man.get_indent(),
                            dst="g2", 
                            src1=self.z_offset,
                            comment="// Assign z")                                         

            src1 = self.w if self.w is not None else 0
            self.smovg.generate(
                self.flow_man.get_indent(),
                modifier="eog",
                dst="g3", src1=src1,
                comment="// Assign w")

            if bcd.OC64_CONV_ROW64_MMA:
                if not merge_add_to_stage:
                    if iter == 0: # Go to next oc32
                        self.sadd.generate(
                            self.flow_man.get_indent(),
                            dst=self.z_offset,
                            src1=self.z_offset,
                            src2=32,
                            comment="// Accumate oc32 to update z axis")
                    elif iter == 1: # Roll back to start of oc64
                        self.sadd.generate(
                            self.flow_man.get_indent(),
                            dst=self.z_offset,
                            src1=self.z_offset,
                            src2=-32,
                            comment="// Restore back oc32 to initial position")
                    else:
                        assert False, "Internal error to handle oc64 in stm operator!"

        self.sadda.generate(
            self.flow_man.get_indent(),
            dst=self.base_reg,
            src1=vgpr_stride,
            src2=self.base_reg,
            comment="// Increase vgpr base")


    def _core_func(self):

        self.flow_man.generate_loop_config(self.loopconfig)

        self._generate_loop_header()

        self._generate_loop_body()

        self._generate_loop_tailer()
        
