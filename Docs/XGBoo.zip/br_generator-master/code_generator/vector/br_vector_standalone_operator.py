#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
from code_generator.vector.br_vector_base import vector
from code_generator.vector.common.funcgen import FuncGenHandler
from code_generator.share.br_defined_print import br_print
import code_generator.share.br_const_defs as bcd 
from abc import abstractmethod
import code_generator.vector.common.hwCaps as hwCaps
import code_generator.vector.common.funcLib as funcLib
import code_generator.vector.common.kernelLib as kernelLib

# this is the base implementation for standalone vector
# operators like bn/dwc/maxpooling/averpooling/loss etc
class standalone_operator(vector):

    def __init__(
            self,
            src_sample, src_channel,
            src_height, src_width,
            vgpr_range=None,
            dst_sample=None, dst_channel=None,
            dst_height=None, dst_width=None,
            idtype="bf16", wdtype="bf16", odtype="bf16"):

        super().__init__()
        self.core_func = None
        self.vgpr_range = vgpr_range
        self.loop_config = None
        self.flow_handler.outer_oc_loop = None
        self.flow_handler.inner_oc_loop = None

        self.operator_name = None
        self.fun_gen_handler = FuncGenHandler()
        self.src_sample = src_sample
        self.src_channel = src_channel
        self.src_height = src_height
        self.src_width = src_width

        self.micro_batch_mode = False

        # Vgpr attributes
        self.vgpr_stride = None
        self.buffer_num = 2
        self.y_span_list = []
        self.x_align_size = None
        self.block_size_x = None
        self.eu_id_sgpr = None
        self.reduce_2_bn_barid_sgpr = None
        self.bn_2_reduce_barid_sgpr = None
        self.z_axis_sgpr = None

        # Operator descriptions
        self.usharp_info = []
        self.sgpr_info = []
        self.vgpr_info = []

        self.MAX_OFFSET_FOR_SLD_MMAT1D = 128
        self.TOLERANCE_EPILSON = 0.000001
        self.CHANNEL_GRANDULE = 32
        # yBorderType_blockHeight_syncId_rightBorder
        self.LOAD_FUNC_FORMAT = "layer_{}_warp_{}_sub_load_{}_{}_{}_{}"
        self.FUNC_TYPE_LOAD = "load"
        self.LOAD_LOOP_UNROLL_THRESHOLD = 16
        self.ALU_LOOP_UNROLL_THRESHOLD = 16
        self.HEIGHT_LOOP_UNROLL_THRESHOLD = 8
        # yBorderType_blockHeight_rightBorder
        self.ALU_FUNC_FORMAT = "layer_{}_warp_{}_sub_alu_{}_{}_{}"
        self.FUNC_TYPE_ALU = "alu"
        # Data type input and output
        self.idtype=idtype
        self.wdtype=wdtype
        self.odtype=odtype
        
    def _gen_descs(self):
        br_print("// Layer information:")
        br_print("//    Operator name: " + self.operator_name)
        br_print("//    Surface shape: NxCxHxW = {}x{}x{}x{}".format(
            self.src_sample, self.src_channel, self.src_height, self.src_width))

        br_print("// Usharp information:")
        br_print("//    U#ID    Type    Sample    Channel    Height    Widht")
        for info in self.usharp_info:
            br_print("//    ", info)

        br_print("// Tile information:")
        br_print("//    Tile number: TileX = {}, TileY = {}".format(
            self.tile_num_x, self.tile_num_y))
        br_print("// Surface Partition based on given vgpr:")
        br_print("//    Vgpr stride: " + str(self.vgpr_stride))
        br_print("//    Pipeline buffer numbers: " + str(self.buffer_num))
        br_print("//    Y dir partition (last row is not counted as needs special handling):")
        for y_span in self.y_span_list:
            br_print("//        Height: {}, Step: {}, Border: {}".format(
                y_span["SpanHeight"], y_span["BlockHeight"], y_span["BorderFlag"]))
        br_print("//    X dir partition (last col is not counted in partial block width, as needs special handling):")
        br_print("//        Width: {}, Step: {}, Border: {}".format(
            self.x_align_size, self.block_size_x, self.x_bottom_flag))
        
    def _parse_loop_config(self):
        self.outer_oc_cfg = None
        self.inner_oc_cfg = None
        self.inner_oc32_cfg = None
        if self.loop_config is not None:
            print("[SIMT BN] the loop config is: ", self.loop_config)
            for aloop in self.loop_config:
                if len(aloop) < 4:
                    continue
                max_value, inc = aloop[1]*aloop[3], aloop[3]
                if aloop[0] == self.OUTER_OC:
                    self.flow_handler.outer_oc_loop = aloop
                    outer_oc_sgpr = self._alloc_wsr("outer_oc_sgpr")
                    self.outer_oc_cfg = {"max_value":max_value, "inc":inc, "sgpr":outer_oc_sgpr}
                if aloop[0] == self.INNER_OC:
                    self.flow_handler.inner_oc_loop = aloop
                    inner_oc_sgpr = self._alloc_wsr("inner_oc_sgpr")
                    self.inner_oc_cfg = {"max_value":max_value, "inc":inc, "sgpr":inner_oc_sgpr}
                    if bcd.OC64_CONV_ROW64_MMA:
                        assert self.inner_oc_cfg["inc"] == 64, "Inner oc inc should be 64"
                        inner_oc32_sgpr = self._alloc_wsr("inner_oc32_sgpr")
                        self.inner_oc32_cfg = {"max_value":64, "inc":32, "sgpr":inner_oc32_sgpr}

    def _do_tiling(self, src_width, src_height):
        # const definitions within vector standalone operators
        self.TILE_SIZE_X = 8
        self.TILE_SIZE_Y = 4

        # use 5 bits to represent the mode of border
        self.BORDER_TYPE_BOTTOM = 1  # bit 0
        self.BORDER_TYPE_BOTTOM_PARTIAL = 2  # bit 1
        self.BORDER_TYPE_TOP = 4  # bit 2
        self.BORDER_TYPE_RIGHT = 8  # bit 3
        # BORDER_TYPE_LEFT = 16  # bit 4
        self.BORDER_TYPE_RIGHT_PARTIAL = 32  # bit 5
        self.BODER_TYPE_ALL = self.BORDER_TYPE_BOTTOM | (
                        self.BORDER_TYPE_RIGHT | self.BORDER_TYPE_TOP)  # bit 0, 2, 3

        self.tile_num_x = int((src_width + self.TILE_SIZE_X - 1) / self.TILE_SIZE_X)
        self.tile_num_y = int((src_height + self.TILE_SIZE_Y - 1) / self.TILE_SIZE_Y)
        self.border_type = self.BODER_TYPE_ALL
        if (src_height % self.TILE_SIZE_Y):
            self.border_type |= self.BORDER_TYPE_BOTTOM_PARTIAL
        if (src_width % self.TILE_SIZE_X):
            self.border_type |= self.BORDER_TYPE_RIGHT_PARTIAL

        self.y_bottom_flag = self.border_type & (
            self.BORDER_TYPE_BOTTOM | self.BORDER_TYPE_BOTTOM_PARTIAL)
        self.x_bottom_flag = self.border_type & (
            self.BORDER_TYPE_RIGHT | self.BORDER_TYPE_RIGHT_PARTIAL)

        self.image_width_res = self.src_width & (self.TILE_SIZE_X -1)
        self.image_height_res = self.src_height & (self.TILE_SIZE_Y -1)

    @abstractmethod
    def _allocate_sgpr(self):
        pass

    @abstractmethod
    def _calculate_surface_partition(self):
        pass

    @abstractmethod
    def _calculate_available_vgprs(self):
        pass

    @abstractmethod
    def _calculate_buffer_mode(self):
        pass

    @abstractmethod
    def _calculate_block_size_from_vgpr(self):
        pass

    @abstractmethod
    def _gen_main_kernel(self):
        pass
    
    @abstractmethod
    def _gen_sub_kernel(self):
        pass

    def _gen_euid_kernel(self):
        assert self.eu_id_sgpr != None, "Please allocate eu_id_sgpr"
        self.sysid.generate(
            indent_level=self._get_indent(),
            modifier="work",
            dst=self.eu_id_sgpr,
            comment="// Obtain hardware unit ids")
        self.sand.generate(
            indent_level=self._get_indent(),
            dst=self.eu_id_sgpr,
            src1=self.eu_id_sgpr,
            src2="0xf",
            comment="// Obtain unique eu id")

        if self.inner_oc_cfg is None or \
            self.inner_oc_cfg["sgpr"] is None:
            self.sshl.generate(
                indent_level=self._get_indent(),
                dst=self.z_axis_sgpr,
                src1=self.eu_id_sgpr,
                src2="1",
                comment="// Init z with channel pair start")
        else:
            self.sshl.generate(
                indent_level=self._get_indent(),
                dst=self.inner_oc_cfg["sgpr"],
                src1=self.eu_id_sgpr,
                src2="1",
                comment="// Init z with inner channel pair start")

    def _init_bn_bar_kernel(self):
        assert self.reduce_2_bn_barid_sgpr != None, "Please allcoate reduce_2_bn_barid_sgpr"
        assert self.bn_2_reduce_barid_sgpr != None, "Please allcoate bn_2_reduce_barid_sgpr"
        self.smov.generate(
            indent_level=self._get_indent(),
            dst=self.reduce_2_bn_barid_sgpr,
            src1=bcd.VECTOR_PINGPONG_REDUCE_TO_BN_BAR_ID_1,
            comment="// Set reduce -> bn bar id")
        self.smov.generate(
            indent_level=self._get_indent(),
            dst=self.bn_2_reduce_barid_sgpr,
            src1=bcd.VECTOR_PINGPONG_BN_TO_REDUCE_BAR_ID_1,
            comment="// Set bn -> reduce bar id")

    def _init_common_vgpr_bases(self):    
        self.smovs.generate(
            indent_level=self._get_indent(),
            dst=self.vgpr_base,
            src1=self.vgpr_start,
            comment="// Init vgpr base a1")       
        self.smov.generate(
            indent_level=self._get_indent(),
            dst=self.vgpr_load_base_sgpr,
            src1=self.vgpr_start,
            comment="// Init load vgpr base")
        self.smov.generate(
            indent_level=self._get_indent(),
            dst=self.vgpr_alu_base_sgpr,
            src1=self.vgpr_start,
            comment="// Init alu vgpr base") 

    def _core_process(self):
        self._free_wsr()
        self._parse_loop_config()

        if self.core_func is not None:
            self.core_func(
                self.layer_id, self.layer_num, self.warp_id,
                self.layer_info, self.flow_handler, 
                self.idtype, self.wdtype, self.odtype)
        else:
            self.flow_man.start_function_def(
                self._get_layer_label(), True)

            # funcs to inital status, the sgpr only reserve once
            # this will easy the dry_run mode design logics
            self._do_tiling(self.src_width, self.src_height)
            self._allocate_sgpr()
            self._calculate_available_vgprs()
            self._calculate_buffer_mode()
            self._calculate_block_size_from_vgpr()
            self._calculate_surface_partition()
            self._gen_descs()

            self._gen_main_kernel()
            self.flow_man.close_function_def(
                self._get_layer_label(), True)
            self._jump_to_next(self._get_indent())

            self._gen_sub_kernel()






