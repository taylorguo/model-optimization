#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
from code_generator.vector.br_vector_cooperative_operator import co_operator


class reduce(co_operator):

    def __init__(
            self, warpid, usharpid, channelnum, loopconfig,
            layerid=None, layernum=None, afterdwc=None,
            spcnum=20, force_ackgmb=False, sync_layer=False,
            micro_batch_mode=False):
        super().__init__()
        self.opname = "reduce"
        self.sync_defs["bar_sync"]["comment"]["init"] = \
            "// Process bn->reduce, init wait bar id"
        self.sync_defs["bar_sync"]["comment"]["consume"] = \
            "// Process bn->reduce, wait for signal from bn"
        self.sync_defs["bar_pass"]["comment"]["init"] = \
            "// Process reduce->conv, init pass bar id"
        self.sync_defs["bar_pass"]["comment"]["produce"] = \
            "// Process reduce->conv, inform conv to conitue"
        self.sync_defs["bar_csm"]["comment"]["init"] = \
            "// Process conv->reduce, init csm bar id"
        self.sync_defs["bar_csm"]["comment"]["consume"] = \
            "// Process conv->reduce, wait for signal from conv"

        self.layer_id = layerid
        self.layer_num = layernum
        self.warp_id = warpid
        self.usharpid = usharpid
        self.channelnum = channelnum
        self.afterdwc = afterdwc
        self.spc_num = spcnum
        self.loopconfig = loopconfig
        self.force_ackgmb = force_ackgmb
        self.sync_layer = sync_layer
        self.micro_batch_mode = micro_batch_mode

    def _core_func(self):
        self.op_wred.init_gen(self.flow_man.get_indent())

        self.flow_man.generate_loop_config(self.loopconfig)

        self._generate_loop_header()

        self.op_wred.core_gen(
            self.flow_man.get_indent(), 
            self.usharpid, 
            self.z_offset,
            self.slot_info["grb_pingpong"][0], 
            self.outer_z, 
            self.inner_z, 
            (self.w if self.micro_batch_mode else None),
            self.channelnum, 
            self.spc_num)

        self._generate_loop_tailer()