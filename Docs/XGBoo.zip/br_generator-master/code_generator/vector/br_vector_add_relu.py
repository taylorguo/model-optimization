#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import math, copy
from code_generator.vector.br_vector_standalone_operator import standalone_operator
import code_generator.share.br_const_defs as bcd
from code_generator.vector.common.funcgen import FuncGenHandler
import code_generator.vector.common.hwCaps as hwCaps
import code_generator.vector.common.funcLib as funcLib
import code_generator.vector.common.kernelLib as kernelLib
from code_generator.share.br_vector_instructions_def import*

class Load(object):
    def __init__(self, x_start, y_start, width, height, sc, data, indent):
        self.x_start = x_start
        self.y_start = y_start
        self.width = width
        self.height = height
        self.sc = sc
        self.data = data #may be usharp
        self.indent = indent
    def __enter__():
        pass

    def __exit__():
        pass

    def generate(self, vgpr_start, vgpr_num):

        # ldm.generate(self.indent, )
        pass

    def call(self):
        pass



class add_relu(standalone_operator):
    
    def __init__(self, warpid, vgpr_start, vgpr_end, usharp_0,
                 usharp_1, usharp_2, usharp_3=None, relu_on=True,
                 options=None, layer_id=None,
                 layer_num=None, force_ackgmb=False, sync_layer=False,
                 loop_config=None):

        super().__init__(
            usharp_0[1][0],  usharp_0[1][1], usharp_0[1][2], usharp_0[1][3],
            [vgpr_start, vgpr_end])
        if False:#relu_on
            assert (usharp_3 is not None), "Relu usharp is missing!"
            self.usharp_info = [
                    [usharp_0[0], "3d Activation",  usharp_0[1][0],  usharp_0[1][1], usharp_0[1][2], usharp_0[1][3], "input, 3d activation"],
                    [usharp_1[0], "3d Activation",  usharp_1[1][0],  usharp_1[1][1], usharp_1[1][2], usharp_1[1][3], "input, 3d activation"],
                    [usharp_2[0], "3d Activation",  usharp_2[1][0],  usharp_2[1][1], usharp_2[1][2], usharp_2[1][3], "add output, 3d activation"],
                    [usharp_3[0], "3d Activation",  usharp_3[1][0],  usharp_3[1][1], usharp_3[1][2], usharp_3[1][3], "relu output, 3d activation"]
                ]
        else:
            self.usharp_info = [
                    [usharp_0[0], "3d Activation",  usharp_0[1][0],  usharp_0[1][1], usharp_0[1][2], usharp_0[1][3], "input, 3d activation"],
                    [usharp_1[0], "3d Activation",  usharp_1[1][0],  usharp_1[1][1], usharp_1[1][2], usharp_1[1][3], "input, 3d activation"],
                    [usharp_2[0], "3d Activation",  usharp_2[1][0],  usharp_2[1][1], usharp_2[1][2], usharp_2[1][3], "relu output, 3d activation"]
                ]

        if layer_id is not None:
            self.layer_id = layer_id
        if layer_num is not None:
            self.layer_num = layer_num
        self.loop_config = loop_config
        self.warp_id = warpid
        self.operator_name = "AddRelu"
        self.usharpid_input_4d_activation_0 = usharp_0[0]
        self.usharpid_input_4d_activation_1 = usharp_1[0]
        self.usharpid_output_4d_activation = usharp_2[0]
        self.enable_relu = relu_on
        self.force_ackgmb = force_ackgmb
        self.sync_layer = sync_layer
        if False:#relu_on
            self.usharpid_output_4d_activation_relu = usharp_3[0]

    def _gen_main_kernel(self):
        print("_gen_main_kernel")
        self.smov.generate(
            indent_level=self._get_indent(),
            dst="q3",
            src1=bcd.VECTOR_PINGPONG_REDUCE_TO_BN_BAR_ID_1,
            comment="// Set reduce -> bn bar id")