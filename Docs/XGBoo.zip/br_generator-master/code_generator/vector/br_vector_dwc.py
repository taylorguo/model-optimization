#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
from code_generator.vector.br_vector_standalone_operator import standalone_operator
import code_generator.vector.golden.dwc as dwc_core
import code_generator.vector.common.hwCaps as hwCaps


class dwc(standalone_operator):
    def __init__(self, warpid, vgpr_start, vgpr_end,
                 usharp_0, usharp_1, usharp_2, options,
                 layerid=None, layernum=None, force_ackgmb=False, 
                 sync_layer=False, fused_tcore=False,
                 idtype="bf16", wdtype="bf16", odtype="bf16"):
        
        super().__init__(usharp_0[1][0],  usharp_0[1][1], usharp_0[1][2], usharp_0[1][3])
        self.core_func = dwc_core.gen_layer_main_kernel

        usharps_list = [
                [usharp_0[0], hwCaps.SurfaceType3DActivation(),  usharp_0[1][0],  usharp_0[1][1], usharp_0[1][2], usharp_0[1][3], "input, 3d activation"],
                [usharp_1[0], hwCaps.SurfaceType1DVector(),      usharp_1[1][0],  usharp_1[1][1], usharp_1[1][2], usharp_1[1][3], "weight, 1d vector"],
                [usharp_2[0], hwCaps.SurfaceType3DActivation(),  usharp_2[1][0],  usharp_2[1][1], usharp_2[1][2], usharp_2[1][3], "output, 3d activation"]]

        if layerid is not None:
            self.layer_id = layerid
        if layernum is not None:
            self.layer_num = layernum

        self.warp_id = warpid
        self.layer_info = ["dwc", usharps_list, [vgpr_start, vgpr_end], options]
        self.flow_handler.sync_layer = sync_layer
        self.flow_handler.force_ackgmb = force_ackgmb
        self.flow_handler.syncid_with_bn = None
        self.init_tcore_producer = False
        self.init_reduce_producer = False
        self.idtype = idtype
        self.wdtype = wdtype
        self.odtype = odtype

    def _core_func(self):
        pass