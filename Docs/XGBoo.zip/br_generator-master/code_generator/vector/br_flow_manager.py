#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
from code_generator.share.br_singleton_base import singleton
import code_generator.share.br_utils as utils
import code_generator.share.br_vector_instructions_def as vec_inst
from code_generator.share.br_defined_print import br_print
import code_generator.share.br_defined_print as bdp
from code_generator.share.br_resource_manager import resource_man
import code_generator.vector.common.constDefs as cfgs


class flow_man(singleton):
    __instance = None  # singlton pattern

    def __new__(cls, *args, **kwargs):
        if cls.__instance is None:
            cls.__instance = super(flow_man, cls).__new__(cls)
            cls.__instance.__initialized = False
        return cls.__instance

    def __init__(self, temp_start=None, stack_start=None):
        if self.__initialized:
            return
        self.__initialized = True
        super().__init__()

        self.code_style = utils.get_code_sytle()  # it is pseudo code
        self.indent_obj = utils.Br_Indent()
        self.resource_man = resource_man()
        self.label_list = []
        self.forloop_iters = []
        self.ifloop_iters = []
        self.label_depth = 0
        self.label_index = 0
        self.name = ""

        self.temp_start = cfgs.FLOW_TEMP_START_INDEX \
            if temp_start is None else temp_start
        self.stack_start = cfgs.FLOW_STACK_START_INDEX \
            if stack_start is None else stack_start

        self.smov = vec_inst.smov()
        self.sadd = vec_inst.sadd()
        self.jump = vec_inst.jump()
        self.bne = vec_inst.bne()
        self.beq = vec_inst.beq()
        self.bles = vec_inst.bles()
        self.blts = vec_inst.blts()

    def reset_status(self):
        self.indent_obj = utils.Br_Indent()
        self.label_list = []
        self.forloop_iters = []
        self.ifloop_iters = []
        self.label_depth = 0
        self.label_index = 0
        self.name = ""

        self.temp_start = cfgs.FLOW_TEMP_START_INDEX
        self.stack_start = cfgs.FLOW_STACK_START_INDEX

    def set_temp_start(self, tempstart):
        self.temp_start = tempstart

    def set_stack_start(self, stackstart):
        self.stack_start = stackstart

    def get_temp_start(self):
        return self.temp_start

    def get_stack_start(self):
        return self.stack_start

    def increase_indent(self, indent=1):
        self.indent_obj.indent += indent
        return self.indent_obj

    def decrease_indent(self, indent=1):
        self.indent_obj.indent -= indent
        return self.indent_obj

    def get_indent(self):
        return self.indent_obj

    def increase_label(self, step):
        self.label_list.append(self.label_index)
        self.label_depth += 1
        self.label_index += step

    def decrease_label(self):
        assert self.label_depth > 0, "label underflow"
        self.label_list = self.label_list[:-1]
        self.label_depth -= 1

    def get_label(self, index):
        return "LABEL_" + self.name + "_" + str(self.label_list[-1] + index)

    def set_label_suffix(self, newlabelsuffix):
        self.name = newlabelsuffix.upper()

    def set_label_index(self, newlabelindex):
        self.label_index = newlabelindex

    def for_loop_start(
            self, start_value, max_value,
            inc, reg, comment="", loopconfig=None, accum_start_value=False):
        self.forloop_iters.append([start_value, max_value, inc, reg])
        self.increase_label(1)
        if not accum_start_value:
            start_val = 0 if start_value == "" else int(start_value)
            self.smov.generate(
                self.indent_obj, dst=reg, src1=(int(start_val)-int(inc)),
                comment="// Init the index sgpr with minus inc")
        else:
            self.sadd.generate(
                self.indent_obj, dst=reg, src1=(-int(inc)), src2=start_value,
                comment="// Accumulate the index sgpr with minus inc")

        if self.code_style:
            if start_value == "":
                br_print(
                    "for (; " + str(reg) + " < " + str(max_value)
                    +"; " + str(reg) + " += " + str(inc) + " )",
                    indent=self.indent_obj,
                    comment=comment)
            else:
                br_print(
                    "for ( " + str(reg) + " = " + str(start_value) + 
                    " ; " + str(reg) + " < " + str(max_value) + "; "
                    +str(reg) + " += " + str(inc) + " )",
                    indent=self.indent_obj,
                    comment=comment)

            br_print("{", indent=self.indent_obj)

        br_print(
            "FOR_LOOP_" + self.get_label(0) + ":",
            comment=comment, indent=self.indent_obj,)

        self.increase_indent()
        self.sadd.generate(
            indent_level=self.indent_obj, dst=reg,
            src1=reg, src2=inc, comment="// Init loop index from 0")

    def for_loop_close(self):
        if len(self.forloop_iters) < 1:
            assert False, "[Internal Error] For start is missing!"
        iter_list = self.forloop_iters.pop()
        max_value, inc = iter_list[1], iter_list[2]
        reg = iter_list[3]

        if str(max_value).isdigit() and (int(max_value) >= 64):
            asource = self.resource_man.alloc_wsr(
                "exceeds_64_imm", transient=True)
            self.smov.generate(
                indent_level=self.indent_obj, dst=asource, src1=max_value,
                comment="// Move large imm to wsr")
            self.resource_man.free_wsr(asource)
            max_value = asource

        self.blts.generate(
            indent_level=self.indent_obj, modifier="rel",
            src1=reg, src2=str(max_value), target="FOR_LOOP_"+self.get_label(0))
        self.decrease_label()
        self.decrease_indent()

        if self.code_style:
            br_print("}", indent=self.indent_obj)

    def start_if_loop(self, asource, bsource, relation, hasElse,
    local_label=False, local_label_value=0, forward=True):
        if self.code_style:
            br_print("if (" + asource + relation + bsource + ")",
                     indent=self.get_indent())
            br_print("{" ,indent=self.get_indent())
            self.increase_indent()
        else:
            self.increase_label(2)

            if (asource.isdigit()):
                aInt = int(asource)
                if (aInt >= 64):
                    asource = self.resource_man.alloc_wsr(
                        "tmp_asource", transient=True)
                    self.smov.generate(
                        indent_level=self.indent_obj, dst=asource, src1=aInt,
                        comment="// Move large imm to wsr")
                    self.resource_man.free_wsr(asource)

            if (bsource.isdigit()):
                bInt = int(bsource)
                if (bInt >= 64):
                    bsource = self.resource_man.alloc_wsr(
                        "tmp_bsource", transient=True)
                    self.smov.generate(
                        indent_level=self.indent_obj, dst=bsource, src1=bInt,
                        comment="// Move large imm to wsr")
                    self.resource_man.free_wsr(bsource)

            if (bsource == "0" and relation == "=="):
                relation = "nz"
                bSource = ""
            elif (relation == "=="):
                relation = "ne"
            elif (relation == "!="):
                relation = "eq"
            elif (relation == ">"):
                relation = "les"
            elif (relation == ">="):
                relation = "lts"
            else:
                if (relation == "<"):
                    #  proceed if a < b, jump if b>=a
                    relation = "les"
                elif (relation == "<="):
                    relation = "lts"
                else:
                    assert False, " relation operation " \
                        +relation + " not supported yet"

                tempsrc = bsource
                bsource = asource
                asource = tempsrc

            if (bsource != ""):
                bsource = bsource + ", "
            if not local_label:
                relationstr = "b" + relation + ".rel " + asource + ", " \
                    +bsource + "IF_BLOCK_" + self.get_label(1 - hasElse)
            else:
                dir = "f" if forward else "b"
                relationstr = "b" + relation + ".rel " + asource + ", " \
                    +bsource + str(local_label_value) + dir

            br_print(relationstr, indent=self.get_indent(), comment="// Check if start condition")

    def start_else_loop(self):
        if self.code_style == 1:
            self.decrease_indent()
            br_print("}", indent=self.get_indent())
            br_print("else", indent=self.get_indent())
            br_print("{", indent=self.get_indent())
            self.increase_indent()
        else:
            self.jump.generate(
                rel="rel", indent=self.indent_obj,
                target="IF_BLOCK_"+self.get_label(1), comment="// Jump to the else block")
            br_print(
                "IF_BLOCK_"+self.get_label(0) + ":",
                indent=self.indent_obj,
                comment="// The start of else block")

    def close_if_loop(self, local_label=False, local_label_value=1):
        if self.code_style == 1:
            self.decrease_indent()
            br_print("}", indent=self.get_indent())
        else:
            if not local_label:
                br_print(
                    "IF_BLOCK_"+self.get_label(1)+":",
                    indent=self.indent_obj,
                    comment="// The end of if block")
                self.decrease_label()
            else:
                br_print(
                    str(local_label_value) + ":",
                    indent=self.indent_obj,
                    comment="// The end of if block")
                self.decrease_label()


    def main_start(self, funcname):
        if self.code_style == 1:
            br_print("main " + funcname, indent=self.get_indent())
            br_print("{", indent=self.get_indent())
            self.increase_indent()
        else:
            name = funcname.upper()
            br_print(".global " + name)
            br_print(".type " + name + ", @function")
            br_print(name + ":")
            self.increase_indent()

    def main_close(self):
        self.decrease_indent()
        if self.code_style == 1:
            br_print("}", indent=self.get_indent())

    def start_function_def(self, funcname, from_caller=True):
        if not from_caller:
            bdp.set_print_subfunc_stage(start=True)

        if (self.code_style == 1):
            if from_caller:
                br_print("main " + funcname, indent=self.get_indent())
            else:
                br_print("func " + funcname, indent=self.get_indent())
            br_print("{", indent=self.get_indent())
        else:
            if not from_caller:
                labelName = "FUNC_" + funcname.upper()
                br_print (".local " + labelName, print_level=bdp.BR_PRINT_LEVEL_SUBFUNC_DECLARE)
                br_print (".type " + labelName + ", @function", print_level=bdp.BR_PRINT_LEVEL_SUBFUNC_DECLARE)

                br_print(".local " + labelName)
                br_print(".type " + labelName + ", @function")
                br_print(labelName + ":")
            else:
                br_print(funcname.upper() + ":")
        self.increase_indent()
        if not from_caller:
            self.stack_start -= 1

    def close_function_def(self, function_name, from_caller=True):
        if self.code_style == 1:
            self.decrease_indent()
            br_print("}", indent=self.get_indent())
        else:
            if not from_caller:
                self.stack_start += 1
                br_print("ret q" + str(self.stack_start), indent=self.get_indent())
            self.decrease_indent()
        
        if (self.code_style != 1 and not from_caller):
            self.mark_shader_size(function_name, from_caller)
        
        if not from_caller:
            br_print("\n", indent=self.get_indent())
            bdp.set_print_subfunc_stage(start=False)

    def start_macro_def(self, macro_name, from_caller=True):
        if not from_caller:
            bdp.set_print_macro_stage(start=True)

        if (self.code_style == 1):
            if not from_caller:
                br_print(".macro " + macro_name, indent=self.get_indent())
            br_print("{", indent=self.get_indent())
        else:
            if not from_caller:
                labelName = macro_name.upper()
                br_print (".macro " + labelName)
        self.increase_indent()

    def close_macro_def(self, macro_name, from_caller=True):
        if self.code_style == 1:
            self.decrease_indent()
            br_print("}", indent=self.get_indent())
        else:
            self.decrease_indent()
            if not from_caller:
                self.stack_start += 1
                br_print(".endm", indent=self.get_indent())

        
        if not from_caller:
            br_print("\n", indent=self.get_indent())
            bdp.set_print_macro_stage(start=False)

    def mark_shader_size(self, function_name, from_caller):
        if not from_caller:
            label_name = "FUNC_" + function_name.upper()
        else:
            label_name = function_name.upper()

        br_print(label_name + "_END:")
        br_print(".size" + " " + label_name + ", " + label_name + "_END-" + label_name, 
            indent=self.get_indent())

    def start_function_call(self, funcname):
        if self.code_style == 1:
            br_print("call.rel " + funcname, indent=self.get_indent())
        else:
            br_print(
                "call.rel q" + str(self.stack_start) + 
                " FUNC_" + funcname.upper(),
                indent=self.get_indent())
            self.stack_start -= 1

    def end_function_call(self):
        if self.code_style != 1:
            self.stack_start += 1

    def start_macro_call(self, macro_name, inplace=False):
        if self.code_style == 1:
            br_print("" + macro_name.upper(), indent=self.get_indent())
        else:
            if not inplace:
                br_print("" + macro_name.upper(),
                    indent=self.get_indent())
            else:
                br_print("//Inplace Macro " + macro_name, indent=self.get_indent())


    def end_macro_call(self, macro_name, inplace=False):
        if inplace:
            br_print("//End Iplace Macro " + macro_name, indent=self.get_indent())

    def generate_loop_config(self, loopconfig):
        br_print(
            " ", indent=self.get_indent(), 
            comment_header="// Info: Loop Configuration is"
            +str(loopconfig))