
#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import sys
import os
import math

import vector.common.hwCaps as hwCaps
import vector.common.flowLib as flowLib
import vector.common.cwarp as cwarp
import vector.common.funcgen as funcgen
import vector.common.funcLib as funcLib
import vector.common.kernelLib as kernelLib
import vector.common.compiler as compiler
import vector.common.usharp as usharp

from code_generator.share.br_defined_print import br_print


def GetModeMatrixVector():
  return 0

def GetModeVectorMatrix():
  return 1

####################################################
#
def	load_activation(isHalf, channelSGPRStr, channelId, vgprNumber, vgprAddr, syncId, usharpId, indentstring):

  if (isHalf != 0):
    formatStr = ".mb16.rb16"
    scale = 2
  else:
    formatStr = ".mb32.rb32"
    scale = 1

  if (channelId >= 0 and channelId > hwCaps.MaxIMM()):
    print (indentstring + "smov " + channelSGPRStr + ", " + str(channelId))

  sizeList = funcLib.SplitRepeatIntoGroups(vgprNumber, hwCaps.MaxLDMGranule())

  syncStr = kernelLib.GetSyncModifier(syncId)

  y = 0
  for thisSize in sizeList:
    for z in range(thisSize[0]):
      vectorModifier = kernelLib.GetVectorModifier(thisSize[1] * scale, "e")
      print (indentstring + "ldm" + syncStr + ".float" + formatStr + vectorModifier + ".gc4" + " r" + str(vgprAddr) + ", g0, " + str(usharpId))
      print (indentstring + "smovg g0, 0")
      print (indentstring + "smovg g1, " + str(y * hwCaps.TileSizeY()))
      if (channelId < 0 or channelId > hwCaps.MaxIMM()):
        print (indentstring + "smovg g2, " + channelSGPRStr)
      else:
        print (indentstring + "smovg g2, " + str(channelId))
      print (indentstring + "smovg.eog g3, 0")
      vgprAddr += thisSize[1]
      y += thisSize[1]




####################################################
#
def load_activation_ex(isHalf, channelSGPRStr, channelId, memTileNumberX, memTileNumberY, vgprStride, vgprAddr, syncId, usharpId, indentstring):

  if (isHalf != 0):
    formatStr = ".mb16.rb16"
    scale = 2
  else:
    formatStr = ".mb32.rb32"
    scale = 1

  if (channelId >= 0 and channelId > hwCaps.MaxIMM()):
    print (indentstring + "smov " + channelSGPRStr + ", " + str(channelId))

  syncStr = kernelLib.GetSyncModifier(syncId)

  sizeList = funcLib.SplitRepeatIntoGroups(memTileNumberY, hwCaps.MaxLDMGranule())

  for x in range (memTileNumberX):
    y = 0
    for thisSize in sizeList:
      for z in range(thisSize[0]):
        vectorModifier = kernelLib.GetVectorModifier(thisSize[1] * scale, "e")
        print (indentstring + "ldm.float" + formatStr + syncStr + vectorModifier + ".gc4" + " r" + str(vgprAddr) + ", g0, " + str(usharpId))
        print (indentstring + "smovg g0, " + str(x * hwCaps.TileSizeX()))
        print (indentstring + "smovg g1, " + str(y * hwCaps.TileSizeY()))
        if (channelId < 0 or channelId > hwCaps.MaxIMM()):
          print (indentstring + "smovg g2, " + channelSGPRStr)
        else:
          print (indentstring + "smovg g2, " + str(channelId))
        print (indentstring + "smovg.eog g3, 0")
        vgprAddr += thisSize[1]
        y += thisSize[1]

    vgprAddr += vgprStride - memTileNumberY


####################################################
#
def	store_activation(isHalf, channelSGPRStr, channelId, vgprNumber, vgprAddr, usharpId, indentstring):

  if (isHalf != 0):
    formatStr = ".mb16.rb16"
    formatStr2 = ".f16"
    scale = 2
  else:
    formatStr = ".mb32.rb32"
    formatStr2 = ".f32"
    scale = 1

  sizeList = funcLib.SplitRepeatIntoGroups(vgprNumber, hwCaps.MaxStoreGranule())

  if (channelId >= 0 and channelId > hwCaps.MaxIMM()):
    print (indentstring + "smov " + channelSGPRStr + ", " + str(channelId))

  y = 0
  for thisSize in sizeList:
    for z in range(thisSize[0]):
      vectorModifier = kernelLib.GetVectorModifier(thisSize[1] * scale, "e")
      movVecModifier = kernelLib.GetVectorModifier(thisSize[1], "v")

      print (indentstring + "stm.float" + formatStr + vectorModifier + ".gc" + str(4+thisSize[1]) + " g0, g4, " + str(usharpId))
      print (indentstring + "smovg g0, 0")
      print (indentstring + "smovg g1, " + str(y * hwCaps.TileSizeY()))
      if (channelId < 0 or channelId > hwCaps.MaxIMM()):
        print (indentstring + "smovg g2, " + channelSGPRStr)
      else:
        print (indentstring + "smovg g2, " + str(channelId))
      print (indentstring + "smovg g3, 0")
      print (indentstring + "mov" + movVecModifier + ".eog g4" + formatStr2 + ", " + "r" + str(vgprAddr) + formatStr2 + ".a")
      vgprAddr += thisSize[1]
      y += thisSize[1]



####################################################
#
def	reduce_eu_data(isHalf, vgprNumber, srcVGPRAddr, dstVGPRAddr, syncId, indentstring):

  if (isHalf != 0):
    formatStr = ".b16"
  else:
    formatStr = ".b32"

  syncStr = kernelLib.GetSyncModifier(syncId)

  sizeList = funcLib.SplitRepeatIntoGroups(vgprNumber, hwCaps.MaxALUGranule())

  for thisSize in sizeList:
    for z in range(thisSize[0]):
      print (indentstring + "fadd" + kernelLib.GetVectorModifier(thisSize[1], "v") + formatStr + syncStr + " r" + str(dstVGPRAddr) + ", r" + str(dstVGPRAddr) + ".a, r" + str(srcVGPRAddr) + ".a")
      srcVGPRAddr += thisSize[1]
      dstVGPRAddr += thisSize[1]
      syncStr = ""



def gen_layer_main_kernel(layerId, layerNumber, warpId, layerGroupInfo0, layerGroupInfo1, funcParameterMap, flowHandler):

  flowHandler.startFunctionDef("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel", 0)
  flowHandler.setLabelSuffix("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel")

  indentstring = flowHandler.getIndentStr()

  ####################################################
  # options
  bLoadResult = 1
  bOutputHalfFloat = 1

  # 0 - matrix * vector
  # 1 - vector * matrix
  bMode = GetModeMatrixVector()

  if (bMode == GetModeMatrixVector()):
    bAcrossEUReduce = 1
    bAddBias = 1
  else:
    bAcrossEUReduce = 0
    bAddBias = 0

  bSoftMax = 1
  bTotalError = 1
  bStoreResult = 1
  bHasNextLayer = (layerId != (layerNumber-1))

  ####################################################
  # usharp
  usharpList = ([0, 20, 10, 10, "3D activation, order is channel, height, width, origin is previous layer's output, from hbm"],
                [1, 500, 2002, 0, "2D weight, order is row, col, last 2 cols are bias"],
                [2, 20, 64, 8, "3D activation, order is channel, height, width, used as temp buffer in reduce and output, can be in L1.5"],
                [3, 2,  64, 8, "3D activation, order is channel, height, width, final output, to hbm"])

  print (indentstring + "// U#id    D     H     W  Note")
  for usharp in usharpList:
    print (indentstring + "// " + "{:3d}".format(usharp[0]) + ",{:5d}".format(usharp[1]) + ",{:5d}".format(usharp[2]) + ",{:5d}".format(usharp[3]) + ", " + usharp[4])

  fcActivationUSharpIndex = 0
  fcWeightUSharpIndex = 1
  fcReduceUSharpIndex = 2
  fcFinalUSharpIndex = 3

  fcActivationTileNumberX = int ((usharpList[fcActivationUSharpIndex][3] + hwCaps.TileSizeX() - 1) / hwCaps.TileSizeX())
  fcActivationTileNumberY = int ((usharpList[fcActivationUSharpIndex][2] + hwCaps.TileSizeY() - 1) / hwCaps.TileSizeY())

  fcActivationTileNumberYAligned = funcLib.AlignToPower2(fcActivationTileNumberY)
  fcActivationTileNumberYLog = funcLib.GetLeadingOnePos(fcActivationTileNumberYAligned)

  weightColSize = usharpList[fcWeightUSharpIndex][1]

  activationVGPRNumber = fcActivationTileNumberYAligned * fcActivationTileNumberX
  weightVGPRNumber = (weightColSize + 31) >> 5
  accumulateVGPRNumber = (weightVGPRNumber << 1)

  if (bOutputHalfFloat != 0):
    dstVGPRNumber = (weightVGPRNumber + 1) >> 1
  else:
    dstVGPRNumber = weightVGPRNumber

  if (bLoadResult != 0):
    activationVGPRAddr = flowHandler.allocateVGPR(activationVGPRNumber)
  else:
    activationVGPRAddr = flowHandler.reserveVGPR(16, activationVGPRNumber)

  weightVGPRAddr = flowHandler.allocateVGPR(weightVGPRNumber)
  accumulateVGPRAddr = flowHandler.allocateVGPR(accumulateVGPRNumber)
  dstVGPRAddr = flowHandler.allocateVGPR(dstVGPRNumber)
  tempVGPRAddr = flowHandler.allocateVGPR(3)

  outerLoopNumber = 1

  if (usharpList[fcActivationUSharpIndex][3] == 1):
    euNumber = 16
    channelStep = 32
    print (indentstring + "TODO, use lddw?")
  else:
    euNumber = (usharpList[fcActivationUSharpIndex][1] + 1) >> 1
    channelStep = usharpList[fcActivationUSharpIndex][1]

    if (euNumber > 16):
      print (indentstring + "TODO, add loop")
      outerLoopNumber = (euNumber + 15) >> 4
      euNumber = 16


  euIDSGPRIndex = flowHandler.allocateSGPR(1)
  euIDSGPRStr = "q" + str(euIDSGPRIndex)

  channelSGPRIndex = flowHandler.allocateSGPR(1)
  channelSGPRStr = "q" + str(channelSGPRIndex)

  loopEndSGPRIndex = flowHandler.allocateSGPR(1)
  loopEndSGPRStr = "q" + str(loopEndSGPRIndex)

  vgprBaseSGPRIndex = flowHandler.allocateSGPR(1)
  vgprBaseSGPRStr = "q" + str(vgprBaseSGPRIndex)

  spatialSGPRIndex = flowHandler.allocateSGPR(2)
  spatialXSGPRStr = "q" + str(spatialSGPRIndex)
  spatialYSGPRStr = "q" + str(spatialSGPRIndex + 1)

  tempSGPRIndex = flowHandler.allocateSGPR(4)
  spatialXBitSGPRStr = "q" + str(tempSGPRIndex)
  spatialYBitSGPRStr = "q" + str(tempSGPRIndex + 1)
  spatialXVGPRSGPRStr = "q" + str(tempSGPRIndex + 2)
  spatialYVGPRSGPRStr = "q" + str(tempSGPRIndex + 3)

  scalarFactorSGPRStr = "q" + str(tempSGPRIndex)

  print (indentstring + "")

  funcLib.AlignPrint(indentstring + "sysid.work q0", flowLib.GetCommentPos(), "");
  funcLib.AlignPrint(indentstring + "sand " + euIDSGPRStr + ", q0, 0xf", flowLib.GetCommentPos(), "// obtain unique cu_eu id");
  funcLib.AlignPrint(indentstring + "sshl " + channelSGPRStr + ", " + euIDSGPRStr + ", 1", flowLib.GetCommentPos(), "// obtain channel index for current EU")
  print (indentstring + "")

  if (euNumber < 16):
    flowHandler.startIfLoop(euIDSGPRStr, str(euNumber), "<", 0)
    indentstring = flowHandler.getIndentStr()

  if (bLoadResult != 0):
    print (indentstring + "// load previous layer's result or input")
    load_activation_ex(1, channelSGPRStr, -1, fcActivationTileNumberX, fcActivationTileNumberY, fcActivationTileNumberYAligned, activationVGPRAddr, 1, usharpList[fcActivationUSharpIndex][0], indentstring)
  else:
    print (indentstring + "// load previous layer's result already in vgpr, TODO")

  print (indentstring + "")
  print (indentstring + "// iniialize accumlate result")
  sizeList = funcLib.SplitRepeatIntoGroups(accumulateVGPRNumber, hwCaps.MaxMovGranule())
  thisVGPRAddr = accumulateVGPRAddr
  for y in sizeList:
    for z in range(y[0]):
      print (indentstring + "movi" + kernelLib.GetVectorModifier(y[1], "v") + " r" + str(thisVGPRAddr) + ".u32, 0")
      thisVGPRAddr += y[1]


  print (indentstring + "")
  if (bMode == GetModeMatrixVector()):
    print (indentstring + "// matrix * vector")
  else:
    print (indentstring + "// vector * matrix")

  funcLib.AlignPrint(indentstring + "smov " + str(spatialXSGPRStr) + ", 0", flowLib.GetCommentPos(), "// initialize spatial x index")
  funcLib.AlignPrint(indentstring + "smov " + str(spatialYSGPRStr) + ", 0", flowLib.GetCommentPos(), "// initialize spatial y index")
  funcLib.AlignPrint(indentstring + "smov " + loopEndSGPRStr + ", " + str(int((usharpList[fcWeightUSharpIndex][2]-2) / usharpList[fcActivationUSharpIndex][1])), flowLib.GetCommentPos(), "// initialize loop count")
#  funcLib.AlignPrint(indentstring + "smov " + loopEndSGPRStr + ", 1", GetCommentPos(), "// initialize loop count to 1")


  # start loop over weight's cols
  flowHandler.startForLoop("0", loopEndSGPRStr, "1", -1, "loop weight cols")
  indentstring = flowHandler.getIndentStr()

  vgprStrideX = int ((usharpList[fcActivationUSharpIndex][3] + hwCaps.TileSizeX() - 1) / hwCaps.TileSizeX())

  print (indentstring + "// load a col from weight matrix, usharp " + str(usharpList[fcWeightUSharpIndex][0]))

  load_activation(1, channelSGPRStr, -1, weightVGPRNumber, weightVGPRAddr, 1, usharpList[fcWeightUSharpIndex][0], indentstring)

  print (indentstring + "")
  print (indentstring + "// find out corresponding activation from vgprs from " + str(activationVGPRAddr))
  if (usharpList[fcActivationUSharpIndex][3] > hwCaps.TileSizeX()):
    funcLib.AlignPrint(indentstring + "sand " + spatialXBitSGPRStr + ", " + spatialXSGPRStr + ", 7", flowLib.GetCommentPos(), "// x[2:0]")
    funcLib.AlignPrint(indentstring + "sand " + spatialYBitSGPRStr + ", " + spatialYSGPRStr + ", 3", flowLib.GetCommentPos(), "// y[1:0]")
    funcLib.AlignPrint(indentstring + "sshr " + spatialXVGPRSGPRStr + ", " + spatialXSGPRStr + ", 3", flowLib.GetCommentPos(), "// tile index in x dir")
    funcLib.AlignPrint(indentstring + "sshr " + spatialYVGPRSGPRStr + ", " + spatialYSGPRStr + ", 2", flowLib.GetCommentPos(), "// tile index in y dir")

    funcLib.AlignPrint(indentstring + "sshl " + spatialYBitSGPRStr + ", " + spatialYBitSGPRStr + ", 3", flowLib.GetCommentPos(), "")
    funcLib.AlignPrint(indentstring + "sor  " + spatialYBitSGPRStr + ", " + spatialYBitSGPRStr + ", " + spatialXBitSGPRStr, flowLib.GetCommentPos(), "// thread position 0-31")
    funcLib.AlignPrint(indentstring + "sshl " + spatialYBitSGPRStr + ", 1, " + spatialYBitSGPRStr, flowLib.GetCommentPos(), "// thread mask")

    funcLib.AlignPrint(indentstring + "sshl " + spatialXVGPRSGPRStr + ", " + spatialXVGPRSGPRStr + ", " + str(fcActivationTileNumberYLog), flowLib.GetCommentPos(), "// col major")
    funcLib.AlignPrint(indentstring + "sadd " + spatialYVGPRSGPRStr + ", " + spatialYVGPRSGPRStr + ", " + spatialXVGPRSGPRStr, flowLib.GetCommentPos(), "// index to input")

    funcLib.AlignPrint(indentstring + "sadd  " + vgprBaseSGPRStr + ", " + str(activationVGPRAddr) + ", " + spatialYVGPRSGPRStr, flowLib.GetCommentPos(), "// vgpr addr to input activation")
    funcLib.AlignPrint(indentstring + "smovs a1, " + vgprBaseSGPRStr, flowLib.GetCommentPos(), "// set vgpr base")
    funcLib.AlignPrint(indentstring + "smovs wm0, " + spatialYBitSGPRStr, flowLib.GetCommentPos(), "// set m0 mask")
    funcLib.AlignPrint(indentstring + "mov r" + str(tempVGPRAddr) + ".f32, ir0.f16", flowLib.GetCommentPos(), "// expand to fp32 to move to sgpr")
    funcLib.AlignPrint(indentstring + "m0.movw.r2q  " + scalarFactorSGPRStr + ", r" + str(tempVGPRAddr) + ".f32", flowLib.GetCommentPos(), "// mov corresponding lane's activation data to a sgpr")
    funcLib.AlignPrint(indentstring + "mov r" + str(tempVGPRAddr) + ".f32, " + scalarFactorSGPRStr + ".f32", flowLib.GetCommentPos(), "// replicate")
    funcLib.AlignPrint(indentstring + "m0.movw.r2q  " + scalarFactorSGPRStr + ", r" + str(tempVGPRAddr+1) + ".f32", flowLib.GetCommentPos(), "// mov corresponding lane's activation data to a sgpr")
    funcLib.AlignPrint(indentstring + "mov r" + str(tempVGPRAddr+1) + ".f32, " + scalarFactorSGPRStr + ".f32", flowLib.GetCommentPos(), "// replicate")
    funcLib.AlignPrint(indentstring + "mov.v2 r" + str(tempVGPRAddr+2) + ".f16, r" + str(tempVGPRAddr) + ".f32.a", flowLib.GetCommentPos(), "// now we have duplicate of the lane we need")

    funcLib.AlignPrint(indentstring + "smovs wm0, 0xffffffff", flowLib.GetCommentPos(), "// reset m0 mask")
    funcLib.AlignPrint(indentstring + "// movw  " + scalarFactorSGPRStr + ", ir0.u32", flowLib.GetCommentPos(), "// mov corresponding lane's activation data to a sgpr")
  else:
    # assume full tile, otherwise need more code
    print (indentstring + "TODO")

  print (indentstring + "")
  print (indentstring + "// start accumulation")
  syncStr = ".sc1"
  thisSrcVGPRAddr = weightVGPRAddr
  thisDstVGPRAddr = accumulateVGPRAddr
  sizeList = funcLib.SplitRepeatIntoGroups(weightVGPRNumber, hwCaps.MaxALUGranule())
  for y in sizeList:
    for z in range(y[0]):
      vectorModifier = kernelLib.GetVectorModifier(y[1], "v")
      funcLib.AlignPrint(indentstring + "fmac" + vectorModifier + ".b16.wd" + syncStr + " r" + str(thisDstVGPRAddr) + " r" + str(thisSrcVGPRAddr) + ".a, r" + str(tempVGPRAddr+2), flowLib.GetCommentPos(), "")
      syncStr = ""
      thisSrcVGPRAddr += y[1]
      thisDstVGPRAddr += (y[1] << 1)


  print (indentstring + "")
  print (indentstring + "// move to next weight")
  print (indentstring + "")
  print (indentstring + "sadd " + spatialXSGPRStr + ", " + spatialXSGPRStr + ", 1")
  flowHandler.startIfLoop(spatialXSGPRStr, str(usharpList[fcActivationUSharpIndex][3]), ">=", 0)
  indentstring = flowHandler.getIndentStr()
  print (indentstring + "smov " + str(spatialXSGPRStr) + ", 0")
  print (indentstring + "sadd " + spatialYSGPRStr + ", " + spatialYSGPRStr + ", 1")
  flowHandler.closeIfLoop()
  indentstring = flowHandler.getIndentStr()


  print (indentstring + "sadd " + channelSGPRStr + ", " + channelSGPRStr + ", " + str(channelStep))

  flowHandler.closeForLoop("0", loopEndSGPRStr, "1", -1)
  indentstring = flowHandler.getIndentStr()

  print (indentstring + "")
  print (indentstring + "// now accumulator has 2 channels, add them together")
  thisSrcVGPRAddr = accumulateVGPRAddr
  thisDstVGPRAddr = accumulateVGPRAddr
  for y in range (weightVGPRNumber):
    print (indentstring + "fadd.b32 r" + str(thisDstVGPRAddr) + ", r" + str(thisSrcVGPRAddr) + ", r" + str(thisSrcVGPRAddr+1))
    thisSrcVGPRAddr += 2
    thisDstVGPRAddr += 1

  if ((weightColSize & 0x3f) != 0):
    print (indentstring + "")
    print (indentstring + "// now clear oob data to 0")

    validLaneNumber0 = ((weightColSize & 0x3f) + 1) >> 1
    validLaneNumber1 = ((weightColSize & 0x3f)) >> 1

    if (validLaneNumber0 != 32):
      funcLib.AlignPrint(indentstring + "smovs wm0, " + hex((0xffffffff << validLaneNumber0) &0xffffffff), flowLib.GetCommentPos(), "// set m0 mask")
      print (indentstring + "m0.movi" + " r" + str(accumulateVGPRAddr + weightVGPRNumber - 2) + ".u32, 0")

    if (validLaneNumber1 != validLaneNumber0):
      funcLib.AlignPrint(indentstring + "smovs wm0, " + hex((0xffffffff << validLaneNumber1) &0xffffffff), flowLib.GetCommentPos(), "// set m0 mask")

    print (indentstring + "m0.movi" + " r" + str(accumulateVGPRAddr + weightVGPRNumber - 1) + ".u32, 0")

    funcLib.AlignPrint(indentstring + "smovs wm0, 0xffffffff", flowLib.GetCommentPos(), "// reset m0 mask")


  if (bOutputHalfFloat != 0):
    print (indentstring + "")
    print (indentstring + "// now pack float into half float")
    sizeList = funcLib.SplitRepeatIntoGroups(dstVGPRNumber << 1, hwCaps.MaxMovGranule())
    thisSrcVGPRAddr = accumulateVGPRAddr
    thisDstVGPRAddr = dstVGPRAddr
    for y in sizeList:
      for z in range(y[0]):
        vectorModifier = kernelLib.GetVectorModifier(y[1], "v")
        funcLib.AlignPrint(indentstring + "mov.rdne" + vectorModifier + " r" + str(thisDstVGPRAddr) + ".f16, r" + str(thisSrcVGPRAddr) + ".a.f32", flowLib.GetCommentPos(), "")
        thisDstVGPRAddr += y[1] >> 1
        thisSrcVGPRAddr += y[1]


  print (indentstring + "")
  print (indentstring + "// save to temp buffer for later reduce")
  flowHandler.startIfLoop(euIDSGPRStr, "0", "!=", 0)
  indentstring = flowHandler.getIndentStr()
  funcLib.AlignPrint(indentstring + "sshl " + channelSGPRStr + ", " + euIDSGPRStr + ", 1", flowLib.GetCommentPos(), "// obtain channel index for current EU")
  store_activation(bOutputHalfFloat, channelSGPRStr, -1, dstVGPRNumber, dstVGPRAddr, usharpList[fcReduceUSharpIndex][0], indentstring)
  flowHandler.closeIfLoop()
  indentstring = flowHandler.getIndentStr()

  print (indentstring + "")
  if (bAcrossEUReduce != 0 and euNumber > 1):
    print (indentstring + "// flush write for later reduce")
    print (indentstring + "ackgmb")

  if (euNumber < 16):
    flowHandler.closeIfLoop()
    indentstring = flowHandler.getIndentStr()

  flowHandler.releaseVGPR(activationVGPRAddr)
  flowHandler.releaseVGPR(weightVGPRAddr)
  flowHandler.releaseVGPR(accumulateVGPRAddr)

  if (bAddBias != 0 and bOutputHalfFloat == 0):
    vgprGranule = (dstVGPRNumber + 1) & ~1
  else:
    vgprGranule = dstVGPRNumber

  reduceVGPRAddr = flowHandler.allocateVGPR(vgprGranule * 4)

  if (bAcrossEUReduce != 0 or bAddBias != 0):
    print (indentstring + "")

    loadIndex = 0
    aluIndex = 0

    if (bAcrossEUReduce != 0 and euNumber > 1):
      print (indentstring + "// let eu0 do reduce and/or add bias")
      funcLib.AlignPrint(indentstring + "bar.wtg.sync.cnt 8, 16", flowLib.GetCommentPos(), "// all EUs wait at here")

    if ((bAcrossEUReduce != 0 and euNumber > 1) or (bAddBias != 0)):
      flowHandler.startIfLoop(euIDSGPRStr, "0", "==", 0)
      indentstring = flowHandler.getIndentStr()

      load_activation(bOutputHalfFloat, channelSGPRStr, 1 << 1, dstVGPRNumber, reduceVGPRAddr, loadIndex + 1, usharpList[fcReduceUSharpIndex][0], indentstring)
      loadIndex += 1
      print (indentstring + "")

    if (bAcrossEUReduce != 0 and euNumber > 2):
      load_activation(bOutputHalfFloat, channelSGPRStr, 2 << 1, dstVGPRNumber, reduceVGPRAddr + loadIndex * vgprGranule, loadIndex + 1, usharpList[fcReduceUSharpIndex][0], indentstring)
      loadIndex += 1
      print (indentstring + "")

    if (bAcrossEUReduce != 0):
      for z in range (euNumber - 3):
        vgprAddr = reduceVGPRAddr + (loadIndex * vgprGranule)
        load_activation(bOutputHalfFloat, channelSGPRStr, (z + 3) << 1, dstVGPRNumber, vgprAddr, loadIndex + 1, usharpList[fcReduceUSharpIndex][0], indentstring)

        print (indentstring + "")
        vgprAddr = reduceVGPRAddr + (aluIndex * vgprGranule)
        reduce_eu_data(bOutputHalfFloat, dstVGPRNumber, vgprAddr, dstVGPRAddr, aluIndex + 1, indentstring)

        loadIndex = funcLib.IncAndWrap(loadIndex, 3)
        aluIndex = funcLib.IncAndWrap(aluIndex, 3)

        if (z != (euNumber - 4)):
          print (indentstring + "")

    if (bAddBias != 0):
      # bias is packed, so roughly half of other cols
      print (indentstring + "// load bias")
      vgprAddr = reduceVGPRAddr + (loadIndex * vgprGranule)
      load_activation(1, channelSGPRStr, usharpList[fcWeightUSharpIndex][2]-2, (weightVGPRNumber + 1) >> 1, reduceVGPRAddr + loadIndex * dstVGPRNumber, loadIndex + 1, usharpList[fcWeightUSharpIndex][0], indentstring)

    if (bAcrossEUReduce != 0 and euNumber > 2):
      vgprAddr = reduceVGPRAddr + (aluIndex * vgprGranule)
      reduce_eu_data(bOutputHalfFloat, dstVGPRNumber, vgprAddr, dstVGPRAddr, aluIndex + 1, indentstring)
      aluIndex = funcLib.IncAndWrap(aluIndex, 3)

    if (bAcrossEUReduce != 0 and euNumber > 1):
      vgprAddr = reduceVGPRAddr + (aluIndex * vgprGranule)
      reduce_eu_data(bOutputHalfFloat, dstVGPRNumber, vgprAddr, dstVGPRAddr, aluIndex + 1, indentstring)
      aluIndex = funcLib.IncAndWrap(aluIndex, 3)

    if (bAddBias != 0):
      vgprAddr = reduceVGPRAddr + (aluIndex * vgprGranule)

      if (bOutputHalfFloat == 0):
        print (indentstring + " - expand bias, which is half float, to float")
        syncId = 0
      else:
        syncId = aluIndex + 1

      reduce_eu_data(bOutputHalfFloat, dstVGPRNumber, vgprAddr, dstVGPRAddr, syncId, indentstring)

    print (indentstring + "")
    flowHandler.releaseVGPR(reduceVGPRAddr)

    if (bSoftMax != 0):

      pass


    if (bStoreResult != 0):
      print (indentstring + "// final output")
      store_activation(bOutputHalfFloat, channelSGPRStr, 0, dstVGPRNumber, dstVGPRAddr, usharpList[fcFinalUSharpIndex][0], indentstring)

      if (bHasNextLayer):
        print (indentstring + "ackgmb")

    if ((bAcrossEUReduce != 0 and euNumber > 1) or (bAddBias != 0)):
      flowHandler.closeIfLoop()
      indentstring = flowHandler.getIndentStr()

  if (bStoreResult != 0 and bHasNextLayer):
    print ("")
    funcLib.AlignPrint(indentstring + "bar.wtg.sync.cnt 8, 16", flowLib.GetCommentPos(), "// all EUs wait at here")

  flowHandler.releaseVGPR(dstVGPRAddr)
  flowHandler.releaseVGPR(tempVGPRAddr)
  flowHandler.closeFunctionDef(0)
  indentstring = flowHandler.getIndentStr()
  print ("\n\n\n\n")

  kernelLib.finish_layer_main_kernel(layerId, layerNumber, warpId, indentstring)







def main():
  flowHandler = flowLib.FlowHandler("", 1, 31, compiler.GetASMMode())

  #flowHandler.reserveVGPR(24, 32)
  #print (flowHandler.vgprNumber)
  #print (flowHandler.vgprAllocList)
  #
  #addr0 = flowHandler.allocateVGPR(8)
  #print (flowHandler.vgprNumber)
  #print (flowHandler.vgprAllocList)
  #
  #addr1 = flowHandler.allocateVGPR(80)
  #print (flowHandler.vgprNumber)
  #print (flowHandler.vgprAllocList)
  #
  #flowHandler.releaseVGPR(addr0)
  #addr2 = flowHandler.allocateVGPR(18)
  #print (flowHandler.vgprNumber)
  #print (flowHandler.vgprAllocList)
  #
  #flowHandler.releaseVGPR(addr1)
  #flowHandler.releaseVGPR(addr2)
  #print (flowHandler.vgprNumber)
  #print (flowHandler.vgprAllocList)
  #
  #flowHandler.releaseVGPR(24)
  #print (flowHandler.vgprNumber)
  #print (flowHandler.vgprAllocList)
  #
  #return

  funcGenHandler = FuncGenHandler()

  funcParameterMap["SubFunctionSelect"] = -1
  funcParameterMap["dvSpcNumber"] = 24

  qIndex = flowHandler.getQTempStart()
  flowHandler.startMainDef("main")
  indentstring = flowHandler.getIndentStr()

  print (indentstring + "sysid.work q" + str(qIndex))

  funcLib.AlignPrint(indentstring + "sshr q" + str(qIndex) + ", q" + str(qIndex) + ", 4", flowLib.GetCommentPos(), "// obtain cwarp id");

  print (indentstring + "beq.rel q" + str(qIndex) + ", 0, " + "MAIN_WARP_ENTRY_" + str(0))
  #print (indentstring + "beq q" + str(qIndex) + ", 1, " + "MAIN_WARP_ENTRY_" + str(1))
  #print (indentstring + "beq q" + str(qIndex) + ", 2, " + "MAIN_WARP_ENTRY_" + str(2))
  #print (indentstring + "beq q" + str(qIndex) + ", 3, " + "MAIN_WARP_ENTRY_" + str(3))
  print (indentstring + "end")
  flowHandler.closeMainDef()
  indentstring = flowHandler.getIndentStr()

  layerNumber = 1

  for z in range (1):
    warpId = z * 2
    print (indentstring + "MAIN_WARP_ENTRY_" + str(warpId) + ":")

    for layerId in range(layerNumber):
      surfaceInfo1 = [16, 16, 1179, 523]
      layerGroupInfo0 = [["dwc", surfaceInfo1, [[0, 1], [2]], [16, 156], [3, 3, 1, 1, 1], [1]]]
      layerGroupInfo1 = [["bn",  surfaceInfo1, [[2, 3], [2]], [156, 256], [1]]]

#     self.fc1 = nn.Linear(20*10*10,500)
#     self.fc2 = nn.Linear(500,10)

      surfaceInfo2 = [32, 20, 10, 10]

#      layerGroupInfo1 = [["fc",  surfaceInfo2, [[2, 3], [2]], [156, 200], [1], [100]],
#                         ["fc",  [1, 1, 1, 500], [[2, 3], [2]], [200, 256], [1], [10]]]
# goal
#     fc0 	20 * 10 x 10 -> 500 + relu
#     fc1 	500 -> 10

      gen_layer_main_kernel(layerId, layerNumber, warpId, layerGroupInfo0, layerGroupInfo1, funcParameterMap, flowHandler)


if __name__ == '__main__':
  main()

#surface mode
# [16, 16, 13, 13]
#tile number y = 4, tile number x = 2
#load data will use vgpr[24, 156)
