#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import sys
import os
import math

import code_generator.vector.common.hwCaps as hwCaps
import code_generator.vector.common.flowLib as flowLib
import code_generator.vector.common.cwarp as cwarp
import code_generator.vector.common.funcgen as funcgen
import code_generator.vector.common.funcLib as funcLib
import code_generator.vector.common.kernelLib as kernelLib
import code_generator.vector.common.compiler as compiler
import code_generator.vector.common.usharp as usharp

from code_generator.share.br_defined_print import br_print

####################################################
# calculate loss function
# now assumes softmax
# and always in float space

def gen_layer_main_kernel(layerId, layerNumber, warpId, layerInfo, flowHandler):

  cmdIndex = cwarp.GetCMDIndex()

  if (layerInfo[cmdIndex] != "loss"):
    assert False, "unsupported op " + layerInfo[cmdIndex]
    return

  flowHandler.startFunctionDef("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel", 0)
  indentstring = flowHandler.getIndentStr()

  flowHandler.setLabelSuffix("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel")

  uSharpIndex = cwarp.GetUSharpIndex()
  optionsIndex = cwarp.GetOptionsIndex()


  ####################################################
  # options
  bRefHotVector = layerInfo[optionsIndex][0]
  bRefClassIndex = layerInfo[optionsIndex][1]
  bCalculateGradient = layerInfo[optionsIndex][2]


  ####################################################
  # surfaces
  activationUSharpIndex = 0
  refUSharpIndex = 1
  lossUSharpIndex = 2
  gradientUSharpIndex = 3

  usharpList = layerInfo[uSharpIndex]
  kernelLib.PrintUSharpList(usharpList, indentstring)

  br_print (indentstring + "// sgpr usage:")

  ####################################################
  # allocate sgprs
  euIDSGPRIndex = flowHandler.allocateSGPR(1)
  euIDSGPRStr = "q" + str(euIDSGPRIndex)
  br_print (indentstring + "//   eu id at sgpr q" + str(euIDSGPRIndex))

  coordSGPRIndex = flowHandler.allocateSGPR(4)
  xSGPRStr = "q" + str(coordSGPRIndex)
  ySGPRStr = "q" + str(coordSGPRIndex + 1)
  zSGPRStr = "q" + str(coordSGPRIndex + 2)
  wSGPRStr = "q" + str(coordSGPRIndex + 3)
  br_print (indentstring + "//   x/y/z/w at sgpr q" + str(coordSGPRIndex) + "-q" + str(coordSGPRIndex+3))

  vgprBaseSGPR = flowHandler.allocateSGPR(1)
  vgprBaseSGPRStr = "q" + str(vgprBaseSGPR)
  br_print (indentstring + "//   vgpr base at sgpr q" + str(euIDSGPRIndex))

  br_print (indentstring + "// vgpr usage:")
  ####################################################
  # reserve vgpr0 for lane id
  laneIdVGPRIndex = flowHandler.reserveVGPR(0, 1)
  laneIdVGPRStr = "r" + str(laneIdVGPRIndex)
  br_print (indentstring + "//   lane id at vgpr r" + str(laneIdVGPRIndex) + ", initialized at beginning, should never be overwritten")

  addressVGPRIndex = flowHandler.allocateVGPR(1)
  addressVGPRStr = "r" + str(addressVGPRIndex)
  br_print (indentstring + "//   address at vgpr r" + str(addressVGPRIndex))


  activationInputFormat = hwCaps.SurfaceFormatFP16()

  if (bRefClassIndex == 0):
    referenceInputFormat = hwCaps.SurfaceFormatFP16()
  else:
    referenceInputFormat = hwCaps.SurfaceFormatUINT16()

  gradientOutputFormat = hwCaps.SurfaceFormatFP16()
  lossOutputFormat = hwCaps.SurfaceFormatFP16()
  vectorElementNumber = usharpList[activationUSharpIndex][5]

  activationElementIndexStep = 32
  refElementIndexStep = 32
  gradientElementIndexStep = 32

  vgprElementNumber = 32
  lastVGPRLaneNumber = (vectorElementNumber) & (vgprElementNumber - 1)
  vectorVGPRNumber = (vectorElementNumber + vgprElementNumber - 1) >> 5

  ####################################################
  # this is to tell how many shuffle we need to do
  if (vectorElementNumber >= 32):
    validLaneNumber = 32
  else:
    validLaneNumber = vectorElementNumber

  # if only 1, just a copy, if 2, just an add, no accumulation
  if (vectorVGPRNumber <= 2):
    accumulationMode = vectorVGPRNumber
  else:
    accumulationMode = 0

  # allocate space for ref, source and gradient
  if (bRefClassIndex == 0):
    refVGPRNumber = vectorVGPRNumber
  else:
    refVGPRNumber = 1

  sourceVGPRAddr = flowHandler.allocateVGPR(vectorVGPRNumber)
  refVGPRAddr = flowHandler.allocateVGPR(refVGPRNumber)

  if (bCalculateGradient != 0):
    # just hold a small portion
    gradientVGPRAddr = flowHandler.allocateVGPR(hwCaps.MaxALUGranule())
  else:
    gradientVGPRAddr = -1

  funcLib.AlignPrint(indentstring + "ackgmb", flowLib.GetCommentPos(), "// flush write")
  funcLib.AlignPrint(indentstring + "bar.wtg.sync.cnt 8, 16", flowLib.GetCommentPos(), "// all EUs wait at here")
  br_print (indentstring)

  funcLib.AlignPrint(indentstring + "sysid.work q0", flowLib.GetCommentPos(), "");
  funcLib.AlignPrint(indentstring + "sand " + euIDSGPRStr + ", q0, 0xf", flowLib.GetCommentPos(), "// obtain unique cu_eu id");

  br_print (indentstring + "// let eu0 do reduce")
  flowHandler.startIfLoop(euIDSGPRStr, "0", "==", 0)
  indentstring = flowHandler.getIndentStr()

  # how many vgprs to load/alu activation each time
  if vectorVGPRNumber > 4:
    vgprGroupNumber = 4
  else:
    vgprGroupNumber = vectorVGPRNumber


  funcLib.AlignPrint(indentstring + "and " + addressVGPRStr + ", " + laneIdVGPRStr + ", 0x1f", flowLib.GetCommentPos(), "// get element index of each lane, assume r0 is lane id")

  rowGroupNumber = int ((vectorVGPRNumber + vgprGroupNumber - 1) / vgprGroupNumber)

  # last group may be partial
  vgprRemainNumber = vectorVGPRNumber % vgprGroupNumber

  br_print (indentstring + "// vgpr number = " + str(vectorVGPRNumber))
  br_print (indentstring + "// group number = " + str(rowGroupNumber))
  br_print (indentstring + "// vgpr remain number = " + str(vgprRemainNumber))

  # number of vgprs affects load, load might cross boundary, so has to take out of loop
  if (vgprRemainNumber != 0):
    rowGroupNumber -= 1
    tailNumber = 1
  else:
    tailNumber = 0

  bodyNumber = 0

  # reserve one sync channel for exp
  syncGroupNumber = 2
  if (rowGroupNumber > syncGroupNumber):
    headNumber = syncGroupNumber - 1
    tailNumber += (rowGroupNumber - headNumber) % syncGroupNumber
    loopNumber = int ((rowGroupNumber - headNumber) / syncGroupNumber)

    if (loopNumber != 0):
      bodyNumber = syncGroupNumber
  else:
    headNumber = rowGroupNumber
    loopNumber = 0

  lastLoadIndex = headNumber + bodyNumber + tailNumber - 1
  expandNumber = headNumber + bodyNumber + tailNumber + headNumber

  # load takes headNumber + bodyNumber + tailNumber
  # alu starts from headNumber

  br_print (indentstring + "// loop number = " + str(loopNumber))
  br_print (indentstring + "// head: " + str(headNumber) + ", body: " + str(bodyNumber) + ", tail: " + str(tailNumber) + ", last vgpr valid lane number: " + str(lastVGPRLaneNumber))

  loadIndex = 0
  aluIndex = 0

  tempVGPRAddr = flowHandler.allocateVGPR(2)

  accumulateVGPRNumber = 1 + hwCaps.MaxALUGranule()

  if (accumulateVGPRNumber < (vgprGroupNumber + 1)):
    accumulateVGPRNumber = vgprGroupNumber + 1

  # first one used as accumulation, rest to store temp result such as exp (xi)
  accumulateVGPRAddr = flowHandler.allocateVGPR(accumulateVGPRNumber)

  if accumulationMode == 0:
    funcLib.AlignPrint(indentstring + "movi r" + str(accumulateVGPRAddr) + ".f32, 0.0", flowLib.GetCommentPos(), "// initialize accumlate result")

  loadVGPRBaseSGPRStr = vgprBaseSGPRStr

  # reuse zSGPR as alu vgpr base
  aluVGPRBaseSGPRStr  = zSGPRStr


  br_print (indentstring + "// start loading activation, doing exp, source is not changed")
  funcLib.AlignPrint(indentstring + "smov " + loadVGPRBaseSGPRStr + ", " + str(sourceVGPRAddr), flowLib.GetCommentPos(), "// init load vgpr base sgpr")
  funcLib.AlignPrint(indentstring + "smov " + aluVGPRBaseSGPRStr + ", " + str(sourceVGPRAddr), flowLib.GetCommentPos(), "// init alu vgpr base sgpr")
  funcLib.AlignPrint(indentstring + "movi r" + str(tempVGPRAddr) + ".f32, 1.442695", flowLib.GetCommentPos(), "// log2e")

  # load and do exp
  for z in range (expandNumber):

    if (z == headNumber and loopNumber > 1):
      br_print (indentstring)
      flowHandler.startForLoop("0", str(loopNumber), "1", -1, "")
      indentstring = flowHandler.getIndentStr()

    if (z <= lastLoadIndex):
      br_print (indentstring)
      if (z == lastLoadIndex and vgprRemainNumber != 0):
        loadVGPRNumber = vgprRemainNumber
      else:
        loadVGPRNumber = vgprGroupNumber

      funcLib.AlignPrint(indentstring + "smovs a1, " + loadVGPRBaseSGPRStr, flowLib.GetCommentPos(), "// set load vgpr base")
      kernelLib.load_1d_vector(activationInputFormat, hwCaps.SurfaceFormatFP32(), addressVGPRStr, activationElementIndexStep, -1, loadVGPRNumber, loadIndex + 1, usharpList[activationUSharpIndex][0], indentstring)

      if (lastLoadIndex != 0):
        funcLib.AlignPrint(indentstring + "sadd " + loadVGPRBaseSGPRStr + ", " + loadVGPRBaseSGPRStr + ", " + str(vgprGroupNumber), flowLib.GetCommentPos(), "// advance load vgpr base")
        loadIndex = funcLib.IncAndWrap(loadIndex, syncGroupNumber)

    if (z >= headNumber):
      br_print (indentstring)
      syncId = aluIndex + 1
      funcLib.AlignPrint(indentstring + "smovs a1, " + aluVGPRBaseSGPRStr, flowLib.GetCommentPos(), "// switch to alu vgpr base")

      if (z == expandNumber-1 and vgprRemainNumber != 0):
        aluVGPRNumber = vgprRemainNumber
      else:
        aluVGPRNumber = vgprGroupNumber

      if (z == expandNumber-1):
        thisLastLaneNumber = lastVGPRLaneNumber
      else:
        thisLastLaneNumber = 0

      syncStr = kernelLib.GetSyncModifier(syncId)

      kernelLib.sum_vector_exp(accumulateVGPRAddr, -1, aluVGPRNumber, accumulationMode, tempVGPRAddr, thisLastLaneNumber, syncId, indentstring)

      if (lastLoadIndex != 0):
        funcLib.AlignPrint(indentstring + "sadd " + aluVGPRBaseSGPRStr + ", " + aluVGPRBaseSGPRStr + ", " + str(vgprGroupNumber), flowLib.GetCommentPos(), "// advance alu vgpr base")
        aluIndex = funcLib.IncAndWrap(aluIndex, syncGroupNumber)

    if (z == (headNumber + bodyNumber - 1) and loopNumber > 1):
      flowHandler.closeForLoop("0", str(loopNumber), "1", -1)
      indentstring = flowHandler.getIndentStr()

  br_print (indentstring)
  br_print (indentstring + "// finish loading activation and doing exp")

  # load reference
  br_print (indentstring)
  br_print (indentstring + "// load reference, can't use burst....")

  # use sync id 2 as sync id 1 is taken by butterfly sum
  loadRefSyncId = 2

  if (bRefClassIndex != 0):
    funcLib.AlignPrint(indentstring + "movi " + addressVGPRStr + ".u32, 0", flowLib.GetCommentPos(), "// read element 0")
    kernelLib.load_1d_vector(referenceInputFormat, hwCaps.SurfaceFormatUINT32(), addressVGPRStr, 0, refVGPRAddr, refVGPRNumber, loadRefSyncId, usharpList[refUSharpIndex][0], indentstring)
  else:
    funcLib.AlignPrint(indentstring + "and " + addressVGPRStr + ", " + laneIdVGPRStr + ", 0x1f", flowLib.GetCommentPos(), "// get element index of each lane, assume r0 is lane id")
    kernelLib.load_1d_vector(referenceInputFormat, hwCaps.SurfaceFormatFP32(), addressVGPRStr, refElementIndexStep, refVGPRAddr, refVGPRNumber, loadRefSyncId, usharpList[refUSharpIndex][0], indentstring)

  br_print (indentstring)
  br_print (indentstring + "// formula to calculate lass")
  br_print (indentstring + "// loss = sum( -yi * ln ((e^xi) / sum (e^xi)))")
  br_print (indentstring + "//      = sum( -yi * (ln (e^xi) - ln (sum (e^xi))))")
  br_print (indentstring + "//      = sum( -yi * xi) + sum (yi) * ln (sum (e^xi))")
  br_print (indentstring + "//      = sum( -yi * xi) + ln (sum (e^xi)) if y is hot vector")

  br_print (indentstring)
  br_print (indentstring + "// 1. butterfly sum to get sum (e^xi), and then replicate to all lanes")
  kernelLib.butterfly_sum(accumulateVGPRAddr, 1, tempVGPRAddr, 32, indentstring)
  br_print (indentstring)

  br_print (indentstring)
  br_print (indentstring + "// 2. wait till butterfly sum finishs and then get log2(sum(e^xi)))")
  br_print (indentstring + "mov" + kernelLib.GetSyncModifier(1) + ".lg2 r" + str(tempVGPRAddr) + ".f32, r" + str(accumulateVGPRAddr) + ".f32")

  if (bRefHotVector == 0):
    br_print (indentstring)
    br_print (indentstring + "// need to get sum of reference")
    br_print (indentstring + "TODO")

  br_print (indentstring)

  # make sure ref data is back
  syncStr = kernelLib.GetSyncModifier(loadRefSyncId)

  if (bRefClassIndex != 0):
    br_print (indentstring + "// 3. wait till ref data is back, find which xi to get -yi * xi")

    # reuse coord SGPR
    vgprOffsetSGPRStr  = xSGPRStr
    vgprLaneMaskSGPRStr  = ySGPRStr
    scalarSGPRStr  = wSGPRStr

    assert (vgprElementNumber == 32), "need more work to support fp16"
    funcLib.AlignPrint(indentstring + "m0.movw.r2q " + vgprLaneMaskSGPRStr + ", r" + str(refVGPRAddr) + ".u32", flowLib.GetCommentPos(), "// mov to sgpr")

    if (vectorVGPRNumber > 1):
      funcLib.AlignPrint(indentstring + "sshr " + vgprOffsetSGPRStr + ", " + vgprLaneMaskSGPRStr + ", "  + str(funcLib.GetLeadingOnePos(vgprElementNumber)), flowLib.GetCommentPos(), "// get vgpr address offset to source")
      funcLib.AlignPrint(indentstring + "sand " + vgprLaneMaskSGPRStr + ", " + vgprLaneMaskSGPRStr + ", " + str(vgprElementNumber - 1), flowLib.GetCommentPos(), "// get lane index")


    funcLib.AlignPrint(indentstring + "sshl " + vgprLaneMaskSGPRStr + ", 1, " + vgprLaneMaskSGPRStr, flowLib.GetCommentPos(), "// get lane mask")
    funcLib.AlignPrint(indentstring + "smovs wm0, " + vgprLaneMaskSGPRStr, flowLib.GetCommentPos(), "// set m0 mask to the target lane")

    if (vectorVGPRNumber > 1):
      funcLib.AlignPrint(indentstring + "smovs a1, " + str(sourceVGPRAddr), flowLib.GetCommentPos(), "// set vgpr base")
      funcLib.AlignPrint(indentstring + "sadda a1, a1, " + vgprOffsetSGPRStr, flowLib.GetCommentPos(), "// vgpr offset")
      funcLib.AlignPrint(indentstring + "m0.movw.r2q " + scalarSGPRStr + ", ir0.f32", flowLib.GetCommentPos(), "// mov corresponding lane's activation data to a sgpr")
    else:
      funcLib.AlignPrint(indentstring + "m0.movw.r2q " + scalarSGPRStr + ", r" + str(sourceVGPRAddr) + ".f32", flowLib.GetCommentPos(), "// mov corresponding lane's activation data to a sgpr")

    br_print (indentstring)
    br_print (indentstring + "// 4. sum of -yi * xi, which essentially is the xi selected by y")
    funcLib.AlignPrint(indentstring + "mov r" + str(accumulateVGPRAddr) + ".f32, " + scalarSGPRStr + ".n.f32", flowLib.GetCommentPos(), "// replicate")
    funcLib.AlignPrint(indentstring + "smovs wm0, 0xffffffff", flowLib.GetCommentPos(), "// reset m0 mask")

  else:
    br_print (indentstring + "// 3. wait till ref data is back, get -yi * xi, use accumulate buffer to calculate sum")

    sizeList = funcLib.SplitRepeatIntoGroups(vectorVGPRNumber, hwCaps.MaxALUGranule())
    thisSrcVGPRAddr1 = sourceVGPRAddr
    thisSrcVGPRAddr2 = refVGPRAddr

    if (accumulationMode == kernelLib.get_accmulation_mode_accu()):
      funcLib.AlignPrint(indentstring + "movi r" + str(accumulateVGPRAddr) + ".f32, 0.0", flowLib.GetCommentPos(), "// clear accumulate buffer")

    if (accumulationMode == kernelLib.get_accmulation_mode_mov()):
      thisDstVGPRAddr = accumulateVGPRAddr
    else:
      thisDstVGPRAddr = accumulateVGPRAddr + 1

    for thisArray in sizeList:
      for z in range(thisArray[0]):
        br_print (indentstring + "fmul.b32" + syncStr + kernelLib.GetVectorModifier(thisArray[1], "v") + " r" + str(thisDstVGPRAddr) + ", r" + str(thisSrcVGPRAddr1) + ".n, r" + str(thisSrcVGPRAddr2))

        if (accumulationMode != kernelLib.get_accmulation_mode_mov()):
          kernelLib.sum_vector(accumulateAddr, accumulateAddr+1, thisArray[1], accumulationMode, "b32", 0, indentstring)


        #if (accumulationMode != kernelLib.get_accmulation_mode_mov()):
        #  inVGPRNumber = thisArray[1]
        #  thisLoopGranule = vgprGroupNumber * 2
        #  offset = 0
        #  while (inVGPRNumber > thisLoopGranule):
        #    thisLoopNumber = thisLoopGranule
        #    kernelLib.sum_vector(accumulateVGPRAddr, thisDstVGPRAddr + offset, thisLoopNumber, accumulationMode, ".b32", 0, indentstring)
        #    offset += thisLoopGranule
        #    inVGPRNumber -= thisLoopGranule
        #
        #  if (inVGPRNumber != 0):
        #    thisLoopNumber = inVGPRNumber
        #    kernelLib.sum_vector(accumulateVGPRAddr, thisDstVGPRAddr + offset, thisLoopNumber, accumulationMode, ".b32", 0, indentstring)

        thisSrcVGPRAddr1 += thisArray[1]
        thisSrcVGPRAddr2 += thisArray[1]

        syncStr = ""
        loadRefSyncId = 0


    br_print (indentstring)
    br_print (indentstring + "// 4. butterfly to get sum of -yi * xi and replicate to all lanes")
    kernelLib.butterfly_sum(accumulateVGPRAddr, 1, tempVGPRAddr+1, 32, indentstring)


  br_print (indentstring)
  br_print (indentstring + "// 5. now get ln (sum (e^xi)) by multiplying ln2")
  funcLib.AlignPrint(indentstring + "movi r" + str(tempVGPRAddr+1) + ".f32, 0.69314718", flowLib.GetCommentPos(), "// ln2")
  thisVGPRAddr = sourceVGPRAddr
  br_print (indentstring + "fmul.b32.lg2.sc3 r" + str(tempVGPRAddr) + ", r" + str(tempVGPRAddr) + ", r" + str(tempVGPRAddr+1))

  br_print (indentstring)
  br_print (indentstring + "// 6. wait till butterfly sum finishes and then get final loss")
  br_print (indentstring + "fadd.b32.sc1 r" + str(accumulateVGPRAddr) + ", r" + str(accumulateVGPRAddr) + ", r" + str(tempVGPRAddr))

  if (lossOutputFormat != hwCaps.SurfaceFormatFP32()):
    funcLib.AlignPrint(indentstring + "movi r" + str(accumulateVGPRAddr + 1) + ".f32, 0.0", flowLib.GetCommentPos(), "// clear to 0 as 2 fp32 are packed together")


  br_print (indentstring)
  br_print (indentstring + "// store loss, use wm1 to control lane")
  funcLib.AlignPrint(indentstring + "smovs wm1, 1", flowLib.GetCommentPos(), "// set mask to lane 0 only")
  funcLib.AlignPrint(indentstring + "and " + addressVGPRStr + ", " + laneIdVGPRStr + ", 0x1f", flowLib.GetCommentPos(), "// get element index of each lane, assume r0 is lane id")
  kernelLib.store_1d_vector(lossOutputFormat, hwCaps.SurfaceFormatFP32(), addressVGPRStr, 0, accumulateVGPRAddr, 1, usharpList[lossUSharpIndex][0], indentstring)
  funcLib.AlignPrint(indentstring + "smovs wm1, 0xffffffff", flowLib.GetCommentPos(), "// reset mask")

  if (bCalculateGradient != 0):
    br_print (indentstring)
    funcLib.AlignPrint(indentstring + "and " + addressVGPRStr + ", " + laneIdVGPRStr + ", 0x1f", flowLib.GetCommentPos(), "// get element index of each lane, assume r0 is lane id")

    if (bRefClassIndex != 0):
      vgprOffsetSGPRStr  = xSGPRStr
      vgprLaneMaskSGPRStr  = ySGPRStr
      scalarSGPRStr  = wSGPRStr

      br_print (indentstring + "// calculate gradient = reference - source")
      funcLib.AlignPrint(indentstring + "movi r" + str(tempVGPRAddr) + ".f32, 0.0", flowLib.GetCommentPos(), "// all 0")
      funcLib.AlignPrint(indentstring + "smovs wm0, " + vgprLaneMaskSGPRStr, flowLib.GetCommentPos(), "// set m0 mask to the target lane")
      funcLib.AlignPrint(indentstring + "m0.movi r" + str(tempVGPRAddr) + ".f32, 1.0", flowLib.GetCommentPos(), "// yi = 1.0")

      if (vectorVGPRNumber > 1):
        funcLib.AlignPrint(indentstring + "fadd.b32 ir0, ir0, r" + str(tempVGPRAddr) + ".n", flowLib.GetCommentPos(), "// xi-yi")
      else:
        funcLib.AlignPrint(indentstring + "fadd.b32 r" + str(sourceVGPRAddr) + ", r" + str(sourceVGPRAddr) + ", r" + str(tempVGPRAddr) + ".n", flowLib.GetCommentPos(), "// xi-yi")

      br_print (indentstring)
      br_print (indentstring + "// store gradient")
      sizeList = funcLib.SplitRepeatIntoGroups(vectorVGPRNumber, hwCaps.MaxStoreGranule())
      thisSrcVGPRAddr = sourceVGPRAddr

      for thisSizeArray in sizeList:
        for thisSize in range(thisSizeArray[0]):
          br_print (indentstring + "mov" + kernelLib.GetVectorModifier(thisSizeArray[1], "v") + " r" + str(thisSrcVGPRAddr) + ".f32, r" + str(thisSrcVGPRAddr) + ".f32.n.a")
          kernelLib.store_1d_vector(gradientOutputFormat, hwCaps.SurfaceFormatFP32(), addressVGPRStr, gradientElementIndexStep, thisSrcVGPRAddr, thisSizeArray[1], usharpList[gradientUSharpIndex][0], indentstring)
          thisSrcVGPRAddr += thisSizeArray[1]

    else:
      br_print (indentstring + "// calculate gradient = reference - source, and store it")
      sizeList = funcLib.SplitRepeatIntoGroups(vectorVGPRNumber, hwCaps.MaxALUGranule())
      thisSrcVGPRAddr1 = refVGPRAddr
      thisSrcVGPRAddr2 = sourceVGPRAddr
      thisDstVGPRAddr = gradientVGPRAddr
      for thisSizeArray in sizeList:
        for thisSize in range(thisSizeArray[0]):
          br_print (indentstring + "fadd.b32" + kernelLib.GetVectorModifier(thisSizeArray[1], "v") + " r" + str(thisDstVGPRAddr) + ", r" + str(thisSrcVGPRAddr1) + ".a, r" + str(thisSrcVGPRAddr2) + ".n.a")

          kernelLib.store_1d_vector(gradientOutputFormat, hwCaps.SurfaceFormatFP32(), addressVGPRStr, gradientElementIndexStep, thisDstVGPRAddr, thisSizeArray[1], usharpList[gradientUSharpIndex][0], indentstring)
          thisSrcVGPRAddr1 += thisSizeArray[1]
          thisSrcVGPRAddr2 += thisSizeArray[1]
          thisDstVGPRAddr += thisSizeArray[1]


  flowHandler.closeIfLoop()
  indentstring = flowHandler.getIndentStr()

  br_print (indentstring)
  kernelLib.jump_to_next_layer(layerId, layerNumber, warpId, indentstring)
  br_print (indentstring)

  flowHandler.closeFunctionDef("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel", 0)
