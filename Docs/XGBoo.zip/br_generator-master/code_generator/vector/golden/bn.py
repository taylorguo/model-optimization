#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import sys
import os
import math
import copy

from code_generator.share.br_defined_print import br_print
import code_generator.share.br_const_defs as bcd
import code_generator.vector.common.hwCaps as hwCaps
import code_generator.vector.common.flowLib as flowLib
import code_generator.vector.common.cwarp as cwarp
import code_generator.vector.common.funcgen as funcgen
import code_generator.vector.common.funcLib as funcLib
import code_generator.vector.common.kernelLib as kernelLib
import code_generator.vector.common.compiler as compiler
import code_generator.vector.common.usharp as usharp


def FuncTypeLoad():
  return 0


def FuncTypeALU():
  return 1


def GetReduceOnIndex():
  return 6


def GetReluOnIndex():
  return 7


def GetGammaUSharpIndex():
  return 1


def GetBNLoadLoopUnrollThreshold():
  return 2


def GetBNAluLoopUnrollThreshold():
  return 2


def BufferRowModeThresholdX():
  return 8


def BufferRowModeThresholdY():
  return 3


def BufferBlockMode():
  return 0


def BufferSurfaceMode():
  return 1


def BufferRowMode():
  return 2


def BufferColMode():
  return 3


def BorderTypeBottom():
  return 1


def BorderTypeBottomPartial():
  return 2


def BorderTypeTop():
  return 4


def BorderTypeRight():
  return 8


def BorderTypeLeft():
  return 16


def BorderTypeRightPartial():
  return 32


def BorderTypeAll():
  return BorderTypeBottom() | BorderTypeRight() | BorderTypeTop()

################################################################################################################
# general functions
# does not necessarily for pooling kernel only
################################################################################################################


####################################################
# load_tile_cols_v
#   load one or more cols of tiles to vgprs
def load_tile_cols_v(resetY, resetVgprBase, vgprStartIndex, vgprRowNumber, vgprColNumber, yStartOffset, vgprStride, isIndexed, clearColMinus1, syncId, funcParameterMap, indentstring):

  syncStr = kernelLib.GetSyncModifier(syncId)

  if (isIndexed == 0):
    vgprStrPrefix = " r"
    vgprStrPostfix = ""
  else:
    vgprStrPrefix = " ir"
    vgprStrPostfix = ""

  vgprIndex = vgprStartIndex

  xSGPRStr = funcParameterMap["xSGPRStr"]
  ySGPRStr = funcParameterMap["ySGPRStr"]
  zSGPRStr = funcParameterMap["zSGPRStr"]
  wSGPRStr = funcParameterMap["wSGPRStr"]
  uSharpIdList = funcParameterMap["uSharpIdList"]

  if (yStartOffset != 0):
    br_print (indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(yStartOffset * hwCaps.TileSizeY()))

  sizeList = funcLib.SplitRepeatIntoGroups(vgprRowNumber, hwCaps.MaxLDMGranule())

  sizeListLen = len(sizeList)
  arrayIndex = 0
  yChange = yStartOffset

  for thisArray in sizeList:
    arrayIndex += 1

    vectorModifier = kernelLib.GetVectorModifier(thisArray[1], "v")
    vectorModifierLoad = kernelLib.GetVectorModifier(thisArray[1] * 2, "e")
    for z in range(thisArray[0]):

      if (clearColMinus1 != 0):
        br_print (indentstring + "movi" + vectorModifier + vgprStrPrefix + str(vgprIndex - vgprStride) + vgprStrPostfix + ".u32, 0")

      for x in range (vgprColNumber):
        br_print (indentstring + "ldm" + syncStr + ".float.mb16.rb16" + vectorModifierLoad + ".gc4" + vgprStrPrefix + str(vgprIndex) + vgprStrPostfix + ", g0, u" + str(uSharpIdList[0][0]))
        br_print (indentstring + "smovg g0, " + xSGPRStr)
        br_print (indentstring + "smovg g1, " + ySGPRStr)
        br_print (indentstring + "smovg g2, " + zSGPRStr)
        br_print (indentstring + "smovg.eog g3, " + wSGPRStr)

        if (x != (vgprColNumber - 1)):
          vgprIndex += vgprStride
          br_print (indentstring + "sadd " + xSGPRStr + ", " + xSGPRStr + ", " + str(hwCaps.TileSizeX()))

      if (vgprColNumber != 1):
        vgprIndex -= (vgprColNumber - 1) * vgprStride
        br_print (indentstring + "sadd " + xSGPRStr + ", " + xSGPRStr + ", " + str(-(vgprColNumber - 1) * hwCaps.TileSizeX()))

      vgprIndex += thisArray[1]

      if (arrayIndex != sizeListLen or z != (thisArray[0] - 1)):
        yChange += thisArray[1]
        br_print (indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(thisArray[1] * hwCaps.TileSizeY()))

  if ((resetY != 0) and (yChange != 0)):
    br_print (indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(-yChange * hwCaps.TileSizeY()))

  if (resetVgprBase == 0):
    vgprBaseStr = funcParameterMap["vgprBase"]
    br_print (indentstring + "sadda " + vgprBaseStr + ", " + vgprBaseStr + ", " + str(vgprRowNumber))


####################################################
# store_tile_v
#   store 1 tile, without setting g0 register
def store_tile_v(vectorSize, usharpStr, mmat3d, write_through, indentstring):
  mmat = ".mmat3d" if mmat3d is True else ".mmat2d"
  wt = ".wt" if write_through is True else ".nwt"
  br_print (indentstring + "stm.float.mb16.rb16" + mmat + kernelLib.GetVectorModifier(vectorSize * 2, "e") + wt + ".gc" + str(4 + vectorSize) + " g0, g4, u" + usharpStr)


####################################################
#
# vcnt = {v1|v2|v3|v4|v8}
def bn_tile_v(vgprAddr, vgprNumber, bnCoeffVGPRIndex, isPartial, indentstring):

  sizeList = funcLib.SplitRepeatIntoGroups(vgprNumber, hwCaps.MaxALUGranule())

  if (isPartial):
    predicateModifier = "m0."
  else:
    predicateModifier = ""

  for thisArray in sizeList:
    for z in range(thisArray[0]):
      vectorModifier = kernelLib.GetVectorModifier(thisArray[1], "v")
      br_print (indentstring + predicateModifier + "fmad.b16" + vectorModifier + " ir" + str(vgprAddr) + ", ir" + str(vgprAddr) + ".a, r" + str(bnCoeffVGPRIndex) + ", r" + str(bnCoeffVGPRIndex + 1))

      # if withRelu:
      #  br_print (indentstring + predicateModifier + "fmax.b16" + vectorModifier + " ir" + str(vgprAddr) + ", ir" + str(vgprAddr) + ".a, 0")

      vgprAddr += thisArray[1]


####################################################
#
# vcnt = {v1|v2|v3|v4|v8}
def relu_tile_v(vgprAddr, vgprNumber, bnCoeffVGPRIndex, isPartial, indentstring):

  sizeList = funcLib.SplitRepeatIntoGroups(vgprNumber, hwCaps.MaxALUGranule())

  if (isPartial):
    predicateModifier = "m0."
  else:
    predicateModifier = ""

  for thisArray in sizeList:
    for z in range(thisArray[0]):
      vectorModifier = kernelLib.GetVectorModifier(thisArray[1], "v")
      br_print (indentstring + predicateModifier + "fmax.b16" + vectorModifier + " ir" + str(vgprAddr) + ", ir" + str(vgprAddr) + ".a, 0.0")

      vgprAddr += thisArray[1]


def store_tile_col(vgprNumber, vgprAddr, usharpStr, xSGPRStr, ySGPRStr, zSGPRStr, wSGPRStr, yChange, indentstring):
  sizeList = funcLib.SplitRepeatIntoGroups(vgprNumber, hwCaps.MaxSTMGranule())
  sizeListLen = len(sizeList)
  arrayIndex = 0

  mmat3d = True
  write_through = True

  for thisArray in sizeList:
    arrayIndex += 1

    for z in range(thisArray[0]):
      store_tile_v(thisArray[1], usharpStr, mmat3d, write_through, indentstring)

      # br_print (indentstring + "mov" + kernelLib.GetVectorModifier(thisArray[1] << 1, "v") + " g4.f16, " + "ir" + str(vgprAddr) + ".f16")

      br_print (indentstring + "smovg g0, " + xSGPRStr)
      br_print (indentstring + "smovg g1, " + ySGPRStr)
      br_print (indentstring + "smovg g2, " + zSGPRStr)
      br_print (indentstring + "smovg g3, " + wSGPRStr)
      br_print (indentstring + "mov" + kernelLib.GetVectorModifier(thisArray[1], "v") + ".eog g4.f16, " + "ir" + str(vgprAddr) + ".f16.a")

      vgprAddr += thisArray[1]

      if ((arrayIndex != sizeListLen) or (z != (thisArray[0] - 1))):
        yChange += thisArray[1]
        br_print (indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(thisArray[1] * hwCaps.TileSizeY()))

  return yChange


####################################################
#
#
def bn_tile_col(vgprAddr, vgprNumber, vgprStride, vgprDstStart, colBorderType, funcParameterMap, flowHandler):

  indentstring = flowHandler.getIndentStr()

  imageWidthRes = funcParameterMap["imageWidthRes"]
  imageHeightRes = funcParameterMap["imageHeightRes"]
  xSGPRStr = funcParameterMap["xSGPRStr"]
  ySGPRStr = funcParameterMap["ySGPRStr"]
  zSGPRStr = funcParameterMap["zSGPRStr"]
  wSGPRStr = funcParameterMap["wSGPRStr"]
  bnCoeffVGPRAddr = funcParameterMap["bnCoeffVGPRAddr"]
  uSharpIdList = funcParameterMap["uSharpIdList"]

  isRowPartial = (colBorderType & BorderTypeBottom()) and (imageHeightRes != 0)

  # special handling of last row
  if (isRowPartial):
    vgprNumber -= 1

  isColPartial = ((colBorderType & BorderTypeRight()) and (imageWidthRes != 0))

  vgprAddr_relu = copy.copy(vgprAddr)
  if (vgprNumber != 0):
    if (isColPartial):
      br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(0, imageWidthRes, 0)))

    bn_tile_v(vgprAddr, vgprNumber, bnCoeffVGPRAddr, isColPartial, indentstring)

  if (isRowPartial):
    if (isColPartial):
      br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(imageHeightRes, imageWidthRes, 0)))
    else:
      br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(imageHeightRes, 0, 0)))

    bn_tile_v(vgprAddr + vgprNumber, 1, bnCoeffVGPRAddr, True, indentstring)

    # restore total vgpr number
    vgprNumber += 1

  yChange = 0
  usharpStr = str(uSharpIdList[1][0])
  yChange = store_tile_col(vgprNumber, vgprAddr, usharpStr, xSGPRStr, ySGPRStr, zSGPRStr, wSGPRStr, yChange, indentstring)

  if (yChange != 0):
    br_print (indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(-yChange * hwCaps.TileSizeY()))

  if flowHandler.enableRelu:
    usharpStr = str(uSharpIdList[1][1])
    if (vgprNumber != 0):
      relu_tile_v(vgprAddr_relu, vgprNumber, bnCoeffVGPRAddr, isColPartial, indentstring)

    if (isRowPartial):
      relu_tile_v(vgprAddr_relu + vgprNumber, 1, bnCoeffVGPRAddr, True, indentstring)
      # restore total vgpr number
      vgprNumber += 1

    store_tile_col(vgprNumber, vgprAddr_relu, usharpStr, xSGPRStr, ySGPRStr, zSGPRStr, wSGPRStr, 0, indentstring)

    if (yChange != 0):
      br_print (indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(-yChange * hwCaps.TileSizeY()))

################################################################################################################
# sub function generators
# sub function will be called at run time
# it uses some q/r registers as parameter
################################################################################################################


####################################################
# gen_bn_sub_function
def gen_bn_sub_function(funcType, yBorderType, rowSize, rightBorderMode, syncIndex, funcParameterMap, flowHandler):

  if (funcType == FuncTypeLoad()):
    funcParameterMap["xSGPRStr"] = funcParameterMap["xLoadSGPRStr"]
    funcParameterMap["ySGPRStr"] = funcParameterMap["yLoadSGPRStr"]
    vgprBaseSGPRStr = funcParameterMap["vgprLoadBaseSGPRStr"]
  else:
    funcParameterMap["xSGPRStr"] = funcParameterMap["xAluSGPRStr"]
    funcParameterMap["ySGPRStr"] = funcParameterMap["yAluSGPRStr"]
    vgprBaseSGPRStr = funcParameterMap["vgprAluBaseSGPRStr"]

  uSharpIdList = funcParameterMap["uSharpIdList"]

  xSGPRStr = funcParameterMap["xSGPRStr"]
  ySGPRStr = funcParameterMap["ySGPRStr"]

  vgprBaseStr = funcParameterMap["vgprBase"]
  vgprTempStart = funcParameterMap["vgprTempStart"]
  vgprStride = funcParameterMap["vgprStride"]

  fullBlockWidth = funcParameterMap["fullBlockWidth"]
  partialBlockWidth = funcParameterMap["partialBlockWidth"]

  vgprIndexEnd = funcParameterMap["vgprIndexEnd"]
  vgprIndexStart = funcParameterMap["vgprIndexStart"]
  vgprStepBack = funcParameterMap["vgprStepBack"]

  coordSGPRStrList = [xSGPRStr, ySGPRStr, funcParameterMap["zSGPRStr"], funcParameterMap["wSGPRStr"]]

  if (funcType == FuncTypeLoad()):
    pass
  else:
    imageWidthRes = funcParameterMap["imageWidthRes"]
    imageHeightRes = funcParameterMap["imageHeightRes"]

  indentstring = flowHandler.getIndentStr()

  br_print (indentstring + "// funciton gen_bn_sub_function")
  br_print (indentstring + "// gpr base always points to curRow, curCol")
  br_print (indentstring + "// naming rule:")
  if (funcType == FuncTypeLoad()):
    br_print (indentstring + "//    yBorderType_blockHeight_syncId_rightBorder")
  else:
    br_print (indentstring + "//    yBorderType_blockHeight_rightBorder")

  br_print (indentstring + "//    yBorderType    - y border info, top/bottom or both")
  if (yBorderType & BorderTypeTop()):
    br_print (indentstring + "//                   - top border")
  if (yBorderType & BorderTypeRight()):
    br_print (indentstring + "//                   - right border")
  if (yBorderType & BorderTypeBottom()):
    br_print (indentstring + "//                   - bottom border")
  if (yBorderType & BorderTypeLeft()):
    br_print (indentstring + "//                   - left border")

  br_print (indentstring + "//    blockHeight    - row number of current block")
  if (funcType == FuncTypeLoad()):
    br_print (indentstring + "//    syncId         - which sync channel to use, 1 or 2 ")
  br_print (indentstring + "//    rightBorder    - whether it is right border, different width and border handling")
  if (rightBorderMode != 0):
    br_print (indentstring + "//                   - right border")

  br_print (indentstring)

  loopRowSize = rowSize

  if (yBorderType & BorderTypeBottom()):
    loopRowSize += 1

  if (funcType == FuncTypeLoad()):
    loopUnrollThreshold = GetBNLoadLoopUnrollThreshold()
  else:
    loopUnrollThreshold = GetBNAluLoopUnrollThreshold()

  if (rightBorderMode == 0):
    loopColNumber = fullBlockWidth
  elif ((funcType == FuncTypeLoad()) or (imageWidthRes == 0)):
    loopColNumber = partialBlockWidth + 1
  else:
    loopColNumber = partialBlockWidth

  # special handling or single col in alu block
  if (loopColNumber == 0 or loopColNumber < loopUnrollThreshold):
    loopMode = 0
  else:
    loopMode = 1

  br_print (indentstring + "// check vgpr base, as we can't use auto wrap")
  br_print (indentstring + "// if too big, step back, vgpr range is [" + str(vgprIndexStart) + ", " + str(vgprIndexEnd) + ")")
  flowHandler.startIfLoop(vgprBaseSGPRStr, str(vgprIndexEnd-loopColNumber*vgprStride), ">=", 0)
  indentstring = flowHandler.getIndentStr()
  br_print (indentstring + "smov " + vgprBaseSGPRStr + ", " + str(vgprIndexStart))
  flowHandler.closeIfLoop()

  if (funcType == FuncTypeLoad()):
    funcLib.AlignPrint(indentstring + "smovs " + vgprBaseStr + ", " + vgprBaseSGPRStr, flowLib.GetCommentPos(), "// restore load vgpr base from sgpr")
  else:
    funcLib.AlignPrint(indentstring + "smovs " + vgprBaseStr + ", " + vgprBaseSGPRStr, flowLib.GetCommentPos(), "// restore alu vgpr base from sgpr")


  if (loopMode != 0):
    xControlQIndex = flowHandler.allocateSGPR(1)
    xIndexSGPRStr = "q" + str(xControlQIndex)
    funcLib.AlignPrint(indentstring + "smov " + xIndexSGPRStr + ", 0", flowLib.GetCommentPos(), "// set loop start, 0")
    xSizeSGPRStr = str(loopColNumber)

    if (loopColNumber > 1):
      flowHandler.startForLoop("", xSizeSGPRStr, "1", xControlQIndex, "loop in x dir")
      indentstring = flowHandler.getIndentStr()

    loopUnrollNumber = 1
  else:
    loopUnrollNumber = loopColNumber

  for z in range (loopUnrollNumber):
    if (funcType == FuncTypeLoad()):
      kernelLib.load_4d_activation(hwCaps.SurfaceFormatFP16(), hwCaps.SurfaceFormatFP16(), coordSGPRStrList, \
  	                               -1, loopRowSize, syncIndex, uSharpIdList[0][0], indentstring)
    else:
      bn_tile_col(0, loopRowSize, vgprStride, vgprTempStart, yBorderType, funcParameterMap, flowHandler)

    funcLib.AlignPrint(indentstring + "sadd " + xSGPRStr + ", " + xSGPRStr + ", " + str(hwCaps.TileSizeX()), flowLib.GetCommentPos(), "// move to next col")

  if (loopMode != 0):
    br_print (indentstring + "sadda " + vgprBaseStr + ", " + vgprBaseStr + ", " + str(vgprStride))
    br_print (indentstring + "sadd " + vgprBaseSGPRStr + ", " + vgprBaseSGPRStr + ", " + str(vgprStride))
    br_print (indentstring + "// bn - finish one column")
    if (loopColNumber > 1):
      flowHandler.closeForLoop("", xSizeSGPRStr, "1", xControlQIndex)

    indentstring = flowHandler.getIndentStr()
    rightBorderShift = 0
  else:
    rightBorderShift = loopUnrollNumber

    if (loopUnrollNumber != 0):
      br_print (indentstring + "// bn - finish a block of rows or a surface")

  if (funcType != FuncTypeLoad()) and (rightBorderMode != 0) and (imageWidthRes != 0):
    br_print (indentstring + "// process right border")

    rightBorderType = BorderTypeRight() | yBorderType

    bn_tile_col(rightBorderShift * vgprStride, loopRowSize, vgprStride, vgprTempStart, rightBorderType, funcParameterMap, flowHandler)

  if (loopMode == 0):
    xAdvanceStep = 0
  else:
    xAdvanceStep = loopColNumber

  xAdvanceStep = fullBlockWidth - xAdvanceStep
  vgprBaseShift = vgprStride * xAdvanceStep

  if (vgprBaseShift != 0):
    br_print (indentstring + "// adjust vgpr base, most time no need")
    br_print (indentstring + "sadd " + vgprBaseSGPRStr + ", " + vgprBaseSGPRStr + ", " + str(vgprBaseShift))

  if (loopMode != 0):
    flowHandler.releaseSGPR(1)

  br_print (indentstring)


####################################################
# called whenever starting a new slice (sample or channel)
# initialize y coordinate for load/alu
#


def do_y_initialize(vgprStride, colSize, yBorderType, funcParameterMap, flowHandler):
  yLoadSGPRStr = funcParameterMap["yLoadSGPRStr"]
  yAluSGPRStr = funcParameterMap["yAluSGPRStr"]

  indentstring = flowHandler.getIndentStr()

  funcLib.AlignPrint(indentstring + "smov " + yAluSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize alu's y coord")
  funcLib.AlignPrint(indentstring + "smov " + yLoadSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize load's y coord")

####################################################
# called whenever starting a new band
# initialize x coordinate for load/alu
#


def do_x_initialize(vgprStride, rowSize, yBorderType, funcParameterMap, flowHandler):
  indentstring = flowHandler.getIndentStr()

  xLoadSGPRStr = funcParameterMap["xLoadSGPRStr"]
  xAluSGPRStr = funcParameterMap["xAluSGPRStr"]

  funcLib.AlignPrint(indentstring + "smov " + xLoadSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize load's x coord")
  funcLib.AlignPrint(indentstring + "smov " + xAluSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize alu's x coord")

####################################################
# called whenever starting a channel
# issue load gamma/beta and reduction result
#


def do_z_initialize(funcParameterMap, flowHandler, uSharpIdList):

  indentstring = flowHandler.getIndentStr()

  newWeightSGPRStr = funcParameterMap["newWeightSGPRStr"]

  sldXSGPRStr = funcParameterMap["sldXSGPRStr"] 
  zSGPRStr = funcParameterMap["zSGPRStr"]
  funcLib.AlignPrint(indentstring + "sshl " + sldXSGPRStr + ", " + zSGPRStr + ", 1", flowLib.GetCommentPos(), "// calculate the 1d weight x axis")
  funcLib.AlignPrint(indentstring + "smov " + newWeightSGPRStr + ", 1", flowLib.GetCommentPos(), "// reduction needs preprocess, set a flag")

  gammaDataSGPRIndex = funcParameterMap["gammaDataSGPRIndex"]
  reduceResSGPRIndex = funcParameterMap["reduceResSGPRIndex"]
  surfaceChannel = funcParameterMap["surfaceChannel"]

  gammaDataVGPRIndex = funcParameterMap["gammaDataVGPRIndex"]
  reduceResVGPRIndex = funcParameterMap["reduceResVGPRIndex"]
  vgprSldmNum = funcParameterMap["vgprSldmNumber"]
  maxSldXValue = None
  if surfaceChannel*2 >= 128:
    maxSldXValue = funcParameterMap["maxSldXValue"]
    funcLib.AlignPrint(indentstring + "smov " + maxSldXValue + ", " + str(surfaceChannel*2), flowLib.GetCommentPos(), "// Move large imm to wsr")

  br_print (indentstring + "// load gamma/beta")
  kernelLib.scalar_load_sldm(hwCaps.SurfaceFormatFP32(), sldXSGPRStr, gammaDataVGPRIndex, 4, 0, 1, uSharpIdList[0][GetGammaUSharpIndex()], indentstring, funcParameterMap["wSGPRStr"])
  #kernelLib.scalar_load(hwCaps.SurfaceFormatFP32(), zSGPRStr, gammaDataSGPRIndex, 4, 0, 1, uSharpIdList[0][GetGammaUSharpIndex()], indentstring)
  br_print (indentstring + "// load sigma/mu")
  #kernelLib.scalar_load(hwCaps.SurfaceFormatFP32(), zSGPRStr, reduceResSGPRIndex, 4, 0, 1, uSharpIdList[0][GetGammaUSharpIndex()], indentstring, surfaceChannel)
  kernelLib.scalar_load_sldm(hwCaps.SurfaceFormatFP32(), sldXSGPRStr, reduceResVGPRIndex, 4, 0, 1, uSharpIdList[0][GetGammaUSharpIndex()], indentstring, funcParameterMap["wSGPRStr"], surfaceChannel, maxSldXValue)

####################################################
# preprocess lddw load, need to insert a wbar sync
# preprocess bn's gamma/beta and reduction result


def do_z_preprocess(funcParameterMap, flowHandler):

  newWeightSGPRStr = funcParameterMap["newWeightSGPRStr"]

  flowHandler.startIfLoop(newWeightSGPRStr, str(0), "!=", 0)
  indentstring = flowHandler.getIndentStr()
  br_print (indentstring + "smov " + newWeightSGPRStr + ", 0")

  gammaDataSGPRIndex = funcParameterMap["gammaDataSGPRIndex"]
  reduceResultSGPRAddr = funcParameterMap["reduceResSGPRIndex"]
  bnCoeffVGPRAddr = funcParameterMap["bnCoeffVGPRAddr"]
  gammaDataVGPRIndex = funcParameterMap["gammaDataVGPRIndex"]
  reduceResVGPRIndex = funcParameterMap["reduceResVGPRIndex"]

  vgprTempStart = funcParameterMap["vgprTempStart"]

  br_print (indentstring + "// y = gamma * (x-u)/sigma + beta")
  br_print (indentstring + "//   = gamma * (1/sigma) * x - gamma * u * (1/sigma) + beta")
  br_print (indentstring + "// assume order in reduce sgpr is c0_x_sum, c0_x^2_sum, c1_x_sum, c1_x^2_sum")
  br_print (indentstring + "// assume order in gamma sgpr is c0_gamma, c0_beta, c1_gamma, c1_beta")

  funcLib.AlignPrint(indentstring + "movi r" + str(vgprTempStart) + ".f32, " + str(funcParameterMap["reduceSurfaceCoeff"]), flowLib.GetCommentPos(), "// 1/surface_area")
  funcLib.AlignPrint(indentstring + "movi r" + str(vgprTempStart + 1) + ".f32, 0.000001", flowLib.GetCommentPos(), "// epilson to handle rcp of 0")

  funcLib.AlignPrint(indentstring + "fmul.b32.v4 r" + str(vgprTempStart + 2) + ", r" + str(reduceResVGPRIndex) + ".a, r" + str(vgprTempStart), flowLib.GetCommentPos(), "// scale by 1/surface_area: ")


  funcLib.AlignPrint(indentstring + "fmad.b32 r" + str(vgprTempStart + 3) + ", r" + str(vgprTempStart + 2) + ".n, r" + str(vgprTempStart + 2) + ", r" + str(vgprTempStart + 3), flowLib.GetCommentPos(), "// c0_sigma^2=1/m*c0_x^2_sum - (c0_u)^2")
  funcLib.AlignPrint(indentstring + "fmad.b32 r" + str(vgprTempStart + 5) + ", r" + str(vgprTempStart + 4) + ".n, r" + str(vgprTempStart + 4) + ", r" + str(vgprTempStart + 5), flowLib.GetCommentPos(), "// c1_sigma^2=1/m*c1_x^2_sum - (c1_u)^2")

  funcLib.AlignPrint(indentstring + "fadd.b32.rsqrt r" + str(vgprTempStart + 3) + ", r" + str(vgprTempStart + 3) + ", r" + str(vgprTempStart + 1), flowLib.GetCommentPos(), "// 1/sqrt(c0_sigma^2+epsilon)")
  funcLib.AlignPrint(indentstring + "fadd.b32.rsqrt.sc3 r" + str(vgprTempStart + 5) + ", r" + str(vgprTempStart + 5) + ", r" + str(vgprTempStart + 1), flowLib.GetCommentPos(), "// 1/sqrt(c1_sigma^2+epsilon)")

  funcLib.AlignPrint(indentstring + "fmul.b32.sc3 r" + str(vgprTempStart) + ", r" + str(vgprTempStart + 3) + ", r" + str(gammaDataVGPRIndex), flowLib.GetCommentPos(), "// c0_gamma/c0_sigma")
  funcLib.AlignPrint(indentstring + "fmul.b32 r" + str(vgprTempStart + 1) + ", r" + str(vgprTempStart + 5) + ", r" + str(gammaDataVGPRIndex + 2), flowLib.GetCommentPos(), "// c1_gamma/c1_sigma")

  funcLib.AlignPrint(indentstring + "fmad.b32 r" + str(vgprTempStart + 2) + ", r" + str(vgprTempStart + 2) + ".n, r" + str(vgprTempStart + 3) + ", r" + str(gammaDataVGPRIndex + 1), flowLib.GetCommentPos(), "// -c0_gamma/c0_sigma*c0_u + c0_beta")
  funcLib.AlignPrint(indentstring + "fmad.b32 r" + str(vgprTempStart + 3) + ", r" + str(vgprTempStart + 4) + ".n, r" + str(vgprTempStart + 5) + ", r" + str(gammaDataVGPRIndex + 3), flowLib.GetCommentPos(), "// -c1_gamma/c1_sigma*c1_u + c1_beta")

  funcLib.AlignPrint(indentstring + "mov.rdne.v4 r" + str(bnCoeffVGPRAddr) + ".f16, r" + str(vgprTempStart) + ".a.f32", flowLib.GetCommentPos(), "// pack to fp16")

  br_print (indentstring + "// now for each pixel, r, r = r * r" + str(bnCoeffVGPRAddr) + " + r" + str(bnCoeffVGPRAddr + 1))

  flowHandler.closeIfLoop()
  indentstring = flowHandler.getIndentStr()

####################################################
# process a horizontal band


def bn_kernel_process_channel_group(layerId, warpId, surfaceTileInfo, surfacePartition, funcParameterMap, funcGenHandler, flowHandler):

  wSize = surfaceTileInfo[0]

  uSharpIdList = funcParameterMap["uSharpIdList"]

  xLoadSGPRStr = funcParameterMap["xLoadSGPRStr"]
  yLoadSGPRStr = funcParameterMap["yLoadSGPRStr"]
  xAluSGPRStr = funcParameterMap["xAluSGPRStr"]
  yAluSGPRStr = funcParameterMap["yAluSGPRStr"]
  zSGPRStr = funcParameterMap["zSGPRStr"]
  wSGPRStr = funcParameterMap["wSGPRStr"]
  vgprTempStart = funcParameterMap["vgprTempStart"]

  vgprBaseStr = funcParameterMap["vgprBase"]

  euIdSGPRStr = funcParameterMap["euIdSGPRStr"]

  newWeightSGPRStr = funcParameterMap["newWeightSGPRStr"]

  reduce2bnBarIdSGPRStr = funcParameterMap["reduce2bnBarIdSGPRStr"]
  bn2reduceBarIdSGPRStr = funcParameterMap["bn2reduceBarIdSGPRStr"]

  if funcParameterMap["zOuterSGPRIndex"] is not None:
     flowHandler.startForLoop("", str(flowHandler.outer_oc_loop[1]*flowHandler.outer_oc_loop[3]), str(flowHandler.outer_oc_loop[3]), funcParameterMap["zOuterSGPRIndex"], "loop outer channel")
  
  if funcParameterMap["zInnerSGPRIndex"] is not None:
      indentstring = flowHandler.getIndentStr()
      br_print (indentstring + "// waiting for reduction buffer ready to use")
      br_print (indentstring + "bar.tg.sync " + reduce2bnBarIdSGPRStr + ", 8")
      flowHandler.startForLoop("", str(flowHandler.inner_oc_loop[1]*flowHandler.inner_oc_loop[3]), str(flowHandler.inner_oc_loop[3]), funcParameterMap["zInnerSGPRIndex"], "loop inner channel")
      if funcParameterMap["zOuterSGPRIndex"] is not None:
        funcLib.AlignPrint(indentstring + "sadd " + funcParameterMap["zSGPRStr"] + ", " + funcParameterMap["zInnerSGPRStr"] + ", " + funcParameterMap["zOuterSGPRStr"], flowLib.GetCommentPos(), "// assign z axis")
      else:
        funcLib.AlignPrint(indentstring + "smov " + funcParameterMap["zSGPRStr"] + ", " + funcParameterMap["zInnerSGPRStr"], flowLib.GetCommentPos(), "// assign z axis")

  if funcParameterMap["zInnerSGPRIndex"] is None and funcParameterMap["zOuterSGPRIndex"] is None:
    flowHandler.startForLoop("", str(surfaceTileInfo[1]), str(32), funcParameterMap["zSGPRIndex"], "loop channel")
    indentstring = flowHandler.getIndentStr()
    br_print (indentstring + "// waiting for reduction buffer ready to use")
    br_print (indentstring + "bar.tg.sync " + reduce2bnBarIdSGPRStr + ", 8")

  indentstring = flowHandler.getIndentStr()

  do_z_initialize(funcParameterMap, flowHandler, uSharpIdList)

  funcLib.AlignPrint(indentstring + "smov " + wSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize w")
  if (wSize > 1):
    flowHandler.startForLoop("", str(wSize), str(1), funcParameterMap["wSGPRIndex"], "loop sample/test")

  indentstring = flowHandler.getIndentStr()

  vgprStride = surfacePartition[0]
  ySpanList = surfacePartition[1]
  xSpanList = surfacePartition[2]

  ySpanListSize = len(ySpanList)

  isFirstSub = 1

  do_y_initialize(vgprStride, xSpanList[0], ySpanList[0][2], funcParameterMap, flowHandler)

  for ySpan in ySpanList:
    thisSpanHeight = ySpan[0]
    thisBlockHeight = ySpan[1]
    thisBorderFlagY = ySpan[2]

    indentstring = flowHandler.getIndentStr()

    br_print (indentstring + "//////////////////////////////////////////////")
    if (thisBorderFlagY & BorderTypeBottom()):
      br_print (indentstring + "// process bottom horizontal band")
    else:
      br_print (indentstring + "// process top/middle horizontal band")

    thisSpanWidth = xSpanList[0]
    thisBlockWidth = xSpanList[1]

    if (thisBlockHeight == 0):
      blockNumberY = 1
    else:
      blockNumberY = int (thisSpanHeight / thisBlockHeight)

    if (thisBlockWidth == 0):
      blockNumberX = 1
    else:
      blockNumberX = int (thisSpanWidth / thisBlockWidth)

    if (blockNumberY > 1):
      flowHandler.startForLoop(str(0), str(blockNumberY), str(1), -1, "loop y")
      indentstring = flowHandler.getIndentStr()

    blockLoopNumber = blockNumberX - 3
    blockLoopNumber >>= 1

    if (blockLoopNumber < 0):
      blockLoopNumber = 0

    blockRemainNumber = blockNumberX - (blockLoopNumber << 1)

    br_print (indentstring + "// block number = " + str(blockNumberX) + ", block remain number = " + str(blockRemainNumber))

    br_print (indentstring + "// initialize whenever switching to a new horizontal band")

    do_x_initialize(vgprStride, ySpan[1], ySpan[2], funcParameterMap, flowHandler)

    br_print (indentstring + "// finish initializing horizontal band")

    functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_load_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_1_"

    if (blockNumberX == 1):
      functionName += "1"
    else:
      functionName += "0"

    funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
    flowHandler.startFunctionCall(functionName)
    flowHandler.endFunctionCall()
    if (blockNumberX > 1):
      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_load_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_2"

      if (blockNumberX == 2):
        functionName = functionName + "_1"
      else:
        functionName = functionName + "_0"

      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

    funcLib.AlignPrint(indentstring + "nop.sc1", flowLib.GetCommentPos(), "// wait for sync channel 1")

    if (isFirstSub != 0):
      do_z_preprocess(funcParameterMap, flowHandler)

    br_print (indentstring)
    if (blockLoopNumber > 1):
      flowHandler.startForLoop(str(0), str(blockLoopNumber), str(1), -1, "loop x")
      indentstring = flowHandler.getIndentStr()

    if (blockLoopNumber > 0):
      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_alu_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_0"
      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_load_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_1_0"
      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

      funcLib.AlignPrint(indentstring + "nop.sc2", flowLib.GetCommentPos(), "// wait for sync channel 2")
      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_alu_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_0"
      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_load_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_2_0"
      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

      funcLib.AlignPrint(indentstring + "nop.sc1", flowLib.GetCommentPos(), "// wait for sync channel 1")

    if (blockLoopNumber > 1):
      flowHandler.closeForLoop(str(0), str(blockLoopNumber), str(1), -1)
      indentstring = flowHandler.getIndentStr()

    functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_alu_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_"
    if (blockNumberX == 1):
      functionName += "1"
    else:
      functionName += "0"
    funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
    flowHandler.startFunctionCall(functionName)
    flowHandler.endFunctionCall()

    if (blockRemainNumber >= 3):
      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_load_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_1"
      if (blockRemainNumber == 3):
        functionName = functionName + "_1"
      else:
        functionName = functionName + "_0"
      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

    if (blockNumberX > 1):
      funcLib.AlignPrint(indentstring + "nop.sc2", flowLib.GetCommentPos(), "// wait for sync channel 2")
      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_alu_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight)

      if (blockNumberX == 2):
        functionName = functionName + "_1"
      else:
        functionName = functionName + "_0"

      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

      if (blockRemainNumber >= 4):
        functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_load_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_2_1"
        funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
        flowHandler.startFunctionCall(functionName)
        flowHandler.endFunctionCall()

      if (blockRemainNumber >= 3):
        funcLib.AlignPrint(indentstring + "nop.sc1", flowLib.GetCommentPos(), "// wait for sync channel 1")
        functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_alu_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight)
        if (blockRemainNumber == 3):
          functionName = functionName + "_1"
        else:
          functionName = functionName + "_0"
        funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
        flowHandler.startFunctionCall(functionName)
        flowHandler.endFunctionCall()

      if (blockRemainNumber >= 4):
        funcLib.AlignPrint(indentstring + "nop.sc2", flowLib.GetCommentPos(), "// wait for sync channel 2")
        functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_alu_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_1"
        funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
        flowHandler.startFunctionCall(functionName)
        flowHandler.endFunctionCall()

    if ((thisBorderFlagY & BorderTypeBottom()) == 0):
      br_print (indentstring + "// adjust y to next band")
      funcLib.AlignPrint(indentstring + "sadd " + yLoadSGPRStr + ", " + yLoadSGPRStr + ", " + str(thisBlockHeight * hwCaps.TileSizeY()), flowLib.GetCommentPos(), "// adjust load y")
      funcLib.AlignPrint(indentstring + "sadd " + yAluSGPRStr + ", " + yAluSGPRStr + ", " + str(thisBlockHeight * hwCaps.TileSizeY()), flowLib.GetCommentPos(), "// adjust alu y")

    if (blockNumberY > 1):
      flowHandler.closeForLoop(str(0), str(blockNumberY), str(1), -1)
      indentstring = flowHandler.getIndentStr()

    isFirstSub = 0

  if (wSize > 1):
    flowHandler.closeForLoop("", str(wSize), str(1), funcParameterMap["wSGPRIndex"])

  if funcParameterMap["zInnerSGPRIndex"] is not None: 
    flowHandler.closeForLoop("", str(flowHandler.inner_oc_loop[1]*flowHandler.inner_oc_loop[3]), str(flowHandler.inner_oc_loop[3]), funcParameterMap["zInnerSGPRIndex"])
  
    funcLib.AlignPrint(indentstring + "bar.tg.pass " + bn2reduceBarIdSGPRStr + ", 8", flowLib.GetCommentPos(), "// inform reduce to start next, TODO - what if no next?")
    funcLib.AlignPrint(indentstring + "sxor " + bn2reduceBarIdSGPRStr + ", " + bn2reduceBarIdSGPRStr + ", 1", flowLib.GetCommentPos(), "// toggle bn->reduce bar id")
    funcLib.AlignPrint(indentstring + "sxor " + reduce2bnBarIdSGPRStr + ", " + reduce2bnBarIdSGPRStr + ", 1", flowLib.GetCommentPos(), "// toggle reduce->bn bar id")
  
  if funcParameterMap["zOuterSGPRIndex"] is not None: 
    flowHandler.closeForLoop("", str(flowHandler.outer_oc_loop[1]*flowHandler.outer_oc_loop[3]), str(flowHandler.outer_oc_loop[3]), funcParameterMap["zOuterSGPRIndex"])
  
  if funcParameterMap["zInnerSGPRIndex"] is None and funcParameterMap["zOuterSGPRIndex"] is None:
    indentstring = flowHandler.getIndentStr()
    funcLib.AlignPrint(indentstring + "bar.tg.pass " + bn2reduceBarIdSGPRStr + ", 8", flowLib.GetCommentPos(), "// inform reduce to start next, TODO - what if no next?")
    funcLib.AlignPrint(indentstring + "sxor " + bn2reduceBarIdSGPRStr + ", " + bn2reduceBarIdSGPRStr + ", 1", flowLib.GetCommentPos(), "// toggle bn->reduce bar id")
    funcLib.AlignPrint(indentstring + "sxor " + reduce2bnBarIdSGPRStr + ", " + reduce2bnBarIdSGPRStr + ", 1", flowLib.GetCommentPos(), "// toggle reduce->bn bar id")
    flowHandler.closeForLoop("", str(surfaceTileInfo[1]), str(32), funcParameterMap["zSGPRIndex"])


####################################################
# set_vgpr_number
#   find out how many vgprs can be used as load buffer
#
def set_vgpr_number(warpId, vgprPartition, funcParameterMap):
  if (vgprPartition[1] <= vgprPartition[0]):
    assert False, "  no vgpr to use"

  vgprStart = vgprPartition[0]
  vgprNumber = vgprPartition[1] - vgprPartition[0]
  #2 indicates 2 more tlrs for gamma/beta/sum/ssq load
  vgprTempNumber = hwCaps.MaxLDMGranule() + 2

  if (vgprTempNumber < 8):
    # bn needs at least 6 vgprs
    vgprTempNumber = 8

  bnCoeffVGPRNumber = 2

  if (vgprNumber <= (vgprTempNumber + bnCoeffVGPRNumber)):
    assert False, "  not enough vgprs to hold temps"

  vgprTempStart = vgprStart
  funcParameterMap["vgprTempStart"] = vgprTempStart
  funcParameterMap["vgprTempNumber"] = vgprTempNumber

  vgprNumber -= vgprTempNumber
  vgprStart += vgprTempNumber

  #sldm gama/beta/sum/ssq
  #reuse [2, 10)allocated in temp
  vgprSldmNumber = 8 # 4 x 2 (two channels, hard code)
  funcParameterMap["vgprSldmNumber"] = vgprSldmNumber
  funcParameterMap["reduceResVGPRIndex"] = vgprTempStart + 2
  funcParameterMap["gammaDataVGPRIndex"] = vgprTempStart + 6

  funcParameterMap["bnCoeffVGPRAddr"] = vgprStart
  vgprNumber -= bnCoeffVGPRNumber
  vgprStart += bnCoeffVGPRNumber

  funcParameterMap["vgprIndexStart"] = vgprStart
  funcParameterMap["vgprNumber"] = vgprNumber


####################################################
# find out block size
#
def get_bn_block_size(ySize, xSize, vgprNumber):

  bufferNumber = 2

  vgprNumber = int (vgprNumber / bufferNumber)

  blockSizeY = math.floor(math.sqrt(vgprNumber))
  iteration = 0

  while (iteration < 2):
    if (blockSizeY > 8):
      blockSizeY = int (blockSizeY / hwCaps.MaxLoadGranule()) * hwCaps.MaxLoadGranule()

    if (blockSizeY > ySize):
      blockSizeY = ySize

    vgprStride = blockSizeY
    blockSizeX = math.floor (vgprNumber / vgprStride)

    refitY = 0

    if (blockSizeX > (xSize)):
      blockSizeX = xSize
      refitY = 1

    if (refitY == 0):
      break
    else:
      blockSizeY = math.floor(math.floor(vgprNumber / blockSizeX))
      iteration += 1

      if (blockSizeY > ySize):
        blockSizeY = ySize

    vgprStride = blockSizeY

  return (vgprStride, blockSizeY, blockSizeX)

####################################################


def get_bn_surface_partition(surfaceTileInfo, vgprNumber, borderType, indendString):

  ySize = surfaceTileInfo[2]
  xSize = surfaceTileInfo[3]

  (vgprStride, yUnit, xUnit) = get_bn_block_size(ySize, xSize, vgprNumber)

  if (yUnit == 0 or xUnit == 0):
    assert False, "  not enough vgprs, can't find a block that can fit " + str(vgprNumber) + " vgprs"

  partitionList = []

  yBottomFlag = borderType & (BorderTypeBottom() | BorderTypeBottomPartial())

  yAlignedSize = int (ySize / yUnit) * yUnit
  yRemainder = ySize - yAlignedSize

  ySpanList = []

  if (yAlignedSize != 0 and yRemainder == 0):
    yRemainder = yUnit
    yAlignedSize -= yUnit

  if (yAlignedSize != 0):
    ySpanList.append([yAlignedSize, yUnit, 0])

  ySpanList.append([yRemainder - 1, yRemainder - 1, 0])

  ySpanList[-1][2] |= yBottomFlag

  xBorderFlag = borderType & (BorderTypeRight() | BorderTypeRightPartial())

  xAlignedSize = int (xSize / xUnit) * xUnit
  partialBlockWidth = xSize - xAlignedSize

  if (partialBlockWidth == 0):
    partialBlockWidth = xUnit
  else:
    xAlignedSize += xUnit

  partialBlockWidth -= 1

  rightBorderBlockX = xAlignedSize - xUnit

  xSpanList = [xAlignedSize, xUnit, xBorderFlag]

  return ([vgprStride], ySpanList, xSpanList, [rightBorderBlockX * hwCaps.TileSizeX(), xUnit, partialBlockWidth])


####################################################
# set_surface_parameter
#   set surface related info such as border info, block width etc
#
def set_surface_parameter(warpId, funcParameterMap, surfaceTileInfo, surfacePartition, surfaceWidth):
  vgprStride = surfacePartition[0][0]

  fullBlockWidth = surfacePartition[3][1]
  fullHeight = surfacePartition[1][0][1]

  bufferGroupNumber = 2

  funcParameterMap["vgprStride"] = vgprStride

  funcParameterMap["rightBorderBlockX"] = surfacePartition[3][0]
  funcParameterMap["fullBlockWidth"] = fullBlockWidth
  funcParameterMap["partialBlockWidth"] = surfacePartition[3][2]

  vgprStepBack = fullBlockWidth * bufferGroupNumber * vgprStride
  vgprBufferSize = vgprStepBack + vgprStride

  funcParameterMap["vgprIndexEnd"] = funcParameterMap["vgprIndexStart"] + vgprBufferSize

  funcParameterMap["vgprStepBack"] = vgprStepBack


####################################################
# set_layer_parameter
#   set layer related info and other info
#
def set_layer_parameter(warpId, funcParameterMap, layerInfo, flowHandler):
  indentstring = flowHandler.getIndentStr()

  funcParameterMap["loadNextChannelWeight"] = 0

  optionsIndex = cwarp.GetOptionsIndex()

  uSharpIndex = cwarp.GetUSharpIndex()
  if flowHandler.enableRelu:
    uSharpIdList = [[layerInfo[uSharpIndex][0][usharp.GetSurfUsharpIDIndex()], layerInfo[uSharpIndex][1][usharp.GetSurfUsharpIDIndex()]], [layerInfo[uSharpIndex][2][usharp.GetSurfUsharpIDIndex()], layerInfo[uSharpIndex][-1][usharp.GetSurfUsharpIDIndex()]]]
  else:
    uSharpIdList = [[layerInfo[uSharpIndex][0][usharp.GetSurfUsharpIDIndex()], layerInfo[uSharpIndex][1][usharp.GetSurfUsharpIDIndex()]], [layerInfo[uSharpIndex][-1][usharp.GetSurfUsharpIDIndex()]]]

  funcParameterMap["uSharpIdList"] = uSharpIdList

  funcParameterMap["constBase"] = "a0"
  funcParameterMap["vgprBase"] = "a1"
  funcParameterMap["sgprBase"] = "a2"

  br_print (indentstring + "// sgpr usage:")
  surfaceChannel = funcParameterMap["surfaceChannel"]
  num_sgpr = 7 if surfaceChannel*2 < 128 else 8
  coordSGPRIndex = flowHandler.allocateSGPR(num_sgpr)
  funcParameterMap["zSGPRIndex"] = coordSGPRIndex + 4
  funcParameterMap["wSGPRIndex"] = coordSGPRIndex + 5
  funcParameterMap["xLoadSGPRStr"] = "q" + str(coordSGPRIndex)
  funcParameterMap["yLoadSGPRStr"] = "q" + str(coordSGPRIndex + 1)
  funcParameterMap["xAluSGPRStr"] = "q" + str(coordSGPRIndex + 2)
  funcParameterMap["yAluSGPRStr"] = "q" + str(coordSGPRIndex + 3)
  funcParameterMap["zSGPRStr"] = "q" + str(coordSGPRIndex + 4)
  funcParameterMap["wSGPRStr"] = "q" + str(coordSGPRIndex + 5)
  funcParameterMap["sldXSGPRStr"] = "q" + str(coordSGPRIndex + 6)
  if surfaceChannel*2 >= 128:
    funcParameterMap["maxSldXValue"] = "q" + str(coordSGPRIndex + 7)

  funcParameterMap["zOuterSGPRIndex"] = None
  if flowHandler.outer_oc_loop is not None:
      if flowHandler.outer_oc_loop[1] > 1:
        coordSGPRIndex = flowHandler.allocateSGPR(1)
        funcParameterMap["zOuterSGPRIndex"] = coordSGPRIndex

        funcParameterMap["zOuterSGPRStr"] = "q" + str(coordSGPRIndex)

  funcParameterMap["zInnerSGPRIndex"] = None
  if flowHandler.inner_oc_loop is not None:
      if flowHandler.inner_oc_loop[1] > 1:
        coordSGPRIndex = flowHandler.allocateSGPR(1)
        funcParameterMap["zInnerSGPRIndex"] = coordSGPRIndex
        funcParameterMap["zInnerSGPRStr"] = "q" + str(coordSGPRIndex)

  funcParameterMap["xSGPRStr"] = funcParameterMap["xLoadSGPRStr"]
  funcParameterMap["ySGPRStr"] = funcParameterMap["yLoadSGPRStr"]

  br_print (indentstring + "//   x/y/z/w at sgpr q" + str(coordSGPRIndex) + "-q" + str(coordSGPRIndex + 5))
  br_print (indentstring + "//     load x/y uses " + funcParameterMap["xLoadSGPRStr"] + " and " + funcParameterMap["yLoadSGPRStr"])
  br_print (indentstring + "//     alu  x/y uses " + funcParameterMap["xAluSGPRStr"] + " and " + funcParameterMap["yAluSGPRStr"])

  euIdSGPRIndex = flowHandler.allocateSGPR(1)
  euIdSGPRStr = "q" + str(euIdSGPRIndex)
  funcParameterMap["euIdSGPRStr"] = euIdSGPRStr
  br_print (indentstring + "//   unique eu id at sgpr " + euIdSGPRStr)

  surfaceWidth = layerInfo[uSharpIndex][0][usharp.GetSurfCoordXIndex()]
  surfaceHeight = layerInfo[uSharpIndex][0][usharp.GetSurfCoordYIndex()]

  newWeightSGPRIndex = flowHandler.allocateSGPR(1)
  newWeightSGPRStr = "q" + str(newWeightSGPRIndex)
  funcParameterMap["newWeightSGPRStr"] = newWeightSGPRStr
  br_print (indentstring + "//   new weight at sgpr " + newWeightSGPRStr + ", triggered when channel switches, to wbar sync for lddw and preprocess reduction coeff")

  funcParameterMap["reduceSurfaceCoeff"] = 1 / surfaceWidth / surfaceHeight

  #Todo: remove wsr use for gamma/beta/sum/ssq load
  gammaDataSGPRIndex = flowHandler.allocateSGPR(4)
  gammaDataSGPRStr = "q" + str(gammaDataSGPRIndex)
  funcParameterMap["gammaDataSGPRStr"] = gammaDataSGPRStr
  funcParameterMap["gammaDataSGPRIndex"] = gammaDataSGPRIndex
  br_print (indentstring + "//   gamma/beta data at sgpr " + gammaDataSGPRStr + "-" + str(gammaDataSGPRIndex + 3))

  reduceResSGPRIndex = flowHandler.allocateSGPR(4)
  reduceResultSGPRStr = "q" + str(reduceResSGPRIndex)
  funcParameterMap["reduceResultSGPRStr"] = reduceResultSGPRStr
  funcParameterMap["reduceResSGPRIndex"] = reduceResSGPRIndex
  br_print (indentstring + "//   reduce result at sgpr q" + str(reduceResSGPRIndex) + "-" + str(reduceResSGPRIndex + 3) + ", temporarily before befor moving to vgpr")

  reduce2bnBarIdSGPRIndex = flowHandler.allocateSGPR(2)
  reduce2bnBarIdSGPRStr = "q" + str(reduce2bnBarIdSGPRIndex)
  bn2reduceBarIdSGPRStr = "q" + str(reduce2bnBarIdSGPRIndex + 1)
  funcParameterMap["reduce2bnBarIdSGPRStr"] = reduce2bnBarIdSGPRStr
  funcParameterMap["bn2reduceBarIdSGPRStr"] = bn2reduceBarIdSGPRStr
  br_print (indentstring + "//   channel sync bar id at sgpr " + reduce2bnBarIdSGPRStr + " and " + bn2reduceBarIdSGPRStr)
  br_print (indentstring + "//     reduce->bn uses 2 bars, from " + str(cwarp.GetReduce2BNSyncBarId()) + ", id at " + reduce2bnBarIdSGPRStr)
  br_print (indentstring + "//     bn->reduce uses 2 bars, from " + str(cwarp.GetBN2ReduceSyncBarId()) + ", id at " + bn2reduceBarIdSGPRStr)

  vgprBaseSGPRIndex = flowHandler.allocateSGPR(2)
  vgprLoadBaseSGPRStr = "q" + str(vgprBaseSGPRIndex)
  vgprAluBaseSGPRStr = "q" + str(vgprBaseSGPRIndex + 1)
  funcParameterMap["vgprLoadBaseSGPRStr"] = vgprLoadBaseSGPRStr
  funcParameterMap["vgprAluBaseSGPRStr"] = vgprAluBaseSGPRStr
  br_print (indentstring + "//   vgpr base at sgpr " + vgprLoadBaseSGPRStr + " and " + vgprAluBaseSGPRStr)
  br_print (indentstring + "//     load uses " + vgprLoadBaseSGPRStr)
  br_print (indentstring + "//     alu uses " + vgprAluBaseSGPRStr)

  funcParameterMap["imageWidthRes"] = surfaceWidth & (hwCaps.TileSizeX() - 1)
  funcParameterMap["imageHeightRes"] = surfaceHeight & (hwCaps.TileSizeY() - 1)

  vgprTempStart = funcParameterMap["vgprTempStart"]
  vgprTempNumber = funcParameterMap["vgprTempNumber"]
  vgprStart = funcParameterMap["vgprIndexStart"]
  vgprNumber = funcParameterMap["vgprNumber"]
  bnCoeffVGPRAddr = funcParameterMap["bnCoeffVGPRAddr"]

  gammaDataVGPRIndex = funcParameterMap["gammaDataVGPRIndex"]
  reduceResVGPRIndex = funcParameterMap["reduceResVGPRIndex"]
  vgprSldmNumber = funcParameterMap["vgprSldmNumber"]

  br_print (indentstring + "// vgpr usage:")
  br_print (indentstring + "//   temp will use vgpr[" + str(vgprTempStart) + ", " + str(vgprTempStart + vgprTempNumber) + ")")
  br_print(indentstring + "//   sldm(sum/ssq) will use vgpr[" + str(reduceResVGPRIndex) + ", " + str(reduceResVGPRIndex + 4) + ")")
  br_print(indentstring + "//   sldm(gamma/beta) will use vgpr[" + str(gammaDataVGPRIndex) + ", " + str(gammaDataVGPRIndex + 4) + ")")
  br_print (indentstring + "//   bn coeff will use vgpr[" + str(bnCoeffVGPRAddr) + ", " + str(vgprStart) + ")")
  br_print (indentstring + "//   load data will use vgpr[" + str(vgprStart) + ", " + str(vgprStart + vgprNumber) + ")")

####################################################
# gen_kernel_sub_function
#   generate sub functions that will be called


def gen_kernel_sub_function(funcDefMap, funcParaDict):
  flowHandler = flowLib.FlowHandler("", 0, 0, compiler.GetASMMode())

  for x, y in funcDefMap.items():
    funcKeys = x.split("_")

    flowHandler.startFunctionDef(x, 1)
    flowHandler.setLabelIndex(0)
    flowHandler.setLabelSuffix(x.upper())
    flowHandler.setQTempStart(y[0])
    flowHandler.setQStackStart(y[1])

    if (funcKeys[5] == "load"):
      funcType = 0
    else:
      funcType = 1

    yBorderType = int (funcKeys[6])
    blockHeight = int (funcKeys[7])

    if (funcType == 0):
      syncIndex = int (funcKeys[8])
      rightBorderMode = int (funcKeys[9])
    else:
      syncIndex = 0
      rightBorderMode = int (funcKeys[8])

    gen_bn_sub_function(funcType, yBorderType, blockHeight, rightBorderMode, syncIndex, funcParaDict, flowHandler)

    flowHandler.closeFunctionDef(x, 1)


####################################################
#
def gen_layer_main_kernel(layerId, layerNumber, warpId, layerInfo, flowHandler):

  cmdIndex = cwarp.GetCMDIndex()

  if (layerInfo[cmdIndex] != "bn"):
    assert False, "unsupported op " + layerInfo[cmdIndex]
    return

  layer_prefix = ["layer_{}_warp_{}_main_kernel", "warp_{}_main_kernel"]
  if layerId is not None:
      layer_label = layer_prefix[0].format(str(layerId), str(warpId))
  else:
      layer_label = layer_prefix[1].format(str(warpId))

  flowHandler.startFunctionDef(layer_label, 0)
  indentstring = flowHandler.getIndentStr()

  funcGenHandler = funcgen.FuncGenHandler()
  funcParameterMap = {}

  flowHandler.setLabelSuffix(layer_label)

  br_print (indentstring + "// TODO bar unit")
  br_print (indentstring + "// TODO not enough loop in z dimension")

  uSharpIndex = cwarp.GetUSharpIndex()
  optionsIndex = cwarp.GetOptionsIndex()

  surfaceSample = layerInfo[uSharpIndex][0][usharp.GetSurfCoordSampleIndex()]
  surfaceChannel = layerInfo[uSharpIndex][0][usharp.GetSurfCoordChannelIndex()]
  surfaceHeight = layerInfo[uSharpIndex][0][usharp.GetSurfCoordYIndex()]
  surfaceWidth = layerInfo[uSharpIndex][0][usharp.GetSurfCoordXIndex()]

  br_print (indentstring + "// layer info:")
  br_print (indentstring + "//   op            - :" + layerInfo[cmdIndex])
  br_print (indentstring + "//   surface       - sample : " + str(surfaceSample) + ", channel: " + str(surfaceChannel) + ", height: " + str(surfaceHeight) + ", width: " + str(surfaceWidth))

  funcParameterMap["surfaceChannel"] = surfaceChannel

  kernelLib.PrintUSharpList(layerInfo[uSharpIndex], indentstring)

  vgprPartitionIndex = cwarp.GetVGPRPartitionIndex()

  set_vgpr_number(warpId, layerInfo[vgprPartitionIndex], funcParameterMap)

  borderType = BorderTypeAll()

  tileNumberX = int ((surfaceWidth + hwCaps.TileSizeX() - 1) / hwCaps.TileSizeX())
  tileNumberY = int ((surfaceHeight + hwCaps.TileSizeY() - 1) / hwCaps.TileSizeY())

  if (surfaceHeight % hwCaps.TileSizeY()):
    borderType |= BorderTypeBottomPartial()

  if (surfaceWidth % hwCaps.TileSizeX()):
    borderType |= BorderTypeRightPartial()

  vgprNumber = funcParameterMap["vgprNumber"]

  surfaceTileInfo = [surfaceSample, surfaceChannel, tileNumberY, tileNumberX]

  surfacePartition = get_bn_surface_partition(surfaceTileInfo, vgprNumber, borderType, flowHandler.getIndentStr())

  set_surface_parameter(warpId, funcParameterMap, surfaceTileInfo, surfacePartition, surfaceWidth)

  set_layer_parameter(warpId, funcParameterMap, layerInfo, flowHandler)

  indentstring = flowHandler.getIndentStr()

  br_print (indentstring + "// tile info:")
  br_print (indentstring + "//   tile number y = " + str(tileNumberY) + ", tile number x = " + str(tileNumberX))
  br_print (indentstring)

  br_print (indentstring + "// start preprocessing")
  br_print (indentstring)

  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "//  " + layerInfo[cwarp.GetCMDIndex()] + " parition :")

  vgprStride = surfacePartition[0][0]
  br_print (indentstring + "//    vgprStride: " + str(surfacePartition[0][0]))
  br_print (indentstring + "//    buffer numbers: 2")

  br_print (indentstring + "//    y dir partition (last row is not counted, as it needs special handling):")
  for thisSpan in surfacePartition[1]:
    br_print (indentstring + "//      height: " + str(thisSpan[0]) + ", step: " + str(thisSpan[1]) + ", border: " + str(thisSpan[2]))

  thisSpan = surfacePartition[2]
  br_print (indentstring + "//    x dir partition (last col is not counted in partial block width, as it needs special handling):")
  br_print (indentstring + "//      width:  " + str(thisSpan[0]) + ", step: " + str(thisSpan[1]) + ", border: " + str(thisSpan[2]))

  thisSpan = surfacePartition[3]
  br_print (indentstring + "//      x border block pos: " + str(thisSpan[0]))
  br_print (indentstring + "//      partial block width: " + str(thisSpan[2]))

  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "// start bn")
  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring)

  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "// initialize relative addr")
  funcLib.AlignPrint(indentstring + "smovs up0, " + str(funcParameterMap["vgprIndexEnd"]), flowLib.GetCommentPos(), "// set relative addr upper bound")
  funcLib.AlignPrint(indentstring + "smovs sz0, " + str(funcParameterMap["vgprStepBack"]), flowLib.GetCommentPos(), "// set relative addr range")
  br_print (indentstring)

  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "// initialize bar")

  bn2reduceBarIdSGPRStr = funcParameterMap["bn2reduceBarIdSGPRStr"]
  reduce2bnBarIdSGPRStr = funcParameterMap["reduce2bnBarIdSGPRStr"]
  funcLib.AlignPrint(indentstring + "smov " + reduce2bnBarIdSGPRStr + ", " + str(bcd.VECTOR_PINGPONG_REDUCE_TO_BN_BAR_ID_1), flowLib.GetCommentPos(), "// set reduce->bn bar id")
  funcLib.AlignPrint(indentstring + "smov " + bn2reduceBarIdSGPRStr + ", " + str(bcd.VECTOR_PINGPONG_BN_TO_REDUCE_BAR_ID_1), flowLib.GetCommentPos(), "// set bn->reduce bar id")
  # funcLib.AlignPrint(indentstring + "bar.tg.pass " + str(cwarp.GetBN2ReduceSyncBarId()) + ", 8", flowLib.GetCommentPos(), "// initialize bn->reduce bar so reduce could start")
  # funcLib.AlignPrint(indentstring + "bar.tg.pass " + str(cwarp.GetBN2ReduceSyncBarId()+1) + ", 8", flowLib.GetCommentPos(), "// initialize bn->reduce bar so reduce could start")

  # br_print (indentstring)

  # [Arthur Duan] eu0 takes channel 0/1, eu1 takes channel 2/3 etc, 16 eus can take
  # this channel pairs without conflict.
  zSGPRStr = funcParameterMap["zSGPRStr"]

  euIdSGPRStr = funcParameterMap["euIdSGPRStr"]
  br_print (indentstring + "sysid.work " + euIdSGPRStr)
  funcLib.AlignPrint(indentstring + "sand " + euIdSGPRStr + ", " + euIdSGPRStr + ", 0xf", flowLib.GetCommentPos(), "// obtain unique eu id")
  if funcParameterMap["zInnerSGPRIndex"] is not None:
    funcLib.AlignPrint(indentstring + "sshl " + funcParameterMap["zInnerSGPRStr"] + ", " + euIdSGPRStr + ", 1", flowLib.GetCommentPos(), "// initialize z with channel pair start")
  else:
    funcLib.AlignPrint(indentstring + "sshl " + zSGPRStr + ", " + euIdSGPRStr + ", 1", flowLib.GetCommentPos(), "// initialize z with channel pair start")
  
  vgprBaseStr = funcParameterMap["vgprBase"]
  vgprIndexStart = funcParameterMap["vgprIndexStart"]
  funcLib.AlignPrint(indentstring + "smovs " + vgprBaseStr + ", " + str(vgprIndexStart), flowLib.GetCommentPos(), "// initialize vgpr base a1")
  funcLib.AlignPrint(indentstring + "smov " + funcParameterMap["vgprLoadBaseSGPRStr"] + ", " + str(vgprIndexStart), flowLib.GetCommentPos(), "// initialize load vgpr base")
  funcLib.AlignPrint(indentstring + "smov " + funcParameterMap["vgprAluBaseSGPRStr"] + ", " + str(vgprIndexStart), flowLib.GetCommentPos(), "// initialize alu vgpr base")

  bn_kernel_process_channel_group(layerId, warpId, surfaceTileInfo, surfacePartition, funcParameterMap, funcGenHandler, flowHandler)

  if (funcParameterMap["loadNextChannelWeight"] != 0):
    br_print (indentstring + "// load weight for next channel group, now clear sync channel")
    flowHandler.startIfLoop(euIdSGPRStr, str(0), "==", 0)
    indentstring = flowHandler.getIndentStr()
    br_print (indentstring + "nop.sc1")
    flowHandler.closeIfLoop()
    indentstring = flowHandler.getIndentStr()

  if flowHandler.force_ackgmb:
    funcLib.AlignPrint(indentstring + "ackgmb ", flowLib.GetCommentPos(), "// ensure the kernel done")
  if flowHandler.sync_layer:
    funcLib.AlignPrint(indentstring + "bar.wtg.pass 1, 17", flowLib.GetCommentPos(), "// inform next conv layer to start")

  if (layerNumber is not None) and (layerNumber > 1):
    kernelLib.jump_to_next_layer(layerId, layerNumber, warpId, indentstring)

  flowHandler.closeFunctionDef("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel", 0)

  gen_kernel_sub_function(funcGenHandler.getFuncDef(), funcParameterMap)

