#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.


import sys
import os
import math

import code_generator.vector.common.hwCaps as hwCaps
import code_generator.vector.common.flowLib as flowLib
import code_generator.vector.common.cwarp as cwarp
import code_generator.vector.common.funcgen as funcgen
import code_generator.vector.common.funcLib as funcLib
import code_generator.vector.common.kernelLib as kernelLib
import code_generator.vector.common.compiler as compiler
import code_generator.vector.common.usharp as usharp

from code_generator.share.br_defined_print import br_print


####################################################
#
#

####################################################
#
def get_row_parition(rowNumber):
  # how many rows each EU get each time
  rowStep = 64
  groupNumber = 1
  euNumber = 16

  if (rowNumber < rowStep * 15):
    rowStep = ((((rowNumber + 1) >> 1) + euNumber - 1) >> 4) << 1

    if (rowStep == 0):
      rowStep = 2

    euNumber = int ((rowNumber + rowStep - 1) / rowStep)
  else:
    groupNumber = int ((rowNumber + (rowStep * euNumber) - 1) / (rowStep * euNumber))
    if (groupNumber == 1):
      if rowNumber < rowStep * euNumber:
        euNumber = int ((rowNumber + rowStep - 1) / rowStep)

  if (rowNumber == groupNumber * euNumber * rowStep):
    aligned = 1
  else:
    aligned = 0

  return (groupNumber, euNumber, rowStep, aligned)




################################################################################################################
#
# matrix * vector
#
# load all data of vector to vgpr,
#   if vector is 1D, each lane has 1 fp16 element, duplicate 2 times
#   if vector is 3d activation, each lane has 2 fp16, and will be expanded at run time
# split matrix's rows among EUs
#   each time loads 2 rows, dpn
#   in the end, store 2 fp16 (only 1 lane)


def	gen_matrix_vector(usharpList, optionList, funcParameterMap, flowHandler):
  # [0, hwCaps.SurfaceType4DWeight(),    500, 20, 10,  10, "input, 4D weight, order is row, channel, height, width, channel/height/width are packed into col"],
  # [1, hwCaps.SurfaceType3DActivation(),  1, 20, 10,  10, "input, 3D activation, order is 1, channel, height, width, origin is previous layer's output, from hbm"],
  # [2, hwCaps.SurfaceType1DVector(),      1,  1,  1, 500, "input, 1D vector, bias"],
  # [3, hwCaps.SurfaceType1DVector(),      1,  1,  1, 500, "output, 1D vector, fc output, also serve as input to softmax"],


  indentstring = flowHandler.getIndentStr()
  br_print(indentstring + "// TODO")
  br_print(indentstring + "// 1. if activation size can't fit in vgpr")
  br_print(indentstring + "// 2. if weight size is too big, need to split into groups to hide load latency")
  br_print(indentstring)

  br_print(indentstring + "// fc usharp info")
  br_print(indentstring + "// U#id         Type     O     D     H     W  Note")
  for usharp in usharpList:
    br_print(indentstring + "// " + "{:3d}".format(usharp[0]) + ", " + hwCaps.GetSurfaceType(usharp[1]) + ",{:5d}".format(usharp[2]) + ",{:5d}".format(usharp[3]) + ",{:5d}".format(usharp[4]) + ",{:5d}".format(usharp[5]) + ", " + usharp[6])

  ###############################################
  # options
  bAddBias = 0

  matrixUSharpIndex = 0
  vectorUSharpIndex = 1
  biasUSharpIndex = 2
  resultUSharpIndex = 3

  vectorInputFormat = hwCaps.SurfaceFormatFP16()
  matrixInputFormat = hwCaps.SurfaceFormatFP16()
  resultOutputFormat = hwCaps.SurfaceFormatFP16()

  laneIdVGPRStr = funcParameterMap["laneIdVGPRStr"]
  addressVGPRStr = funcParameterMap["addressVGPRStr"]

  euIDSGPRStr = funcParameterMap["euIDSGPRStr"]
  vgprBaseSGPRStr = funcParameterMap["vgprBaseSGPRStr"]

  zSGPRStr = funcParameterMap["zSGPRStr"]

  coordSGPRStrList = (funcParameterMap["xSGPRStr"], funcParameterMap["ySGPRStr"], funcParameterMap["zSGPRStr"], funcParameterMap["wSGPRStr"])

  if (usharpList[vectorUSharpIndex][1] == hwCaps.SurfaceType3DActivation()):
    activationSpatialTileX = int ((usharpList[vectorUSharpIndex][5] + hwCaps.TileSizeX() - 1) / hwCaps.TileSizeX())
    activationSpatialTileY = int ((usharpList[vectorUSharpIndex][4] + hwCaps.TileSizeY() - 1) / hwCaps.TileSizeY())
    activationChannelPair = (usharpList[vectorUSharpIndex][3] + 1) >> 1
    activationVGPRNumber = activationSpatialTileX * activationSpatialTileY * activationChannelPair
    activationVGPRGroupSize = activationSpatialTileX * activationSpatialTileY
  else:
    activationVGPRNumber = int ((usharpList[vectorUSharpIndex][5] + 32 - 1) / 32)
    activationChannelPair = 1
    activationVGPRGroupSize = activationVGPRNumber


  if (usharpList[matrixUSharpIndex][1] == hwCaps.SurfaceType4DWeight()):
    weightRowNumber = usharpList[matrixUSharpIndex][2]
    weightSpatialTileX = int ((usharpList[matrixUSharpIndex][5] + hwCaps.TileSizeX() - 1) / hwCaps.TileSizeX())
    weightSpatialTileY = int ((usharpList[matrixUSharpIndex][4] + hwCaps.TileSizeY() - 1) / hwCaps.TileSizeY()) << 1
    weightVGPRNumber = weightSpatialTileX * weightSpatialTileY
  else:
    weightVGPRNumber = int ((usharpList[vectorUSharpIndex][5] + 32 - 1) / 32)
    weightRowNumber = usharpList[matrixUSharpIndex][4]

  rowIndexSGPRIndex = flowHandler.allocateSGPR(1)
  rowIndexSGPRStr = "q" + str(rowIndexSGPRIndex)

  colIndexSGPRIndex = flowHandler.allocateSGPR(1)
  colIndexSGPRStr = "q" + str(colIndexSGPRIndex)

  (groupNumber, euNumber, rowStep, aligned) = get_row_parition(weightRowNumber)

  br_print(indentstring)
  br_print(indentstring + "// row step        : " + str(rowStep) + " (how many rows each EU handles each time)")
  br_print(indentstring + "// number of eus   : " + str(euNumber) + " (how many eus will be used)")
  br_print(indentstring + "// number of groups: " + str(groupNumber) + " (how many iterations)")
  br_print(indentstring + "// aligned         : " + str(aligned) + " (whether rows are evenly distributed")

  br_print(indentstring + "// allocate " + "{:3d}".format(activationVGPRNumber) + " vgprs to hold activation")
  activationVGPRAddr = flowHandler.allocateVGPR(activationVGPRNumber)

  br_print(indentstring + "// allocate " + "{:3d}".format(weightVGPRNumber) + " vgprs to hold a channel pair of weight")
  weightVGPRAddr = flowHandler.allocateVGPR(weightVGPRNumber)

  # hold two rows' accumulate result
  accumulateVGPRNumber = 2
  br_print(indentstring + "// allocate " + "{:3d}".format(accumulateVGPRNumber) + " vgprs to hold accumulate result")
  accumulateVGPRAddr = flowHandler.allocateVGPR(accumulateVGPRNumber)

  outputVGPRNumber = 1
  br_print(indentstring + "// allocate " + "{:3d}".format(outputVGPRNumber) + " vgprs to hold output result -- obsolete")
  outputVGPRAddr = flowHandler.allocateVGPR(outputVGPRNumber)

  # to expand and replicae activation
  tempVGPRNumber = 8
  br_print(indentstring + "// allocate " + "{:3d}".format(tempVGPRNumber) + " vgprs for temp use")
  tempVGPRAddr = flowHandler.allocateVGPR(tempVGPRNumber)

  if (bAddBias):
    br_print(indentstring + "// allocate " + "{:3d}".format(1) + " vgprs for bias")
    biasVGPRAddr = flowHandler.allocateVGPR(1)

  groupLoopEndStr = str(groupNumber)
  rowIndexEndStr  = str(weightRowNumber)
  tempVGPRStr     = "r" + str(tempVGPRAddr)

  br_print(indentstring)
  funcLib.AlignPrint(indentstring + "sysid.work q0", flowLib.GetCommentPos(), "");
  funcLib.AlignPrint(indentstring + "sand " + euIDSGPRStr + ", q0, 0xf", flowLib.GetCommentPos(), "// obtain unique cu_eu id");

  br_print(indentstring)
  br_print(indentstring + "// load activation")

  if (usharpList[vectorUSharpIndex][1] == hwCaps.SurfaceType3DActivation()):
    br_print(indentstring + "smov " + vgprBaseSGPRStr + ", " + str(activationVGPRAddr))
    br_print(indentstring + "smov " + coordSGPRStrList[0] + ", 0")
    br_print(indentstring + "smov " + coordSGPRStrList[1] + ", 0")
    br_print(indentstring + "smov " + coordSGPRStrList[2] + ", 0")
    br_print(indentstring + "smov " + coordSGPRStrList[3] + ", 0")
    flowHandler.startForLoop("0", str(activationChannelPair), "1", -1, "")
    indentstring = flowHandler.getIndentStr()
    br_print(indentstring + "smovs a1, " + vgprBaseSGPRStr)

    for z in range (activationSpatialTileX):
      kernelLib.load_4d_activation(vectorInputFormat, hwCaps.SurfaceFormatFP16(), coordSGPRStrList, -1, activationSpatialTileY, 1, usharpList[vectorUSharpIndex][0], indentstring)
      br_print(indentstring + "sadd " + coordSGPRStrList[0] + ", " + coordSGPRStrList[0] + ", " + str(hwCaps.TileSizeX()))

    br_print(indentstring + "sadd " + zSGPRStr + ", " + zSGPRStr + ", 2")
    br_print(indentstring + "sadd " + vgprBaseSGPRStr + ", " + vgprBaseSGPRStr + ", " + str(activationSpatialTileX * activationSpatialTileY))
    flowHandler.closeForLoop("0", str(activationChannelPair), "1", -1)
    indentstring = flowHandler.getIndentStr()
  else:
    funcLib.AlignPrint(indentstring + "and " + addressVGPRStr + ", " + laneIdVGPRStr + ", 0x1f", flowLib.GetCommentPos(), "// get element index of each lane, assume r0 is lane id")
    kernelLib.load_1d_vector(vectorInputFormat, hwCaps.SurfaceFormatFP32(), addressVGPRStr, 32, activationVGPRAddr, activationVGPRNumber, 1, usharpList[vectorUSharpIndex][0], indentstring)

    br_print(indentstring)
    br_print(indentstring + "// convert to fp16, replicate 2 times in each lane")
    #sizeList = funcLib.SplitRepeatIntoGroups(activationVGPRNumber, hwCaps.MaxMovGranule())
    thisVGPRAddr = activationVGPRAddr
    syncStr = ".sc1"
    for x in range(activationVGPRNumber):
      br_print(indentstring + "mov.v2" + syncStr + " r" + str(activationVGPRAddr + x) + ".f16, r" + str(activationVGPRAddr + x) + ".f32")
      syncStr = ""

  br_print(indentstring)
  br_print(indentstring + "// initialize accumlate result")
  br_print(indentstring + "movi.v2 r" + str(accumulateVGPRAddr) + ".f32, 0.0")

  br_print(indentstring)
  br_print(indentstring + "// load weight")
  br_print(indentstring + "// calculate start row index for each EU based on eu id")

  if (rowStep == funcLib.AlignToPower2(rowStep)):
    funcLib.AlignPrint(indentstring + "sshl " + rowIndexSGPRStr + ", " + euIDSGPRStr + ", " + str(funcLib.GetLeadingOnePos(rowStep)), flowLib.GetCommentPos(), "// calculate start row index for each EU based on eu id")
  else:
    funcLib.AlignPrint(indentstring + "mov " + tempVGPRStr + ".u32, " + euIDSGPRStr + ".u32", flowLib.GetCommentPos(), "// move euid to vgpr as there is no mul in scalar unit")
    funcLib.AlignPrint(indentstring + "mulu.b32 " + tempVGPRStr + ", " + euIDSGPRStr + ", " + str(rowStep), flowLib.GetCommentPos(), "// calculate start row index for each EU based on eu id")
    funcLib.AlignPrint(indentstring + "mov " + rowIndexSGPRStr + ".u32, " + tempVGPRStr + ".u32", flowLib.GetCommentPos(), "// move back to sgpr")

  if (groupNumber > 1):
    flowHandler.startForLoop("0", groupLoopEndStr, "1", -1, "")
    indentstring = flowHandler.getIndentStr()

  if (euNumber < 16):
    flowHandler.startIfLoop(euIDSGPRStr, str(euNumber), "<", 0)
    indentstring = flowHandler.getIndentStr()

  if (rowStep > 2):
    br_print(indentstring + "// each iteration handles 2 rows, for simplicity")
    flowHandler.startForLoop("0", str(rowStep), "2", -1, "")
    indentstring = flowHandler.getIndentStr()

  if (aligned == 0):
    br_print(indentstring + "// row number can't be evenly distributed among EUs, so check at here")
    flowHandler.startIfLoop(rowIndexSGPRStr, rowIndexEndStr, "<", 0)
    indentstring = flowHandler.getIndentStr()

  funcLib.AlignPrint(indentstring + "smovs a1, " + str(activationVGPRAddr), flowLib.GetCommentPos(), "// set vgpr base")
  funcLib.AlignPrint(indentstring + "smov " + colIndexSGPRStr + ", 0", flowLib.GetCommentPos(), "// init col index")

  if (bAddBias):
    br_print(indentstring)
    br_print(indentstring + "// load 1 bias pair, 32b")
    funcLib.AlignPrint(indentstring + "mov r" + str(tempVGPRAddr) + ".u32, " + rowIndexSGPRStr + ".u32", flowLib.GetCommentPos(), "// row index")
    br_print(indentstring + "ld.m1d.float.mb16.rb16.sc1.e2.gc1 r" + str(biasVGPRAddr) + ", g0, u" + str(usharpList[biasUSharpIndex][0]))
    br_print(indentstring + "mov.eog g0.u32, r" + str(tempVGPRAddr) + ".u32")

  br_print(indentstring)
  if (activationChannelPair > 1):
    br_print(indentstring + "// handle an activation pair each iteration")
    flowHandler.startForLoop("0", str(activationChannelPair), "1", -1, "")
    indentstring = flowHandler.getIndentStr()

  # load weight
  kernelLib.load_2d_weight(matrixInputFormat, hwCaps.SurfaceFormatFP16(), rowIndexSGPRStr, colIndexSGPRStr, weightVGPRAddr, weightVGPRNumber, 0, 1, usharpList[matrixUSharpIndex][0], indentstring)

  # mul and accumulate
  thisActivationAddr = 0
  thisWeightAddr = weightVGPRAddr
  if (usharpList[vectorUSharpIndex][1] == hwCaps.SurfaceType3DActivation()):
    ###############################################
    # for activation, each element has 2 channels, expand so that each channel takes 1 vgpr

    for x in range(activationVGPRGroupSize):
      if (x == 0):
        funcLib.AlignPrint(indentstring + "mov.sc1 r" + str(tempVGPRAddr) + ".f32, ir" + str(thisActivationAddr) + ".f16", flowLib.GetCommentPos(), "// expand row 0 and row 1 to different tlr")
        funcLib.AlignPrint(indentstring + "mov.v2 r" + str(tempVGPRAddr) + ".f16, r" + str(tempVGPRAddr) + ".f32", flowLib.GetCommentPos(), "// replicate row 0")
        funcLib.AlignPrint(indentstring + "mov.v2 r" + str(tempVGPRAddr+1) + ".f16, r" + str(tempVGPRAddr+1) + ".f32", flowLib.GetCommentPos(), "// replicate row 1")
      else:
        br_print(indentstring + "mov r" + str(tempVGPRAddr) + ".f32, ir" + str(thisActivationAddr) + ".f16")
        br_print(indentstring + "mov.v2 r" + str(tempVGPRAddr) + ".f16, r" + str(tempVGPRAddr) + ".f32")
        br_print(indentstring + "mov.v2 r" + str(tempVGPRAddr+1) + ".f16, r" + str(tempVGPRAddr+1) + ".f32")

      br_print(indentstring + "fmac.b16.wd r" + str(accumulateVGPRAddr) + ", r" + str(thisWeightAddr) + ", r" + str(tempVGPRAddr))
      br_print(indentstring + "fmac.b16.wd r" + str(accumulateVGPRAddr) + ", r" + str(thisWeightAddr+1) + ", r" + str(tempVGPRAddr+1))
      thisActivationAddr += 1
      thisWeightAddr += 2

    funcLib.AlignPrint(indentstring + "sadda a1, a1, " + str(activationVGPRGroupSize), flowLib.GetCommentPos(), "// advance in activation")

  else:
    for x in range(activationVGPRGroupSize):
      if (x == 0):
        br_print(indentstring + "fmac.sc1.b16.wd r" + str(accumulateVGPRAddr) + ", r" + str(thisWeightAddr) + ", r" + str(tempVGPRAddr))
      else:
        br_print(indentstring + "fmac.b16.wd r" + str(accumulateVGPRAddr) + ", r" + str(thisWeightAddr) + ", r" + str(tempVGPRAddr))
      thisActivationAddr += 1
      thisWeightAddr += 1

  if (activationChannelPair > 1):
    flowHandler.closeForLoop("0", str(activationChannelPair), "1", -1)
    indentstring = flowHandler.getIndentStr()

  if (aligned == 0):
    flowHandler.closeIfLoop()
    indentstring = flowHandler.getIndentStr()


  #funcLib.AlignPrint(indentstring + "fadd r" + str(accumulateVGPRAddr) + ", r" + str(accumulateVGPRAddr) + ", r" + str(accumulateVGPRAddr + 1), flowLib.GetCommentPos(), "// add row 0 and row 1")
  br_print(indentstring)
  br_print(indentstring + "// butterfly sum within 2 tlrs, each row has its own tlr")

  kernelLib.butterfly_sum(accumulateVGPRAddr, 2, tempVGPRAddr, 32, indentstring)

  if (resultOutputFormat == hwCaps.SurfaceFormatFP16()):
    lsFormatStr = ".mb16.rb16"
    br_print(indentstring)
    funcLib.AlignPrint(indentstring + "mov.v2 r" + str(accumulateVGPRAddr) + ".f16, r" + str(accumulateVGPRAddr) + ".a.f32", flowLib.GetCommentPos(), "// convert fp32 to bf20 and pack together")

    if (bAddBias):
      funcLib.AlignPrint(indentstring + "fadd.b16 r" + str(accumulateVGPRAddr) + ", r" + str(accumulateVGPRAddr) + ", r" + str(biasVGPRAddr), flowLib.GetCommentPos(), "// add bias")
  else:
    lsFormatStr = ".mb32.rb32"
    if (bAddBias):
      funcLib.AlignPrint(indentstring + "mov r" + str(tempVGPRAddr) + ".f32, r" + str(biasVGPRAddr) + ".f16", flowLib.GetCommentPos(), "// expand bias to fp32")
      funcLib.AlignPrint(indentstring + "fadd.b32.v2 r" + str(accumulateVGPRAddr) + ", r" + str(accumulateVGPRAddr) + ".a, r" + str(tempVGPRAddr), flowLib.GetCommentPos(), "// add bias")

  br_print(indentstring)
  br_print(indentstring + "// output 1 lane")
  br_print(indentstring + "// could shuffle 64 rows into 1 tlr and output once")
  funcLib.AlignPrint(indentstring + "smovs wm0, 1", flowLib.GetCommentPos(), "// set m0 mask to lane 0")

  funcLib.AlignPrint(indentstring + "mov r" + str(tempVGPRAddr) + ".u32, " + rowIndexSGPRStr + ".u32", flowLib.GetCommentPos(), "// row index")

  if (resultOutputFormat == hwCaps.SurfaceFormatFP16()):
    funcLib.AlignPrint(indentstring + "st.m1d.float" + lsFormatStr + ".e2.gc2 g0, g1, " + str(usharpList[resultUSharpIndex][0]), flowLib.GetCommentPos(), "// store a lane")
    br_print(indentstring + "mov g0.u32, r" + str(tempVGPRAddr) + ".u32")
    br_print(indentstring + "mov.eog g1.f16, r" + str(accumulateVGPRAddr) + ".f16")
  else:
    funcLib.AlignPrint(indentstring + "st.m1d.float" + lsFormatStr + ".e2.gc3 g0, g1, " + str(usharpList[resultUSharpIndex][0]), flowLib.GetCommentPos(), "// store a lane")
    br_print(indentstring + "mov g0.u32, r" + str(tempVGPRAddr) + ".u32")
    br_print(indentstring + "mov.v2.eog g1.f32, r" + str(accumulateVGPRAddr) + ".a.f32")

  br_print(indentstring)
  funcLib.AlignPrint(indentstring + "sadd " + rowIndexSGPRStr + ", " + rowIndexSGPRStr + ", 2", flowLib.GetCommentPos(), "// move to next row pair")
  funcLib.AlignPrint(indentstring + "smovs wm0, 0xffffffff", flowLib.GetCommentPos(), "// reset m0 mask")

  if (rowStep > 2):
    flowHandler.closeForLoop("0", str(rowStep), "2", -1)
    indentstring = flowHandler.getIndentStr()
  else:
    pass

  if (euNumber < 16):
    flowHandler.closeIfLoop()
    indentstring = flowHandler.getIndentStr()

  if (groupNumber > 1):
    br_print(indentstring + "sadd " + rowIndexSGPRStr + ", " + rowIndexSGPRStr + ", " + str(rowStep * 15))
    flowHandler.closeForLoop("0", groupLoopEndStr, "1", -1)


  flowHandler.releaseVGPR(activationVGPRAddr)
  flowHandler.releaseVGPR(weightVGPRAddr)
  flowHandler.releaseVGPR(accumulateVGPRAddr)
  flowHandler.releaseVGPR(outputVGPRAddr)
  flowHandler.releaseVGPR(tempVGPRAddr)

  if (bAddBias):
    flowHandler.releaseVGPR(biasVGPRAddr)






####################################################
#  colGranule means how many cols we want to handle each time
#  colValidGranule how many cols are bundled together - oob handling
def get_col_parition(colNumber, colGranule, colValidGranule):
  # how many cols each EU get each time

  colStep = colGranule * 4
  groupNumber = 1
  euNumber = 16

  while (1):
    if (colNumber <= colStep * 15):
      if (colStep == colGranule):
        euNumber = int ((colNumber + colStep - 1) / colStep)
        break
      else:
        colStep = colStep >> 1
    else:
      groupNumber = int ((colNumber + (colStep * euNumber) - 1) / (colStep * euNumber))
      break

  if (colValidGranule > 1):
    alignedColNumber = (int ((colNumber + colValidGranule - 1) / colValidGranule)) * colValidGranule
  else:
    alignedColNumber = colNumber

  if (alignedColNumber == groupNumber * euNumber * colStep):
    aligned = 1
  else:
    aligned = 0

  return (groupNumber, euNumber, colStep, aligned)



################################################################################################################
#
# vector * matrix
#
def	gen_vector_matrix(usharpList, optionList, funcParameterMap, flowHandler):
  # [0, hwCaps.SurfaceType1DVector(),      1,  1,   1,  500, "input, 1D vector, e.g., gradient from previous layer"],
  # [1, hwCaps.SurfaceType2DWeight(),      1,  1, 500, 2000, "input, 2D weight"],
  # [2, hwCaps.SurfaceType3DActivation(),  1, 20, 10,   10, "output, 3D activation, gradient to 3d activation"],
  # [3, hwCaps.SurfaceType3DActivation(),  1, 20, 10,  10, "input, 3D activation, order is channel, height, width, e.g., 3D activation in forward pass"],
  # [4, hwCaps.SurfaceType2DWeight(),      1,  1, 500, 2000, "output, 4D weight, e.g., gradient to weight"],

  # [0, hwCaps.SurfaceType1DVector(),      1,  1,     1,   10, "input, 1D vector"],
  # [1, hwCaps.SurfaceType2DWeight(),      1,  1,    10,  500, "input, 2D weight"],
  # [2, hwCaps.SurfaceType1DVector(),      1,  1,     1,  500, "output, 1D vector, gradient"],

  indentstring = flowHandler.getIndentStr()

  ####################################################
  # options
  bCalculateGradientToWeight = optionList[0]
  # TODO
  # if enabled, mul vi with activation.chw and output to 2d weight

  vectorUSharpIndex = 0
  matrixUSharpIndex = 1
  resultUSharpIndex = 2

  vectorSurfFormat = hwCaps.SurfaceFormatFP16()
  matrixSurfFormat = hwCaps.SurfaceFormatFP16()
  resultSurfFormat = hwCaps.SurfaceFormatFP16()

  euIDSGPRStr = funcParameterMap["euIDSGPRStr"]
  vgprBaseSGPRStr = funcParameterMap["vgprBaseSGPRStr"]
  xSGPRStr = funcParameterMap["xSGPRStr"]
  ySGPRStr = funcParameterMap["ySGPRStr"]
  zSGPRStr = funcParameterMap["zSGPRStr"]
  wSGPRStr = funcParameterMap["wSGPRStr"]

  laneIdVGPRStr = funcParameterMap["laneIdVGPRStr"]
  addressVGPRStr = funcParameterMap["addressVGPRStr"]

  assert (usharpList[vectorUSharpIndex][1] == hwCaps.SurfaceType1DVector()), "3d activation * 4d weight should go to gemm pass"
  assert (usharpList[matrixUSharpIndex][1] == hwCaps.SurfaceType2DWeight()), "4d weight should be converted to 2d weight"

  # 2 fp16 elements in each lane, 64 fp16 elements in a vgpr
  vectorVGPRNumber = int ((usharpList[vectorUSharpIndex][5] + 64 - 1) / 64)

  # 2 rows per vgpr
  matrixColVGPRNumber = int ((usharpList[matrixUSharpIndex][4] + 2 - 1) / 2)
  matrixColNumber = usharpList[matrixUSharpIndex][5]

  rowIndexSGPRIndex = flowHandler.allocateSGPR(1)
  rowIndexSGPRStr = "q" + str(rowIndexSGPRIndex)

  colIndexSGPRIndex = flowHandler.allocateSGPR(1)
  colIndexSGPRStr = "q" + str(colIndexSGPRIndex)

  vectorVGPRBaseSGPRStr = vgprBaseSGPRStr

  # reuse coord sgprs
  br_print(indentstring)
  aluVGPRBaseSGPRStr  = xSGPRStr
  vgprLaneIdSGPRStr   = ySGPRStr
  vgprLaneMaskSGPRStr = zSGPRStr
  scalarFactorSGPRStr = wSGPRStr
  br_print(indentstring + "// reuse " + xSGPRStr + " as alu pass's vgpr base")
  br_print(indentstring + "// reuse " + ySGPRStr + " as vgpr lane id, this is row index")
  br_print(indentstring + "// reuse " + zSGPRStr + " as vgpr lane mask, this is to select the right data from vector's vgpr")
  br_print(indentstring + "// reuse " + wSGPRStr + " as scalar factor")

  br_print(indentstring)
  br_print(indentstring + "// load vector, all data should fit vgpr, each lane has 2 rows, packed f16")

  br_print(indentstring + "// allocate " + "{:3d}".format(vectorVGPRNumber) + " vgprs to hold vector input")
  vectorVGPRAddr = flowHandler.allocateVGPR(vectorVGPRNumber)

  funcLib.AlignPrint(indentstring + "and " + addressVGPRStr + ", " + laneIdVGPRStr + ", 0x1f", flowLib.GetCommentPos(), "// get element index of each lane, assume r0 is lane id")
  kernelLib.load_1d_vector(vectorSurfFormat, hwCaps.SurfaceFormatFP16(), addressVGPRStr, 64, vectorVGPRAddr, vectorVGPRNumber, 1, usharpList[vectorUSharpIndex][0], indentstring)


  ################################################
  # find out how to process a col band - how many cols
  if (usharpList[resultUSharpIndex][1] == hwCaps.SurfaceType1DVector()):
    colStepGranule = 32
  else:
    # 3d activation needs to pack 2 channels together
    colStepGranule = 64

  (groupNumber, euNumber, colStep, aligned) = get_col_parition(matrixColNumber, colStepGranule, 32)

  br_print(indentstring)
  br_print(indentstring + "// col step        : " + str(colStep) + " (how many cols each EU handles each time)")
  br_print(indentstring + "// number of eus   : " + str(euNumber) + " (how many eus will be used)")
  br_print(indentstring + "// number of groups: " + str(groupNumber) + " (how many iterations)")
  br_print(indentstring + "// aligned         : " + str(aligned) + " (whether cols are evenly distributed)")

  vgprColSpan = colStep >> 5

  #if (groupNumber > hwCaps.MaxIMM()):
  #  groupLoopEndSGPRIndex = flowHandler.allocateSGPR(1)
  #  groupLoopEndStr = "q" + str(groupLoopEndSGPRIndex)
  #  funcLib.AlignPrint(indentstring + "smov " + groupLoopEndStr + ", " + str(groupNumber), flowLib.GetCommentPos(), "// init group end")
  #else:
  #  groupLoopEndStr = str(groupNumber)

  groupLoopEndStr = str(groupNumber)
  colIndexEndStr  = str(matrixColNumber)

  #if (aligned == 0):
  #  if (matrixColNumber > hwCaps.MaxIMM()):
  #    colIndexEndSGPRIndex = flowHandler.allocateSGPR(1)
  #    colIndexEndStr = "q" + str(colIndexEndSGPRIndex)
  #    funcLib.AlignPrint(indentstring + "smov " + colIndexEndStr + ", " + str(matrixColNumber), flowLib.GetCommentPos(), "// init col end")
  #  else:
  #    colIndexEndStr  = str(matrixColNumber)
  #else:
  #  colIndexEndStr = "WRONG"

  ######################################

  br_print(indentstring)
  br_print(indentstring + "// find out parameters to handle a col of the matrix")

  availVGPRNumber = flowHandler.getAvailVGPRNumber()

  syncGroupNumber = 3

  # need reserve 2 set of vgprColSpan to hold accumulation result, and some vgprs for temp
  maxVGPRRowSpan = int ((int ((availVGPRNumber - 12) / vgprColSpan) - 1) / syncGroupNumber)

  assert maxVGPRRowSpan > 0, "not enough vgprs, need to use a smaller span"

  if (maxVGPRRowSpan > 4):
    maxVGPRRowSpan = 4

  # group should be power of 2, and less than 32
  if (matrixColVGPRNumber > maxVGPRRowSpan):
    vgprRowSpan = maxVGPRRowSpan
  else:
    vgprRowSpan = matrixColVGPRNumber

  rowGroupNumber = int ((matrixColVGPRNumber + vgprRowSpan - 1) / vgprRowSpan)

  # last group may be partial
  vgprRowSpanRemains = matrixColVGPRNumber % vgprRowSpan

  br_print(indentstring + "// total vgpr number in a col = " + str(matrixColVGPRNumber))
  br_print(indentstring + "// vgpr group size in rows = " + str(vgprRowSpan))
  br_print(indentstring + "// vgpr group size in cols = " + str(vgprColSpan))
  br_print(indentstring + "// group number = " + str(rowGroupNumber))
  br_print(indentstring + "// vgpr group remains in rows = " + str(vgprRowSpanRemains))

  # number of vgprs affects load, load might cross boundary, so has to take out of loop
  if (vgprRowSpanRemains != 0):
    rowGroupNumber -= 1
    tailNumber = 1
  else:
    tailNumber = 0

  bodyNumber = 0

  if (rowGroupNumber > syncGroupNumber):
    headNumber = syncGroupNumber - 1
    tailNumber += (rowGroupNumber - headNumber) % syncGroupNumber
    loopNumber = int ((rowGroupNumber - headNumber) / syncGroupNumber)

    if (loopNumber != 0):
      bodyNumber = syncGroupNumber
  else:
    headNumber = rowGroupNumber
    loopNumber = 0

  lastLoadIndex = headNumber + bodyNumber + tailNumber - 1
  expandNumber = headNumber + bodyNumber + tailNumber + headNumber

  br_print(indentstring + "// loop number = " + str(loopNumber))
  br_print(indentstring + "// head: " + str(headNumber) + ", body: " + str(bodyNumber) + ", tail: " + str(tailNumber))



  ################################################
  # allocate vgprs accordingly

  matrixColVGPRGroupSize = vgprRowSpan * vgprColSpan
  br_print(indentstring + "// allocate " + "{:3d}".format(matrixColVGPRGroupSize * syncGroupNumber) + " vgprs to hold a portion of matrix col", end ="")
  matrixColVGPRAddr = flowHandler.allocateVGPR(matrixColVGPRGroupSize * syncGroupNumber)
  br_print(" from vgpr " + str(matrixColVGPRAddr))

  # hold two rows' accumulate result
  accumulateVGPRNumber = 2 * vgprColSpan
  br_print(indentstring + "// allocate " + "{:3d}".format(accumulateVGPRNumber) + " vgprs to hold accumulate result", end ="")
  accumulateVGPRAddr = flowHandler.allocateVGPR(accumulateVGPRNumber)
  br_print(" from vgpr " + str(accumulateVGPRAddr))

  outputVGPRNumber = 1
  br_print(indentstring + "// allocate " + "{:3d}".format(outputVGPRNumber) + " vgprs to hold output result", end ="")
  outputVGPRAddr = flowHandler.allocateVGPR(outputVGPRNumber)
  br_print(" from vgpr " + str(outputVGPRAddr))

  tempVGPRNumber = 4
  br_print(indentstring + "// allocate " + "{:3d}".format(tempVGPRNumber) + " vgprs for temp use", end ="")
  tempVGPRAddr = flowHandler.allocateVGPR(tempVGPRNumber)
  br_print(" from vgpr " + str(tempVGPRAddr))

  br_print(indentstring)
  br_print(indentstring + "// initialize accumulate result")
  kernelLib.mov_imm_v(hwCaps.SurfaceFormatFP32(), accumulateVGPRAddr, accumulateVGPRNumber, "0.0", "", indentstring)

  br_print(indentstring)
  br_print(indentstring + "// load weight")
  br_print(indentstring + "// calculate start col index for each EU based on eu id, each EU gets " + str(vgprColSpan << 5) + " cols")

  br_print(indentstring + "sshl " + colIndexSGPRStr + ", " + euIDSGPRStr + ", " + str(funcLib.GetLeadingOnePos(vgprColSpan) + 5))

  if (groupNumber > 1):
    flowHandler.startForLoop("0", groupLoopEndStr, "1", -1, "")
    indentstring = flowHandler.getIndentStr()

  if (euNumber < 16):
    flowHandler.startIfLoop(euIDSGPRStr, str(euNumber), "<", 0)
    indentstring = flowHandler.getIndentStr()

  if (aligned == 0):
    br_print(indentstring + "// col number can't be evenly distributed among EUs, so check at here")
    flowHandler.startIfLoop(colIndexSGPRStr, colIndexEndStr, "<", 0)
    indentstring = flowHandler.getIndentStr()

  funcLib.AlignPrint(indentstring + "smovs a1, " + str(vectorVGPRAddr), flowLib.GetCommentPos(), "// set vgpr base")
  funcLib.AlignPrint(indentstring + "smov " + rowIndexSGPRStr + ", 0", flowLib.GetCommentPos(), "// init row index")

  br_print(indentstring)

  br_print(indentstring + "// start loading multiple of 32-col of matrix and doing accumulation")

#  funcLib.AlignPrint (indentstring + "smov " + loadVGPRBaseSGPRStr + ", " + str(matrixColVGPRAddr), flowLib.GetCommentPos(), "// init load vgpr base")
#  funcLib.AlignPrint (indentstring + "smov " + aluVGPRBaseSGPRStr + ", " + str(matrixColVGPRAddr), flowLib.GetCommentPos(), "// init alu vgpr base")
  funcLib.AlignPrint (indentstring + "smov " + vectorVGPRBaseSGPRStr + ", " + str(vectorVGPRAddr), flowLib.GetCommentPos(), "// init vector vgpr base")
  funcLib.AlignPrint (indentstring + "smov " + vgprLaneIdSGPRStr + ", 0", flowLib.GetCommentPos(), "// init lane id to 0")

  loadIndex = 0
  aluIndex = 0

  # load and alu
  for z in range (expandNumber):

    if (z == headNumber and loopNumber > 1):
      br_print(indentstring)
      flowHandler.startForLoop("0", str(loopNumber), "1", -1, "")
      indentstring = flowHandler.getIndentStr()

    if (z <= lastLoadIndex):
      br_print(indentstring)
      if (z == lastLoadIndex and vgprRowSpanRemains != 0):
        loadVGPRNumber = vgprRowSpanRemains
      else:
        loadVGPRNumber = vgprRowSpan

#      funcLib.AlignPrint(indentstring + "smovs a1, " + loadVGPRBaseSGPRStr, flowLib.GetCommentPos(), "// set load vgpr base")

      br_print(indentstring + "// load pass")
      loadVGPRAddr = matrixColVGPRAddr + loadIndex * matrixColVGPRGroupSize

      for x in range (loadVGPRNumber):
        kernelLib.load_2d_weight(matrixSurfFormat, hwCaps.SurfaceFormatFP16(), rowIndexSGPRStr, colIndexSGPRStr, loadVGPRAddr, vgprColSpan, 1, loadIndex + 1, usharpList[matrixUSharpIndex][0], indentstring)
        funcLib.AlignPrint(indentstring + "sadd " + rowIndexSGPRStr + ", " + rowIndexSGPRStr + ", 2", flowLib.GetCommentPos(), "// advance row")
        loadVGPRAddr += vgprColSpan

      if (lastLoadIndex != 0):
#        funcLib.AlignPrint(indentstring + "sadd " + loadVGPRBaseSGPRStr + ", " + loadVGPRBaseSGPRStr + ", " + str(vgprRowSpan), flowLib.GetCommentPos(), "// advance load vgpr base")
        loadIndex = funcLib.IncAndWrap(loadIndex, syncGroupNumber)

    if (z >= headNumber):
      br_print(indentstring)
      syncId = aluIndex + 1
      br_print(indentstring + "// alu pass, first grab a lane from vector input")

      if (z == expandNumber-1 and vgprRowSpanRemains != 0):
        aluVGPRNumber = vgprRowSpanRemains
      else:
        aluVGPRNumber = vgprRowSpan

      syncStr = kernelLib.GetSyncModifier(syncId)

      funcLib.AlignPrint(indentstring + "smov " + aluVGPRBaseSGPRStr + ", " + str(matrixColVGPRAddr + aluIndex * matrixColVGPRGroupSize), flowLib.GetCommentPos(), "// calculate alu vgpr base")

      funcLib.AlignPrint(indentstring + "nop" + syncStr, flowLib.GetCommentPos(), "// nop instr to wait sync channel")
      syncStr = ""

      if (aluVGPRNumber > 1):
        flowHandler.startForLoop("0", str(aluVGPRNumber), "1", -1, "")
        indentstring = flowHandler.getIndentStr()

      funcLib.AlignPrint(indentstring + "smovs" + " a1, " + vectorVGPRBaseSGPRStr, flowLib.GetCommentPos(), "// switch to vector input base")
      funcLib.AlignPrint(indentstring + "sshl " + vgprLaneMaskSGPRStr + ", 1, " + vgprLaneIdSGPRStr, flowLib.GetCommentPos(), "// get lane mask from lane id")
      funcLib.AlignPrint(indentstring + "smovs wm0, " + vgprLaneMaskSGPRStr, flowLib.GetCommentPos(), "// set m0 mask")
      funcLib.AlignPrint(indentstring + "mov r" + str(tempVGPRAddr) + ".f32, ir0.f16", flowLib.GetCommentPos(), "// expand 2 fp16 to 2 fp32")
      funcLib.AlignPrint(indentstring + "m0.movw.r2q  " + scalarFactorSGPRStr + ", r" + str(tempVGPRAddr) + ".u32", flowLib.GetCommentPos(), "// mov corresponding lane's activation data to a sgpr")
      funcLib.AlignPrint(indentstring + "mov r" + str(tempVGPRAddr) + ".f32, " + scalarFactorSGPRStr + ".f32", flowLib.GetCommentPos(), "// replicate")
      funcLib.AlignPrint(indentstring + "m0.movw.r2q  " + scalarFactorSGPRStr + ", r" + str(tempVGPRAddr+1) + ".u32", flowLib.GetCommentPos(), "// mov corresponding lane's activation data to a sgpr")
      funcLib.AlignPrint(indentstring + "mov r" + str(tempVGPRAddr+1) + ".f32, " + scalarFactorSGPRStr + ".f32", flowLib.GetCommentPos(), "// replicate")
      funcLib.AlignPrint(indentstring + "mov.v2 r" + str(tempVGPRAddr) + ".f16, r" + str(tempVGPRAddr) + ".f32.a", flowLib.GetCommentPos(), "// now we have duplicate of the lane we need, pack back to fp16")

      funcLib.AlignPrint(indentstring + "smovs a1, " + aluVGPRBaseSGPRStr, flowLib.GetCommentPos(), "// switch to alu vgpr base")

      vectorModifier = kernelLib.GetVectorModifier(vgprColSpan, 'v')

      for vgprColIndex in range (vgprColSpan):
        funcLib.AlignPrint(indentstring + "fmac" + vectorModifier + ".b16.wd" + " r" + str(accumulateVGPRAddr + vgprColIndex*2) + " ir" + str(vgprColIndex) + ", r" + str(tempVGPRAddr), flowLib.GetCommentPos(), "// packed fp16 * packed fp16")

      funcLib.AlignPrint(indentstring + "sadd " + aluVGPRBaseSGPRStr + ", " + aluVGPRBaseSGPRStr + ", " + str(vgprColSpan), flowLib.GetCommentPos(), "// advance alu vgpr base")
      funcLib.AlignPrint(indentstring + "sadd " + vgprLaneIdSGPRStr + ", " + vgprLaneIdSGPRStr + ", 1", flowLib.GetCommentPos(), "// advance vector vgpr lane id")

      if (aluVGPRNumber > 1):
        flowHandler.closeForLoop("0", str(aluVGPRNumber), "1", -1)
        indentstring = flowHandler.getIndentStr()

      funcLib.AlignPrint(indentstring + "smovs wm0, 0xffffffff", flowLib.GetCommentPos(), "// reset m0 mask")
      aluIndex = funcLib.IncAndWrap(aluIndex, syncGroupNumber)

      flowHandler.startIfLoop(vgprLaneIdSGPRStr, "32", "==", 0)
      indentstring = flowHandler.getIndentStr()
      br_print(indentstring + "smov " + vgprLaneIdSGPRStr + ", 0")
      funcLib.AlignPrint(indentstring + "sadd " + vectorVGPRBaseSGPRStr + ", " + vectorVGPRBaseSGPRStr + ", 1", flowLib.GetCommentPos(), "// advance vector vgpr base")
      flowHandler.closeIfLoop()
      indentstring = flowHandler.getIndentStr()

    if (z == (headNumber + bodyNumber - 1) and loopNumber > 1):
      flowHandler.closeForLoop("0", str(loopNumber), "1", -1)
      indentstring = flowHandler.getIndentStr()

  br_print(indentstring)
  br_print(indentstring + "// finish loading a col of vgpr and doing accumulation")


  br_print(indentstring)
  br_print(indentstring + "// add even row and odd row")

  for vgprColIndex in range (vgprColSpan):
    br_print(indentstring + "fadd.b32 r" + str(accumulateVGPRAddr + vgprColIndex) + ", r" + str(accumulateVGPRAddr + 2 * vgprColIndex) + ", r" + str(accumulateVGPRAddr + 2 * vgprColIndex + 1))

  br_print(indentstring)
  br_print(indentstring + "// output " + str(vgprColSpan << 5) + " cols")

  if (usharpList[resultUSharpIndex][1] == hwCaps.SurfaceType1DVector()):
    funcLib.AlignPrint(indentstring + "and " + addressVGPRStr + ", " + laneIdVGPRStr + ", 0x1f", flowLib.GetCommentPos(), "// get element index of each lane, assume r0 is lane id")
    funcLib.AlignPrint(indentstring + "addu.b32 r" + str(tempVGPRAddr) + ", " + colIndexSGPRStr + ", " + addressVGPRStr, flowLib.GetCommentPos(), "// adjust by col index")

    br_print(indentstring + "// TODO - oob")

    kernelLib.store_1d_vector(resultSurfFormat, hwCaps.SurfaceFormatFP32(), "r" + str(tempVGPRAddr), 32, accumulateVGPRAddr, vgprColSpan, resultUSharpIndex, indentstring)

    #funcLib.AlignPrint(indentstring + "st.m1d.float" + ".mb16" + ".gc2 g0, g1, " + str(usharpList[resultUSharpIndex][0]), flowLib.GetCommentPos(), "// store a lane")
    #br_print(indentstring + "mov g0.u32, r" + str(tempVGPRAddr) + ".u32")
    #br_print(indentstring + "mov.eog g1.f16, r" + str(accumulateVGPRAddr) + ".f32")

  else:
    br_print(indentstring + "// calculate c, x, y")
    br_print(indentstring + "// an alternative way is to split based on channels")

    funcLib.AlignPrint(indentstring + "shr r" + str(tempVGPRAddr) + ", " + colIndexSGPRStr + ", 6", flowLib.GetCommentPos(), "// get 4x8 channel pair's index")

    surfaceXStride = ((usharpList[resultUSharpIndex][4] + 3) >> 2)
    surfaceSliceStride = ((usharpList[resultUSharpIndex][5] + 7) >> 3) * surfaceXStride

    funcLib.AlignPrint(indentstring + "mov r" + str(tempVGPRAddr + 1) + ".f32, r" + str(tempVGPRAddr) + ".f32", flowLib.GetCommentPos(), "// convert to float")
    funcLib.AlignPrint(indentstring + "movi r" + str(tempVGPRAddr + 2) + ".f32, " + "{:10.8f}".format(1/surfaceSliceStride), flowLib.GetCommentPos(), "// 1/slice_stride")
    funcLib.AlignPrint(indentstring + "movi r" + str(tempVGPRAddr + 3) + ".f32, " + "{:10.8f}".format(0.01), flowLib.GetCommentPos(), "// address precision loss")
    funcLib.AlignPrint(indentstring + "fmul.b32 r" + str(tempVGPRAddr + 2) + ", r" + str(tempVGPRAddr + 1) + ", r" + str(tempVGPRAddr + 2), flowLib.GetCommentPos(), "// divide by slice stride")
    funcLib.AlignPrint(indentstring + "fadd.b32 r" + str(tempVGPRAddr + 2) + ", r" + str(tempVGPRAddr + 2) + ", r" + str(tempVGPRAddr + 3), flowLib.GetCommentPos(), "// address precision, need or not?")
    funcLib.AlignPrint(indentstring + "mov r" + str(tempVGPRAddr + 2) + ".u32, r" + str(tempVGPRAddr + 2) + ".f32", flowLib.GetCommentPos(), "// convert channel pair index to int")
    funcLib.AlignPrint(indentstring + "shl r" + str(tempVGPRAddr + 3) + ", r" + str(tempVGPRAddr + 2) + ", 1", flowLib.GetCommentPos(), "// get channel index")
    funcLib.AlignPrint(indentstring + "m0.movw.r2q  " + zSGPRStr + ", r" + str(tempVGPRAddr + 3) + ".u32", flowLib.GetCommentPos(), "// mov channel pair index to sgpr")

    funcLib.AlignPrint(indentstring + "mulu r" + str(tempVGPRAddr + 2) + ", r" + str(tempVGPRAddr + 2) + ", " + str(surfaceSliceStride), flowLib.GetCommentPos(), "// to caculate offset in slice")
    funcLib.AlignPrint(indentstring + "addu r" + str(tempVGPRAddr) + ", r" + str(tempVGPRAddr) + ", r" + str(tempVGPRAddr + 2) + ".n", flowLib.GetCommentPos(), "// get offset in slice")
    funcLib.AlignPrint(indentstring + "movi r" + str(tempVGPRAddr + 2) + ".f32, " + "{:10.8f}".format(1/surfaceXStride), flowLib.GetCommentPos(), "// 1/x_stride")
    funcLib.AlignPrint(indentstring + "mov r" + str(tempVGPRAddr + 1) + ".f32, r" + str(tempVGPRAddr) + ".f32", flowLib.GetCommentPos(), "// convert to float")
    funcLib.AlignPrint(indentstring + "fmul.b32 r" + str(tempVGPRAddr + 2) + ", r" + str(tempVGPRAddr + 1) + ", r" + str(tempVGPRAddr + 2), flowLib.GetCommentPos(), "// divide by x stride")
    funcLib.AlignPrint(indentstring + "fadd.b32 r" + str(tempVGPRAddr + 2) + ", r" + str(tempVGPRAddr + 2) + ", r" + str(tempVGPRAddr + 3), flowLib.GetCommentPos(), "// address precision, need or not?")
    funcLib.AlignPrint(indentstring + "mov r" + str(tempVGPRAddr + 2) + ".u32, r" + str(tempVGPRAddr + 2) + ".f32", flowLib.GetCommentPos(), "// convert x tile index to int")
    funcLib.AlignPrint(indentstring + "shl r" + str(tempVGPRAddr + 3) + ", r" + str(tempVGPRAddr + 2) + ", 3", flowLib.GetCommentPos(), "// get x index")
    funcLib.AlignPrint(indentstring + "m0.movw.r2q  " + xSGPRStr + ", r" + str(tempVGPRAddr + 3) + ".u32", flowLib.GetCommentPos(), "// mov x index to sgpr")

    funcLib.AlignPrint(indentstring + "mulu r" + str(tempVGPRAddr + 2) + ", r" + str(tempVGPRAddr + 2) + ", " + str(surfaceXStride), flowLib.GetCommentPos(), "// to caculate offset in y dir")
    funcLib.AlignPrint(indentstring + "addu r" + str(tempVGPRAddr) + ", r" + str(tempVGPRAddr) + ", r" + str(tempVGPRAddr + 2) + ".n", flowLib.GetCommentPos(), "// get offset in y direction")
    funcLib.AlignPrint(indentstring + "m0.movw.r2q  " + ySGPRStr + ", r" + str(tempVGPRAddr) + ".u32", flowLib.GetCommentPos(), "// mov y tile index to sgpr")
    funcLib.AlignPrint(indentstring + "sshl " + ySGPRStr + ", " + ySGPRStr + ", 2", flowLib.GetCommentPos(), "// get y index")

    (stFormatStr, scale) = kernelLib.GetLSFormatModifier(resultSurfFormat, hwCaps.SurfaceFormatFP16())

    for vgprColIndex in range (vgprColSpan >> 1):
      funcLib.AlignPrint(indentstring + "mov.v2 r" + str(accumulateVGPRAddr + vgprColIndex) + ".f16, r" + str(accumulateVGPRAddr + vgprColIndex * 2) + ".f32.a", flowLib.GetCommentPos(), "// pack 2 channel fp16")
      funcLib.AlignPrint(indentstring + "stm.float" + stFormatStr + ".e2.gc5 g0, g4, " + str(usharpList[resultUSharpIndex][0]), flowLib.GetCommentPos(), "// store a tile")
      br_print(indentstring + "smovg g0, " + xSGPRStr)
      br_print(indentstring + "smovg g1, " + ySGPRStr)
      br_print(indentstring + "smovg g2, " + zSGPRStr)
      br_print(indentstring + "smovg g3, 0")
      br_print(indentstring + "mov.eog g4.f16, r" + str(accumulateVGPRAddr + vgprColIndex) + ".f16")

      if (vgprColIndex != ((vgprColSpan >> 1) - 1)):
        br_print(indentstring + "// calculate coordinates for next tile")
        funcLib.AlignPrint(indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(hwCaps.TileSizeY()), flowLib.GetCommentPos(), "// advance in y dir")
        flowHandler.startIfLoop(ySGPRStr, str(usharpList[resultUSharpIndex][4]), ">=", 0)
        indentstring = flowHandler.getIndentStr()
        funcLib.AlignPrint(indentstring + "smov " + ySGPRStr + ", 0", flowLib.GetCommentPos(), "// reset in y dir")
        funcLib.AlignPrint(indentstring + "sadd " + xSGPRStr + ", " + xSGPRStr + ", " + str(hwCaps.TileSizeX()), flowLib.GetCommentPos(), "// advance in x dir")
        flowHandler.startIfLoop(ySGPRStr, str(usharpList[resultUSharpIndex][5]), ">=", 0)
        indentstring = flowHandler.getIndentStr()
        funcLib.AlignPrint(indentstring + "smov " + xSGPRStr + ", 0", flowLib.GetCommentPos(), "// reset in x dir")
        funcLib.AlignPrint(indentstring + "sadd " + zSGPRStr + ", " + zSGPRStr + ", 2", flowLib.GetCommentPos(), "// advance in c dir")
        flowHandler.closeIfLoop()
        flowHandler.closeIfLoop()
        indentstring = flowHandler.getIndentStr()


  if (aligned == 0):
    br_print(indentstring)
    br_print(indentstring + "// col number can't be evenly distributed among EUs")
    flowHandler.closeIfLoop()
    indentstring = flowHandler.getIndentStr()

  if (euNumber < 16):
    flowHandler.closeIfLoop()
    indentstring = flowHandler.getIndentStr()

  if (groupNumber > 1):
    br_print(indentstring + "sadd " + colIndexSGPRStr + ", " + colIndexSGPRStr + ", " + str(vgprColSpan * 32 * 16))
    flowHandler.closeForLoop("0", groupLoopEndStr, "1", -1)

  flowHandler.releaseVGPR(vectorVGPRAddr)
  flowHandler.releaseVGPR(matrixColVGPRAddr)
  flowHandler.releaseVGPR(accumulateVGPRAddr)
  flowHandler.releaseVGPR(outputVGPRAddr)
  flowHandler.releaseVGPR(tempVGPRAddr)




def gen_layer_main_kernel(layerId, layerNumber, warpId, layerInfo, flowHandler):

  cmdIndex = cwarp.GetCMDIndex()

  if (layerInfo[cmdIndex] != "fc"):
    assert False, "unsupported op " + layerInfo[cmdIndex]
    return

  flowHandler.startFunctionDef("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel", 0)
  indentstring = flowHandler.getIndentStr()

  funcParameterMap = {}

  flowHandler.setLabelSuffix("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel")

  uSharpIndex = cwarp.GetUSharpIndex()
  optionsIndex = cwarp.GetOptionsIndex()

  ####################################################
  # options
  optionList = layerInfo[optionsIndex]


  ####################################################
  # usharp
  usharpList = layerInfo[uSharpIndex]
  kernelLib.PrintUSharpList(usharpList, indentstring)

  #usharpList1 = (
# fw 1
#                 [0, hwCaps.SurfaceType2DWeight(),      1,  1, 500, 2000, "input, 2D weight, order is row, channel, height, width, channel/height/width are packed into col"],
#                 [1, hwCaps.SurfaceType3DActivation(),  1, 20,  10,   10, "input, 3D activation, order is 1, channel, height, width, origin is previous layer's output, from hbm"],
#                 [2, hwCaps.SurfaceType1DVector(),      1,  1,   1,   10, "input, 1D vector, bias"],
#                 [3, hwCaps.SurfaceType1DVector(),      1,  1,   1,   10, "output, 1D vector, fc output, also serve as input to softmax"],
#                 [0, hwCaps.SurfaceType4DWeight(),    500, 20, 10,  10, "input, 4D weight, order is row, channel, height, width, channel/height/width are packed into col"],
#                 [1, hwCaps.SurfaceType3DActivation(),  1, 20, 10,  10, "input, 3D activation, order is 1, channel, height, width, origin is previous layer's output, from hbm"],
#                 [2, hwCaps.SurfaceType1DVector(),      1,  1,  1, 500, "input, 1D vector, bias"],
#                 [3, hwCaps.SurfaceType1DVector(),      1,  1,  1, 500, "output, 1D vector, fc output, also serve as input to softmax"],

# fw 2

# back 1
#                 [0, hwCaps.SurfaceType2DWeight(),      1,  1, 500, 2000, "input, 2D weight"],
#                 [1, hwCaps.SurfaceType1DVector(),      1,  1,   1,  500, "input, 1D vector"],
#                 [2, hwCaps.SurfaceType3DActivation(),  1,  20, 10,   10, "output, 3D activation"],
# back 2
#                 [0, hwCaps.SurfaceType2DWeight(),      1,  1,    10,  500, "input, 2D weight"],
#                 [1, hwCaps.SurfaceType1DVector(),      1,  1,     1,   10, "input, 1D vector"],
#                 [2, hwCaps.SurfaceType1DVector(),      1,  1,     1,  500, "output, 1D vector, gradient"],
  #              )

  br_print(indentstring + "// sgpr usage:")

  ####################################################
  # allocate sgprs
  euIDSGPRIndex = flowHandler.allocateSGPR(1)
  euIDSGPRStr = "q" + str(euIDSGPRIndex)
  br_print(indentstring + "//   eu id at sgpr q" + str(euIDSGPRIndex))
  funcParameterMap["euIDSGPRStr"] = euIDSGPRStr

  coordSGPRIndex = flowHandler.allocateSGPR(4)
  xSGPRStr = "q" + str(coordSGPRIndex)
  ySGPRStr = "q" + str(coordSGPRIndex + 1)
  zSGPRStr = "q" + str(coordSGPRIndex + 2)
  wSGPRStr = "q" + str(coordSGPRIndex + 3)
  br_print(indentstring + "//   x/y/z/w at sgpr q" + str(coordSGPRIndex) + "-q" + str(coordSGPRIndex+3))
  funcParameterMap["xSGPRStr"] = xSGPRStr
  funcParameterMap["ySGPRStr"] = ySGPRStr
  funcParameterMap["zSGPRStr"] = zSGPRStr
  funcParameterMap["wSGPRStr"] = wSGPRStr

  vgprBaseSGPR = flowHandler.allocateSGPR(1)
  vgprBaseSGPRStr = "q" + str(vgprBaseSGPR)
  br_print(indentstring + "//   vgpr base at sgpr q" + str(euIDSGPRIndex))
  funcParameterMap["vgprBaseSGPRStr"] = vgprBaseSGPRStr

  br_print(indentstring + "// vgpr usage:")
  ####################################################
  # reserve vgpr0 for lane id
  laneIdVGPRIndex = flowHandler.reserveVGPR(0, 1)
  laneIdVGPRStr = "r" + str(laneIdVGPRIndex)
  br_print(indentstring + "//   lane id at vgpr r" + str(laneIdVGPRIndex) + ", initialized at beginning, should never be overwritten")
  funcParameterMap["laneIdVGPRStr"] = laneIdVGPRStr

  addressVGPRIndex = flowHandler.allocateVGPR(1)
  addressVGPRStr = "r" + str(addressVGPRIndex)
  br_print(indentstring + "//   address at vgpr r" + str(addressVGPRIndex))
  funcParameterMap["addressVGPRStr"] = addressVGPRStr

  if (usharpList[0][1] == hwCaps.SurfaceType1DVector()):
    gen_vector_matrix(usharpList, optionList, funcParameterMap, flowHandler)
  else:
  # [0, hwCaps.SurfaceType4DWeight(),    500, 20, 10,  10, "input, 4D weight, order is row, channel, height, width, channel/height/width are packed into col"],
  # [1, hwCaps.SurfaceType3DActivation(),  1, 20, 10,  10, "input, 3D activation, order is 1, channel, height, width, origin is previous layer's output, from hbm"],
  # [2, hwCaps.SurfaceType1DVector(),      1,  1,  1, 500, "input, 1D vector, bias"],
  # [3, hwCaps.SurfaceType1DVector(),      1,  1,  1, 500, "output, 1D vector, fc output, also serve as input to softmax"],
  # or
  # [0, hwCaps.SurfaceType2DWeight(),      1,  1,  10,  500, "input, 2D weight"],
  # [1, hwCaps.SurfaceType1DVector(),      1,  1,   1,  500, "input, 1D vector"],
  # [2, hwCaps.SurfaceType1DVector(),      1,  1,   1,   10, "input, 1D vector, bias"],
  # [3, hwCaps.SurfaceType1DVector(),      1,  1,   1,   10, "output, 1D vector, fc output, also serve as input to softmax"],

    gen_matrix_vector(usharpList, optionList, funcParameterMap, flowHandler)

  br_print(indentstring)
  kernelLib.jump_to_next_layer(layerId, layerNumber, warpId, indentstring)
  br_print(indentstring)

  flowHandler.closeFunctionDef("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel", 0)
