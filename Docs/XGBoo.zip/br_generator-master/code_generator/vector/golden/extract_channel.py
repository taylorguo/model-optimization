#!/usr/bin/env python3



import sys
import os
import math
import array
import struct
  
    
def main():

  if (len(sys.argv) > 1):
    if sys.argv[1] == "-h":
      print ("usage:")
      print ("  cmd file_name surface_channel_number, surface_height, surface_weight, target_channel_id")
      return
    
  if (len(sys.argv) < 6):
    print ("insufficient paramters")
    print ("  cmd file_name surface_channel_number, surface_height, surface_weight, target_channel_id")
    return
    
  
  gChannelNumber = int (sys.argv[2])
  gSurfaceHeight = int (sys.argv[3])
  gSurfaceWidth = int (sys.argv[4])
  gChannelIndex = int (sys.argv[5])
       
  # 8 in y dir, 8 in x dir, 4 in channel pair, element is 32b
  gYStrideInElement = (((gSurfaceHeight + 7) >> 3) << 8)
  gSurfaceStrideInElement = ((gSurfaceWidth + 7) >> 3) * gYStrideInElement
  
  gChannel8 = (gChannelNumber + 7) >> 3
  gTotalSizeInElement = gChannel8 * gSurfaceStrideInElement

  f = open(sys.argv[1], "rb")
  
  #byte_arr = [data & 0xff, data >> 8]
  #binary_format = bytearray(byte_arr)
  #f.write(binary_format)
  #gTotalSizeInElement = 2
  
  
  dataArray = [[0] * gSurfaceWidth for z in range (gSurfaceHeight)]
  #for y in range (gSurfaceHeight):
  #  for x in range (gSurfaceWidth):
  #     addr
  
  u16Index = 0
  dataNumber = 0
  
  while (1):
    bytes = f.read(2)
    
    if not bytes:
      break
      
    val = struct.unpack('H', bytes)[0]
    
    z = u16Index >> 1
    
    thisChannel8 = int (z / gSurfaceStrideInElement)
    offsetInSurface = z - thisChannel8 * gSurfaceStrideInElement
    thisX8 = int (offsetInSurface / gYStrideInElement)
    offsetInY = offsetInSurface - thisX8 * gYStrideInElement
    thisY4 = offsetInY >> 7
    thisChannel2 = (offsetInY & 0x7f) >> 5
    thisY0_3 = (offsetInY & 0x1f) >> 3
    thisX0_7 = (offsetInY & 0x7)
  
    thisX = (thisX8 << 3) | thisX0_7
    thisY = (thisY4 << 2) | thisY0_3
    thisChannel = (thisChannel8 << 3) | (thisChannel2 << 1) | (u16Index & 1)
    
    if (thisChannel == gChannelIndex and thisX < gSurfaceWidth and thisY < gSurfaceHeight):
      dataArray[thisY][thisX] = val
      dataNumber += 1
    
    u16Index += 1
    
  f.close()
  
  print ("read " + str(dataNumber) + " out of " + str(gSurfaceWidth * gSurfaceHeight) + " elements")
  for y in range(gSurfaceHeight):
    for x in range(gSurfaceWidth):
      print ("{:04x}".format(dataArray[y][x]), end = " ")
    print ("")
      
if __name__ == '__main__':
  main()
  
