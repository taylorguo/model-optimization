#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.


import sys
import os
import math

import code_generator.vector.common.hwCaps as hwCaps
import code_generator.vector.common.flowLib as flowLib
import code_generator.vector.common.cwarp as cwarp
import code_generator.vector.common.funcgen as funcgen
import code_generator.vector.common.funcLib as funcLib
import code_generator.vector.common.kernelLib as kernelLib
import code_generator.vector.common.compiler as compiler
import code_generator.vector.common.usharp as usharp

from code_generator.share.br_defined_print import br_print



################################################################################################################
# split tile based on code_generator.share memory (gsm) size
# for each block
#   clear block of code_generator.shared memory (gsm), including padding, to 0
#   use ldm activation gradient to gpr
#   atomic add to code_generator.shared memory based on offset usharp
#   for inner block, use stm to save to output
#   for padding (both inner and outer), use atomic add to modify output, oob shall be discarded

# for each lane,
#   source cord is tile.y + lane_offset.y + pool_offset.y, tile.x + lane_offset.x + pool_offset.x
#   target coord is src.y + pool_offset.y, src.x + pool_offset.x
#   gsm addr = y * stride + x
#   oob if < 0 or > surface width/height
#     cmps.lt.b32 q1 x, 0
#     cmps.le.b32 q2 width, x
#     cmps.lt.b32 q3 y, 0
#     cmps.le.b32 q4 height, y
#     sand q1, q2, q1
#     sand q3, q3, q4
#     sand wm0, q1, q3

# atadd or mbar
#   atadd needs address, there is no function to get tensor format address, needs usharp info and instructions to calculate
#     atadd.mt2.ca.dt.mdem.rdem.sync.aa.dcnt.gcnt d, g0, gi, desc;
#     mt1 = {gsm|glm} // memory type
#   alternatively
#   we can stm, and then fll1, and then ldm back
#     Both LSC and EU/DE preserve order of GSM accesses
# code_generator.shared memory
#   128B per tile
#   32kB code_generator.shared memory, each Eu gets 1/4, or 64 tiles
#
# pseudo code
#   load 6x6 of input gradient and offset to vgpr
#   if top horizontal band
#     clear top 1x8 tile to 0
#   else
#     load top 2x8 tiles from output gradient, write to gsm
#   if 1st block in horizontal band
#     clear left 7x1 to 0
#   else
#
#   clear rest 6x8 tiles to 0

# if valid mode
#   add offset from fwd pass by (px, py), no padding in top and left edge in gsm
#   output surface is bigger than input surface
# if padding mode
#   add offset from fwd pass by tile (4, 8), padding in top and left edge in gsm

# stride 2
#   instead of loading 6x6 input gradient/offset, load 3x3 and expand to 6x6


# pool.bf16 r32, r0, r239, r8
# & mate.fw2.fh2.strd2.dilt1.padx1.pady1.bndtop.fwd.max.grp0 c0, q10
# padx/y1 means 1 pixel padding at top-left corner

# if filter offset <= 0, there is no padding in top left, means "same" mode
# in this case, there is no padding in top left in gsm as well
# we could load 7x7 gradient/offset
# but if stride is 2, we can still only load 3x3 and expand to 6x6

def GetFilterSizeX():
  return 0

def GetFilterSizeY():
  return 1

def GetFilterOffsetX():
  return 2

def GetFilterOffsetY():
  return 3

def GetFilterStrideIndex():
  return 4





def BufferBlockMode():
  return 0

def BufferRowMode():
  return 2


def BorderTypeBottom():
  return 1

def BorderTypeBottomPartial():
  return 2

def BorderTypeTop():
  return 4

def BorderTypeRight():
  return 8

def BorderTypeLeft():
  return 16

def BorderTypeRightPartial():
  return 32

def BorderTypeAll():
  return BorderTypeBottom() | BorderTypeRight() | BorderTypeTop()





################################################################################################################
# general functions
# does not necessarily for pooling kernel only
################################################################################################################






####################################################
# pbk_block_init_gsm
#   load data from memory
#   1. load top 2 rows from output gradient surface, this is updated by previous band, and store to gsm
#      rest gsm will be cleared to 0
#   2. load input gradient and input offset
#
def pbk_block_load(borderType, rowSize, funcParameterMap, flowHandler):

  # y (0-3) * stride + x (0-7) inside a tile
  laneByteOffsetInGSMVGPRStr = funcParameterMap["laneByteOffsetInGSMVGPRStr"]
  tileAddresVGPRStr   = funcParameterMap["tileAddresVGPRStr"]

  uSharpIdList        = funcParameterMap["uSharpIdList"]

  tempVGPRAddr        = funcParameterMap["tempVGPRAddr"]
  inGradientVGPRAddr  = funcParameterMap["inGradientVGPRAddr"]
  inOffsetVGPROffset  = funcParameterMap["inOffsetVGPROffset"]
  vgprBaseStr         = funcParameterMap["vgprBaseStr"]

  vgprStride          = funcParameterMap["vgprStride"]

  # xSGPR/ySGPRStr are coordinates in input gradient/offset surface
  # start from tile (0, 0)
  xSGPRStr            = funcParameterMap["xSGPRStr"]
  coordSGPRStrList    = [xSGPRStr, funcParameterMap["ySGPRStr"], funcParameterMap["zSGPRStr"], funcParameterMap["wSGPRStr"]]

  # outReadXSGPRStr are coordinates to read from output gradient surface
  # start from tile (-1, -1)
  xOutReadSGPRStr     = funcParameterMap["xOutReadSGPRStr"]
  xOutWriteSGPRStr    = funcParameterMap["xOutWriteSGPRStr"]
  coordSGPRStrList2   = [xOutReadSGPRStr, funcParameterMap["yOutSGPRStr"], funcParameterMap["zSGPRStr"], funcParameterMap["wSGPRStr"]]

  # scalar offset to adjust laneAddress
  # 0x80
  addressStepSGPRStr  = funcParameterMap["addressStepSGPRStr"]
  tempSGPRAddr        = funcParameterMap["tempSGPRAddr"]

  fullBlockWidth      = funcParameterMap["fullBlockWidth"]
  partialBlockWidth   = funcParameterMap["partialBlockWidth"]
  bufferGroupType     = funcParameterMap["bufferGroupType"]

  filterStride        = funcParameterMap["filterStride"]

  leftPaddingTile     = funcParameterMap["leftPaddingTile"]
  rightPaddingTile    = funcParameterMap["rightPaddingTile"]
  topPaddingTile      = funcParameterMap["topPaddingTile"]
  bottomPaddingTile   = funcParameterMap["bottomPaddingTile"]

  rightExtraTile      = funcParameterMap["rightExtraTile"]
  bottomExtraTile     = funcParameterMap["bottomExtraTile"]

  gsmBlockSizeX       = funcParameterMap["gsmBlockSizeX"]

  gsmBlockStride      = gsmBlockSizeX * 0x80

  if ((borderType & BorderTypeTop()) != 0):
    # if top, no need to load anything from output gradient surface
    outGradRowNumber = 0
  else:
    outGradRowNumber = topPaddingTile + bottomPaddingTile

  if ((borderType & BorderTypeRight()) == 0):
    inGradColNumber = fullBlockWidth
  else:
    inGradColNumber = partialBlockWidth

  # convert to dst surface space
  if (filterStride != 0):
    outGradColNumber = inGradColNumber << 1
  else:
    outGradColNumber = inGradColNumber

  if ((borderType & BorderTypeRight()) != 0):
    # right padding tile will be dropped if not needed, so no need to reload
    if (rightExtraTile == 0):
      outGradColNumber -= rightPaddingTile

  indentstring = flowHandler.getIndentStr()

  funcLib.AlignPrint (indentstring + "smovs " + vgprBaseStr + ", " + str(inGradientVGPRAddr), flowLib.GetCommentPos(), "// init vgpr base")

  if (outGradRowNumber != 0 and outGradColNumber != 0 and bufferGroupType != BufferRowMode()):
    # load top 2 rows of previously generated output gradient from memory, use sync channel 2
    # only for non row mode
    br_print (indentstring)
    br_print (indentstring + "// TODO - only need to do there is overlap")
    br_print (indentstring + "//      - e.g., if filter is 2 and stride is 2 and padding is 0, there is no overlap")
    br_print (indentstring + "// load top 2 rows of output gradient, which were written in previous call")

    for colIndex in range(outGradColNumber):
      kernelLib.load_4d_activation(hwCaps.SurfaceFormatFP16(), hwCaps.SurfaceFormatFP16(), coordSGPRStrList2, \
        tempVGPRAddr + outGradRowNumber * (rightPaddingTile + colIndex), outGradRowNumber, 2, uSharpIdList[1][0], indentstring)
      br_print (indentstring + "sadd " + xOutReadSGPRStr + ", " + xOutReadSGPRStr + ", " + str(hwCaps.TileSizeX()))

  # load 6x6 input gradient and offset from memory
  br_print (indentstring)
  br_print (indentstring + "// load a block of input gradient and offet")
  flowHandler.startForLoop("0", str(inGradColNumber), "1", -1, "loop in x dir")
  indentstring = flowHandler.getIndentStr()
  kernelLib.load_4d_activation(hwCaps.SurfaceFormatFP16(), hwCaps.SurfaceFormatFP16(), coordSGPRStrList, -1, rowSize, 1, uSharpIdList[0][0], indentstring)
  kernelLib.load_4d_activation(hwCaps.SurfaceFormatSINT8(), hwCaps.SurfaceFormatSINT8(), coordSGPRStrList, -1-inOffsetVGPROffset, rowSize, 1, uSharpIdList[0][1], indentstring)
  br_print (indentstring + "sadda " + vgprBaseStr + ", " + vgprBaseStr + ", " + str(vgprStride))
  funcLib.AlignPrint (indentstring + "sadd " + xSGPRStr + ", " + xSGPRStr + ", " + str(hwCaps.TileSizeX()), flowLib.GetCommentPos(), "// advance in x dir")
  flowHandler.closeForLoop("0", str(inGradColNumber), "1", -1)
  indentstring = flowHandler.getIndentStr()

  br_print (indentstring)

  if (filterStride != 0):
    dstRowSize = rowSize << 1
  else:
    dstRowSize = rowSize

  if (outGradRowNumber != 0):
    br_print (indentstring + "// clear entire " + str(dstRowSize) + " rows from row " + str(outGradRowNumber))
    funcLib.AlignPrint(indentstring + "smov " + addressStepSGPRStr + ", " + hex(outGradRowNumber * gsmBlockStride), flowLib.GetCommentPos(), "// set col's first tile's offset in gsm")
    br_print (indentstring + "addu.b32 " + tileAddresVGPRStr + ", " + laneByteOffsetInGSMVGPRStr + ", " + addressStepSGPRStr)
  else:
    dstRowSize += topPaddingTile + bottomPaddingTile
    br_print (indentstring + "// clear entire " + str(dstRowSize) + " rows from row 0, each row has 8 tiles, offset is 0")
    br_print (indentstring + "mov " + tileAddresVGPRStr + ".u32, " + laneByteOffsetInGSMVGPRStr + ".u32")

  funcLib.AlignPrint(indentstring + "smov " + addressStepSGPRStr + ", 0x80", flowLib.GetCommentPos(), "// set x stride in gsm, each tile has 128B")

  extraRowNumber = topPaddingTile + bottomPaddingTile

  if (extraRowNumber == 0) and (bottomExtraTile != 0) and ((borderType & BorderTypeBottom()) != 0):
    extraRowNumber = bottomExtraTile

  gsmBlock4Number = (dstRowSize * gsmBlockSizeX + 3) >> 2

  flowHandler.startForLoop("0", str(gsmBlock4Number), "1", -1, "clear 4 gsm blocks each time")
  indentstring = flowHandler.getIndentStr()
  funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "// clear 1 tile in gsm")
  br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
  br_print (indentstring + "movi.eog g1.f16, 0.0")
  br_print (indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + addressStepSGPRStr)
  funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "// clear 1 tile in gsm")
  br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
  br_print (indentstring + "movi.eog g1.f16, 0.0")
  br_print (indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + addressStepSGPRStr)
  funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "// clear 1 tile in gsm")
  br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
  br_print (indentstring + "movi.eog g1.f16, 0.0")
  br_print (indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + addressStepSGPRStr)
  funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "// clear 1 tile in gsm")
  br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
  br_print (indentstring + "movi.eog g1.f16, 0.0")
  br_print (indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + addressStepSGPRStr)
  flowHandler.closeForLoop("0", str((rowSize + extraRowNumber - outGradRowNumber) * 2), "1", -1)
  indentstring = flowHandler.getIndentStr()


  if (outGradRowNumber != 0 and bufferGroupType != BufferRowMode()):
    # start from tile (0, 2) in gsm
    funcLib.AlignPrint(indentstring + "nop.sc2", flowLib.GetCommentPos(), "// wait for load output gradient to finish")
    funcLib.AlignPrint(indentstring + "smov q" + str(tempSGPRAddr) + ", " + hex(gsmBlockStride), flowLib.GetCommentPos(), "// set y stride in gsm, 8 tiles, each has 128B")
    br_print (indentstring + "// write 2 rows to gsm")

    if (rightPaddingTile != 0):
      flowHandler.startIfLoop(xOutWriteSGPRStr, "0", "<", 0)
      indentstring = flowHandler.getIndentStr()
      funcLib.AlignPrint(indentstring + "addu.b32 " + tileAddresVGPRStr + ", " + addressStepSGPRStr + ", " + laneByteOffsetInGSMVGPRStr, flowLib.GetCommentPos(), "// move to gsm tile (x=1, y=0)")
      for rowIndex in range (outGradRowNumber):
        funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "// save to gsm row " + str(rowIndex))
        br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
        br_print (indentstring + "mov.eog g1.f16, r" + str(tempVGPRAddr + rowIndex) + ".f16")

        if (rowIndex < (outGradRowNumber - 1)):
          funcLib.AlignPrint(indentstring + "addu.b32 " + tileAddresVGPRStr + ", q" + str(tempSGPRAddr) + ", " + tileAddresVGPRStr, flowLib.GetCommentPos(), "// advance to next row")

      flowHandler.closeIfLoop()
      indentstring = flowHandler.getIndentStr()

    br_print (indentstring + "// store rest cols to code_generator.shared memory, to gsm col " + str(leftPaddingTile + rightPaddingTile))
    funcLib.AlignPrint(indentstring + "smov q" + str(tempSGPRAddr) + ", " + hex((leftPaddingTile + rightPaddingTile) * 0x80), flowLib.GetCommentPos(), "// init gsm address for this col")
    for rowIndex in range (outGradRowNumber):
      funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + laneByteOffsetInGSMVGPRStr + ", q" + str(tempSGPRAddr), flowLib.GetCommentPos(), "// init per lane address in gsm for current row")
      for colIndex in range(outGradColNumber):
        funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "// save previously generated output gradient to gsm")
        br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
        br_print (indentstring + "mov.eog g1.f16, r" + str(tempVGPRAddr + (colIndex + rightPaddingTile) * 2 + rowIndex) + ".f16")
        br_print (indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + addressStepSGPRStr)

      if (rowIndex < (outGradRowNumber - 1)):
        funcLib.AlignPrint(indentstring + "sadd q" + str(tempSGPRAddr) + ", q" + str(tempSGPRAddr) + ", " + hex(gsmBlockStride), flowLib.GetCommentPos(), "// advance to next row")

  br_print (indentstring)
  funcLib.AlignPrint(indentstring + "nop.sc1", flowLib.GetCommentPos(), "// wait for load input gradient/offset to finish")





####################################################
# pbk_block_update
#   use source grad and source offset, accumulate in gsm
#
def pbk_block_update(borderType, rowSize, funcParameterMap, flowHandler):

  indentstring = flowHandler.getIndentStr()

  tempVGPRAddr        = funcParameterMap["tempVGPRAddr"]
  inGradientVGPRAddr  = funcParameterMap["inGradientVGPRAddr"]
  inOffsetVGPROffset  = funcParameterMap["inOffsetVGPROffset"]
  vgprBaseStr         = funcParameterMap["vgprBaseStr"]
  vgprStride          = funcParameterMap["vgprStride"]

  tempSGPRAddr        = funcParameterMap["tempSGPRAddr"]
  addressStepSGPRStr  = funcParameterMap["addressStepSGPRStr"]

  fullBlockWidth      = funcParameterMap["fullBlockWidth"]
  partialBlockWidth   = funcParameterMap["partialBlockWidth"]

  leftPaddingTile     = funcParameterMap["leftPaddingTile"]
  rightPaddingTile    = funcParameterMap["rightPaddingTile"]
  topPaddingTile      = funcParameterMap["topPaddingTile"]
  bottomPaddingTile   = funcParameterMap["bottomPaddingTile"]

  filterStride        = funcParameterMap["filterStride"]
  lanePixelOffsetVGPRStr = funcParameterMap["lanePixelOffsetVGPRStr"]

  gsmBlockSizeX       = funcParameterMap["gsmBlockSizeX"] * hwCaps.TileSizeX()

  # as 64 is too big for imm in alu 2
  if (funcLib.IsPower2(gsmBlockSizeX)):
    gsmYStrideShift = funcLib.GetLeadingOnePos(gsmBlockSizeX)
  else:
    gsmYStrideShift = -1

  if ((borderType & BorderTypeRight()) == 0):
    inGradColNumber = fullBlockWidth
  else:
    inGradColNumber = partialBlockWidth

  ##########################
  # first 2 used as s16 coordinate offset
  # 2nd 2 used as fp32 gradient
  # next 2 used as dst coordinate and gsm addr
  offset16VGPRAddr   = tempVGPRAddr
  fp32GradVGPRAddr   = tempVGPRAddr + 2
  gsmAddrVGPRAddr    = tempVGPRAddr + 4

  gsmTileCoordStr = "q" + str(tempSGPRAddr)
  gsmTileOffsetStr = "q" + str(tempSGPRAddr + 1)

  funcLib.AlignPrint(indentstring + "smov " + gsmTileCoordStr + ", 0", flowLib.GetCommentPos(), "// init tile position, x at low 16b, y at high 16b")
  funcLib.AlignPrint(indentstring + "smovs " + vgprBaseStr + ", " + str(inGradientVGPRAddr), flowLib.GetCommentPos(), "// init vgpr base")

  coordAdjust = 0
  if (leftPaddingTile != 0):
    coordAdjust |= hwCaps.TileSizeX()

  if (topPaddingTile != 0):
    coordAdjust |= hwCaps.TileSizeY() << 8

  if (coordAdjust != 0):
    coordAdjust |= coordAdjust << 16
    funcLib.AlignPrint(indentstring + "smov " + addressStepSGPRStr + ", " + hex(coordAdjust), flowLib.GetCommentPos(), "// init lane offset")

  if (inGradColNumber > 1):
    flowHandler.startForLoop("0", str(inGradColNumber), "1", -1, "loop in x dir")
    indentstring = flowHandler.getIndentStr()

  if (rowSize > 1):
    flowHandler.startForLoop("0", str(rowSize), "1", -1, "loop in y dir")
    indentstring = flowHandler.getIndentStr()

  # offset is 2 channel packed, each has 8bit x offset (LSB) and 8bit y offset (MSB)
  if (coordAdjust != 0):
    funcLib.AlignPrint(indentstring + "adds.b8 ir" + str(inOffsetVGPROffset) + ", ir" + str(inOffsetVGPROffset) + ", " + addressStepSGPRStr, flowLib.GetCommentPos(), "// add a tile offset, as gsm starts from tile (-1, -1)")

  funcLib.AlignPrint(indentstring + "mov r" + str(offset16VGPRAddr) + ".s16, ir" + str(inOffsetVGPROffset) + ".s8", flowLib.GetCommentPos(), "// expand s8 offset to s16")
  funcLib.AlignPrint(indentstring + "mov r" + str(fp32GradVGPRAddr) + ".f32, ir" + str(0) + ".f16", flowLib.GetCommentPos(), "// expand packed fp16 gradient to f32 (decouple channel's gradient)")

  for cid in range (2):
    br_print (indentstring + "// process channel " + str(cid))
    funcLib.AlignPrint(indentstring + "adds.b16 r" + str(gsmAddrVGPRAddr) + ", " + gsmTileCoordStr + ", r" + str(offset16VGPRAddr + cid), flowLib.GetCommentPos(), "// add all offset together")
    if (filterStride != 0):
      funcLib.AlignPrint(indentstring + "adds.b16 r" + str(gsmAddrVGPRAddr) + ", r" + str(gsmAddrVGPRAddr) + ", " + lanePixelOffsetVGPRStr, flowLib.GetCommentPos(), "// adjust for stride 2")
    funcLib.AlignPrint(indentstring + "mov r" + str(gsmAddrVGPRAddr) + ".s32, r" + str(gsmAddrVGPRAddr) + ".s16", flowLib.GetCommentPos(), "// expand to s32")

    if (gsmYStrideShift > 0):
      funcLib.AlignPrint(indentstring + "shl.b32 r" + str(gsmAddrVGPRAddr+1) + ", r" + str(gsmAddrVGPRAddr+1) + ", " + str(gsmYStrideShift), flowLib.GetCommentPos(), "// multiply by y stride in gsm")
    else:
      funcLib.AlignPrint(indentstring + "mulu.b32 r" + str(gsmAddrVGPRAddr+1) + ", r" + str(gsmAddrVGPRAddr+1) + ", " + str(gsmYStrideShift), flowLib.GetCommentPos(), "// multiply by y stride in gsm")

    funcLib.AlignPrint(indentstring + "adds.b32 r" + str(gsmAddrVGPRAddr) + ", r" + str(gsmAddrVGPRAddr) + ", r" + str(gsmAddrVGPRAddr+1), flowLib.GetCommentPos(), "// element addr in gsm")
    funcLib.AlignPrint(indentstring + "shl.b32 r" + str(gsmAddrVGPRAddr) + ", r" + str(gsmAddrVGPRAddr) + ", 2", flowLib.GetCommentPos(), "// byte addr in gsm")
    if (cid != 0):
      funcLib.AlignPrint(indentstring + "adds.b32 r" + str(gsmAddrVGPRAddr) + ", r" + str(gsmAddrVGPRAddr) + ", 2", flowLib.GetCommentPos(), "// high channel")
    funcLib.AlignPrint(indentstring + "atadd.gsm.float.mb16.rb32.rw.e1.gc2 z0, g0, g1", flowLib.GetCommentPos(), "// atomic update gsm")
    br_print (indentstring + "mov g0.u32, r" + str(gsmAddrVGPRAddr) + ".u32")
    br_print (indentstring + "mov.eog g1.f32, r" + str(fp32GradVGPRAddr + cid) + ".f32")

  funcLib.AlignPrint(indentstring + "sadd " + gsmTileCoordStr + ", " + gsmTileCoordStr + ", " + hex(hwCaps.TileSizeY() << (16 + filterStride)), flowLib.GetCommentPos(), "// step in y direction")
  funcLib.AlignPrint(indentstring + "sadda " + vgprBaseStr + ", " + vgprBaseStr + ", 1", flowLib.GetCommentPos(), "// step vgpr base")

  if (rowSize > 1):
    flowHandler.closeForLoop("0", str(rowSize), "1", -1)
    indentstring = flowHandler.getIndentStr()

  if (rowSize < vgprStride):
    funcLib.AlignPrint(indentstring + "sadda " + vgprBaseStr + ", " + vgprBaseStr + ", " + str(vgprStride-rowSize), flowLib.GetCommentPos(), "// step vgpr base")

  funcLib.AlignPrint(indentstring + "sand " + gsmTileCoordStr + ", " + gsmTileCoordStr + ", 0xffff", flowLib.GetCommentPos(), "// reset y coordinate")
  funcLib.AlignPrint(indentstring + "sadd " + gsmTileCoordStr + ", " + gsmTileCoordStr + ", " + hex(hwCaps.TileSizeX() << filterStride), flowLib.GetCommentPos(), "// step in x direction")

  if (inGradColNumber > 1):
    flowHandler.closeForLoop("0", str(inGradColNumber), "1", -1)
    indentstring = flowHandler.getIndentStr()



####################################################
# pbk_col_save_gsm
#   load left 8x6 from gsm and use stm to write out
#

def pbk_block_save(borderType, rowSize, funcParameterMap, flowHandler):
  indentstring = flowHandler.getIndentStr()

  # y (0-3) * stride + x (0-7) inside a tile
  laneByteOffsetInGSMVGPRStr = funcParameterMap["laneByteOffsetInGSMVGPRStr"]
  tileAddresVGPRStr   = funcParameterMap["tileAddresVGPRStr"]

  tempVGPRAddr        = funcParameterMap["tempVGPRAddr"]

  uSharpIdList        = funcParameterMap["uSharpIdList"]

  # outReadXSGPRStr are coordinates to read from output gradient surface
  # start from block start + (0, 8)
  xOutWriteSGPRStr    = funcParameterMap["xOutWriteSGPRStr"]
  coordSGPRStrList    = [xOutWriteSGPRStr, funcParameterMap["yOutSGPRStr"], funcParameterMap["zSGPRStr"], funcParameterMap["wSGPRStr"]]

  bufferGroupType     = funcParameterMap["bufferGroupType"]
  fullBlockWidth      = funcParameterMap["fullBlockWidth"]
  partialBlockWidth   = funcParameterMap["partialBlockWidth"]
  imageWidthRes       = funcParameterMap["imageWidthRes"]
  imageHeightRes      = funcParameterMap["imageHeightRes"]

  addressStepSGPRStr  = funcParameterMap["addressStepSGPRStr"]
  tempSGPRAddr        = funcParameterMap["tempSGPRAddr"]

  leftPaddingTile     = funcParameterMap["leftPaddingTile"]
  rightPaddingTile    = funcParameterMap["rightPaddingTile"]
  topPaddingTile      = funcParameterMap["topPaddingTile"]
  bottomPaddingTile   = funcParameterMap["bottomPaddingTile"]

  filterStride        = funcParameterMap["filterStride"]

  gsmBlockSizeX       = funcParameterMap["gsmBlockSizeX"]
  gsmBlockStride      = gsmBlockSizeX * 0x80

  gsmAddrVGPRAddr     = tempVGPRAddr + 4


  if ((borderType & BorderTypeRight()) == 0):
    # first tile's left padding is oob and can be skipped
    colNumber = fullBlockWidth
  else:
    colNumber = partialBlockWidth

  if (filterStride != 0):
    colNumber <<= 1
    rowSize <<= 1

  if ((borderType & BorderTypeRight()) != 0) and (bufferGroupType != BufferRowMode()):
    # inlcude left padding
    colNumber += leftPaddingTile

  if ((borderType & BorderTypeTop()) == 0):
    # add top padding
    rowSize += topPaddingTile

  if ((borderType & BorderTypeBottom()) == 0):
    # add bottom padding
    rowSize += bottomPaddingTile
    isColPartial = False
  else:
    isColPartial = imageHeightRes != 0

  br_print (indentstring)
  br_print (indentstring + "// load from gsm and write to output gradient surface")
  br_print (indentstring + "// tile stride is always 128B or 0x80 in x dir")
  br_print (indentstring + "// q" + str(tempSGPRAddr) + " holds start offset of a tile col, initialized at col start, advanced by 0x80 when moving in y dir")

  # set up x/y stride in gsm
  funcLib.AlignPrint(indentstring + "smov " + addressStepSGPRStr + ", " + hex(gsmBlockStride), flowLib.GetCommentPos(), "// y stride in gsm, 8 tile * 128B each")

  tileStartAddrInGSM = 0

  if ((borderType & BorderTypeTop()) and (topPaddingTile != 0)):
    br_print (indentstring + "// first valid tile starts from gsm row " + str(topPaddingTile))
    tileStartAddrInGSM = topPaddingTile * gsmBlockStride
  else:
    br_print (indentstring + "// first valid tile starts from gsm row 0")
    tileStartAddrInGSM = 0x0

  if (bufferGroupType == BufferRowMode() and leftPaddingTile != 0):
    tileStartAddrInGSM += leftPaddingTile * 0x80
    br_print (indentstring + "// first valid tile starts from gsm col " + str(leftPaddingTile))
  else:
    br_print (indentstring + "// first valid tile starts from gsm col 0")

  funcLib.AlignPrint(indentstring + "smov q" + str(tempSGPRAddr) + ", " + hex(tileStartAddrInGSM), flowLib.GetCommentPos(), "// set tile start addr in gsm")

  if (bufferGroupType == BufferRowMode()) and ((borderType & BorderTypeBottom()) == 0):
    funcLib.AlignPrint(indentstring + "smov q" + str(tempSGPRAddr + 1) + ", 0x80", flowLib.GetCommentPos(), "// for copying bottom row to top, init tile write start addr, from gsm col 1")

  groupNumber = colNumber
  syncChannelNumber = 2

  br_print (indentstring + "// group number = " + str(groupNumber))

   # right boundary, so has to take out of loop
  if ((borderType & BorderTypeRight()) != 0 and imageWidthRes != 0):
    groupNumber -= 1
    tailNumber = 1
  else:
    tailNumber = 0

  bodyNumber = 0

  if (groupNumber >= syncChannelNumber):
    headNumber = syncChannelNumber - 1
    tailNumber += (groupNumber - headNumber) % syncChannelNumber
    loopNumber = int ((groupNumber - headNumber) / syncChannelNumber)

    if (loopNumber != 0):
      bodyNumber = syncChannelNumber
  else:
    headNumber = groupNumber
    loopNumber = 0

  loadNumber = headNumber + bodyNumber + tailNumber

  overlapColNumber = 0
  if (bufferGroupType != BufferRowMode()) and ((borderType & BorderTypeRight()) == 0):
    overlapColNumber = (leftPaddingTile + rightPaddingTile)
    loadNumber += overlapColNumber

  overlapRowNumber = topPaddingTile + bottomPaddingTile

  lastLoadIndex = loadNumber - 1
  expandNumber = headNumber + bodyNumber + tailNumber + headNumber
  lastAluIndex = expandNumber - 1

  if (expandNumber < loadNumber):
    expandNumber = loadNumber

  # load takes headNumber + bodyNumber + tailNumber
  # alu starts from headNumber
  br_print (indentstring + "// loop number = " + str(loopNumber))
  br_print (indentstring + "// head: " + str(headNumber) + ", body: " + str(bodyNumber) + ", tail: " + str(tailNumber))

  loadIndex = 0
  aluIndex = 0

  for z in range (expandNumber):

    if (z == headNumber and loopNumber > 1):
      br_print (indentstring)
      flowHandler.startForLoop("0", str(loopNumber), "1", -1, "")
      indentstring = flowHandler.getIndentStr()

    if (z <= lastLoadIndex):
      br_print (indentstring)

      funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + laneByteOffsetInGSMVGPRStr + ", q" + str(tempSGPRAddr), flowLib.GetCommentPos(), "// init per lane address in gsm for current col")

      for rowIndex in range(int(rowSize)):
        br_print (indentstring + "ld.gsm.float.mb16.rb16.sc" + str(loadIndex + 1) + ".e2.gc1 r" + str(tempVGPRAddr + loadIndex * 8 + rowIndex) + ", g0")
        br_print (indentstring + "mov.eog g0.u32, " + tileAddresVGPRStr + ".u32")
        if (rowIndex != (rowSize-1)):
          if (rowIndex == 0):
            funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + str(addressStepSGPRStr), flowLib.GetCommentPos(), "// advance to next row")
          else:
            funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + str(addressStepSGPRStr), flowLib.GetCommentPos(), "")

      funcLib.AlignPrint(indentstring + "sadd q" + str(tempSGPRAddr) + ", q" + str(tempSGPRAddr) + ", 0x80", flowLib.GetCommentPos(), "// advance to next col in gsm")
      loadIndex = funcLib.IncAndWrap(loadIndex, syncChannelNumber)

    if (z >= headNumber and z <= lastAluIndex):
      br_print (indentstring)
      syncId = aluIndex + 1
      funcLib.AlignPrint(indentstring + "nop.sc" + str(syncId), flowLib.GetCommentPos(), "// wait for data return from gsm")
      thisVGPRAddr = tempVGPRAddr + aluIndex * 8
      if (z == lastAluIndex and imageWidthRes != 0):
        funcLib.AlignPrint(indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(0, imageWidthRes, 1)), flowLib.GetCommentPos(), "// pool result may be from oob, so clear oob at here")
        if (not isColPartial):
          kernelLib.mov_imm_v(hwCaps.SurfaceFormatFP16(), thisVGPRAddr, rowSize, "0.0", "m0.", indentstring)
        else:
          if (rowSize > 1):
            kernelLib.mov_imm_v(hwCaps.SurfaceFormatFP16(), thisVGPRAddr, rowSize - 1, "0.0", "m0.", indentstring)

          br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(imageHeightRes, imageWidthRes, 1)))
          kernelLib.mov_imm_v(hwCaps.SurfaceFormatFP16(), thisVGPRAddr + rowSize - 1, 1, "0.0", "m0.", indentstring)
      else:
        if (isColPartial):
          br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(imageHeightRes, 0, 1)))
          kernelLib.mov_imm_v(hwCaps.SurfaceFormatFP16(), thisVGPRAddr + rowSize - 1, 1, "0.0", "m0.", indentstring)

      if (bufferGroupType == BufferRowMode()) and ((borderType & BorderTypeBottom()) == 0) and (overlapRowNumber != 0):
        br_print (indentstring)
        br_print (indentstring + "// copy bottom " + str(overlapRowNumber) + " rows to top")
        funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + laneByteOffsetInGSMVGPRStr + ", q" + str(tempSGPRAddr+1), flowLib.GetCommentPos(), "// init per lane address in gsm for current col")
        funcLib.AlignPrint(indentstring + "sadd q" + str(tempSGPRAddr+1) + ", q" + str(tempSGPRAddr+1) + ", 0x80", flowLib.GetCommentPos(), "// advance to next col")
        for rowIndex in range (overlapRowNumber):
          funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "")
          br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
          br_print (indentstring + "mov.eog g1.f16, r" + str(thisVGPRAddr + rowSize - 2 + rowIndex) + ".f16")
          br_print (indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + addressStepSGPRStr)

      kernelLib.store_4d_activation(hwCaps.SurfaceFormatFP16(), hwCaps.SurfaceFormatFP16(), coordSGPRStrList, thisVGPRAddr, rowSize, uSharpIdList[1][0], indentstring)
      funcLib.AlignPrint(indentstring + "sadd " + coordSGPRStrList[0] + ", " + coordSGPRStrList[0] + ", " + str(hwCaps.TileSizeX()), flowLib.GetCommentPos(), "// advance to next col in output gradient surface")

      #if (z == expandNumber-1 and lastVGPRLaneNumber != 0):
      #  funcLib.AlignPrint(indentstring + "smovs wm0, " + hex((0xffffffff << lastVGPRLaneNumber) & 0xffffffff), GetCommentPos(), "// set m0 mask")
      #  funcLib.AlignPrint(indentstring + "m0.movi.sc" + str(syncId) + " ir" + str(aluVGPRNumber - 1) + ".f32, 0.0", GetCommentPos(), "// clear invalid lane to 0")
      #  syncId = 0
      aluIndex = funcLib.IncAndWrap(aluIndex, syncChannelNumber)

    if (z == (headNumber + bodyNumber - 1) and loopNumber > 1):
      flowHandler.closeForLoop("0", str(loopNumber), "1", -1)
      indentstring = flowHandler.getIndentStr()

  if (bufferGroupType == BufferRowMode()):
    pass
  else:
    if ((borderType & BorderTypeRight()) == 0) and (overlapColNumber != 0):
      br_print (indentstring)
      br_print (indentstring + "// copy right " + str(overlapColNumber) + " cols to left")
      if ((borderType & BorderTypeTop()) and (topPaddingTile != 0)):
        funcLib.AlignPrint(indentstring + "smov q" + str(tempSGPRAddr) + ", " + hex(topPaddingTile * gsmBlockStride), flowLib.GetCommentPos(), "// top band starts from row 1")
      else:
        funcLib.AlignPrint(indentstring + "smov q" + str(tempSGPRAddr) + ", 0", flowLib.GetCommentPos(), "// starts from row 0")

      for colIndex in range (overlapColNumber):
        funcLib.AlignPrint(indentstring + "adds.b32.sc" + str(colIndex+1) + " " + tileAddresVGPRStr + ", " + laneByteOffsetInGSMVGPRStr + ", q" + str(tempSGPRAddr), flowLib.GetCommentPos(), "// init per lane address in gsm for current col, and wait for data back from gsm")
        for rowIndex in range(int(rowSize)):
          funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "")
          br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
          br_print (indentstring + "mov.eog g1.f16, r" + str(tempVGPRAddr + colIndex * 8 + rowIndex) + ".f16")

          if (rowIndex != (rowSize-1)):
            if (rowIndex == 0):
              funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + str(addressStepSGPRStr), flowLib.GetCommentPos(), "// advance to next row")
            else:
              funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + str(addressStepSGPRStr), flowLib.GetCommentPos(), "")

        if (colIndex == 0):
          br_print (indentstring)
          funcLib.AlignPrint(indentstring + "sadd q" + str(tempSGPRAddr) + ", q" + str(tempSGPRAddr) + ", 0x80", flowLib.GetCommentPos(), "// advance to next col in gsm")







####################################################
# nextColX is next col's x coordinates, only set for inner cols (i.e. except right 2 cols) in loop unroll mode

def pbk_tile_col(instrOp, isaModifier, vgprAddr, vgprNumber, vgprStride, vgprDstStart, colBorderType, \
                 funcParameterMap, flowHandler):

  indentstring   = flowHandler.getIndentStr()

  imageWidthRes  = funcParameterMap["imageWidthRes"]
  imageHeightRes = funcParameterMap["imageHeightRes"]
  xSGPRStr       = funcParameterMap["xSGPRStr"]
  ySGPRStr       = funcParameterMap["ySGPRStr"]
  zSGPRStr       = funcParameterMap["zSGPRStr"]
  wSGPRStr       = funcParameterMap["wSGPRStr"]
  uSharpIdList   = funcParameterMap["uSharpIdList"]

  # handle dwc
  isRowPartial = (colBorderType & BorderTypeBottom()) and (imageHeightRes != 0)

  # special handling of last row
  if (isRowPartial):
    vgprNumber -= 1

  isColPartial = ((colBorderType & BorderTypeRight()) and (imageWidthRes != 0))

  if (isColPartial):
    br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(0, imageWidthRes, 1)))

  sizeList = funcLib.SplitRepeatIntoGroups(vgprNumber, hwCaps.MaxSTMGranule())
  sizeListLen = len(sizeList)
  arrayIndex = 0
  yChange = 0

  usharpStr = str(uSharpIdList[1][0])

  # clear bottom flag at first
  tileBorderType = colBorderType & ~BorderTypeBottom()

  for thisArray in sizeList:
    arrayIndex += 1

    for z in range(thisArray[0]):

      if ((not isRowPartial) and (arrayIndex == sizeListLen) and (z == (thisArray[0] - 1))):
        # last group
        tileBorderType |= (colBorderType & BorderTypeBottom())

      pbk_tile_v(vgprAddr, vgprStride, vgprDstStart, 0, tileBorderType, funcParameterMap, flowHandler)

      if (isColPartial):
        br_print (indentstring + "m0.movi" + kernelLib.GetVectorModifier(thisArray[1] << 1, "v") + " r"+ str(vgprDstStart) + ".f16, 0.0")

      store_tile_v(thisArray[1], usharpStr, indentstring)

      br_print (indentstring + "mov" + kernelLib.GetVectorModifier(thisArray[1] << 1, "v") + " g4.f16, " + "r" + str(vgprDstStart) + ".f16")

      br_print (indentstring + "smovg g0, " + xSGPRStr)
      br_print (indentstring + "smovg g1, " + ySGPRStr)
      br_print (indentstring + "smovg g2, " + zSGPRStr)
      br_print (indentstring + "smovg.eog g3, " + wSGPRStr)
      vgprAddr += thisArray[1]

      if (isRowPartial or (arrayIndex != sizeListLen) or (z != (thisArray[0] - 1))):
        yChange += thisArray[1]
        br_print (indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(thisArray[1] * hwCaps.TileSizeY()))

      tileBorderType = tileBorderType & ~BorderTypeTop()

  if (isRowPartial):
    tileBorderType |= (colBorderType & BorderTypeBottom())
    pbk_tile_v(vgprAddr, vgprStride, vgprDstStart, 0, tileBorderType, funcParameterMap, flowHandler)

    if (isColPartial):
      br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(imageHeightRes, imageWidthRes, 1)))
    else:
      br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(imageHeightRes, 0, 1)))

    br_print (indentstring + "m0.movi.v2" + " r"+ str(vgprDstStart) + ".f16, 0.0")
    store_tile_v(1, usharpStr, indentstring)
    br_print (indentstring + "smovg g0, " + xSGPRStr)
    br_print (indentstring + "smovg g1, " + ySGPRStr)
    br_print (indentstring + "smovg g2, " + zSGPRStr)
    br_print (indentstring + "smovg.eog g3, " + wSGPRStr)

  if (yChange != 0):
    br_print (indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(-yChange * hwCaps.TileSizeY()))










################################################################################################################
# sub function generators
# sub function will be called at run time
# it uses some q/r registers as parameter
################################################################################################################




####################################################
# gen_pbk_sub_function
def gen_pbk_sub_function(yBorderType, rowSize, rightBorderMode, funcParameterMap, flowHandler):

  uSharpIdList      = funcParameterMap["uSharpIdList"]

  xSGPRStr          = funcParameterMap["xSGPRStr"]
  ySGPRStr          = funcParameterMap["ySGPRStr"]

  vgprBaseStr       = funcParameterMap["vgprBaseStr"]
  tempVGPRAddr      = funcParameterMap["tempVGPRAddr"]
  vgprStride        = funcParameterMap["vgprStride"]

  fullBlockWidth    = funcParameterMap["fullBlockWidth"]
  partialBlockWidth = funcParameterMap["partialBlockWidth"]

  filterStride      = funcParameterMap["filterStride"]
  leftPaddingTile   = funcParameterMap["leftPaddingTile"]
  topPaddingTile    = funcParameterMap["topPaddingTile"]
  rightPaddingTile  = funcParameterMap["rightPaddingTile"]
  bottomPaddingTile = funcParameterMap["bottomPaddingTile"]


  coordSGPRStrList  = [xSGPRStr, ySGPRStr, funcParameterMap["zSGPRStr"], funcParameterMap["wSGPRStr"]]

  imageWidthRes  = funcParameterMap["imageWidthRes"]
  imageHeightRes  = funcParameterMap["imageHeightRes"]

  indentstring = flowHandler.getIndentStr()

  br_print (indentstring + "// funciton gen_pbk_sub_function")
  br_print (indentstring + "// gsm holds (block start row-1, block start col-1) to (block end row+1, block start end+1)")
  br_print (indentstring + "// naming rule:")
  br_print (indentstring + "//    yBorderType_blockHeight_rightBorder")
  br_print (indentstring + "//    yBorderType    - y border info, top/bottom or both")
  if (yBorderType & BorderTypeTop()):
    br_print (indentstring + "//                   - top border")
  if (yBorderType & BorderTypeRight()):
    br_print (indentstring + "//                   - right border")
  if (yBorderType & BorderTypeBottom()):
    br_print (indentstring + "//                   - bottom border")
  if (yBorderType & BorderTypeLeft()):
    br_print (indentstring + "//                   - left border")

  br_print (indentstring + "//    blockHeight    - row number of current block")
  br_print (indentstring + "//    rightBorder    - whether it is right border, different width and border handling")
  if (rightBorderMode != 0):
    br_print (indentstring + "//                   - right border")

  blockBorderType = yBorderType

  if (rightBorderMode != 0):
    blockBorderType |= BorderTypeRight()

  br_print (indentstring)

  pbk_block_load(blockBorderType, rowSize, funcParameterMap, flowHandler)
  pbk_block_update(blockBorderType, rowSize, funcParameterMap, flowHandler)
  pbk_block_save(blockBorderType, rowSize, funcParameterMap, flowHandler)








####################################################
# called whenever starting a new slice (sample or channel)
# initialize y coordinate for load/alu
# for block/row mode, load starts from row 0 or -1 depends on whether there is top band
# for row mode, load row 0, also load row -1 if non top band
# no need to clear row -1 for top band
# top band is always separated from other bands

def do_y_initialize(vgprStride, colSize, yBorderType, funcParameterMap, flowHandler):
  indentstring = flowHandler.getIndentStr()

  ySGPRStr = funcParameterMap["ySGPRStr"]
  yOutSGPRStr = funcParameterMap["yOutSGPRStr"]

  funcLib.AlignPrint(indentstring + "smov " + ySGPRStr + ", 0", flowLib.GetCommentPos(), "// init input grad/offset's y")
  funcLib.AlignPrint(indentstring + "smov " + yOutSGPRStr + ", 0", flowLib.GetCommentPos(), "// init output grad's y")






####################################################
# called whenever starting a new band
# initialize x coordinate for load/alu
# for block/col mode, load col 0, also load col -1 or clear col -1
#   following load starts from col 1

def do_x_initialize(vgprStride, yBorderType, funcParameterMap, flowHandler):

  indentstring = flowHandler.getIndentStr()

  xSGPRStr          = funcParameterMap["xSGPRStr"]
  xOutReadSGPRStr   = funcParameterMap["xOutReadSGPRStr"]
  xOutWriteSGPRStr  = funcParameterMap["xOutWriteSGPRStr"]
  bufferGroupType   = funcParameterMap["bufferGroupType"]

  leftPaddingTile   = funcParameterMap["leftPaddingTile"]
  rightPaddingTile  = funcParameterMap["rightPaddingTile"]


  funcLib.AlignPrint(indentstring + "smov " + xSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize in grad/offset's x coord")
  funcLib.AlignPrint(indentstring + "smov " + xOutReadSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize out grad read's x coord")

  if (bufferGroupType != BufferRowMode() and leftPaddingTile != 0):
    # write starts from left padding tile
    # usually rely on OOB to drop left padding tile, but at row mode, as there is only 1 block, we could skip writing left padding tile
    funcLib.AlignPrint(indentstring + "smov " + xOutWriteSGPRStr + ", " + str(-hwCaps.TileSizeX()), flowLib.GetCommentPos(), "// initialize out grad write's x coord")
  else:
    funcLib.AlignPrint(indentstring + "smov " + xOutWriteSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize out grad write's x coord")

  # usually leftPaddingTile + rightPaddingTile need to be kept when switching to next block in x dir
  # each block will load right padding tile from its right block
  # so initializer shall load right padding tile for first block
  # first block's left padding tile eventually will be dropped, so no need to load
  if ((yBorderType & BorderTypeTop()) == 0) and (bufferGroupType != BufferRowMode()) and (rightPaddingTile != 0):
    br_print (indentstring + "// load output gradient col 0 and store to gsm col 1 later")
    uSharpIdList    = funcParameterMap["uSharpIdList"]
    tempVGPRAddr    = funcParameterMap["tempVGPRAddr"]

    rowNumber       = funcParameterMap["topPaddingTile"] + funcParameterMap["bottomPaddingTile"]

    coordSGPRStrList2   = [xOutReadSGPRStr, funcParameterMap["yOutSGPRStr"], funcParameterMap["zSGPRStr"], funcParameterMap["wSGPRStr"]]

    kernelLib.load_4d_activation(hwCaps.SurfaceFormatFP16(), hwCaps.SurfaceFormatFP16(), coordSGPRStrList2, tempVGPRAddr, rowNumber, 2, uSharpIdList[1][0], indentstring)








####################################################
# process a horizontal band

def pbk_kernel_process_channel_group(layerId, warpId, wSize, surfacePartition, funcParameterMap, funcGenHandler, flowHandler):

  uSharpIdList      = funcParameterMap["uSharpIdList"]

  xSGPRStr          = funcParameterMap["xSGPRStr"]
  ySGPRStr          = funcParameterMap["ySGPRStr"]
  zSGPRStr          = funcParameterMap["zSGPRStr"]
  wSGPRStr          = funcParameterMap["wSGPRStr"]

  yOutSGPRStr       = funcParameterMap["yOutSGPRStr"]
  xOutReadSGPRStr   = funcParameterMap["xOutReadSGPRStr"]
  xOutWriteSGPRStr  = funcParameterMap["xOutWriteSGPRStr"]

  tempVGPRAddr      = funcParameterMap["tempVGPRAddr"]

  vgprBaseStr       = funcParameterMap["vgprBaseStr"]
  euIdSGPRStr       = funcParameterMap["euIdSGPRStr"]

  topPaddingTile    = funcParameterMap["topPaddingTile"]
  filterStride      = funcParameterMap["filterStride"]

  indentstring = flowHandler.getIndentStr()

  funcLib.AlignPrint(indentstring + "smov " + wSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize w")
  if (wSize > 1):
    flowHandler.startForLoop("", str(wSize), str(1), funcParameterMap["wSGPRIndex"], "loop sample/test")

  indentstring = flowHandler.getIndentStr()

  vgprStride = surfacePartition[0][0]
  ySpanList = surfacePartition[1]
  xSpanList = surfacePartition[2]

  ySpanListSize = len(ySpanList)

  do_y_initialize(vgprStride, xSpanList[0], ySpanList[0][2], funcParameterMap, flowHandler)

  for ySpan in ySpanList:
    thisSpanHeight  = ySpan[0]
    thisBlockHeight = ySpan[1]
    thisBorderFlagY = ySpan[2]

    indentstring = flowHandler.getIndentStr()

    br_print (indentstring + "//////////////////////////////////////////////")
    if ((thisBorderFlagY & BorderTypeTop()) or (thisBorderFlagY & BorderTypeBottom())):
      assert (thisSpanHeight == thisBlockHeight), "top or bottom border span can't be in loop"

      if ((thisBorderFlagY & BorderTypeTop()) and (thisBorderFlagY & BorderTypeBottom())):
        br_print (indentstring + "// process signle horizontal band, both top and bottom")
      elif (thisBorderFlagY & BorderTypeTop()):
        br_print (indentstring + "// process top horizontal band")
      else:
        br_print (indentstring + "// process bottom horizontal band")
    else:
      br_print (indentstring + "// process middle horizontal band")

    vgprRowNumber = thisBlockHeight
    vgprStartIndex = vgprStride

    thisSpanWidth   = xSpanList[0]
    thisBlockWidth  = xSpanList[1]

    blockNumberY = int (thisSpanHeight / thisBlockHeight)
    blockNumberX = int (thisSpanWidth / thisBlockWidth)

    if (blockNumberY > 1):
      flowHandler.startForLoop(str(0), str(blockNumberY), str(1), -1, "loop y")
      indentstring = flowHandler.getIndentStr()

    br_print (indentstring + "// initialize whenever switching to a new horizontal band")

    do_x_initialize(vgprStride, ySpan[2], funcParameterMap, flowHandler)

    br_print (indentstring + "// finish initializing horizontal band")

    if (blockNumberX != 0):
      if (blockNumberX > 1):
        flowHandler.startForLoop(str(0), str(blockNumberX), str(1), -1, "loop x")
        indentstring = flowHandler.getIndentStr()

      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_0"
      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

      if (blockNumberX > 1):
        flowHandler.closeForLoop(str(0), str(blockNumberX), str(1), -1)
        indentstring = flowHandler.getIndentStr()

    functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_1"
    funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
    flowHandler.startFunctionCall(functionName)
    flowHandler.endFunctionCall()

    br_print (indentstring)
    if ((thisBorderFlagY & BorderTypeBottom()) == 0):
      br_print (indentstring + "// switch to next band")
      funcLib.AlignPrint(indentstring + "fll1", flowLib.GetCommentPos(), "// flush l1 so that next band can get latest data from output gradient")
      funcLib.AlignPrint(indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(thisBlockHeight * hwCaps.TileSizeY()), flowLib.GetCommentPos(), "// adjust input grad/offset's y")

      if (filterStride != 0):
        dstYStep = thisBlockHeight << 1
      else:
        dstYStep = thisBlockHeight

      if (thisBorderFlagY & BorderTypeTop()) and (topPaddingTile != 0):
        if (dstYStep != topPaddingTile):
          br_print (indentstring + "// top band starts from row=0, and next band should start from row -topPaddingTile")
          funcLib.AlignPrint(indentstring + "sadd " + yOutSGPRStr + ", " + yOutSGPRStr + ", " + str((dstYStep - topPaddingTile)*hwCaps.TileSizeY()), flowLib.GetCommentPos(), "// adjust output grad's y")
      else:
        funcLib.AlignPrint(indentstring + "sadd " + yOutSGPRStr + ", " + yOutSGPRStr + ", " + str(dstYStep*hwCaps.TileSizeY()), flowLib.GetCommentPos(), "// adjust output grad's y")

    if (blockNumberY > 1):
      flowHandler.closeForLoop(str(0), str(blockNumberY), str(1), -1)
      indentstring = flowHandler.getIndentStr()

    isFirstSub = 0

  if (wSize > 1):
    flowHandler.closeForLoop("", str(wSize), str(1), funcParameterMap["wSGPRIndex"])








####################################################
# set_layer_parameter
#   set layer related info and other info
#
def set_layer_parameter(funcParameterMap, layerInfo):

  optionsIndex = cwarp.GetOptionsIndex()
  uSharpIndex = cwarp.GetUSharpIndex()

  srcSurfaceWidth   = layerInfo[uSharpIndex][0][usharp.GetSurfCoordXIndex()]
  srcSurfaceHeight  = layerInfo[uSharpIndex][0][usharp.GetSurfCoordYIndex()]
  dstSurfaceWidth   = layerInfo[uSharpIndex][-1][usharp.GetSurfCoordXIndex()]
  dstSurfaceHeight  = layerInfo[uSharpIndex][-1][usharp.GetSurfCoordYIndex()]

  filterSizeX       = layerInfo[optionsIndex][GetFilterSizeX()]
  filterSizeY       = layerInfo[optionsIndex][GetFilterSizeY()]
  filterOffsetX     = layerInfo[optionsIndex][GetFilterOffsetX()]
  filterOffsetY     = layerInfo[optionsIndex][GetFilterOffsetY()]
  filterStride      = layerInfo[optionsIndex][GetFilterStrideIndex()]

  if (filterStride != 0):
    alignedSrcWidth   = srcSurfaceWidth << 1
    alignedSrcHeight  = srcSurfaceHeight << 1
  else:
    alignedSrcWidth   = srcSurfaceWidth
    alignedSrcHeight  = srcSurfaceHeight

  alignedSrcWidth   = funcLib.AlignToUnit(alignedSrcWidth, hwCaps.TileSizeX())
  alignedSrcHeight  = funcLib.AlignToUnit(alignedSrcHeight, hwCaps.TileSizeY())
  alignedDstWidth   = funcLib.AlignToUnit(dstSurfaceWidth, hwCaps.TileSizeX())
  alignedDstHeight  = funcLib.AlignToUnit(dstSurfaceHeight, hwCaps.TileSizeY())

  rightExtraTile = int ((alignedDstWidth - alignedSrcWidth) / hwCaps.TileSizeX())
  bottomExtraTile = int ((alignedDstHeight - alignedSrcHeight) / hwCaps.TileSizeY())


  # padding means when we process a block, whether we need a padding tile in each of 4 directions
  # padding tile needs to be saved when switch to a new block
  if (filterOffsetX != 0):
    leftPadding = 1
  else:
    leftPadding = 0

  if (filterOffsetY != 0):
    topPadding = 1
  else:
    topPadding = 0

  if (filterSizeX <= (filterOffsetX + 1)) or (filterStride != 0 and filterSizeX == 2 and filterOffsetX == 0):
    rightPadding = 0
  else:
    rightPadding = 1

  if (filterSizeY <= (filterOffsetY + 1)) or (filterStride != 0 and filterSizeY == 2 and filterOffsetY == 0):
    bottomPadding = 0
  else:
    bottomPadding = 1

  funcParameterMap["filterStride"]        = filterStride
  funcParameterMap["imageWidthRes"]       = dstSurfaceWidth & (hwCaps.TileSizeX() - 1)
  funcParameterMap["imageHeightRes"]      = dstSurfaceHeight & (hwCaps.TileSizeY() - 1)
  funcParameterMap["rightExtraTile"]      = rightExtraTile
  funcParameterMap["bottomExtraTile"]     = bottomExtraTile

  funcParameterMap["leftPaddingTile"]     = leftPadding
  funcParameterMap["topPaddingTile"]      = topPadding
  funcParameterMap["rightPaddingTile"]    = rightPadding
  funcParameterMap["bottomPaddingTile"]   = bottomPadding


  uSharpIdList = [[layerInfo[uSharpIndex][0][usharp.GetSurfUsharpIDIndex()],    #   input gradient
                   layerInfo[uSharpIndex][1][usharp.GetSurfUsharpIDIndex()]],   #   input offset
                  [layerInfo[uSharpIndex][-1][usharp.GetSurfUsharpIDIndex()]]]  #   output gradient

  funcParameterMap["uSharpIdList"]    = uSharpIdList



####################################################
# set_vgpr_number
#   find out how many vgprs can be used as load buffer
#
def set_vgpr_number(vgprPartition, funcParameterMap):
  if (vgprPartition[1] <= vgprPartition[0]):
    assert False, "  no vgpr to use"

  vgprStart = vgprPartition[0]
  vgprNumber = vgprPartition[1] - vgprPartition[0]

  vgprTempNumber = 16

  funcParameterMap["laneOffsetVGPRAddr"] = vgprStart
  vgprNumber -= 2
  vgprStart += 2

  funcParameterMap["tileAddresVGPRAddr"] = vgprStart
  vgprNumber -= 1
  vgprStart += 1

  funcParameterMap["tempVGPRAddr"]   = vgprStart
  vgprNumber -= vgprTempNumber
  vgprStart += vgprTempNumber

  funcParameterMap["vgprNumber"]      = vgprNumber

  inGradVGPRNumber = 36

  funcParameterMap["inGradientVGPRAddr"]  = vgprStart
  vgprNumber -= inGradVGPRNumber
  vgprStart += inGradVGPRNumber

  funcParameterMap["inOffsetVGPROffset"]  = vgprStart - funcParameterMap["inGradientVGPRAddr"]





####################################################
# find out block size
#
def get_pbk_block_size(surfaceTileInfo, funcParameterMap, vgprNumber):

  # 8x8*0x80 = 8k, that is each EU can get from gsm
  gsmBlockSizeX = 8
  gsmBlockSizeY = 8

  blockUnitX = gsmBlockSizeX
  blockUnitY = gsmBlockSizeY

  leftPaddingTile     = funcParameterMap["leftPaddingTile"]
  topPaddingTile      = funcParameterMap["topPaddingTile"]
  rightPaddingTile    = funcParameterMap["rightPaddingTile"]
  bottomPaddingTile   = funcParameterMap["bottomPaddingTile"]
  filterStride        = funcParameterMap["filterStride"]

  blockUnitX -= (leftPaddingTile + rightPaddingTile)
  blockUnitY -= (topPaddingTile + bottomPaddingTile)

  if (filterStride != 0):
    # stride, source surface will be expanded 2 times in x/y direction
    blockUnitX >>= 1
    blockUnitY >>= 1

  return (blockUnitX, blockUnitY, gsmBlockSizeX, gsmBlockSizeY)



####################################################
# find out buffer mode
#
def get_pbk_buffer_mode(surfaceTileInfo, blockUnit, vgprNumber):
  xSize = surfaceTileInfo[3]

  if (xSize <= blockUnit[0]):
    bufferMode = BufferRowMode()
  else:
    bufferMode = BufferBlockMode()

  return bufferMode





####################################################

def get_pbk_surface_partition(surfaceTileInfo, vgprNumber, borderType, funcParameterMap, indendString):

  blockUnit = get_pbk_block_size(surfaceTileInfo, funcParameterMap, vgprNumber)

  bufferConfig = get_pbk_buffer_mode(surfaceTileInfo, blockUnit, vgprNumber)

  topPaddingTile      = funcParameterMap["topPaddingTile"]

  ySize = surfaceTileInfo[2]
  xSize = surfaceTileInfo[3]
  xUnit = blockUnit[0]
  yUnit = blockUnit[1]

  if (yUnit == 0 or xUnit == 0):
    assert False, "  not enough vgprs, can't find a block that can fit " + str(vgprNumber) + " vgprs"

  partitionList = []

  yTopFlag = borderType & BorderTypeTop()
  yBottomFlag = borderType & (BorderTypeBottom() | BorderTypeBottomPartial())

  yAlignedSize = int (ySize / yUnit) * yUnit
  yRemainder = ySize - yAlignedSize

  ySpanList = []

  if (yRemainder == 0 and yAlignedSize != 0):
    yAlignedSize -= yUnit
    yRemainder += yUnit

  if (yAlignedSize != 0):
    if (topPaddingTile != 0):
      # first one is top, last one is bottom
      ySpanList.append([yUnit, yUnit, yTopFlag])
      yAlignedSize -= yUnit

    if (yAlignedSize != 0):
      ySpanList.append([yAlignedSize, yUnit, 0])

  ySpanList.append([yRemainder, yRemainder, 0])
  # first one is top, last one is bottom
  ySpanList[-1][2] |= yBottomFlag

  xBorderFlag = borderType & (BorderTypeRight() | BorderTypeRightPartial())

  xAlignedSize = int (xSize / xUnit) * xUnit
  partialBlockWidth = xSize - xAlignedSize

  if (partialBlockWidth == 0):
    partialBlockWidth += xUnit
    xAlignedSize -= xUnit

  xSpanList = [xAlignedSize, xUnit, xBorderFlag]

  vgprStride = yUnit

  return ([vgprStride, bufferConfig], ySpanList, xSpanList, [partialBlockWidth, blockUnit[2], blockUnit[3]])





####################################################
# set_surface_parameter
#   set surface related info such as border info, block width etc
#
def set_surface_parameter(funcParameterMap, surfacePartition):
  vgprStride = surfacePartition[0][0]
  bufferGroupType = surfacePartition[0][1]

  fullHeight = surfacePartition[1][0][1]

  funcParameterMap["vgprStride"]  = vgprStride
  funcParameterMap["bufferGroupType"]  = bufferGroupType

  if (bufferGroupType == BufferRowMode()):
    # there is no full wide block, use partial width instead
    fullBlockWidth = surfacePartition[3][0]
  else:
    # xUnit
    fullBlockWidth = surfacePartition[2][1]

  funcParameterMap["fullBlockWidth"]  = fullBlockWidth
  funcParameterMap["partialBlockWidth"] = surfacePartition[3][0]
  funcParameterMap["gsmBlockSizeX"] = surfacePartition[3][1]
  funcParameterMap["gsmBlockSizeY"] = surfacePartition[3][2]






def set_gpr_usage(funcParameterMap, layerInfo, flowHandler):
  indentstring = flowHandler.getIndentStr()

  funcParameterMap["constBase"]       = "a0"
  funcParameterMap["vgprBaseStr"]     = "a1"
  funcParameterMap["sgprBase"]        = "a2"

  br_print (indentstring + "// sgpr usage:")
  coordSGPRIndex = flowHandler.allocateSGPR(7)
  funcParameterMap["zSGPRIndex"]      = coordSGPRIndex + 2
  funcParameterMap["wSGPRIndex"]      = coordSGPRIndex + 3
  funcParameterMap["xSGPRStr"]        = "q" + str(coordSGPRIndex)
  funcParameterMap["ySGPRStr"]        = "q" + str(coordSGPRIndex + 1)
  funcParameterMap["zSGPRStr"]        = "q" + str(coordSGPRIndex + 2)
  funcParameterMap["wSGPRStr"]        = "q" + str(coordSGPRIndex + 3)

  funcParameterMap["xOutReadSGPRStr"] = "q" + str(coordSGPRIndex + 4)
  funcParameterMap["xOutWriteSGPRStr"] = "q" + str(coordSGPRIndex + 5)
  funcParameterMap["yOutSGPRStr"]     = "q" + str(coordSGPRIndex + 6)

  br_print (indentstring + "//   x/y/z/w at sgpr q" + str(coordSGPRIndex) + "-q" + str(coordSGPRIndex+5))
  br_print (indentstring + "//     input (gradient/offset) x/y uses " + funcParameterMap["xSGPRStr"] + " and " + funcParameterMap["ySGPRStr"])
  br_print (indentstring + "//     output gradient y uses " + funcParameterMap["yOutSGPRStr"])
  br_print (indentstring + "//     output gradient read x uses " + funcParameterMap["xOutReadSGPRStr"])
  br_print (indentstring + "//     output gradient write x uses " + funcParameterMap["xOutWriteSGPRStr"])

  euIdSGPRIndex = flowHandler.allocateSGPR(1)
  euIdSGPRStr = "q" + str(euIdSGPRIndex)
  funcParameterMap["euIdSGPRStr"]   = euIdSGPRStr
  br_print (indentstring + "//   unique eu id at sgpr " + euIdSGPRStr)

  addressStepSGPRIndex = flowHandler.allocateSGPR(1)
  addressStepSGPRStr = "q" + str(addressStepSGPRIndex)
  funcParameterMap["addressStepSGPRStr"] = addressStepSGPRStr
  br_print (indentstring + "//   address step at sgpr " + addressStepSGPRStr)

  tempSGPRAddr = flowHandler.allocateSGPR(2)
  funcParameterMap["tempSGPRAddr"] = tempSGPRAddr
  br_print (indentstring + "//   temp at sgpr q" + str(tempSGPRAddr))

  vgprBaseSGPRIndex = flowHandler.allocateSGPR(1)
  vgprBaseSGPRStr = "q" + str(vgprBaseSGPRIndex)
  funcParameterMap["vgprBaseSGPRStr"] = vgprBaseSGPRStr
  br_print (indentstring + "//   vgpr base at sgpr " + vgprBaseSGPRStr)


  laneOffsetVGPRAddr = funcParameterMap["laneOffsetVGPRAddr"]
  tileAddresVGPRAddr = funcParameterMap["tileAddresVGPRAddr"]
  tempVGPRAddr = funcParameterMap["tempVGPRAddr"]
  inGradientVGPRAddr = funcParameterMap["inGradientVGPRAddr"]
  inOffsetVGPROffset = funcParameterMap["inOffsetVGPROffset"]
  vgprNumber = funcParameterMap["vgprNumber"]

  br_print (indentstring + "// vgpr usage:")

  laneIdVGPRIndex = flowHandler.reserveVGPR(0, 1)
  laneIdVGPRStr = "r" + str(laneIdVGPRIndex)
  br_print (indentstring + "//   lane id at vgpr " + laneIdVGPRStr + ", initialized at beginning, should never be overwritten")
  funcParameterMap["laneIdVGPRStr"] = laneIdVGPRStr

  laneByteOffsetInGSMVGPRStr = "r" + str(laneOffsetVGPRAddr)
  funcParameterMap["laneByteOffsetInGSMVGPRStr"] = laneByteOffsetInGSMVGPRStr
  br_print (indentstring + "//   lane byte addr offset in gsm at " + laneByteOffsetInGSMVGPRStr + ", initialized at beginning, should never be overwritten")

  lanePixelOffsetVGPRStr = "r" + str(laneOffsetVGPRAddr + 1)
  funcParameterMap["lanePixelOffsetVGPRStr"] = lanePixelOffsetVGPRStr
  br_print (indentstring + "//   lane pixel offset at " + lanePixelOffsetVGPRStr + " for stride 2, initialized at beginning, should never be overwritten")

  tileAddresVGPRStr = "r" + str(tileAddresVGPRAddr)
  funcParameterMap["tileAddresVGPRStr"] = tileAddresVGPRStr
  br_print (indentstring + "//   tile's address at " + tileAddresVGPRStr + ", set on the fly")

  br_print (indentstring + "//   temp will use r[" + str(tempVGPRAddr) + ", " + str(inGradientVGPRAddr) + ")")
  br_print (indentstring + "//   input gradient will use r[" + str(inGradientVGPRAddr) + ", " + str(inGradientVGPRAddr + 36) + ")")
  br_print (indentstring + "//   input offset will use r[" + str(inGradientVGPRAddr + inOffsetVGPROffset) + ", " + str(inGradientVGPRAddr + inOffsetVGPROffset + 36) + ")")







####################################################
# gen_kernel_sub_function
#   generate sub functions that will be called

def gen_kernel_sub_function(funcDefMap, funcParaDict):
  flowHandler = flowLib.FlowHandler("", 0, 0, compiler.GetASMMode())

  for x, y in funcDefMap.items():
    br_print ("// func " + x + ", q regs free to use: " + str(y))
    br_print ("// return address at q" + str(y[1]+1))

    funcKeys = x.split("_")

    flowHandler.startFunctionDef(x, 1)
    flowHandler.setLabelIndex(0)
    flowHandler.setLabelSuffix(x.upper())
    flowHandler.setQTempStart(y[0])
    flowHandler.setQStackStart(y[1])

    yBorderType   = int (funcKeys[5])
    blockHeight   = int (funcKeys[6])
    rightBorderMode = int (funcKeys[7])

    gen_pbk_sub_function(yBorderType, blockHeight, rightBorderMode, funcParaDict, flowHandler)

    flowHandler.closeFunctionDef(x, 1)
    br_print ("\n\n\n\n")






####################################################
#
def gen_layer_main_kernel(layerId, layerNumber, warpId, layerInfo, flowHandler):

  cmdIndex = cwarp.GetCMDIndex()

  if (layerInfo[cmdIndex] != "pbk"):
    assert False, "unsupported op " + layerInfo[cmdIndex]
    return

  flowHandler.startFunctionDef("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel", 0)
  indentstring = flowHandler.getIndentStr()

  funcGenHandler = funcgen.FuncGenHandler()
  funcParameterMap = {}

  flowHandler.setLabelSuffix("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel")

  br_print (indentstring + "// TODO row mode - no need to save to output buffer and read back")

  uSharpIndex = cwarp.GetUSharpIndex()
  optionsIndex = cwarp.GetOptionsIndex()

  surfaceSample = layerInfo[uSharpIndex][0][usharp.GetSurfCoordSampleIndex()]
  surfaceChannel = layerInfo[uSharpIndex][0][usharp.GetSurfCoordChannelIndex()]
  surfaceHeight = layerInfo[uSharpIndex][0][usharp.GetSurfCoordYIndex()]
  surfaceWidth = layerInfo[uSharpIndex][0][usharp.GetSurfCoordXIndex()]

  filterInfo = [layerInfo[optionsIndex][GetFilterSizeX()], layerInfo[optionsIndex][GetFilterSizeY()],
                layerInfo[optionsIndex][GetFilterOffsetX()], layerInfo[optionsIndex][GetFilterOffsetY()],
                layerInfo[optionsIndex][GetFilterStrideIndex()]]

  br_print (indentstring + "// layer info:")
  br_print (indentstring + "//   op            - :" + layerInfo[cmdIndex])
  br_print (indentstring + "//   surface       - sample : " + str(surfaceSample) + ", channel: " + str(surfaceChannel) + ", height: " + str(surfaceHeight) + ", width: " + str(surfaceWidth))
  br_print (indentstring + "//   filter        - x size : " + str(filterInfo[0]) + ", y size: " + str(filterInfo[1]))
  br_print (indentstring + "//                 - x offset : " + str(filterInfo[2]) + ", y offset: " + str(filterInfo[3]))
  br_print (indentstring + "//                 - stride : " + str(filterInfo[4]))

  kernelLib.PrintUSharpList(layerInfo[uSharpIndex], indentstring)

  vgprPartitionIndex = cwarp.GetVGPRPartitionIndex()

  borderType = BorderTypeAll()

  tileNumberX = int ((surfaceWidth + hwCaps.TileSizeX() - 1) / hwCaps.TileSizeX())
  tileNumberY = int ((surfaceHeight + hwCaps.TileSizeY() - 1) / hwCaps.TileSizeY())

  if (surfaceHeight % hwCaps.TileSizeY()):
    borderType |= BorderTypeBottomPartial()

  if (surfaceWidth % hwCaps.TileSizeX()):
    borderType |= BorderTypeRightPartial()

  surfaceTileInfo = [surfaceSample, surfaceChannel, tileNumberY, tileNumberX]

  set_layer_parameter(funcParameterMap, layerInfo)

  set_vgpr_number(layerInfo[vgprPartitionIndex], funcParameterMap)

  vgprNumber = funcParameterMap["vgprNumber"]

  surfacePartition = get_pbk_surface_partition(surfaceTileInfo, vgprNumber, borderType, funcParameterMap, flowHandler.getIndentStr())

  set_surface_parameter(funcParameterMap, surfacePartition)

  set_gpr_usage(funcParameterMap, layerInfo, flowHandler)

  indentstring = flowHandler.getIndentStr()

  br_print (indentstring + "// tile info:")
  br_print (indentstring + "//   tile number y = " + str(tileNumberY) + ", tile number x = " + str(tileNumberX))
  br_print (indentstring)

  br_print (indentstring + "// start preprocessing")
  br_print (indentstring)

  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "//  " + layerInfo[cwarp.GetCMDIndex()] + " parition :")

  vgprStride = surfacePartition[0][0]
  br_print (indentstring + "//    vgprStride: " + str(surfacePartition[0][0]))


  br_print (indentstring + "//    y dir partition:")
  for thisSpan in surfacePartition[1]:
    br_print (indentstring + "//      height: " + str(thisSpan[0]) + ", step: " + str(thisSpan[1]) + ", border: " + str(thisSpan[2]))

  thisSpan = surfacePartition[2]
  br_print (indentstring + "//    x dir partition:")
  br_print (indentstring + "//      width:  " + str(thisSpan[0]) + ", step: " + str(thisSpan[1]) + ", border: " + str(thisSpan[2]))

  thisSpan = surfacePartition[3]
  br_print (indentstring + "//      partial block width: " + str(thisSpan[0]))

  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "// start pooling backward")
  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring)



  laneIdVGPRStr = funcParameterMap["laneIdVGPRStr"]
  laneByteOffsetInGSMVGPRStr = funcParameterMap["laneByteOffsetInGSMVGPRStr"]
  tempVGPRAddr = funcParameterMap["tempVGPRAddr"]

  # br_print (indentstring + "//////////////////////////////////////////////")
  # br_print (indentstring + "// initialize bar")
  # bn2reduceBarIdSGPRStr     = funcParameterMap["bn2reduceBarIdSGPRStr"]
  # reduce2bnBarIdSGPRStr     = funcParameterMap["reduce2bnBarIdSGPRStr"]
  # funcLib.AlignPrint(indentstring + "smov " + reduce2bnBarIdSGPRStr + ", " + str(cwarp.GetReduce2BNSyncBarId()), flowLib.GetCommentPos(), "// set reduce->bn bar id")
  # funcLib.AlignPrint(indentstring + "smov " + bn2reduceBarIdSGPRStr + ", " + str(cwarp.GetBN2ReduceSyncBarId()), flowLib.GetCommentPos(), "// set bn->reduce bar id")
  # funcLib.AlignPrint(indentstring + "bar.tg.pass " + str(cwarp.GetBN2ReduceSyncBarId()) + ", 2", flowLib.GetCommentPos(), "// initialize bn->reduce bar so reduce could start")
  # funcLib.AlignPrint(indentstring + "bar.tg.pass " + str(cwarp.GetBN2ReduceSyncBarId()+1) + ", 2", flowLib.GetCommentPos(), "// initialize bn->reduce bar so reduce could start")

  br_print (indentstring)
  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "// initialize channel id")
  zSGPRStr      = funcParameterMap["zSGPRStr"]
  euIdSGPRStr = funcParameterMap["euIdSGPRStr"]
  br_print (indentstring + "sysid.work " + euIdSGPRStr)
  funcLib.AlignPrint(indentstring + "sand " + euIdSGPRStr + ", " + euIdSGPRStr + ", 0xf", flowLib.GetCommentPos(), "// obtain unique eu id")
  funcLib.AlignPrint(indentstring + "sshl " + zSGPRStr + ", " + euIdSGPRStr + ", 1", flowLib.GetCommentPos(), "// initialize z with channel pair start")



  br_print (indentstring)
  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "// initialize lane's addr offset in gsm")
  gsmBlockSizeX       = funcParameterMap["gsmBlockSizeX"] * hwCaps.TileSizeX()

  funcLib.AlignPrint(indentstring + "and.b32 " + laneByteOffsetInGSMVGPRStr + ", " + laneIdVGPRStr + ", 0x18", flowLib.GetCommentPos(), "// extract lane's y")
  funcLib.AlignPrint(indentstring + "and.b32 r" + str(tempVGPRAddr) + ", " + laneIdVGPRStr + ", 7", flowLib.GetCommentPos(), "// extract lane's x")
  if (funcLib.IsPower2(gsmBlockSizeX)):
    funcLib.AlignPrint(indentstring + "shl.b32 " + laneByteOffsetInGSMVGPRStr + ", " + laneByteOffsetInGSMVGPRStr + ", " + str(funcLib.GetLeadingOnePos(gsmBlockSizeX)), flowLib.GetCommentPos(), "// adjust by number of tiles in x dir")
  else:
    funcLib.AlignPrint(indentstring + "mulu.b32 " + laneByteOffsetInGSMVGPRStr + ", " + laneByteOffsetInGSMVGPRStr + ", " + str(gsmBlockSizeX), flowLib.GetCommentPos(), "// adjust by number of tiles in x dir")
  funcLib.AlignPrint(indentstring + "or.b32 " + laneByteOffsetInGSMVGPRStr + ", " + laneByteOffsetInGSMVGPRStr + ", r" + str(tempVGPRAddr), flowLib.GetCommentPos(), "// per lane offset in element")
  funcLib.AlignPrint(indentstring + "shl.b32 " + laneByteOffsetInGSMVGPRStr + ", " + laneByteOffsetInGSMVGPRStr + ", 2", flowLib.GetCommentPos(), "// per lane offset in bytes")

  filterStride        = funcParameterMap["filterStride"]

  lanePixelOffsetVGPRStr = funcParameterMap["lanePixelOffsetVGPRStr"]
  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "// initialize lane's offset in surface in stride 2, essentially it is lane's x/y")
  funcLib.AlignPrint(indentstring + "and.b32 r" + str(tempVGPRAddr + 1) + ", " + laneIdVGPRStr + ", 0x18", flowLib.GetCommentPos(), "// extract lane's y")
  if (filterStride != 0):
    funcLib.AlignPrint(indentstring + "shl.b32 r" + str(tempVGPRAddr) + ", r" + str(tempVGPRAddr) + ", 1", flowLib.GetCommentPos(), "// per lane x*2")
    funcLib.AlignPrint(indentstring + "shr.b32 r" + str(tempVGPRAddr + 1) + ", r" + str(tempVGPRAddr + 1) + ", 2", flowLib.GetCommentPos(), "// per lane y*2")
  else:
    funcLib.AlignPrint(indentstring + "shr.b32 r" + str(tempVGPRAddr + 1) + ", r" + str(tempVGPRAddr + 1) + ", 3", flowLib.GetCommentPos(), "// per lane y")
  funcLib.AlignPrint(indentstring + "mov.v2 " + lanePixelOffsetVGPRStr + ".s16, r" + str(tempVGPRAddr) + ".s32.a", flowLib.GetCommentPos(), "// merge x/y")

  br_print (indentstring)
  flowHandler.startForLoop("", str(surfaceTileInfo[1]), str(32), funcParameterMap["zSGPRIndex"], "loop channel")
  indentstring = flowHandler.getIndentStr()

  pbk_kernel_process_channel_group(layerId, warpId, surfaceTileInfo[0], surfacePartition, funcParameterMap, funcGenHandler, flowHandler)

  br_print (indentstring)
  flowHandler.closeForLoop("", str(surfaceTileInfo[1]), str(32), funcParameterMap["zSGPRIndex"])
  indentstring = flowHandler.getIndentStr()

  br_print (indentstring)
  kernelLib.jump_to_next_layer(layerId, layerNumber, warpId, indentstring)
  br_print (indentstring)

  flowHandler.closeFunctionDef("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel", 0)

  gen_kernel_sub_function(funcGenHandler.getFuncDef(), funcParameterMap)




