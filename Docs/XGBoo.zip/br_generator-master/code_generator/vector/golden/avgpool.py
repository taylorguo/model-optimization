#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.


import sys
import os
import math

import code_generator.vector.common.hwCaps as hwCaps
import code_generator.vector.common.flowLib as flowLib
import code_generator.vector.common.cwarp as cwarp
import code_generator.vector.common.funcgen as funcgen
import code_generator.vector.common.funcLib as funcLib
import code_generator.vector.common.kernelLib as kernelLib
import code_generator.vector.common.compiler as compiler
import code_generator.vector.common.usharp as usharp

from code_generator.share.br_defined_print import br_print

################################################################################################################
# split tile based on code_generator.share memory (gsm) size

# in gsm
#   there may be padding in all 4 directions
#   padding tiles will be replicate in neibouring blocks (x/y direction, either copy or reload)
#
#   top block's top padding and left block's left padding will be cleared to 0
#
#
# for each block
#   load from gsm, add to vgpr
#
# load 0
# alu 0

# load 1
# save 0
# alu 1

# load 0
# save 1

def GetFilterSizeX():
  return 0

def GetFilterSizeY():
  return 1

def GetFilterOffsetX():
  return 2

def GetFilterOffsetY():
  return 3

def GetFilterStrideIndex():
  return 4





def BufferBlockMode():
  return 0

def BufferRowMode():
  return 2


def BorderTypeBottom():
  return 1

def BorderTypeBottomPartial():
  return 2

def BorderTypeTop():
  return 4

def BorderTypeRight():
  return 8

def BorderTypeLeft():
  return 16

def BorderTypeRightPartial():
  return 32

def BorderTypeAll():
  return BorderTypeBottom() | BorderTypeRight() | BorderTypeTop()





################################################################################################################
# general functions
# does not necessarily for pooling kernel only
################################################################################################################






####################################################
# avgpool_block_load
#   load source from memory and save to gsm
#
def avgpool_block_load(borderType, rowSize, funcParameterMap, flowHandler):

  # y (0-3) * stride + x (0-7) inside a tile
  byteOffsetToGSMVGPRStr = funcParameterMap["byteOffsetToGSMVGPRStr"]
  tileAddresVGPRStr   = funcParameterMap["tileAddresVGPRStr"]

  uSharpIdList        = funcParameterMap["uSharpIdList"]

  inputVGPRAddr       = funcParameterMap["inputVGPRAddr"]
  vgprBaseStr         = funcParameterMap["vgprBaseStr"]

  # xSGPR/ySGPRStr are coordinates in input surface
  # start from tile (0, 0)
  xSGPRStr            = funcParameterMap["xSGPRStr"]
  coordSGPRStrList    = [xSGPRStr, funcParameterMap["ySGPRStr"], funcParameterMap["zSGPRStr"], funcParameterMap["wSGPRStr"]]

  # scalar offset to adjust laneAddress
  addressStepSGPRStr  = funcParameterMap["addressStepSGPRStr"]
  tempSGPRAddr        = funcParameterMap["tempSGPRAddr"]

  fullBlockWidth      = funcParameterMap["fullBlockWidth"]
  partialBlockWidth   = funcParameterMap["partialBlockWidth"]
  bufferGroupType     = funcParameterMap["bufferGroupType"]

  bufferGroupType     = funcParameterMap["bufferGroupType"]
  leftPaddingTile     = funcParameterMap["leftPaddingTile"]
  rightPaddingTile    = funcParameterMap["rightPaddingTile"]
  topPaddingTile      = funcParameterMap["topPaddingTile"]
  bottomPaddingTile   = funcParameterMap["bottomPaddingTile"]

  filterStride        = funcParameterMap["filterStride"]

  gsmBlockSizeX       = funcParameterMap["gsmBlockSizeX"]
  gsmBlockSizeY       = funcParameterMap["gsmBlockSizeY"]

  gsmBlockStrideX     = gsmBlockSizeX * 0x80

  if ((borderType & BorderTypeRight()) == 0):
    colNumber = fullBlockWidth
  else:
    # ideally we shall clear rightpadding to 0 instead of reading it from memory
    colNumber = partialBlockWidth

  # convert to src surface space
  if (filterStride != 0):
    colNumber <<= 1
    rowSize <<= 1

  vgprRowStart = 0
  vgprColStart = 0

  # always load bottom padding tile even at bottom band
  # otherwise need to check whether bottom padding tile is oob
  if (bufferGroupType == BufferRowMode()):
    gsmColStart = leftPaddingTile
    gsmRowStart = bottomPaddingTile + topPaddingTile
  else:
    gsmColStart = leftPaddingTile + rightPaddingTile

    if ((borderType & BorderTypeTop()) == 0):
      rowSize += topPaddingTile
      gsmRowStart = 0
    else:
      gsmRowStart = topPaddingTile

    rowSize += bottomPaddingTile

  indentstring = flowHandler.getIndentStr()

  vgprStrideGSM = gsmBlockSizeY

  funcLib.AlignPrint (indentstring + "smovs " + vgprBaseStr + ", " + str(inputVGPRAddr + vgprColStart * vgprStrideGSM), flowLib.GetCommentPos(), "// init vgpr base")

  # load input from memory
  br_print (indentstring)
  br_print (indentstring + "// load a block of input data, split into 2 halves in x dir to hide some latency")
  colLoopSize = [colNumber - (colNumber >> 1), colNumber >> 1]

  for z in range (2):
    syncId = z + 1

    if (colLoopSize[z] > 1):
      flowHandler.startForLoop("0", str(colLoopSize[z]), "1", -1, "loop in x dir")
      indentstring = flowHandler.getIndentStr()

    kernelLib.load_4d_activation(hwCaps.SurfaceFormatFP16(), hwCaps.SurfaceFormatFP16(), coordSGPRStrList, -1-vgprRowStart, rowSize, syncId, uSharpIdList[0][0], indentstring)

    br_print (indentstring + "sadda " + vgprBaseStr + ", " + vgprBaseStr + ", " + str(vgprStrideGSM))
    funcLib.AlignPrint (indentstring + "sadd " + xSGPRStr + ", " + xSGPRStr + ", " + str(hwCaps.TileSizeX()), flowLib.GetCommentPos(), "// advance in x dir")

    if (colLoopSize[z] > 1):
      flowHandler.closeForLoop("0", str(colLoopSize[z]), "1", -1)
      indentstring = flowHandler.getIndentStr()

  funcLib.AlignPrint(indentstring + "smov " + addressStepSGPRStr + ", " + hex(gsmBlockStrideX), flowLib.GetCommentPos(), "// init y stride in gsm")

  br_print (indentstring)
  br_print (indentstring + "// save input data to gsm")
  funcLib.AlignPrint (indentstring + "smovs " + vgprBaseStr + ", " + str(inputVGPRAddr + vgprColStart * vgprStrideGSM), flowLib.GetCommentPos(), "// init vgpr base")
  funcLib.AlignPrint(indentstring + "smov q" + str(tempSGPRAddr) + ", " + hex(gsmRowStart * gsmBlockStrideX + gsmColStart * hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// init tile's offset")

  for z in range (2):
    if (colLoopSize[z] > 0):
      funcLib.AlignPrint(indentstring + "nop.sc" + str(1 + z), flowLib.GetCommentPos(), "// wait for load input to finish")

    #loopEndStr = ""
    #
    #if (z == 0):
    #  if (bufferGroupType != BufferRowMode()) and (rightPaddingTile > 0):
    #    xOutSGPRStr            = funcParameterMap["xOutSGPRStr"]
    #
    #    loopEndStr = "q" + str(tempSGPRAddr+1)
    #    flowHandler.startIfLoop(xOutSGPRStr, "0", "==", 1)
    #    indentstring = flowHandler.getIndentStr()
    #    print (indentstring + "// borrow output x coord to tell whether it is the first block in x dir")
    #    print (indentstring + "// first block needs to handle right padding tile loaded earlier")
    #    funcLib.AlignPrint (indentstring + "smovs " + vgprBaseStr + ", " + str(inputVGPRAddr + leftPaddingTile * vgprStrideGSM), flowLib.GetCommentPos(), "// init vgpr base")
    #    print (indentstring + "smov " + loopEndStr + ", " + str(colLoopSize[z] + rightPaddingTile))
    #    funcLib.AlignPrint(indentstring + "smov q" + str(tempSGPRAddr) + ", " + hex(rowStart * gsmBlockStrideX + leftPaddingTile * hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// init tile's offset")
    #    flowHandler.startElseLoop()
    #    print (indentstring + "smov " + loopEndStr + ", " + str(colLoopSize[z]))
    #    funcLib.AlignPrint(indentstring + "smov q" + str(tempSGPRAddr) + ", " + hex(rowStart * gsmBlockStrideX + colStart * hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// init tile's offset")
    #    flowHandler.closeIfLoop()
    #    indentstring = flowHandler.getIndentStr()
    #  else:
    #    funcLib.AlignPrint (indentstring + "smovs " + vgprBaseStr + ", " + str(inputVGPRAddr + colStart * vgprStrideGSM), flowLib.GetCommentPos(), "// init vgpr base")
    #    funcLib.AlignPrint(indentstring + "smov q" + str(tempSGPRAddr) + ", " + hex(rowStart * gsmBlockStrideX + colStart * hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// init tile's offset")
    #    if (colLoopSize[z] > 1):
    #      loopEndStr = str(colLoopSize[z])
    #else:
    #  if (colLoopSize[z] > 1):
    #    loopEndStr = str(colLoopSize[z])
    #
    #if (loopEndStr != ""):
    #  flowHandler.startForLoop("0", loopEndStr, "1", -1, "loop in x dir")
    if (colLoopSize[z] > 1):
      flowHandler.startForLoop("0", str(colLoopSize[z]), "1", -1, "loop in x dir")
      indentstring = flowHandler.getIndentStr()

    if (colLoopSize[z] > 0):
      funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + byteOffsetToGSMVGPRStr + ", q" + str(tempSGPRAddr), flowLib.GetCommentPos(), "// init addr for cur col")
      for y in range (rowSize):
        funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "// store to gsm")
        br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
        br_print (indentstring + "mov.eog g1.f16, ir" + str(vgprRowStart + y) + ".f16")
        funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + addressStepSGPRStr, flowLib.GetCommentPos(), "// move to next row")

      funcLib.AlignPrint(indentstring + "sadda " + vgprBaseStr + ", " + vgprBaseStr + ", " + str(vgprStrideGSM), flowLib.GetCommentPos(), "// move to next col")
      funcLib.AlignPrint(indentstring + "sadd q" + str(tempSGPRAddr) + ", q" + str(tempSGPRAddr) + ", " + hex(hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// move to next tile in x dir")

    if (colLoopSize[z] > 1):
      flowHandler.closeForLoop("0", str(colLoopSize[z]), "1", -1)
      indentstring = flowHandler.getIndentStr()










####################################################
# avgpool_block_update
#   use source grad and source offset, accumulate in gsm
#
def avgpool_block_update(borderType, rowSize, funcParameterMap, flowHandler):

  indentstring = flowHandler.getIndentStr()

  tempVGPRAddr        = funcParameterMap["tempVGPRAddr"]
  outputVGPRAddr      = funcParameterMap["outputVGPRAddr"]
  outputVGPRStride    = funcParameterMap["outputVGPRStride"]

  vgprBaseStr         = funcParameterMap["vgprBaseStr"]

  tempSGPRAddr        = funcParameterMap["tempSGPRAddr"]
  addressStepSGPRStr  = funcParameterMap["addressStepSGPRStr"]

  fullBlockWidth      = funcParameterMap["fullBlockWidth"]
  partialBlockWidth   = funcParameterMap["partialBlockWidth"]

  leftPaddingTile     = funcParameterMap["leftPaddingTile"]
  topPaddingTile      = funcParameterMap["topPaddingTile"]

  filterSizeX         = funcParameterMap["filterSizeX"]
  filterSizeY         = funcParameterMap["filterSizeY"]
  filterOffsetX       = funcParameterMap["filterOffsetX"]
  filterOffsetY       = funcParameterMap["filterOffsetY"]
  filterStride        = funcParameterMap["filterStride"]

  tileAddresVGPRStr   = funcParameterMap["tileAddresVGPRStr"]
  byteOffsetFromGSMVGPRStr = funcParameterMap["byteOffsetFromGSMVGPRStr"]

  gsmBlockSizeX       = funcParameterMap["gsmBlockSizeX"]

  uSharpIdList        = funcParameterMap["uSharpIdList"]
  xOutSGPRStr         = funcParameterMap["xOutSGPRStr"]
  yOutSGPRStr         = funcParameterMap["yOutSGPRStr"]

  coordSGPRStrList    = [xOutSGPRStr, yOutSGPRStr, funcParameterMap["zSGPRStr"], funcParameterMap["wSGPRStr"]]

  if (filterStride != 0):
    coordScale = 2
  else:
    coordScale = 1

  br_print (indentstring)
  br_print (indentstring + "// perform avg pooling")

  if ((borderType & BorderTypeRight()) == 0):
    colNumber = fullBlockWidth
  else:
    colNumber = partialBlockWidth

  gsmAddrX = "q" + str(tempSGPRAddr)
  gsmAddrY = "q" + str(tempSGPRAddr + 1)

  startAddressOffset = 0
  coordAdjust = 0
  if (leftPaddingTile != 0):
    startXOffset = hwCaps.TileSizeX() - (filterOffsetX & (hwCaps.TileSizeX() - 1))
    startAddressOffset = startXOffset << 2
    coordAdjust |= startXOffset

  if (topPaddingTile != 0):
    startYOffset = hwCaps.TileSizeY() - (filterOffsetY & (hwCaps.TileSizeY() - 1))
    startAddressOffset += (startYOffset * gsmBlockSizeX * hwCaps.TileSizeX()) << 2
    coordAdjust |= startYOffset << 16

  # funcLib.AlignPrint(indentstring + "smovs " + vgprBaseStr + ", " + str(inputVGPRAddr), flowLib.GetCommentPos(), "// init vgpr base")

  funcLib.AlignPrint(indentstring + "smov " + gsmAddrX + ", " + hex(startAddressOffset), flowLib.GetCommentPos(), "// top-left's byte offset in gsm")

  funcLib.AlignPrint(indentstring + "smovs " + vgprBaseStr + ", " + str(outputVGPRAddr), flowLib.GetCommentPos(), "// init output buffer vgpr base")

  if (colNumber > 1):
    flowHandler.startForLoop("0", str(colNumber), "1", -1, "loop in x dir")
    indentstring = flowHandler.getIndentStr()

  funcLib.AlignPrint(indentstring + "smov " + gsmAddrY + ", " + gsmAddrX, flowLib.GetCommentPos(), "// init byte offset of current col")
  kernelLib.mov_imm_v(hwCaps.SurfaceFormatFP16(), -1, rowSize, "0.0", "", indentstring)
  if (rowSize > 1):
    flowHandler.startForLoop("0", str(rowSize), "1", -1, "loop in y dir")
    indentstring = flowHandler.getIndentStr()

  funcLib.AlignPrint(indentstring + "smov " + addressStepSGPRStr + ", " + gsmAddrY, flowLib.GetCommentPos(), "// init byte offset of filter y")


  #if (filterSizeY > 1):
  #  flowHandler.startForLoop("0", str(filterSizeY), "1", -1, "loop in filter y")
  #  indentstring = flowHandler.getIndentStr()
  #
  #funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + byteOffsetFromGSMVGPRStr + ", " + addressStepSGPRStr, flowLib.GetCommentPos(), "")
  #
  #loadIndex = 0
  #for x in range (filterSizeX):
  #  print (indentstring + "ld.gsm.float.mb16.rb16.sc" + str(loadIndex + 1) + ".e2.gc1 r" + str(tempVGPRAddr + loadIndex * 8 + x) + ", g0")
  #  print (indentstring + "mov.eog g0.u32, " + tileAddresVGPRStr + ".u32")
  #  funcLib.AlignPrint(indentstring + "adds.b32 r" + str(tileAddresVGPRStr) + ", " + str(tileAddresVGPRStr) + ", 4", flowLib.GetCommentPos(), "")
  #

  groupNumber = filterSizeY
  syncChannelNumber = 2

  tailNumber = 0
  bodyNumber = 0

  if (groupNumber >= syncChannelNumber):
    headNumber = syncChannelNumber - 1
    tailNumber += (groupNumber - headNumber) % syncChannelNumber
    loopNumber = int ((groupNumber - headNumber) / syncChannelNumber)

    if (loopNumber != 0):
      bodyNumber = syncChannelNumber
  else:
    headNumber = groupNumber
    loopNumber = 0

  loadNumber = headNumber + bodyNumber + tailNumber

  lastLoadIndex = loadNumber - 1
  expandNumber = headNumber + bodyNumber + tailNumber + headNumber

  br_print (indentstring + "// loop number = " + str(loopNumber))
  br_print (indentstring + "// head: " + str(headNumber) + ", body: " + str(bodyNumber) + ", tail: " + str(tailNumber))

  loadIndex = 0
  aluIndex = 0

  for z in range (expandNumber):

    if (z == headNumber and loopNumber > 1):
      br_print (indentstring)
      flowHandler.startForLoop("0", str(loopNumber), "1", -1, "loop in y filter")
      indentstring = flowHandler.getIndentStr()

    if (z <= lastLoadIndex):
      br_print (indentstring)
      syncId = loadIndex + 1
      #print (indentstring + "// TODO - use burst")
      br_print (indentstring + "// load all source data in filter x dir")
      funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + byteOffsetFromGSMVGPRStr + ", " + addressStepSGPRStr, flowLib.GetCommentPos(), "")

      sizeGroupList = funcLib.SplitRepeatIntoGroups(filterSizeX, hwCaps.MaxLoadGranule())
      thisVGPRAddr = tempVGPRAddr + loadIndex * filterSizeX
      for thisSizeGroup in sizeGroupList:
        for sizeIndex in range(thisSizeGroup[0]):
          vectorModifier = kernelLib.GetVectorModifier(thisSizeGroup[1] * 2, "e")
          br_print (indentstring + "ld.gsm.float.mb16.rb16" + vectorModifier + ".sc" + str(loadIndex + 1) + ".gc1 r" + str(thisVGPRAddr) + ", g0")
          br_print (indentstring + "mov.eog g0.u32, " + tileAddresVGPRStr + ".u32")
          funcLib.AlignPrint(indentstring + "adds.b32 " + str(tileAddresVGPRStr) + ", " + str(tileAddresVGPRStr) + ", "+ str(thisSizeGroup[1] * 4), flowLib.GetCommentPos(), "")
          thisVGPRAddr += thisSizeGroup[1]

      #for x in range (filterSizeX):
      #  print (indentstring + "ld.gsm.float.mb16.rb16.sc" + str(loadIndex + 1) + ".e2.gc1 r" + str(tempVGPRAddr + loadIndex * 8 + x) + ", g0")
      #  print (indentstring + "mov.eog g0.u32, " + tileAddresVGPRStr + ".u32")
      #  funcLib.AlignPrint(indentstring + "adds.b32 " + str(tileAddresVGPRStr) + ", " + str(tileAddresVGPRStr) + ", 4", flowLib.GetCommentPos(), "")

      funcLib.AlignPrint(indentstring + "sadd " + addressStepSGPRStr + ", " + addressStepSGPRStr + ", " + hex(gsmBlockSizeX * hwCaps.TileSizeX() *4), flowLib.GetCommentPos(), "// move to next filter in y dir")
      loadIndex = funcLib.IncAndWrap(loadIndex, syncChannelNumber)

    if (z >= headNumber):
      br_print (indentstring)
      syncId = aluIndex + 1

      kernelLib.sum_vector_to_vgpr(-1, tempVGPRAddr + aluIndex * filterSizeX, filterSizeX, ".b16", syncId, indentstring)

      aluIndex = funcLib.IncAndWrap(aluIndex, syncChannelNumber)

    if (z == (headNumber + bodyNumber - 1) and loopNumber > 1):
      flowHandler.closeForLoop("0", str(loopNumber), "1", -1)
      indentstring = flowHandler.getIndentStr()



  #if (filterSizeY > 1):
  #  flowHandler.closeForLoop("0", str(filterSizeY), "1", -1)
  #  indentstring = flowHandler.getIndentStr()

  funcLib.AlignPrint(indentstring + "sadd " + gsmAddrY + ", " + gsmAddrY + ", " + hex(gsmBlockSizeX * coordScale * 0x80), flowLib.GetCommentPos(), "// move to next tile in y dir in gsm")
  funcLib.AlignPrint(indentstring + "sadda " + vgprBaseStr + ", " + vgprBaseStr + ", 1", flowLib.GetCommentPos(), "// advance output buffer vgpr base")
  if (rowSize > 1):
    flowHandler.closeForLoop("0", str(rowSize), "1", -1)
    indentstring = flowHandler.getIndentStr()

  funcLib.AlignPrint(indentstring + "sadd " + gsmAddrX + ", " + gsmAddrX + ", " + hex(coordScale * hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// move to next tile in x dir in gsm")
  if (colNumber > 1):
    flowHandler.closeForLoop("0", str(colNumber), "1", -1)
    indentstring = flowHandler.getIndentStr()


  imageWidthRes       = funcParameterMap["imageWidthRes"]
  imageHeightRes      = funcParameterMap["imageHeightRes"]
  if (((borderType & BorderTypeRight()) != 0) and (imageWidthRes != 0)) or \
     (((borderType & BorderTypeBottom()) != 0) and (imageHeightRes != 0)):
    br_print (indentstring)

    isColPartial = (((borderType & BorderTypeBottom()) != 0) and (imageHeightRes != 0))

    if (((borderType & BorderTypeRight()) != 0) and (imageWidthRes != 0)):
      br_print (indentstring + "// process right border (and possible bottom border)")
      thisVGPRAddr = outputVGPRAddr + (colNumber - 1) * rowSize
      funcLib.AlignPrint(indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(0, imageWidthRes, 1)), flowLib.GetCommentPos(), "// pool result may be from oob, so clear oob at here")
      if (not isColPartial):
         kernelLib.mov_imm_v(hwCaps.SurfaceFormatFP16(), thisVGPRAddr, rowSize, "0.0", "m0.", indentstring)
      else:
        if (rowSize > 1):
          kernelLib.mov_imm_v(hwCaps.SurfaceFormatFP16(), thisVGPRAddr, rowSize - 1, "0.0", "m0.", indentstring)
        br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(imageHeightRes, imageWidthRes, 1)))
        kernelLib.mov_imm_v(hwCaps.SurfaceFormatFP16(), thisVGPRAddr + rowSize - 1, 1, "0.0", "m0.", indentstring)
    else:
      br_print (indentstring + "// process bottom border")
      br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(imageHeightRes, 0, 1)))
      thisVGPRAddr = outputVGPRAddr
      for y in range (colNumber):
        kernelLib.mov_imm_v(hwCaps.SurfaceFormatFP16(), thisVGPRAddr, 1, "0.0", "m0.", indentstring)
        thisVGPRAddr += rowSize

  br_print (indentstring)
  br_print (indentstring + "// save result")
  thisVGPRAddr = outputVGPRAddr
  for y in range (colNumber):
    kernelLib.store_4d_activation(hwCaps.SurfaceFormatFP16(), hwCaps.SurfaceFormatFP16(), coordSGPRStrList, thisVGPRAddr, rowSize, uSharpIdList[1][0], indentstring)
    funcLib.AlignPrint(indentstring + "sadd " + xOutSGPRStr + ", " + xOutSGPRStr + ", " + hex(hwCaps.TileSizeX()), flowLib.GetCommentPos(), "// move to right col")




####################################################
# avgpool_col_save_gsm
#   copy right cols to left in gsm if not row mode
#   copy bottom rows to top in gsm if row mode
#

def avgpool_block_rollover(borderType, rowSize, funcParameterMap, flowHandler):

  bufferGroupType     = funcParameterMap["bufferGroupType"]

  if (((borderType & BorderTypeRight()) != 0) and (bufferGroupType != BufferRowMode())) or \
     (((borderType & BorderTypeBottom()) != 0) and (bufferGroupType == BufferRowMode())):
    return

  indentstring = flowHandler.getIndentStr()

  # y (0-3) * stride + x (0-7) inside a tile
  byteOffsetToGSMVGPRStr = funcParameterMap["byteOffsetToGSMVGPRStr"]
  tileAddresVGPRStr   = funcParameterMap["tileAddresVGPRStr"]
  tempVGPRAddr        = funcParameterMap["tempVGPRAddr"]

  fullBlockWidth      = funcParameterMap["fullBlockWidth"]
  partialBlockWidth   = funcParameterMap["partialBlockWidth"]

  addressStepSGPRStr  = funcParameterMap["addressStepSGPRStr"]
  tempSGPRAddr        = funcParameterMap["tempSGPRAddr"]

  leftPaddingTile     = funcParameterMap["leftPaddingTile"]
  rightPaddingTile    = funcParameterMap["rightPaddingTile"]
  topPaddingTile      = funcParameterMap["topPaddingTile"]
  bottomPaddingTile   = funcParameterMap["bottomPaddingTile"]

  filterStride        = funcParameterMap["filterStride"]

  gsmBlockSizeX       = funcParameterMap["gsmBlockSizeX"]
  gsmBlockSizeY       = funcParameterMap["gsmBlockSizeY"]
  gsmBlockStride      = gsmBlockSizeX * 0x80


  if ((borderType & BorderTypeRight()) == 0):
    colNumber = fullBlockWidth
  else:
    colNumber = partialBlockWidth

  # convert to src surface space
  if (filterStride != 0):
    colNumber <<= 1
    rowSize <<= 1

  vgprRowStart = 0
  vgprColStart = 0

  br_print (indentstring)
  if (bufferGroupType != BufferRowMode()):
    direction = 1
    br_print (indentstring + "// copy right cols to left in gsm")

    if ((borderType & BorderTypeTop()) == 0):
      rowSize += topPaddingTile
      gsmRowStart = 0
    else:
      gsmRowStart = topPaddingTile
    rowSize += bottomPaddingTile

    groupNumber = leftPaddingTile +  rightPaddingTile
    vgprNumber = rowSize
    funcLib.AlignPrint(indentstring + "smov q" + str(tempSGPRAddr) + ", " + hex(gsmRowStart * gsmBlockSizeX * 0x80 + (gsmBlockSizeX - groupNumber) * 4 * hwCaps.TileSizeX()), flowLib.GetCommentPos(), "// init read addr for first row")
    funcLib.AlignPrint(indentstring + "smov q" + str(tempSGPRAddr + 1) + ", " + hex(gsmRowStart * gsmBlockSizeX *0x80), flowLib.GetCommentPos(), "// init write addr for first row")
    funcLib.AlignPrint(indentstring + "smov " + addressStepSGPRStr + ", " + hex(gsmBlockSizeX * 0x80), flowLib.GetCommentPos(), "// init y stride")

  else:
    direction = 0
    br_print (indentstring + "// copy bottom rows to top in gsm")
    gsmColStart = leftPaddingTile

    groupNumber = topPaddingTile +  bottomPaddingTile
    vgprNumber = colNumber
    funcLib.AlignPrint(indentstring + "smov q" + str(tempSGPRAddr) + ", " + hex((gsmBlockSizeY - groupNumber) * gsmBlockSizeX *0x80 + gsmColStart * hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// init read addr for first col")
    funcLib.AlignPrint(indentstring + "smov q" + str(tempSGPRAddr + 1) + ", " + hex(gsmColStart * hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// init write addr for first col")

  syncChannelNumber = 2

  tailNumber = 0
  bodyNumber = 0

  if (groupNumber >= syncChannelNumber):
    headNumber = syncChannelNumber - 1
    tailNumber += (groupNumber - headNumber) % syncChannelNumber
    loopNumber = int ((groupNumber - headNumber) / syncChannelNumber)
    if (loopNumber != 0):
      bodyNumber = syncChannelNumber
  else:
    headNumber = groupNumber
    loopNumber = 0

  loadNumber = headNumber + bodyNumber + tailNumber
  lastLoadIndex = loadNumber - 1
  expandNumber = headNumber + bodyNumber + tailNumber + headNumber
  br_print (indentstring + "// loop number = " + str(loopNumber))
  br_print (indentstring + "// head: " + str(headNumber) + ", body: " + str(bodyNumber) + ", tail: " + str(tailNumber))

  loadIndex = 0
  aluIndex = 0

  for z in range (expandNumber):
    if (z == headNumber and loopNumber > 1):
      br_print (indentstring)
      flowHandler.startForLoop("0", str(loopNumber), "1", -1, "")
      indentstring = flowHandler.getIndentStr()

    if (z <= lastLoadIndex):
      br_print (indentstring)
      syncId = loadIndex + 1

      funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", q" + str(tempSGPRAddr) + ", " + byteOffsetToGSMVGPRStr, flowLib.GetCommentPos(), "// init read addr for this row or col")
      for vgprIndex in range(vgprNumber):
        br_print (indentstring + "ld.gsm.float.mb16.rb16.sc" + str(loadIndex + 1) + ".e2.gc1 r" + str(tempVGPRAddr + loadIndex * vgprNumber + vgprIndex) + ", g0")
        br_print (indentstring + "mov.eog g0.u32, " + tileAddresVGPRStr + ".u32")
        if (vgprIndex != (vgprNumber-1)):
          if (direction == 0):
            funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + hex(hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// advance to next tile in x dir")
          else:
            funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + addressStepSGPRStr, flowLib.GetCommentPos(), "// advance to next tile in y dir")

      if (direction == 0):
        funcLib.AlignPrint(indentstring + "sadd q" + str(tempSGPRAddr) + ", q" + str(tempSGPRAddr) + ", " + addressStepSGPRStr, flowLib.GetCommentPos(), "// advance read addr to next row")
      else:
        funcLib.AlignPrint(indentstring + "sadd q" + str(tempSGPRAddr) + ", q" + str(tempSGPRAddr) + ", " + hex(hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// advance read addr to next col")

      loadIndex = funcLib.IncAndWrap(loadIndex, syncChannelNumber)

    if (z >= headNumber):
      br_print (indentstring)
      syncId = aluIndex + 1

      funcLib.AlignPrint(indentstring + "adds.sc" + str(syncId) + ".b32 " + tileAddresVGPRStr + ", q" + str(tempSGPRAddr+1) + ", " + byteOffsetToGSMVGPRStr, flowLib.GetCommentPos(), "// init write addr for this row or col")
      for vgprIndex in range(vgprNumber):
        funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "")
        br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
        br_print (indentstring + "mov.eog g1.f16, r" + str(tempVGPRAddr + aluIndex * vgprNumber + vgprIndex) + ".f16")

        if (vgprIndex != (vgprNumber-1)):
          if (direction == 0):
            funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + hex(hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// advance to next col")
          else:
            funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + addressStepSGPRStr, flowLib.GetCommentPos(), "// advance to next row")

      if (direction == 0):
        funcLib.AlignPrint(indentstring + "sadd q" + str(tempSGPRAddr + 1) + ", q" + str(tempSGPRAddr + 1) + ", " + addressStepSGPRStr, flowLib.GetCommentPos(), "// advance write addr to next row")
      else:
        funcLib.AlignPrint(indentstring + "sadd q" + str(tempSGPRAddr + 1) + ", q" + str(tempSGPRAddr + 1) + ", " + hex(hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// advance write addr to next col")

      aluIndex = funcLib.IncAndWrap(aluIndex, syncChannelNumber)

    if (z == (headNumber + bodyNumber - 1) and loopNumber > 1):
      flowHandler.closeForLoop("0", str(loopNumber), "1", -1)
      indentstring = flowHandler.getIndentStr()







################################################################################################################
# sub function generators
# sub function will be called at run time
# it uses some q/r registers as parameter
################################################################################################################




####################################################
# gen_avgpool_sub_function
def gen_avgpool_sub_function(yBorderType, rowSize, rightBorderMode, funcParameterMap, flowHandler):

  indentstring = flowHandler.getIndentStr()

  br_print (indentstring + "// funciton gen_avgpool_sub_function")
  br_print (indentstring + "// gsm holds (block start row-1, block start col-1) to (block end row+1, block start end+1)")
  br_print (indentstring + "// naming rule:")
  br_print (indentstring + "//    yBorderType_blockHeight_rightBorder")
  br_print (indentstring + "//    yBorderType    - y border info, top/bottom or both")
  if (yBorderType & BorderTypeTop()):
    br_print (indentstring + "//                   - top border")
  if (yBorderType & BorderTypeRight()):
    br_print (indentstring + "//                   - right border")
  if (yBorderType & BorderTypeBottom()):
    br_print (indentstring + "//                   - bottom border")
  if (yBorderType & BorderTypeLeft()):
    br_print (indentstring + "//                   - left border")

  br_print (indentstring + "//    blockHeight    - row number of current block")
  br_print (indentstring + "//    rightBorder    - whether it is right border, different width and border handling")
  if (rightBorderMode != 0):
    br_print (indentstring + "//                   - right border")

  blockBorderType = yBorderType

  if (rightBorderMode != 0):
    blockBorderType |= BorderTypeRight()

  br_print (indentstring)

  avgpool_block_load(blockBorderType, rowSize, funcParameterMap, flowHandler)
  avgpool_block_update(blockBorderType, rowSize, funcParameterMap, flowHandler)
  avgpool_block_rollover(blockBorderType, rowSize, funcParameterMap, flowHandler)








####################################################
# called whenever starting a new slice (sample or channel)
# initialize y coordinate for load/alu
# clear top padding tile, for both row mode and non row mode
# for row mode
#   also clear left/right padding tile once for all
#   load bottom padding tile rows

def do_y_initialize(inputVGPRStride, colSize, yBorderType, funcParameterMap, flowHandler):
  indentstring = flowHandler.getIndentStr()

  ySGPRStr          = funcParameterMap["ySGPRStr"]
  yOutSGPRStr       = funcParameterMap["yOutSGPRStr"]

  bufferGroupType   = funcParameterMap["bufferGroupType"]

  leftPaddingTile   = funcParameterMap["leftPaddingTile"]
  rightPaddingTile  = funcParameterMap["rightPaddingTile"]
  topPaddingTile    = funcParameterMap["topPaddingTile"]
  bottomPaddingTile  = funcParameterMap["bottomPaddingTile"]

  gsmBlockSizeX     = funcParameterMap["gsmBlockSizeX"]
  gsmBlockSizeY     = funcParameterMap["gsmBlockSizeY"]

  tempSGPRAddr      = funcParameterMap["tempSGPRAddr"]
  tileAddresVGPRStr = funcParameterMap["tileAddresVGPRStr"]
  byteOffsetToGSMVGPRStr = funcParameterMap["byteOffsetToGSMVGPRStr"]

  gsmBlockStrideX   = gsmBlockSizeX * 0x80

  funcLib.AlignPrint(indentstring + "smov " + ySGPRStr + ", 0", flowLib.GetCommentPos(), "// init input y")
  funcLib.AlignPrint(indentstring + "smov " + yOutSGPRStr + ", 0", flowLib.GetCommentPos(), "// init output y")

  if (bufferGroupType == BufferRowMode()) and (bottomPaddingTile != 0):
    br_print (indentstring)
    br_print (indentstring + "// load bottomPaddingTile row(s) for first band in row mode")
    inputVGPRAddr   = funcParameterMap["inputVGPRAddr"]
    inputVGPRStride      = funcParameterMap["inputVGPRStride"]
    xSGPRStr        = funcParameterMap["xSGPRStr"]
    uSharpIdList    = funcParameterMap["uSharpIdList"]
    coordSGPRStrList   = [xSGPRStr, ySGPRStr, funcParameterMap["zSGPRStr"], funcParameterMap["wSGPRStr"]]

    funcLib.AlignPrint(indentstring + "smov " + xSGPRStr + ", 0", flowLib.GetCommentPos(), "// init input x")

    thisVGPRAddr = inputVGPRAddr + leftPaddingTile * inputVGPRStride + topPaddingTile
    for x in range (gsmBlockSizeX - leftPaddingTile - rightPaddingTile):
      kernelLib.load_4d_activation(hwCaps.SurfaceFormatFP16(), hwCaps.SurfaceFormatFP16(), coordSGPRStrList,  thisVGPRAddr, bottomPaddingTile, 1, uSharpIdList[1][0], indentstring)
      thisVGPRAddr += inputVGPRStride
      funcLib.AlignPrint(indentstring + "sadd " + xSGPRStr + ", " + xSGPRStr + ", " + str(hwCaps.TileSizeX()), flowLib.GetCommentPos(), "// move to next tile in x dir")

    funcLib.AlignPrint(indentstring + "smov " + ySGPRStr + ", " + str(bottomPaddingTile * hwCaps.TileSizeY()), flowLib.GetCommentPos(), "// this is where load in loop start")

  if (topPaddingTile != 0):
    br_print (indentstring)
    br_print (indentstring + "// clear all top padding tiles in gsm")
    br_print (indentstring + "smov q" + str(tempSGPRAddr) + ", 0")
    for y in range (topPaddingTile):
      br_print (indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + byteOffsetToGSMVGPRStr + ", q" + str(tempSGPRAddr))
      for x in range (gsmBlockSizeX):
        funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "// clear gsm")
        br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
        br_print (indentstring + "movi.eog g1.f16, 0.0")
        funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + hex(hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// move to next tile in x dir")

      if (y < (topPaddingTile - 1)):
        funcLib.AlignPrint(indentstring + "sadd q" + str(tempSGPRAddr) + ", q" + str(tempSGPRAddr) + ", " + hex(gsmBlockStrideX), flowLib.GetCommentPos(), "// move to next row")

  if (bufferGroupType == BufferRowMode()):
    if (leftPaddingTile != 0):
      br_print (indentstring)
      br_print (indentstring + "// clear left padding tile for row mode")
      br_print (indentstring + "smov q" + str(tempSGPRAddr) + ", " + hex(topPaddingTile * gsmBlockStrideX))
      for y in range (gsmBlockSizeY - topPaddingTile):
        br_print (indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + byteOffsetToGSMVGPRStr + ", q" + str(tempSGPRAddr))
        for x in range (leftPaddingTile):
          funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "// clear gsm")
          br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
          br_print (indentstring + "movi.eog g1.f16, 0.0")

          if (x < (leftPaddingTile - 1)):
            funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + hex(hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// move to next tile in x dir")

        if (y < (gsmBlockSizeY - topPaddingTile - 1)):
          funcLib.AlignPrint(indentstring + "sadd q" + str(tempSGPRAddr) + ", q" + str(tempSGPRAddr) + ", " + hex(gsmBlockStrideX), flowLib.GetCommentPos(), "// move to next row")

    if (rightPaddingTile != 0):
      br_print (indentstring)
      br_print (indentstring + "// clear right padding tile for row mode")
      br_print (indentstring + "smov q" + str(tempSGPRAddr) + ", " + hex(topPaddingTile * gsmBlockStrideX + (gsmBlockSizeX - rightPaddingTile) * hwCaps.TileSizeX() * 4))

      for y in range (gsmBlockSizeY - topPaddingTile):
        br_print (indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + byteOffsetToGSMVGPRStr + ", q" + str(tempSGPRAddr))
        for x in range (rightPaddingTile):
          funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "// clear gsm")
          br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
          br_print (indentstring + "movi.eog g1.f16, 0.0")

          if (x < (rightPaddingTile - 1)):
            funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + hex(hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// move to next tile in x dir")

        if (y < (gsmBlockSizeY - topPaddingTile - 1)):
          funcLib.AlignPrint(indentstring + "sadd q" + str(tempSGPRAddr) + ", q" + str(tempSGPRAddr) + ", " + hex(gsmBlockStrideX), flowLib.GetCommentPos(), "// move to next row")


    if (bottomPaddingTile != 0):
      br_print (indentstring)
      br_print (indentstring + "// store bottomPaddingTile row(s) to gsm after topPaddingTile for first band in row mode")
      inputVGPRAddr   = funcParameterMap["inputVGPRAddr"]
      inputVGPRStride      = funcParameterMap["inputVGPRStride"]

      br_print (indentstring + "smov.sc1 q" + str(tempSGPRAddr) + ", " + hex(topPaddingTile * gsmBlockStrideX + leftPaddingTile * hwCaps.TileSizeX() * 4))

      for y in range (bottomPaddingTile):
        br_print (indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + byteOffsetToGSMVGPRStr + ", q" + str(tempSGPRAddr))
        for x in range (gsmBlockSizeX - leftPaddingTile - rightPaddingTile):
          funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "// st a tile to gsm")
          br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
          br_print (indentstring + "mov.eog g1.f16, r" + str(inputVGPRAddr + inputVGPRStride * x + y) + ".f16")

          if (x < (gsmBlockSizeX - leftPaddingTile - rightPaddingTile - 1)):
            funcLib.AlignPrint(indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + tileAddresVGPRStr + ", " + hex(hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// move to next tile in x dir")

        if (y < (bottomPaddingTile - 1)):
          funcLib.AlignPrint(indentstring + "sadd q" + str(tempSGPRAddr) + ", q" + str(tempSGPRAddr) + ", " + hex(gsmBlockStrideX), flowLib.GetCommentPos(), "// move to next row")
      br_print (indentstring)





####################################################
# called whenever starting a new band
# initialize x coordinate for load/alu
# for non row mode, clear left padding tile to 0
#   > for row mode, left padding is cleared and never overwritten
#   load right padding cols

def do_x_initialize(inputVGPRStride, yBorderType, funcParameterMap, flowHandler):

  indentstring = flowHandler.getIndentStr()

  xSGPRStr          = funcParameterMap["xSGPRStr"]
  xOutSGPRStr       = funcParameterMap["xOutSGPRStr"]
  bufferGroupType   = funcParameterMap["bufferGroupType"]

  leftPaddingTile   = funcParameterMap["leftPaddingTile"]
  rightPaddingTile  = funcParameterMap["rightPaddingTile"]
  topPaddingTile    = funcParameterMap["topPaddingTile"]
  bottomPaddingTile  = funcParameterMap["bottomPaddingTile"]

  gsmBlockSizeX     = funcParameterMap["gsmBlockSizeX"]
  gsmBlockSizeY     = funcParameterMap["gsmBlockSizeY"]

  byteOffsetToGSMVGPRStr = funcParameterMap["byteOffsetToGSMVGPRStr"]

  gsmBlockStrideX   = gsmBlockSizeX * 0x80

  br_print (indentstring)
  funcLib.AlignPrint(indentstring + "smov " + xSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize input x coord")
  funcLib.AlignPrint(indentstring + "smov " + xOutSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize output x coord")

  if (bufferGroupType == BufferRowMode()):
    pass
  else:
    tempSGPRAddr      = funcParameterMap["tempSGPRAddr"]
    tileAddresVGPRStr = funcParameterMap["tileAddresVGPRStr"]
    addressStepSGPRStr  = funcParameterMap["addressStepSGPRStr"]

    rowSize = gsmBlockSizeY
    rowStart = 0

    if ((yBorderType & BorderTypeTop()) != 0):
      rowSize -= topPaddingTile
      rowStart = topPaddingTile

    if (rightPaddingTile != 0):
      # load right padding tile cols for first block, only for non row mode
      br_print (indentstring + "// load right padding tile cols to gsm and write after left padding tile, for first block")
      inputVGPRAddr   = funcParameterMap["inputVGPRAddr"]
      inputVGPRStride      = funcParameterMap["inputVGPRStride"]
      uSharpIdList    = funcParameterMap["uSharpIdList"]
      coordSGPRStrList    = [xSGPRStr, funcParameterMap["ySGPRStr"], funcParameterMap["zSGPRStr"], funcParameterMap["wSGPRStr"]]

      for x in range (rightPaddingTile):
        kernelLib.load_4d_activation(hwCaps.SurfaceFormatFP16(), hwCaps.SurfaceFormatFP16(), coordSGPRStrList, inputVGPRAddr+rowSize*x, rowSize, 1, uSharpIdList[0][0], indentstring)
        funcLib.AlignPrint(indentstring + "sadd " + xSGPRStr + ", " + xSGPRStr + ", " + str(hwCaps.TileSizeX()), flowLib.GetCommentPos(), "// movet to next col in x dir")
      br_print (indentstring)

    if (leftPaddingTile != 0) or (rightPaddingTile != 0):
      funcLib.AlignPrint(indentstring + "smov " + addressStepSGPRStr + ", " + hex(gsmBlockStrideX), flowLib.GetCommentPos(), "// init y stride in gsm")

    if (leftPaddingTile != 0):
      # clear left padding whenever switching to a new band
      br_print (indentstring + "// clear left padding tile")
      br_print (indentstring + "smov q" + str(tempSGPRAddr) + ", " + hex(rowStart * gsmBlockStrideX))

      for x in range (leftPaddingTile):
        br_print (indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + byteOffsetToGSMVGPRStr + ", q" + str(tempSGPRAddr))
        for y in range (rowSize):
          funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "// clear gsm")
          br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
          br_print (indentstring + "movi.eog g1.f16, 0.0")

          if (y < (rowSize - 1)):
            funcLib.AlignPrint(indentstring + "adds.b32" + str(tileAddresVGPRStr) + ", " + str(tileAddresVGPRStr) + ", " + addressStepSGPRStr, flowLib.GetCommentPos(), "// move to next row")

        if (x < (leftPaddingTile - 1)):
          funcLib.AlignPrint(indentstring + "sadd q" + tempSGPRAddr + ", q" + tempSGPRAddr + ", " + hex(hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// move to next tile in x dir")

      br_print (indentstring)

    if (rightPaddingTile != 0):
      br_print (indentstring + "// store right padding tile cols to gsm after left padding tile")
      br_print (indentstring + "smov.sc1 q" + str(tempSGPRAddr) + ", " + hex(rowStart * gsmBlockStrideX + leftPaddingTile * hwCaps.TileSizeX() * 4))

      for x in range (rightPaddingTile):
        br_print (indentstring + "adds.b32 " + tileAddresVGPRStr + ", " + byteOffsetToGSMVGPRStr + ", q" + str(tempSGPRAddr))
        for y in range (rowSize):
          funcLib.AlignPrint(indentstring + "st.gsm.float.mb16.rb16.rw.e2.gc2 g0, g1", flowLib.GetCommentPos(), "// st a tile to gsm")
          br_print (indentstring + "mov g0.u32, " + tileAddresVGPRStr + ".u32")
          br_print (indentstring + "mov.eog g1.f16, r" + str(inputVGPRAddr + rowSize * x + y) + ".f16")

          if (y < (rowSize - 1)):
            funcLib.AlignPrint(indentstring + "adds.b32" + str(tileAddresVGPRStr) + ", " + str(tileAddresVGPRStr) + ", " + addressStepSGPRStr, flowLib.GetCommentPos(), "// move to next row")

        if (x < (leftPaddingTile - 1)):
          funcLib.AlignPrint(indentstring + "sadd q" + tempSGPRAddr + ", q" + tempSGPRAddr + ", " + hex(hwCaps.TileSizeX() * 4), flowLib.GetCommentPos(), "// move to next tile in x dir")

      br_print (indentstring)









####################################################
# process a horizontal band

def avgpool_kernel_process_channel_group(layerId, warpId, wSize, surfacePartition, funcParameterMap, funcGenHandler, flowHandler):

  uSharpIdList      = funcParameterMap["uSharpIdList"]

  xSGPRStr          = funcParameterMap["xSGPRStr"]
  ySGPRStr          = funcParameterMap["ySGPRStr"]
  zSGPRStr          = funcParameterMap["zSGPRStr"]
  wSGPRStr          = funcParameterMap["wSGPRStr"]

  yOutSGPRStr       = funcParameterMap["yOutSGPRStr"]
  xOutSGPRStr       = funcParameterMap["xOutSGPRStr"]

  euIdSGPRStr       = funcParameterMap["euIdSGPRStr"]

  topPaddingTile    = funcParameterMap["topPaddingTile"]
  filterStride      = funcParameterMap["filterStride"]
  bufferGroupType   = funcParameterMap["bufferGroupType"]

  indentstring = flowHandler.getIndentStr()

  funcLib.AlignPrint(indentstring + "smov " + wSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize w")
  if (wSize > 1):
    flowHandler.startForLoop("", str(wSize), str(1), funcParameterMap["wSGPRIndex"], "loop sample/test")

  indentstring = flowHandler.getIndentStr()

  inputVGPRStride = surfacePartition[0][0]
  ySpanList = surfacePartition[1]
  xSpanList = surfacePartition[2]

  ySpanListSize = len(ySpanList)

  do_y_initialize(inputVGPRStride, xSpanList[0], ySpanList[0][2], funcParameterMap, flowHandler)

  for ySpan in ySpanList:
    thisSpanHeight  = ySpan[0]
    thisBlockHeight = ySpan[1]
    thisBorderFlagY = ySpan[2]

    indentstring = flowHandler.getIndentStr()

    br_print (indentstring + "//////////////////////////////////////////////")
    if ((thisBorderFlagY & BorderTypeTop()) or (thisBorderFlagY & BorderTypeBottom())):
      assert (thisSpanHeight == thisBlockHeight), "top or bottom border span can't be in loop"

      if ((thisBorderFlagY & BorderTypeTop()) and (thisBorderFlagY & BorderTypeBottom())):
        br_print (indentstring + "// process signle horizontal band, both top and bottom")
      elif (thisBorderFlagY & BorderTypeTop()):
        br_print (indentstring + "// process top horizontal band")
      else:
        br_print (indentstring + "// process bottom horizontal band")
    else:
      br_print (indentstring + "// process middle horizontal band")

    vgprRowNumber = thisBlockHeight
    vgprStartIndex = inputVGPRStride

    thisSpanWidth   = xSpanList[0]
    thisBlockWidth  = xSpanList[1]

    blockNumberY = int (thisSpanHeight / thisBlockHeight)
    blockNumberX = int (thisSpanWidth / thisBlockWidth)

    if (blockNumberY > 1):
      flowHandler.startForLoop(str(0), str(blockNumberY), str(1), -1, "loop y")
      indentstring = flowHandler.getIndentStr()

    br_print (indentstring + "// initialize whenever switching to a new horizontal band")

    do_x_initialize(inputVGPRStride, ySpan[2], funcParameterMap, flowHandler)

    br_print (indentstring + "// finish initializing horizontal band")

    if (blockNumberX != 0):
      if (blockNumberX > 1):
        flowHandler.startForLoop(str(0), str(blockNumberX), str(1), -1, "loop x")
        indentstring = flowHandler.getIndentStr()

      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_0"
      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

      if (blockNumberX > 1):
        flowHandler.closeForLoop(str(0), str(blockNumberX), str(1), -1)
        indentstring = flowHandler.getIndentStr()

    functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_1"
    funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
    flowHandler.startFunctionCall(functionName)
    flowHandler.endFunctionCall()

    br_print (indentstring)
    if ((thisBorderFlagY & BorderTypeBottom()) == 0):
      br_print (indentstring + "// switch to next band")
      funcLib.AlignPrint(indentstring + "sadd " + yOutSGPRStr + ", " + yOutSGPRStr + ", " + str(thisBlockHeight * hwCaps.TileSizeY()), flowLib.GetCommentPos(), "// adjust output y")

      if (filterStride != 0):
        dstYStep = thisBlockHeight << 1
      else:
        dstYStep = thisBlockHeight

      if (bufferGroupType != BufferRowMode()) and (thisBorderFlagY & BorderTypeTop()) and (topPaddingTile != 0):
        if (dstYStep != topPaddingTile):
          br_print (indentstring + "// top band starts from row=0, and next band should start from row -topPaddingTile")
          funcLib.AlignPrint(indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str((dstYStep - topPaddingTile) * hwCaps.TileSizeY()), flowLib.GetCommentPos(), "// adjust input y")
      else:
        funcLib.AlignPrint(indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(dstYStep*hwCaps.TileSizeY()), flowLib.GetCommentPos(), "// adjust input y")

    if (blockNumberY > 1):
      flowHandler.closeForLoop(str(0), str(blockNumberY), str(1), -1)
      indentstring = flowHandler.getIndentStr()

    isFirstSub = 0

  if (wSize > 1):
    flowHandler.closeForLoop("", str(wSize), str(1), funcParameterMap["wSGPRIndex"])





def get_padding_size(filterInfo):
  filterSizeX       = filterInfo[GetFilterSizeX()]
  filterSizeY       = filterInfo[GetFilterSizeY()]
  filterOffsetX     = filterInfo[GetFilterOffsetX()]
  filterOffsetY     = filterInfo[GetFilterOffsetY()]

  # padding means when we process a block, whether we need a padding tile in each of 4 directions
  # padding tile needs to be saved when switch to a new block
  if (filterOffsetX == 0):
    leftPadding = 0
  else:
    leftPadding = int ((filterOffsetX + hwCaps.TileSizeX() - 1) / hwCaps.TileSizeX())

  if (filterOffsetY == 0):
    topPadding = 0
  else:
    topPadding = int ((filterOffsetY + hwCaps.TileSizeY() - 1) / hwCaps.TileSizeY())

  rightPadding = filterSizeX - (filterOffsetX + 1)

  if (rightPadding != 0):
    rightPadding = int ((rightPadding + hwCaps.TileSizeX() - 1) / hwCaps.TileSizeX())

  bottomPadding = filterSizeY - (filterOffsetY + 1)

  if (bottomPadding != 0):
    bottomPadding = int ((bottomPadding + hwCaps.TileSizeY() - 1) / hwCaps.TileSizeY())

  return [leftPadding, rightPadding, topPadding, bottomPadding]



####################################################
# set_layer_parameter
#   set layer related info and other info
#
def set_layer_parameter(layerInfo, funcParameterMap):

  optionsIndex = cwarp.GetOptionsIndex()
  uSharpIndex = cwarp.GetUSharpIndex()

  srcSurfaceWidth   = layerInfo[uSharpIndex][0][usharp.GetSurfCoordXIndex()]
  srcSurfaceHeight  = layerInfo[uSharpIndex][0][usharp.GetSurfCoordYIndex()]
  dstSurfaceWidth   = layerInfo[uSharpIndex][-1][usharp.GetSurfCoordXIndex()]
  dstSurfaceHeight  = layerInfo[uSharpIndex][-1][usharp.GetSurfCoordYIndex()]

  filterStride      = layerInfo[optionsIndex][GetFilterStrideIndex()]

  if (filterStride != 0):
    alignedSrcWidth   = srcSurfaceWidth << 1
    alignedSrcHeight  = srcSurfaceHeight << 1
  else:
    alignedSrcWidth   = srcSurfaceWidth
    alignedSrcHeight  = srcSurfaceHeight

  alignedSrcWidth   = funcLib.AlignToUnit(alignedSrcWidth, hwCaps.TileSizeX())
  alignedSrcHeight  = funcLib.AlignToUnit(alignedSrcHeight, hwCaps.TileSizeY())
  alignedDstWidth   = funcLib.AlignToUnit(dstSurfaceWidth, hwCaps.TileSizeX())
  alignedDstHeight  = funcLib.AlignToUnit(dstSurfaceHeight, hwCaps.TileSizeY())

  rightExtraTile = int ((alignedDstWidth - alignedSrcWidth) / hwCaps.TileSizeX())
  bottomExtraTile = int ((alignedDstHeight - alignedSrcHeight) / hwCaps.TileSizeY())

  [leftPadding, rightPadding, topPadding, bottomPadding] = get_padding_size(layerInfo[optionsIndex])

  funcParameterMap["filterSizeX"]         = layerInfo[optionsIndex][GetFilterSizeX()]
  funcParameterMap["filterSizeY"]         = layerInfo[optionsIndex][GetFilterSizeY()]
  funcParameterMap["filterOffsetX"]       = layerInfo[optionsIndex][GetFilterOffsetX()]
  funcParameterMap["filterOffsetY"]       = layerInfo[optionsIndex][GetFilterOffsetY()]
  funcParameterMap["filterStride"]        = filterStride

  funcParameterMap["imageWidthRes"]       = dstSurfaceWidth & (hwCaps.TileSizeX() - 1)
  funcParameterMap["imageHeightRes"]      = dstSurfaceHeight & (hwCaps.TileSizeY() - 1)
  funcParameterMap["rightExtraTile"]      = rightExtraTile
  funcParameterMap["bottomExtraTile"]     = bottomExtraTile

  funcParameterMap["leftPaddingTile"]     = leftPadding
  funcParameterMap["topPaddingTile"]      = topPadding
  funcParameterMap["rightPaddingTile"]    = rightPadding
  funcParameterMap["bottomPaddingTile"]   = bottomPadding

  uSharpIdList = [[layerInfo[uSharpIndex][0][usharp.GetSurfUsharpIDIndex()]],    #   input
                  [layerInfo[uSharpIndex][-1][usharp.GetSurfUsharpIDIndex()]]]  #   output

  funcParameterMap["uSharpIdList"]    = uSharpIdList



####################################################
# set_vgpr_number
#   find out how many vgprs can be used as load buffer
#
def set_vgpr_number(vgprPartition, filterInfo, funcParameterMap):
  if (vgprPartition[1] <= vgprPartition[0]):
    assert False, "  no vgpr to use"

  vgprStart = vgprPartition[0]
  vgprNumber = vgprPartition[1] - vgprPartition[0]

  funcParameterMap["laneOffsetVGPRAddr"] = vgprStart
  vgprNumber -= 2
  vgprStart += 2

  funcParameterMap["tileAddresVGPRAddr"] = vgprStart
  vgprNumber -= 1
  vgprStart += 1

  funcParameterMap["vgprNumber"]     = vgprNumber

  funcParameterMap["inputVGPRAddr"]  = vgprStart
  funcParameterMap["tempVGPRAddr"]   = vgprStart

  tempVGPRNumber = 2 * filterInfo[0]

  funcParameterMap["outputVGPRAddr"]   = vgprStart + tempVGPRNumber
  funcParameterMap["outputVGPRNumber"]  = vgprNumber - tempVGPRNumber






####################################################
# find out block size
#
def get_avgpool_block_size(surfaceTileInfo, funcParameterMap):

  vgprNumber = funcParameterMap["vgprNumber"]
  outputVGPRNumber = funcParameterMap["outputVGPRNumber"]

  if (vgprNumber > 64):
    # 8x8*0x80 = 8k, that is each EU can get from gsm
    usefulVGPRNumber = 64
  else:
    usefulVGPRNumber = vgprNumber

  #gsmBlockSizeX = 8
  #gsmBlockSizeY = 8

  filterStride = funcParameterMap["filterStride"]

  xPadding = funcParameterMap["leftPaddingTile"] + funcParameterMap["rightPaddingTile"]
  yPadding = funcParameterMap["topPaddingTile"] + funcParameterMap["bottomPaddingTile"]

  srcTileWidth = surfaceTileInfo[3]
  srcTileHeight = surfaceTileInfo[2]
  dstTileWidth = surfaceTileInfo[3]
  dstTileHeight = surfaceTileInfo[2]

  if (filterStride != 0):
    srcTileWidth <<= 1
    srcTileHeight <<= 1

  if (srcTileWidth < srcTileHeight):
    if (usefulVGPRNumber >= (2 + yPadding) * (srcTileWidth + xPadding)):
      gsmBlockSizeX = (srcTileWidth + xPadding)
    else:
      gsmBlockSizeX = math.floor(math.sqrt(usefulVGPRNumber))

      if (gsmBlockSizeX > (srcTileWidth + xPadding)):
        gsmBlockSizeX = (srcTileWidth + xPadding)

    gsmBlockSizeY = int (usefulVGPRNumber / gsmBlockSizeX)

    if (gsmBlockSizeY > (srcTileHeight + yPadding)):
      gsmBlockSizeY = (srcTileHeight + yPadding)
  else:
    gsmBlockSizeY = math.floor(math.sqrt(usefulVGPRNumber))

    if (gsmBlockSizeY > (srcTileHeight + yPadding)):
      gsmBlockSizeY = (srcTileHeight + yPadding)

    gsmBlockSizeX = int (usefulVGPRNumber / gsmBlockSizeY)

    if (gsmBlockSizeX > (srcTileWidth + xPadding)):
      gsmBlockSizeX = (srcTileWidth + xPadding)

  while (1):
    blockUnitX = gsmBlockSizeX - xPadding
    blockUnitY = gsmBlockSizeY - yPadding

    if (filterStride != 0):
      # stride, source surface will be expanded 2 times in x/y direction
      if (blockUnitX & 1):
        gsmBlockSizeX -= 1

      if (blockUnitY & 1):
        gsmBlockSizeY -= 1

      blockUnitX >>= 1
      blockUnitY >>= 1

    if (blockUnitX * blockUnitY <= outputVGPRNumber):
      break

    if (blockUnitX > blockUnitY):
      gsmBlockSizeY -= 1
    else:
      gsmBlockSizeX -= 1

  return (blockUnitX, blockUnitY, gsmBlockSizeX, gsmBlockSizeY)



####################################################
# find out buffer mode
#
def get_avgpool_buffer_mode(surfaceTileInfo, blockUnit):
  xSize = surfaceTileInfo[3]

  if (xSize <= blockUnit[0]):
    bufferMode = BufferRowMode()
  else:
    bufferMode = BufferBlockMode()

  return bufferMode





####################################################

def get_avgpool_surface_partition(surfaceTileInfo, borderType, funcParameterMap, indendString):

  blockUnit = get_avgpool_block_size(surfaceTileInfo, funcParameterMap)

  bufferConfig = get_avgpool_buffer_mode(surfaceTileInfo, blockUnit)

  topPaddingTile      = funcParameterMap["topPaddingTile"]

  ySize = surfaceTileInfo[2]
  xSize = surfaceTileInfo[3]
  xUnit = blockUnit[0]
  yUnit = blockUnit[1]

  if (yUnit == 0 or xUnit == 0):
    assert False, "  not enough vgprs, can't find a block that can fit " + str(vgprNumber) + " vgprs"

  partitionList = []

  yTopFlag = borderType & BorderTypeTop()
  yBottomFlag = borderType & (BorderTypeBottom() | BorderTypeBottomPartial())

  yAlignedSize = int (ySize / yUnit) * yUnit
  yRemainder = ySize - yAlignedSize

  ySpanList = []

  if (yRemainder == 0 and yAlignedSize != 0):
    yAlignedSize -= yUnit
    yRemainder += yUnit

  if (yAlignedSize != 0):
    if (topPaddingTile != 0):
      # first one is top, last one is bottom
      ySpanList.append([yUnit, yUnit, yTopFlag])
      yAlignedSize -= yUnit

    if (yAlignedSize != 0):
      ySpanList.append([yAlignedSize, yUnit, 0])

  ySpanList.append([yRemainder, yRemainder, 0])
  # first one is top, last one is bottom
  ySpanList[-1][2] |= yBottomFlag

  xBorderFlag = borderType & (BorderTypeRight() | BorderTypeRightPartial())

  xAlignedSize = int (xSize / xUnit) * xUnit
  partialBlockWidth = xSize - xAlignedSize

  if (partialBlockWidth == 0):
    partialBlockWidth += xUnit
    xAlignedSize -= xUnit

  xSpanList = [xAlignedSize, xUnit, xBorderFlag]

  return ([blockUnit[3], bufferConfig, blockUnit[1]], ySpanList, xSpanList, [partialBlockWidth, blockUnit[2], blockUnit[3]])





####################################################
# set_surface_parameter
#   set surface related info such as border info, block width etc
#
def set_surface_parameter(funcParameterMap, surfacePartition):

  bufferGroupType = surfacePartition[0][1]

  funcParameterMap["bufferGroupType"]  = bufferGroupType

  funcParameterMap["inputVGPRStride"]  = surfacePartition[0][0]
  funcParameterMap["outputVGPRStride"]  = surfacePartition[0][2]

  if (bufferGroupType == BufferRowMode()):
    # there is no full wide block, use partial width instead
    fullBlockWidth = surfacePartition[3][0]
  else:
    # xUnit
    fullBlockWidth = surfacePartition[2][1]

  funcParameterMap["fullBlockWidth"]  = fullBlockWidth
  funcParameterMap["partialBlockWidth"] = surfacePartition[3][0]
  funcParameterMap["gsmBlockSizeX"] = surfacePartition[3][1]
  funcParameterMap["gsmBlockSizeY"] = surfacePartition[3][2]






def set_gpr_usage(funcParameterMap, layerInfo, flowHandler):
  indentstring = flowHandler.getIndentStr()

  funcParameterMap["constBase"]       = "a0"
  funcParameterMap["vgprBaseStr"]     = "a1"
  funcParameterMap["sgprBase"]        = "a2"

  br_print (indentstring + "// sgpr usage:")
  coordSGPRIndex = flowHandler.allocateSGPR(6)
  funcParameterMap["zSGPRIndex"]      = coordSGPRIndex + 2
  funcParameterMap["wSGPRIndex"]      = coordSGPRIndex + 3
  funcParameterMap["xSGPRStr"]        = "q" + str(coordSGPRIndex)
  funcParameterMap["ySGPRStr"]        = "q" + str(coordSGPRIndex + 1)
  funcParameterMap["zSGPRStr"]        = "q" + str(coordSGPRIndex + 2)
  funcParameterMap["wSGPRStr"]        = "q" + str(coordSGPRIndex + 3)

  funcParameterMap["xOutSGPRStr"]     = "q" + str(coordSGPRIndex + 4)
  funcParameterMap["yOutSGPRStr"]     = "q" + str(coordSGPRIndex + 5)

  br_print (indentstring + "//   x/y/z/w at sgpr q" + str(coordSGPRIndex) + "-q" + str(coordSGPRIndex+5))
  br_print (indentstring + "//     input x/y uses " + funcParameterMap["xSGPRStr"] + " and " + funcParameterMap["ySGPRStr"])
  br_print (indentstring + "//     output x/y uses " + funcParameterMap["xOutSGPRStr"] + " and " + funcParameterMap["yOutSGPRStr"])

  euIdSGPRIndex = flowHandler.allocateSGPR(1)
  euIdSGPRStr = "q" + str(euIdSGPRIndex)
  funcParameterMap["euIdSGPRStr"]   = euIdSGPRStr
  br_print (indentstring + "//   unique eu id at sgpr " + euIdSGPRStr)

  addressStepSGPRIndex = flowHandler.allocateSGPR(1)
  addressStepSGPRStr = "q" + str(addressStepSGPRIndex)
  funcParameterMap["addressStepSGPRStr"] = addressStepSGPRStr
  br_print (indentstring + "//   address step at sgpr " + addressStepSGPRStr)

  tempSGPRAddr = flowHandler.allocateSGPR(2)
  funcParameterMap["tempSGPRAddr"] = tempSGPRAddr
  br_print (indentstring + "//   temp at sgpr q" + str(tempSGPRAddr))

  vgprBaseSGPRIndex = flowHandler.allocateSGPR(1)
  vgprBaseSGPRStr = "q" + str(vgprBaseSGPRIndex)
  funcParameterMap["vgprBaseSGPRStr"] = vgprBaseSGPRStr
  br_print (indentstring + "//   vgpr base at sgpr " + vgprBaseSGPRStr)


  laneOffsetVGPRAddr = funcParameterMap["laneOffsetVGPRAddr"]
  tileAddresVGPRAddr = funcParameterMap["tileAddresVGPRAddr"]
  tempVGPRAddr = funcParameterMap["tempVGPRAddr"]
  inputVGPRAddr = funcParameterMap["inputVGPRAddr"]
  vgprNumber = funcParameterMap["vgprNumber"]

  br_print (indentstring + "// vgpr usage:")

  laneIdVGPRIndex = flowHandler.reserveVGPR(0, 1)
  laneIdVGPRStr = "r" + str(laneIdVGPRIndex)
  br_print (indentstring + "//   lane id at vgpr " + laneIdVGPRStr + ", initialized at beginning, should never be overwritten")
  funcParameterMap["laneIdVGPRStr"] = laneIdVGPRStr

  byteOffsetToGSMVGPRStr = "r" + str(laneOffsetVGPRAddr)
  funcParameterMap["byteOffsetToGSMVGPRStr"] = byteOffsetToGSMVGPRStr
  br_print (indentstring + "//   lane offset to gsm at " + byteOffsetToGSMVGPRStr + ", this is for load kernel writing togsm")

  byteOffsetFromGSMVGPRStr = "r" + str(laneOffsetVGPRAddr + 1)
  funcParameterMap["byteOffsetFromGSMVGPRStr"] = byteOffsetFromGSMVGPRStr
  br_print (indentstring + "//   lane offset from gsm at " + byteOffsetFromGSMVGPRStr + ", this is for alu kernel reading from gsm")

  tileAddresVGPRStr = "r" + str(tileAddresVGPRAddr)
  funcParameterMap["tileAddresVGPRStr"] = tileAddresVGPRStr
  br_print (indentstring + "//   tile's address at " + tileAddresVGPRStr + ", set on the fly")

  br_print (indentstring + "//   temp will use r[" + str(tempVGPRAddr) + ", " + str(inputVGPRAddr) + ")")
  br_print (indentstring + "//   input will use r[" + str(inputVGPRAddr) + ", " + str(inputVGPRAddr + 36) + ")")







####################################################
# gen_kernel_sub_function
#   generate sub functions that will be called

def gen_kernel_sub_function(funcDefMap, funcParaDict):
  flowHandler = flowLib.FlowHandler("", 0, 0, compiler.GetASMMode())

  for x, y in funcDefMap.items():
    br_print ("// func " + x + ", q regs free to use: " + str(y))
    br_print ("// return address at q" + str(y[1]+1))

    funcKeys = x.split("_")

    flowHandler.startFunctionDef(x, 1)
    flowHandler.setLabelIndex(0)
    flowHandler.setLabelSuffix(x.upper())
    flowHandler.setQTempStart(y[0])
    flowHandler.setQStackStart(y[1])

    yBorderType   = int (funcKeys[5])
    blockHeight   = int (funcKeys[6])
    rightBorderMode = int (funcKeys[7])

    gen_avgpool_sub_function(yBorderType, blockHeight, rightBorderMode, funcParaDict, flowHandler)

    flowHandler.closeFunctionDef(x, 1)
    br_print ("\n\n\n\n")




####################################################
#
def gen_layer_vgpr_usage(layerId, layerNumber, warpId, layerInfo):
  optionsIndex = cwarp.GetOptionsIndex()

  filterInfo = [layerInfo[optionsIndex][GetFilterSizeX()], layerInfo[optionsIndex][GetFilterSizeY()],
                layerInfo[optionsIndex][GetFilterOffsetX()], layerInfo[optionsIndex][GetFilterOffsetY()],
                layerInfo[optionsIndex][GetFilterStrideIndex()]]

  # input is used to as an intermediate space to hold input data from memory before saving them to gsm
  # after that, it is not in use anymore
  # output buffer is used for output, usually it is smaller than input buffer
  # temp buffer is used in two cases
  # 1. load all data in filter x
  # 2. load a whole col or a whole row of input buffer
  # both cases need double buffer

  minOutputBlockTileX = 1
  minOutputBlockTileY = 1

  minVGPRNumber0 = minOutputBlockTileX * minOutputBlockTileY + 2 * filterInfo[0]

  if (filterInfo[4] != 0):
    minGSMBlockTileX = minOutputBlockTileX << 1
    minGSMBlockTileY = minOutputBlockTileY << 1
  else:
    minGSMBlockTileX = minOutputBlockTileX
    minGSMBlockTileY = minOutputBlockTileY

  [leftPadding, rightPadding, topPadding, bottomPadding] = get_padding_size(layerInfo[optionsIndex])

  minGSMBlockTileX += leftPadding + rightPadding
  minGSMBlockTileY += rightPadding + bottomPadding

  minVGPRNumber1 = minGSMBlockTileX * minGSMBlockTileY

  if (minVGPRNumber1 < minVGPRNumber0):
    minVGPRNumber1 = minVGPRNumber0

  # need 3 extra vgprs to hold gsm offset (from and to), and per lane gsm address
  # laneOffsetVGPRAddr and tileAddresVGPRAddr

  return minVGPRNumber1 + 3





####################################################
#
def gen_layer_main_kernel(layerId, layerNumber, warpId, layerInfo, flowHandler):

  cmdIndex = cwarp.GetCMDIndex()

  if (layerInfo[cmdIndex] != "avgpool"):
    assert False, "unsupported op " + layerInfo[cmdIndex]
    return

  flowHandler.startFunctionDef("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel", 0)
  indentstring = flowHandler.getIndentStr()

  funcGenHandler = funcgen.FuncGenHandler()
  funcParameterMap = {}

  flowHandler.setLabelSuffix("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel")

  uSharpIndex = cwarp.GetUSharpIndex()
  optionsIndex = cwarp.GetOptionsIndex()

  # use dst surface to do screen partition
  surfaceSample = layerInfo[uSharpIndex][1][usharp.GetSurfCoordSampleIndex()]
  surfaceChannel = layerInfo[uSharpIndex][1][usharp.GetSurfCoordChannelIndex()]
  surfaceHeight = layerInfo[uSharpIndex][1][usharp.GetSurfCoordYIndex()]
  surfaceWidth = layerInfo[uSharpIndex][1][usharp.GetSurfCoordXIndex()]

  filterInfo = [layerInfo[optionsIndex][GetFilterSizeX()], layerInfo[optionsIndex][GetFilterSizeY()],
                layerInfo[optionsIndex][GetFilterOffsetX()], layerInfo[optionsIndex][GetFilterOffsetY()],
                layerInfo[optionsIndex][GetFilterStrideIndex()]]

  br_print (indentstring + "// layer info:")
  br_print (indentstring + "//   op            - :" + layerInfo[cmdIndex])
  br_print (indentstring + "//   surface       - sample : " + str(surfaceSample) + ", channel: " + str(surfaceChannel) + ", height: " + str(surfaceHeight) + ", width: " + str(surfaceWidth))
  br_print (indentstring + "//   filter        - x size : " + str(filterInfo[0]) + ", y size: " + str(filterInfo[1]))
  br_print (indentstring + "//                 - x offset : " + str(filterInfo[2]) + ", y offset: " + str(filterInfo[3]))
  br_print (indentstring + "//                 - stride : " + str(filterInfo[4]))

  kernelLib.PrintUSharpList(layerInfo[uSharpIndex], indentstring)

  set_layer_parameter(layerInfo, funcParameterMap)

  set_vgpr_number(layerInfo[cwarp.GetVGPRPartitionIndex()], filterInfo, funcParameterMap)

  borderType = BorderTypeAll()

  tileNumberX = int ((surfaceWidth + hwCaps.TileSizeX() - 1) / hwCaps.TileSizeX())
  tileNumberY = int ((surfaceHeight + hwCaps.TileSizeY() - 1) / hwCaps.TileSizeY())

  if (surfaceHeight % hwCaps.TileSizeY()):
    borderType |= BorderTypeBottomPartial()

  if (surfaceWidth % hwCaps.TileSizeX()):
    borderType |= BorderTypeRightPartial()

  surfaceTileInfo = [surfaceSample, surfaceChannel, tileNumberY, tileNumberX]

  surfacePartition = get_avgpool_surface_partition(surfaceTileInfo, borderType, funcParameterMap, flowHandler.getIndentStr())

  set_surface_parameter(funcParameterMap, surfacePartition)

  set_gpr_usage(funcParameterMap, layerInfo, flowHandler)

  indentstring = flowHandler.getIndentStr()

  br_print (indentstring + "// tile info:")
  br_print (indentstring + "//   tile number y = " + str(tileNumberY) + ", tile number x = " + str(tileNumberX))
  br_print (indentstring)

  br_print (indentstring + "// start preprocessing")
  br_print (indentstring)

  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "//  " + layerInfo[cwarp.GetCMDIndex()] + " parition :")

  inputVGPRStride = surfacePartition[0][0]
  br_print (indentstring + "//    input VGPR Stride: " + str(surfacePartition[0][0]))
  br_print (indentstring + "//    output VGPR Stride: " + str(surfacePartition[0][2]))
  br_print (indentstring + "//    buffer mode: " + str(surfacePartition[0][1]))

  br_print (indentstring + "//    y dir partition:")
  for thisSpan in surfacePartition[1]:
    br_print (indentstring + "//      height: " + str(thisSpan[0]) + ", step: " + str(thisSpan[1]) + ", border: " + str(thisSpan[2]))

  thisSpan = surfacePartition[2]
  br_print (indentstring + "//    x dir partition:")
  br_print (indentstring + "//      width:  " + str(thisSpan[0]) + ", step: " + str(thisSpan[1]) + ", border: " + str(thisSpan[2]))

  thisSpan = surfacePartition[3]
  br_print (indentstring + "//      partial block width: " + str(thisSpan[0]))

  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "// start average pooling")
  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring)



  laneIdVGPRStr = funcParameterMap["laneIdVGPRStr"]
  byteOffsetToGSMVGPRStr = funcParameterMap["byteOffsetToGSMVGPRStr"]
  tempVGPRAddr = funcParameterMap["tempVGPRAddr"]

  # print (indentstring + "//////////////////////////////////////////////")
  # print (indentstring + "// initialize bar")
  # bn2reduceBarIdSGPRStr     = funcParameterMap["bn2reduceBarIdSGPRStr"]
  # reduce2bnBarIdSGPRStr     = funcParameterMap["reduce2bnBarIdSGPRStr"]
  # funcLib.AlignPrint(indentstring + "smov " + reduce2bnBarIdSGPRStr + ", " + str(cwarp.GetReduce2BNSyncBarId()), flowLib.GetCommentPos(), "// set reduce->bn bar id")
  # funcLib.AlignPrint(indentstring + "smov " + bn2reduceBarIdSGPRStr + ", " + str(cwarp.GetBN2ReduceSyncBarId()), flowLib.GetCommentPos(), "// set bn->reduce bar id")
  # funcLib.AlignPrint(indentstring + "bar.tg.pass " + str(cwarp.GetBN2ReduceSyncBarId()) + ", 2", flowLib.GetCommentPos(), "// initialize bn->reduce bar so reduce could start")
  # funcLib.AlignPrint(indentstring + "bar.tg.pass " + str(cwarp.GetBN2ReduceSyncBarId()+1) + ", 2", flowLib.GetCommentPos(), "// initialize bn->reduce bar so reduce could start")

  br_print (indentstring)
  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "// initialize channel id")
  zSGPRStr      = funcParameterMap["zSGPRStr"]
  euIdSGPRStr = funcParameterMap["euIdSGPRStr"]
  br_print (indentstring + "sysid.work " + euIdSGPRStr)
  funcLib.AlignPrint(indentstring + "sand " + euIdSGPRStr + ", " + euIdSGPRStr + ", 0xf", flowLib.GetCommentPos(), "// obtain unique eu id")
  funcLib.AlignPrint(indentstring + "sshl " + zSGPRStr + ", " + euIdSGPRStr + ", 1", flowLib.GetCommentPos(), "// initialize z with channel pair start")



  br_print (indentstring)
  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "// initialize lane's addr offset in gsm")
  gsmBlockSizeX       = funcParameterMap["gsmBlockSizeX"] * hwCaps.TileSizeX()
  filterStride        = funcParameterMap["filterStride"]

  funcLib.AlignPrint(indentstring + "and.b32 " + byteOffsetToGSMVGPRStr + ", " + laneIdVGPRStr + ", 0x18", flowLib.GetCommentPos(), "// extract lane's y")
  funcLib.AlignPrint(indentstring + "and.b32 r" + str(tempVGPRAddr) + ", " + laneIdVGPRStr + ", 7", flowLib.GetCommentPos(), "// extract lane's x")

  if (funcLib.IsPower2(gsmBlockSizeX)):
    yShift = funcLib.GetLeadingOnePos(gsmBlockSizeX)
    funcLib.AlignPrint(indentstring + "shl.b32 " + byteOffsetToGSMVGPRStr + ", " + byteOffsetToGSMVGPRStr + ", " + str(yShift), flowLib.GetCommentPos(), "// adjust by number of tiles in x dir")
  else:
    yScale = gsmBlockSizeX
    funcLib.AlignPrint(indentstring + "mulu.b32 " + byteOffsetToGSMVGPRStr + ", " + byteOffsetToGSMVGPRStr + ", " + str(yScale), flowLib.GetCommentPos(), "// adjust by number of tiles in x dir")
  funcLib.AlignPrint(indentstring + "or.b32 " + byteOffsetToGSMVGPRStr + ", " + byteOffsetToGSMVGPRStr + ", r" + str(tempVGPRAddr), flowLib.GetCommentPos(), "// per lane offset in element")
  funcLib.AlignPrint(indentstring + "shl.b32 " + byteOffsetToGSMVGPRStr + ", " + byteOffsetToGSMVGPRStr + ", 2", flowLib.GetCommentPos(), "// per lane offset in bytes, surface -> gsm")

  if (filterStride == 0):
    funcParameterMap["byteOffsetFromGSMVGPRStr"] = byteOffsetToGSMVGPRStr
  else:
    byteOffsetFromGSMVGPRStr = funcParameterMap["byteOffsetFromGSMVGPRStr"]
    funcLib.AlignPrint(indentstring + "shl.b32 " + byteOffsetFromGSMVGPRStr + ", " + byteOffsetToGSMVGPRStr + ", 1", flowLib.GetCommentPos(), "// per lane offset in bytes, pooling reading gsm")


  br_print (indentstring)
  flowHandler.startForLoop("", str(surfaceTileInfo[1]), str(32), funcParameterMap["zSGPRIndex"], "loop channel")
  indentstring = flowHandler.getIndentStr()

  avgpool_kernel_process_channel_group(layerId, warpId, surfaceTileInfo[0], surfacePartition, funcParameterMap, funcGenHandler, flowHandler)

  br_print (indentstring)
  flowHandler.closeForLoop("", str(surfaceTileInfo[1]), str(32), funcParameterMap["zSGPRIndex"])
  indentstring = flowHandler.getIndentStr()

  br_print (indentstring)
  kernelLib.jump_to_next_layer(layerId, layerNumber, warpId, indentstring)
  br_print (indentstring)

  flowHandler.closeFunctionDef("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel", 0)

  gen_kernel_sub_function(funcGenHandler.getFuncDef(), funcParameterMap)




