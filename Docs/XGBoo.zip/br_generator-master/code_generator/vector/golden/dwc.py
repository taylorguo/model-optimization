#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import sys
import os
import math

import code_generator.share.br_const_defs as bcd
import code_generator.vector.common.hwCaps as hwCaps
import code_generator.vector.common.flowLib as flowLib
import code_generator.vector.common.cwarp as cwarp
import code_generator.vector.common.funcgen as funcgen
import code_generator.vector.common.funcLib as funcLib
import code_generator.vector.common.kernelLib as kernelLib
import code_generator.vector.common.compiler as compiler
import code_generator.vector.common.usharp as usharp
import code_generator.share.br_const_defs as bcd

from code_generator.share.br_defined_print import br_print


def FuncTypeLoad():
  return 0


def FuncTypeALU():
  return 1


def GetFilterSizeX():
  return 0


def GetFilterSizeY():
  return 1


def GetFilterOffsetX():
  return 2


def GetFilterOffsetY():
  return 3


def GetFilterStrideIndex():
  return 4


def GetBNBeforeOnIndex():
  return 5


def GetReduceOnIndex():
  return 6

def GetPoolModeIndex():
  return 7

def GetReluAfterBNIndex():
  return 8


def GetReluOnIndex():
  return 9


def GetWeightUSharpIndex():
  return 1


def GetGammaUSharpIndex():
  return 2


def GetDWCLoadLoopUnrollThreshold():
  return 2


def GetDWCAluLoopUnrollThreshold():
  return 2


def BufferRowModeThresholdX():
  return 8


def BufferRowModeThresholdY():
  return 3


def BufferBlockMode():
  return 0


def BufferSurfaceMode():
  return 1


def BufferRowMode():
  return 2


def BufferColMode():
  return 3


def BorderTypeBottom():
  return 1


def BorderTypeBottomPartial():
  return 2


def BorderTypeTop():
  return 4


def BorderTypeRight():
  return 8


def BorderTypeLeft():
  return 16


def BorderTypeRightPartial():
  return 32


def BorderTypeAll():
  return BorderTypeBottom() | BorderTypeRight() | BorderTypeTop()

################################################################################################################
# general functions
# does not necessarily for pooling kernel only
################################################################################################################


####################################################
# dwc_tile_v
#   process a group of tiles, the group is from mov group
#   there is no restriction on border, sync and etc
def dwc_tile_v(instrOp, isaModifier, vectorSize, vgprIndex, vgprStride, vgprDstStart, syncId, borderType, strid2Flag, funcParameterMap, flowHandler):
  
  indentstring = flowHandler.getIndentStr()

  mateInstrStr = funcParameterMap["mateInstrStr"]
  mateInstrSrcStr = funcParameterMap["mateInstrSrcStr"]

  if (vgprDstStart < 0):
    dstVGPRType = "g"
    vgprDstStart += 16
  else:
    dstVGPRType = "r"

  if (borderType & BorderTypeRight()):
    vgprRightStr = "z0"
  else:
    vgprRightStr = "ir" + str(vgprIndex + vgprStride) + ""

  if (borderType & BorderTypeLeft()):
    vgprLeftStr = "z0"
  else:
    vgprLeftStr = "ir" + str(vgprIndex - vgprStride) + ""

  syncModifier = kernelLib.GetSyncModifier(syncId)

  isStride2On = (strid2Flag & kernelLib.GetStrideEnableMask()) != 0

  for y in range (vectorSize):

    if ((borderType & BorderTypeLeft()) == 0):
      if vgprIndex - vgprStride < 0:
        vgprLeftStr = "z0"
      else:
        vgprLeftStr = "ir" + str(vgprIndex - vgprStride) + ""

    if ((borderType & BorderTypeRight()) == 0):
      vgprRightStr = "ir" + str(vgprIndex + vgprStride) + ""

    # generate mate instruction
    if (isStride2On != 0):
      strideGroupModifer = kernelLib.GetStrideGroupModifier(strid2Flag)
      strid2Flag ^= kernelLib.GetStrideGroupFlagYMask()
    else:
      strideGroupModifer = ""

    if (y == 0) and (borderType & BorderTypeTop()) and (not funcParameterMap["singleTileRowMode"]):
      yBoundModifier = ".bndtop"
    else:
      yBoundModifier = ""

    if (y == (vectorSize - 1)) and (borderType & BorderTypeBottom()) and (not funcParameterMap["singleTileRowMode"]):
      yBoundModifier += ".bndbot"

    if (yBoundModifier == ""):
      yBoundModifier = ".bndnot"

    br_print (indentstring + mateInstrStr + yBoundModifier + strideGroupModifer + mateInstrSrcStr)

    br_print (indentstring + "& " +instrOp + isaModifier + " " + dstVGPRType + str(vgprDstStart) + ", ir" + str(vgprIndex) + "" + ", " + vgprLeftStr + ", " + vgprRightStr)

    if (isStride2On == 0) or ((strid2Flag & kernelLib.GetStrideGroupFlagYMask()) == 0):
      vgprDstStart += 1

    syncModifier = ""
    vgprIndex += 1


####################################################
# store_tile_v
#   store 1 tile, without setting g0 register
def store_tile_v(vectorSize, usharpStr, indentstring, mmat3d=True, write_through=True):
  mmat = ".mmat3d" if mmat3d is True else ".mmat2d"
  wt = ".wt" if write_through is True else ".nwt"
  br_print (indentstring + "stm.float.mb16.rb16" + mmat + kernelLib.GetVectorModifier(vectorSize * 2, "e") + wt + ".gc" + str(4 + vectorSize) + " g0, g4, u" + usharpStr)

####################################################
#
# vcnt = {v1|v2|v3|v4|v8}
def bn_tile_v(vgprAddr, vgprNumber, bnCoeffVGPRIndex, isPartial, indentstring, withrelu):

  sizeList = funcLib.SplitRepeatIntoGroups(vgprNumber, hwCaps.MaxALUGranule())

  if (isPartial):
    predicateModifier = "m0."
  else:
    predicateModifier = ""

  for thisArray in sizeList:
    for z in range(thisArray[0]):
      vectorModifier = kernelLib.GetVectorModifier(thisArray[1], "v")
      br_print (indentstring + predicateModifier + "fmad.b16" + vectorModifier + " ir" + str(vgprAddr) + ", ir" + str(vgprAddr) + ".a, r" + str(bnCoeffVGPRIndex) + ", r" + str(bnCoeffVGPRIndex + 1))

      if withrelu:
        br_print (indentstring + predicateModifier + "fmax.b16" + vectorModifier + " ir" + str(vgprAddr) + ", ir" + str(vgprAddr) + ".a, 0.0")

      vgprAddr += thisArray[1]

####################################################
# nextColX is next col's x coordinates, only set for inner cols (i.e. except right 2 cols) in loop unroll mode


def dwc_tile_col(instrOp, isaModifier, vgprAddr, vgprNumber, vgprStride, vgprDstStart, colBorderType, \
                 blockBorderType, nextColX, strid2Flag, funcParameterMap, flowHandler):

  indentstring = flowHandler.getIndentStr()

  xSGPRStr = funcParameterMap["xSGPRStr"]
  ySGPRStr = funcParameterMap["ySGPRStr"]
  zSGPRStr = funcParameterMap["zSGPRStr"]
  wSGPRStr = funcParameterMap["wSGPRStr"]
  uSharpIdList = funcParameterMap["uSharpIdList"]
  bnBefore = funcParameterMap["bnBefore"]

  # bn right col
  # right most col is handled separately, only it has BorderTypeRight set and it does not have any new data
  # can't use colBordertype, as it is for current col, not next col
  if (bnBefore != 0) and ((colBorderType & BorderTypeRight()) == 0):
    bufferMode = funcParameterMap["bufferGroupType"]
    bnCoeffVGPRAddr = funcParameterMap["bnCoeffVGPRAddr"]
    surfaceBorderX = funcParameterMap["surfaceBorderX"]
    srcImageWidthRes = funcParameterMap["srcImageWidthRes"]
    srcImageHeightRes = funcParameterMap["srcImageHeightRes"]

    bnVGPRNumber = vgprNumber

    # advance to next col
    bnVGPRAddr = vgprAddr + vgprStride

    isLastRowPartial = False

    # includes bottom padding (non bottom border) or bottom row (bottom border)
    # bottom row has been accounted in caller
    if ((colBorderType & BorderTypeBottom()) == 0):
      bnVGPRNumber += 1

    if (bufferMode == BufferSurfaceMode()) or (bufferMode == BufferColMode()):
      # no padding in y direction
      pass
    elif (bufferMode == BufferRowMode()):
      if ((blockBorderType & BorderTypeTop()) == 0):
        # top 2 rows have been adjusted already
        bnVGPRAddr += 1
        bnVGPRNumber -= 1
    else:
      if ((blockBorderType & BorderTypeTop()) == 0):
        # valid data starts from row 0, but alu starts from row 1
        bnVGPRAddr -= 1
        # includes top padding
        bnVGPRNumber += 1

    if (srcImageHeightRes != 0):
      if (bufferMode == BufferSurfaceMode()) or (bufferMode == BufferColMode()):
        isLastRowPartial = True
      else:
        if ((blockBorderType & BorderTypeBottom()) != 0):
          isLastRowPartial = True

    if (isLastRowPartial):
      # last row needs special handling
      bnVGPRNumber -= 1

    # in loop unroll mode, we know cols other than right 2's right neighbour is always fully covered
    isNextColPossiblePartial = (nextColX == 0) and (srcImageWidthRes != 0)
    isNextColPartial = (nextColX == surfaceBorderX) and (srcImageWidthRes != 0)

    # only right most block can have partial right col as right most block always have more than 2 cols
    # surface/row mode should always have right border set
    if ((blockBorderType & BorderTypeRight()) == 0):
      isNextColPossiblePartial = False
    elif ((colBorderType & BorderTypeLeft()) != 0):
      if (surfaceBorderX > hwCaps.TileSizeX()):
        isNextColPossiblePartial = False

    if (isNextColPossiblePartial):
      br_print (indentstring + "smovs wm0, -0x7fffffff")
      # br_print (indentstring + "smovs wm0, 0xffffffff")

    if (isNextColPossiblePartial != 0):
      flowHandler.startIfLoop(xSGPRStr, str(surfaceBorderX - hwCaps.TileSizeX()), "==", 0)
      indentstring = flowHandler.getIndentStr()

    if (isNextColPossiblePartial != 0) or (isNextColPartial != 0):
      br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(0, srcImageWidthRes, 0)))

    if (isNextColPossiblePartial != 0):
      flowHandler.closeIfLoop()
      indentstring = flowHandler.getIndentStr()

    if (bnVGPRNumber > 0):
      bn_tile_v(bnVGPRAddr, bnVGPRNumber, bnCoeffVGPRAddr, isNextColPossiblePartial or (nextColX == surfaceBorderX), indentstring, flowHandler.enableRelu)

    # now handle last col
    if (isLastRowPartial):
      if (isNextColPossiblePartial) or (isNextColPartial != 0):
        br_print (indentstring + "sandm wm0, wm0, " + hex(funcLib.GetThreadActiveMask(srcImageHeightRes, 0, 0)))
      else:
        br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(srcImageHeightRes, 0, 0)))

      bn_tile_v(bnVGPRAddr + bnVGPRNumber, 1, bnCoeffVGPRAddr, True, indentstring, flowHandler.enableRelu)

  # handle dwc
  dstImageWidthRes = funcParameterMap["dstImageWidthRes"]
  dstImageHeightRes = funcParameterMap["dstImageHeightRes"]

  isStride2On = (strid2Flag & kernelLib.GetStrideEnableMask()) != 0

  # for stride 2, wait for right half to finish before generating output data
  if (not isStride2On) or ((strid2Flag & kernelLib.GetStrideGroupFlagXMask()) != 0) or ((colBorderType & BorderTypeRight()) != 0):
    isOutput = True
  else:
    isOutput = False

  isRowPartial = (colBorderType & BorderTypeBottom()) and (dstImageHeightRes != 0)

  # special handling of last row
  if (isRowPartial):
    vgprNumber -= 1

  isColPartial = ((colBorderType & BorderTypeRight()) and (dstImageWidthRes != 0))

  if (isColPartial):
    br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(0, dstImageWidthRes, 1)))

  sizeList = funcLib.SplitRepeatIntoGroups(vgprNumber, hwCaps.MaxSTMGranule())
  sizeListLen = len(sizeList)
  arrayIndex = 0
  yChange = 0

  usharpStr = str(uSharpIdList[1][0])

  # clear bottom flag at first
  tileBorderType = colBorderType & ~BorderTypeBottom()

  thisVGPRDst = vgprDstStart

  for thisArray in sizeList:
    arrayIndex += 1

    for z in range(thisArray[0]):
      if (isStride2On == 0):
        # reset dst vgpr in non stride 2 case as we only reserve 8 temp vgpr
        # for stride 2 case, y col is limited to 16 so that 8 temp is enough
        thisVGPRDst = vgprDstStart

      if ((not isRowPartial) and (arrayIndex == sizeListLen) and (z == (thisArray[0] - 1))):
        # last group
        tileBorderType |= (colBorderType & BorderTypeBottom())

      dwc_tile_v(instrOp, isaModifier, thisArray[1], vgprAddr, vgprStride, thisVGPRDst, 0, tileBorderType, strid2Flag, funcParameterMap, flowHandler)

      isNotLastArray = (isRowPartial) or (arrayIndex != sizeListLen) or (z != (thisArray[0] - 1))

      # only the last thisArray[1] can possible be odd
      if (isStride2On == 0):
        dstVGPRNumber = thisArray[1]
      else:
        if (isNotLastArray):
          dstVGPRNumber = thisArray[1] >> 1
        else:
          dstVGPRNumber = (thisArray[1] + 1) >> 1

        if (thisArray[1] & 1):
          strid2Flag ^= kernelLib.GetStrideGroupFlagYMask()

      isOutput = False

      if (dstVGPRNumber > 0):
        isOutput = (isStride2On == 0) or isColPartial or ((strid2Flag & kernelLib.GetStrideGroupFlagXMask()) != 0)
        if isOutput:
          # otherwise, result is partial
          if (isColPartial):
            br_print (indentstring + "m0.movi" + kernelLib.GetVectorModifier(dstVGPRNumber, "v") + " r" + str(thisVGPRDst) + ".f16, 0.0")

          store_tile_v(dstVGPRNumber, usharpStr, indentstring)

          if bcd.BR_STM_G4_FEATURE_ENABLE:
            # br_print (indentstring + "& fadd.b16" + kernelLib.GetVectorModifier(dstVGPRNumber, "v") + " z0, " + "r" + str(thisVGPRDst) + ".a, 0.0")
            br_print (indentstring + "& mov" + kernelLib.GetVectorModifier(dstVGPRNumber, "v") + " z0.f16, " + "r" + str(thisVGPRDst) + ".f16.a")
          else:
            br_print (indentstring + "& mov" + kernelLib.GetVectorModifier(dstVGPRNumber, "v") + " g4.f16, " + "r" + str(thisVGPRDst) + ".f16.a")

          br_print (indentstring + "smovg g0, " + xSGPRStr)
          br_print (indentstring + "smovg g1, " + ySGPRStr)
          br_print (indentstring + "smovg g2, " + zSGPRStr)
          br_print (indentstring + "smovg.eog g3, " + wSGPRStr)

        thisVGPRDst += dstVGPRNumber

      vgprAddr += thisArray[1]

      if (isNotLastArray and isOutput):
        yChange += dstVGPRNumber
        br_print (indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(dstVGPRNumber * hwCaps.TileSizeY()))

      tileBorderType = tileBorderType & ~BorderTypeTop()

  if (isRowPartial):
    tileBorderType |= (colBorderType & BorderTypeBottom())
    dwc_tile_v(instrOp, isaModifier, 1, vgprAddr, vgprStride, thisVGPRDst, 0, tileBorderType, strid2Flag, funcParameterMap, flowHandler)

    isOutput = (isStride2On == 0) or isColPartial or ((strid2Flag & kernelLib.GetStrideGroupFlagXMask()) != 0)

    if (isOutput):
      if (isColPartial):
        br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(dstImageHeightRes, dstImageWidthRes, 1)))
      else:
        br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(dstImageHeightRes, 0, 1)))

      br_print (indentstring + "m0.movi.v2" + " r" + str(thisVGPRDst) + ".f16, 0.0")
      store_tile_v(1, usharpStr, indentstring)
      br_print (indentstring + "& mov g0.u32, " + xSGPRStr + ".u32")
      br_print (indentstring + "smovg g1, " + ySGPRStr)
      br_print (indentstring + "smovg g2, " + zSGPRStr)
      br_print (indentstring + "smovg.eog g3, " + wSGPRStr)

  if (yChange != 0):
    br_print (indentstring + "sadd " + ySGPRStr + ", " + ySGPRStr + ", " + str(-yChange * hwCaps.TileSizeY()))

################################################################################################################
# sub function generators
# sub function will be called at run time
# it uses some q/r registers as parameter
################################################################################################################


####################################################
# gen_dwc_sub_function
def gen_dwc_sub_function(funcType, yBorderType, rowSize, rightBorderMode, syncIndex, funcParameterMap, flowHandler):

  if (funcType == FuncTypeLoad()):
    funcParameterMap["xSGPRStr"] = funcParameterMap["xLoadSGPRStr"]
    funcParameterMap["ySGPRStr"] = funcParameterMap["yLoadSGPRStr"]
    vgprBaseSGPRStr = funcParameterMap["vgprLoadBaseSGPRStr"]
  else:
    funcParameterMap["xSGPRStr"] = funcParameterMap["xAluSGPRStr"]
    funcParameterMap["ySGPRStr"] = funcParameterMap["yAluSGPRStr"]
    vgprBaseSGPRStr = funcParameterMap["vgprAluBaseSGPRStr"]

  uSharpIdList = funcParameterMap["uSharpIdList"]

  xSGPRStr = funcParameterMap["xSGPRStr"]
  ySGPRStr = funcParameterMap["ySGPRStr"]

  vgprBaseStr = funcParameterMap["vgprBase"]
  vgprTempStart = funcParameterMap["vgprTempStart"]
  vgprStride = funcParameterMap["vgprStride"]

  fullBlockWidth = funcParameterMap["fullBlockWidth"]
  partialBlockWidth = funcParameterMap["partialBlockWidth"]
#  rightBorderBlockX = funcParameterMap["rightBorderBlockX"]

  surfaceBorderX = funcParameterMap["surfaceBorderX"]

  vgprIndexEnd = funcParameterMap["vgprIndexEnd"]
  vgprIndexStart = funcParameterMap["vgprIndexStart"]
  vgprStepBack = funcParameterMap["vgprStepBack"]

  bufferMode = funcParameterMap["bufferGroupType"]

  bnBefore = funcParameterMap["bnBefore"]

  filterStride = funcParameterMap["filterStride"]

  coordSGPRStrList = [xSGPRStr, ySGPRStr, funcParameterMap["zSGPRStr"], funcParameterMap["wSGPRStr"]]

  if (funcType == FuncTypeLoad()):
    pass
  else:
    instrOp = funcParameterMap["instrOp"]
    instrModifier = funcParameterMap["instrModifier"]

  indentstring = flowHandler.getIndentStr()

  br_print (indentstring + "// funciton gen_dwc_sub_function")
  br_print (indentstring + "// gpr base always points to curRow-1, curCol-1")
  br_print (indentstring + "// naming rule:")
  if (funcType == FuncTypeLoad()):
    br_print (indentstring + "//    yBorderType_blockHeight_syncId_rightBorder")
  else:
    br_print (indentstring + "//    yBorderType_blockHeight_rightBorder")

  br_print (indentstring + "//    yBorderType    - y border info, top/bottom or both")
  if (yBorderType & BorderTypeTop()):
    br_print (indentstring + "//                   - top border")
  if (yBorderType & BorderTypeRight()):
    br_print (indentstring + "//                   - right border")
  if (yBorderType & BorderTypeBottom()):
    br_print (indentstring + "//                   - bottom border")
  if (yBorderType & BorderTypeLeft()):
    br_print (indentstring + "//                   - left border")

  br_print (indentstring + "//    blockHeight    - row number of current block")
  if (funcType == FuncTypeLoad()):
    br_print (indentstring + "//    syncId         - which sync channel to use, 1 or 2 ")
  br_print (indentstring + "//    rightBorder    - whether it is right border, different width and border handling")
  if (rightBorderMode != 0):
    br_print (indentstring + "//                   - right border")

  if (filterStride != 0):
    stride2Flag = kernelLib.GetStrideEnableMask()
  else:
    stride2Flag = 0

  blockBorderType = yBorderType

  if (rightBorderMode != 0):
    blockBorderType |= BorderTypeRight()

  br_print (indentstring)


  

  if (funcType == FuncTypeLoad()):
    funcLib.AlignPrint(indentstring + "smovs " + vgprBaseStr + ", " + vgprBaseSGPRStr, flowLib.GetCommentPos(), "// restore load vgpr base from sgpr")
  else:
    funcLib.AlignPrint(indentstring + "smovs " + vgprBaseStr + ", " + vgprBaseSGPRStr, flowLib.GetCommentPos(), "// restore alu vgpr base from sgpr")

  if ((bufferMode == BufferSurfaceMode()) or (bufferMode == BufferColMode())):
    assert (yBorderType & BorderTypeTop()), "surface has all 4 borders"
    assert (yBorderType & BorderTypeBottom()), "surface has all 4 borders"

  if ((bufferMode == BufferSurfaceMode()) or (bufferMode == BufferColMode())):
    loopRowStart = 0
  elif ((bufferMode != BufferRowMode()) and ((yBorderType & BorderTypeTop()) == 0)):
    if (funcType == FuncTypeLoad()):
      loopRowStart = 0
    else:
      loopRowStart = 1
  else:
    loopRowStart = 1

  loopRowSize = rowSize

  if (funcType == FuncTypeLoad()):
    if (bufferMode != BufferRowMode()):
      if ((yBorderType & BorderTypeTop()) == 0):
        loopRowSize += 1

      if not funcParameterMap["singleTileRowMode"]:
        loopRowSize += 1
  else:
    if (yBorderType & BorderTypeBottom()):
      if not funcParameterMap["singleTileRowMode"]:
        loopRowSize += 1

  if (partialBlockWidth == fullBlockWidth):
    xAligned = 1
  else:
    xAligned = 0

  if (funcType == FuncTypeLoad()):
#    rightBorderBlockX += hwCaps.TileSizeX()
    isLeftBorderCheck = 0
  else:
    isLeftBorderCheck = xAligned

  indentstring = flowHandler.getIndentStr()

  #########################
  # function disabled
  isLeftBorderCheck = 0

  if (funcType == FuncTypeLoad()):
    loopUnrollThreshold = GetDWCLoadLoopUnrollThreshold()
  else:
    loopUnrollThreshold = GetDWCAluLoopUnrollThreshold()

  loopColNumber = -1
  isHandleLeftBorder = 0

  # loopMode
  # 0/1
  #   surface/row mode
  #   no padding in x direction, need special handling for left border start from col 0 or 1
  #   0 - unroll, no loop
  #   1 - loop
  # 2 - rightBorderMode == 2, disabled
  #     find out band width based on x coordinate, and also whether it is right border
  #     start from col 0 or 1
  # 3 - rightBorderMode == 0 (full vertical band) /1 (partial vertical band, means it is right border)
  #     always start from col 0

  if ((bufferMode == BufferSurfaceMode()) or (bufferMode == BufferRowMode())):

    if ((fullBlockWidth - 2) < loopUnrollThreshold):
      loopMode = 0
    else:
      loopMode = 1

    if (funcType == FuncTypeLoad()):
      loopColNumber = fullBlockWidth
    else:
      loopColNumber = fullBlockWidth - 1

      if (fullBlockWidth != 1):
        isHandleLeftBorder = 1

      isLeftBorderCheck = 0
  else:
    if (rightBorderMode == 2):
      loopMode = 2
    else:
      loopMode = 3

    if (rightBorderMode == 0):
      loopColNumber = fullBlockWidth
    else:
      loopColNumber = partialBlockWidth

  if (loopMode == 3):
    loopSGPRNumber = 1
  else:
    loopSGPRNumber = 2

  if (loopMode != 0):
    xControlQIndex = flowHandler.allocateSGPR(loopSGPRNumber)
    xIndexSGPRStr = "q" + str(xControlQIndex)

    if (loopMode == 2):
      assert False, "disabled"
      # isRightBorderQIndex = flowHandler.allocateSGPR(1)
      # isRightBorderSGPRStr = "q" + str(isRightBorderQIndex)

    funcLib.AlignPrint(indentstring + "smov " + xIndexSGPRStr + ", " + str(isHandleLeftBorder), flowLib.GetCommentPos(), "// set loop start, 0 or 1 (if left border is handled separately)")

  if ((bufferMode == BufferSurfaceMode()) or (bufferMode == BufferRowMode())):
    loopColStart = 0
  else:
    if (funcType == FuncTypeLoad()):
      loopColStart = 2
    else:
      loopColStart = 1

  if (isLeftBorderCheck or isHandleLeftBorder):
    br_print (indentstring + "// left border handling, as col-1's data can't be used")

    if (isLeftBorderCheck):
      assert False, "disabled"
      flowHandler.startIfLoop(xSGPRStr, str(0), "==", 0)
      indentstring = flowHandler.getIndentStr()

    dwc_tile_col(instrOp, instrModifier, loopColStart * vgprStride + loopRowStart, loopRowSize, vgprStride, vgprTempStart, \
                 BorderTypeLeft() | yBorderType, blockBorderType, 0, stride2Flag, funcParameterMap, flowHandler)

    if (filterStride != 0):
      stride2Flag ^= kernelLib.GetStrideGroupFlagXMask()

    br_print (indentstring + "// dwc - finish left column")
    if stride2Flag != 0:
      br_print (indentstring + "smov " + xSGPRStr + ", 0")
    else:
      br_print (indentstring + "smov " + xSGPRStr + ", " + str(hwCaps.TileSizeX()))
      
    br_print (indentstring + "// advance to next col")
    if (loopMode == 2) or (loopColNumber > 2):
      br_print (indentstring + "sadd " + xIndexSGPRStr + ", " + xIndexSGPRStr + ", " + str(1))

    if (isLeftBorderCheck):
      assert False, "disabled"
      br_print (indentstring + "sadd " + vgprBaseStr + ", " + vgprBaseStr + ", " + str(vgprStride))
      br_print (indentstring + "smov " + xIndexSGPRStr + ", " + str(1))
    else:
      loopColStart += 1

    br_print (indentstring + "// finish left border handling")

    if (isLeftBorderCheck):
      assert False, "disabled"
      flowHandler.closeIfLoop()
      indentstring = flowHandler.getIndentStr()

  loopRemains = 0

  if (loopMode != 0):
    loopNumber = loopColNumber - isHandleLeftBorder
    loopStep = 1
    loopEnd = loopColNumber

    if (loopMode == 2):
      assert False, "disabled"
      # xSizeSGPRStr = "q" + str(xControlQIndex+1)
      # br_print (indentstring + "// find out block width")
      # if (funcType == FuncTypeLoad()):
      #  br_print (indentstring + "// rightBorderBlockX has been increased by " + str(hwCaps.TileSizeX()))
      #  br_print (indentstring + "// last block, we already loaded 1st col")
      # else:
      #  br_print (indentstring + "// last block, last col needs special handling")
      #
      # flowHandler.startIfLoop(xSGPRStr, str(rightBorderBlockX), "==", 1)
      # indentstring = flowHandler.getIndentStr()
      # br_print (indentstring + "smov " + xSizeSGPRStr + ", " + str(partialBlockWidth - 1))
      # br_print (indentstring + "smov " + isRightBorderSGPRStr + ", 1")
      # flowHandler.startElseLoop()
      # br_print (indentstring + "smov " + xSizeSGPRStr + ", " + str(fullBlockWidth))
      # br_print (indentstring + "smov " + isRightBorderSGPRStr + ", 0")
      #
      # flowHandler.closeIfLoop()
    else:
      if (funcType != FuncTypeLoad()) and (filterStride != 0) and (loopNumber >= 2):
        loopStep = 2
        loopRemains = loopNumber & 1
        loopEnd -= loopRemains

    xSizeSGPRStr = str(loopEnd + isHandleLeftBorder)

    if (loopMode == 2) or (loopEnd > loopStep):
      flowHandler.startForLoop("", xSizeSGPRStr, str(loopStep), xControlQIndex, "loop in x dir")
      indentstring = flowHandler.getIndentStr()

    if (loopMode == 2) or (loopColNumber > isLeftBorderCheck):
      loopUnrollNumber = 1
    else:
      loopUnrollNumber = 0
  else:
    loopStep = 1
    loopUnrollNumber = loopColNumber - isHandleLeftBorder

  isPartial = 0
  for z in range (loopUnrollNumber):
    if (funcType == FuncTypeLoad()):
      if (z == 0):
        if (loopMode >= 2):
          br_print (indentstring + "// load next col, x has been adjusted already, vgpr base still pointing to col -1")
        else:
          br_print (indentstring + "// load one col, x and vgpr base all point to col 0")

      kernelLib.load_4d_activation(hwCaps.SurfaceFormatFP16(), hwCaps.SurfaceFormatFP16(), coordSGPRStrList, \
  	                               -1 - ((z + loopColStart) * vgprStride + loopRowStart), loopRowSize, syncIndex, uSharpIdList[0][0], indentstring, funcParameterMap["isStride2On"])
    else:
      # for unroll mode, only last col needs to check oob/partial
      if (loopMode == 0):
        nextColX = (z + loopColStart + 1) * hwCaps.TileSizeX()
      else:
        nextColX = 0

      blockBorderType0 = blockBorderType

      if (loopStep > 1):
        blockBorderType0 &= ~BorderTypeRight()

      dwc_tile_col(instrOp, instrModifier, (z + loopColStart) * vgprStride + loopRowStart, loopRowSize, vgprStride, vgprTempStart, \
                   yBorderType, blockBorderType0, nextColX, stride2Flag, funcParameterMap, flowHandler)

      if (loopStep > 1):
        blockBorderType1 = blockBorderType

        if (loopRemains != 0):
          blockBorderType1 &= ~BorderTypeRight()

        if ((stride2Flag & kernelLib.GetStrideGroupFlagXMask()) != 0):
          funcLib.AlignPrint(indentstring + "sadd " + xSGPRStr + ", " + xSGPRStr + ", " + str(hwCaps.TileSizeX()), flowLib.GetCommentPos(), "// move alu x to next col")

        dwc_tile_col(instrOp, instrModifier, (z + loopColStart + 1) * vgprStride + loopRowStart, loopRowSize, vgprStride, vgprTempStart, \
                     yBorderType, blockBorderType1, nextColX, stride2Flag ^ kernelLib.GetStrideGroupFlagXMask(), funcParameterMap, flowHandler)

      else:
        if (filterStride != 0):
          stride2Flag ^= kernelLib.GetStrideGroupFlagXMask()

    if (filterStride == 0) or ((stride2Flag & kernelLib.GetStrideGroupFlagXMask()) == 0):
      if (funcType == FuncTypeLoad()):
        funcLib.AlignPrint(indentstring + "sadd " + xSGPRStr + ", " + xSGPRStr + ", " + str(hwCaps.TileSizeX()), flowLib.GetCommentPos(), "// move load x to next col")
      else:
        funcLib.AlignPrint(indentstring + "sadd " + xSGPRStr + ", " + xSGPRStr + ", " + str(hwCaps.TileSizeX()), flowLib.GetCommentPos(), "// move alu x to next col")

  if (loopMode != 0):
    if (loopUnrollNumber != 0):
      br_print (indentstring + "sadda " + vgprBaseStr + ", " + vgprBaseStr + ", " + str(loopStep * vgprStride))
      br_print (indentstring + "sadd " + vgprBaseSGPRStr + ", " + vgprBaseSGPRStr + ", " + str(loopStep * vgprStride))
      br_print (indentstring + "// dwc - finish one column")

    if (loopMode == 2) or (loopEnd > loopStep):
      flowHandler.closeForLoop("", xSizeSGPRStr, str(loopStep), xControlQIndex)

    indentstring = flowHandler.getIndentStr()
    rightBorderShift = 0
  else:
    rightBorderShift = loopUnrollNumber
    if (loopUnrollNumber != 0):
      br_print (indentstring + "// dwc - finish a block of rows or a surface")

  if (loopMode == 2):
    flowHandler.startIfLoop(isRightBorderSGPRStr, str(0), "!=", 0)
    indentstring = flowHandler.getIndentStr()

  if (loopRemains != 0):
    # we know next one is border
    if (blockBorderType & BorderTypeRight()) != 0:
      nextColX = surfaceBorderX
    else:
      nextColX = 0

    dwc_tile_col(instrOp, instrModifier, loopColStart * vgprStride + loopRowStart, loopRowSize, vgprStride, vgprTempStart, \
                 yBorderType, blockBorderType, nextColX, stride2Flag, funcParameterMap, flowHandler)

    if ((stride2Flag & kernelLib.GetStrideGroupFlagXMask()) != 0):
       funcLib.AlignPrint(indentstring + "sadd " + xSGPRStr + ", " + xSGPRStr + ", " + str(hwCaps.TileSizeX()), flowLib.GetCommentPos(), "// move alu x to next col")

    stride2Flag ^= kernelLib.GetStrideGroupFlagXMask()

    br_print (indentstring + "sadda " + vgprBaseStr + ", " + vgprBaseStr + ", " + str(vgprStride))
    br_print (indentstring + "sadd " + vgprBaseSGPRStr + ", " + vgprBaseSGPRStr + ", " + str(vgprStride))

  if ((loopMode == 2) or (loopMode == 3 and rightBorderMode == 1) or (bufferMode == BufferRowMode()) or (bufferMode == BufferSurfaceMode())):
    if (funcType != FuncTypeLoad()):  # and (funcParameterMap["dstImageWidthRes"] != 0 or funcParameterMap["singleTileRowMode"])):
      br_print (indentstring + "// process right border")

      rightBorderType = BorderTypeRight() | yBorderType
      dwc_tile_col(instrOp, instrModifier, (rightBorderShift + loopColStart) * vgprStride + loopRowStart, loopRowSize, \
                  vgprStride, vgprTempStart, rightBorderType, blockBorderType, 0, stride2Flag, funcParameterMap, flowHandler)

  if (loopMode >= 2):
    if (rightBorderMode != 0):
      if (fullBlockWidth != partialBlockWidth):
        br_print (indentstring + "sadd " + vgprBaseSGPRStr + ", " + vgprBaseSGPRStr + ", " + str((fullBlockWidth - partialBlockWidth) * vgprStride))

  else:
    if (loopMode == 0):
      xAdvanceStep = 0
    else:
      xAdvanceStep = loopColNumber - isHandleLeftBorder

    if (bufferMode == BufferRowMode()):
      bufferGroupNumber = funcParameterMap["bufferGroupNumber"]
      yAdvanceStep = int (vgprStepBack / bufferGroupNumber)
      xAdvanceStep = -xAdvanceStep
    else:
      yAdvanceStep = 0
      xAdvanceStep = fullBlockWidth - xAdvanceStep

    vgprBaseShift = vgprStride * xAdvanceStep + yAdvanceStep

    if (vgprBaseShift != 0):
      br_print (indentstring + "// adjust vgpr base")
      br_print (indentstring + "// for col/block mode, move to next block, which is in x dir")
      br_print (indentstring + "// for row mode, move to next block, which is in y dir")
      br_print (indentstring + "sadd " + vgprBaseSGPRStr + ", " + vgprBaseSGPRStr + ", " + str(vgprBaseShift))

  if (loopMode == 2):
    flowHandler.closeIfLoop()
    indentstring = flowHandler.getIndentStr()

  if (loopMode != 0):
    flowHandler.releaseSGPR(loopSGPRNumber)
    if (loopMode == 2):
      flowHandler.releaseSGPR(1)

  br_print (indentstring)

  br_print (indentstring + "// check vgpr base, as we can't use auto wrap")
  br_print (indentstring + "// if too big, step back, vgpr range is [" + str(vgprIndexStart) + ", " + str(vgprIndexEnd) + ")")

  flowHandler.startIfLoop(vgprBaseSGPRStr, str(vgprIndexEnd), ">=", 0)
  indentstring = flowHandler.getIndentStr()
  br_print (indentstring + "smov " + vgprBaseSGPRStr + ", " + str(vgprIndexStart))

  if (bufferMode == BufferRowMode()):
    if (yBorderType & BorderTypeBottom()):
      br_print (indentstring + "// bottom row, no need to copy bottom 2 rows to top")
    else:
      if (funcType == FuncTypeALU()):
        br_print (indentstring + "// copy bottom 2 rows to top")
        br_print (indentstring + "smovs " + vgprBaseStr + ", " + vgprBaseSGPRStr)
        for z in range (fullBlockWidth):
          br_print (indentstring + "mov.v2 ir" + str(z * vgprStride) + ".u32, ir" + str(z * vgprStride + vgprStepBack) + ".u32.a")

  flowHandler.closeIfLoop()

####################################################
# called whenever starting a new slice (sample or channel)
# initialize y coordinate for load/alu
# for block/row mode, load starts from row 0 or -1 depends on whether there is top band
# for row mode, load row 0, also load row -1 if non top band
# no need to clear row -1 for top band
# top band is always separated from other bands


def do_y_initialize(vgprStride, colSize, yBorderType, funcParameterMap, flowHandler):
  xLoadSGPRStr = funcParameterMap["xLoadSGPRStr"]
  yLoadSGPRStr = funcParameterMap["yLoadSGPRStr"]
  yAluSGPRStr = funcParameterMap["yAluSGPRStr"]
  bufferGroupType = funcParameterMap["bufferGroupType"]

  indentstring = flowHandler.getIndentStr()

  if ((bufferGroupType == BufferBlockMode() or bufferGroupType == BufferRowMode()) and ((yBorderType & BorderTypeTop()) == 0)):
    funcLib.AlignPrint(indentstring + "smov " + yLoadSGPRStr + ", " + str(-hwCaps.TileSizeY()), flowLib.GetCommentPos(), "// initialize load's y coord")
  else:
    funcLib.AlignPrint(indentstring + "smov " + yLoadSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize load's y coord")

  funcLib.AlignPrint(indentstring + "smov " + yAluSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize alu's y coord")

  if (bufferGroupType == BufferRowMode()):
    br_print (indentstring + "// row mode, load row 0, no need to clear row -1 for top band")
    br_print (indentstring + "// next load from row 1")

    coordSGPRStrList = [xLoadSGPRStr, yLoadSGPRStr, funcParameterMap["zSGPRStr"], funcParameterMap["wSGPRStr"]]
    uSharpIdList = funcParameterMap["uSharpIdList"]

    if (yBorderType & BorderTypeTop()):
      rowNumber = 1
      rowStart = 1
    else:
      rowNumber = 2
      rowStart = 0

    for z in range (colSize):
      kernelLib.load_4d_activation(hwCaps.SurfaceFormatFP16(), hwCaps.SurfaceFormatFP16(), coordSGPRStrList, \
                                   -1 - (z * vgprStride) - rowStart, rowNumber, 1, uSharpIdList[0][0], indentstring, funcParameterMap["isStride2On"])

      if z != (colSize - 1):
        br_print (indentstring + "sadd " + xLoadSGPRStr + ", " + xLoadSGPRStr + ", " + str(hwCaps.TileSizeX()))

    if (colSize != 1):
      br_print (indentstring + "smov " + xLoadSGPRStr + ", 0")

    funcLib.AlignPrint(indentstring + "smov " + yLoadSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize load's y coord")

####################################################
# called whenever starting a new band
# initialize x coordinate for load/alu
# for block/col mode, load col 0, also load col -1 or clear col -1
#   following load starts from col 1


def do_x_initialize(vgprStride, rowSize, yBorderType, funcParameterMap, flowHandler):
  indentstring = flowHandler.getIndentStr()

  xLoadSGPRStr = funcParameterMap["xLoadSGPRStr"]
  yLoadSGPRStr = funcParameterMap["yLoadSGPRStr"]
  xAluSGPRStr = funcParameterMap["xAluSGPRStr"]

  funcParameterMap["xSGPRStr"] = xLoadSGPRStr
  funcParameterMap["ySGPRStr"] = yLoadSGPRStr

  # if (bufferMode != BufferSurfaceMode() and bufferMode != BufferRowMode()):
  #   br_print (indentstring + "// restore load vgpr base from sgpr")
  #   br_print (indentstring + "smovs " + vgprBaseStr + ", " + vgprLoadBaseSGPRStr)
  #
  # if (bufferMode != BufferSurfaceMode() and bufferMode != BufferRowMode()):
  #   br_print (indentstring + "// save load vgpr base to sgpr")
  #   br_print (indentstring + "smov " + vgprLoadBaseSGPRStr + ", " + vgprBaseStr)

  bufferGroupType = funcParameterMap["bufferGroupType"]

  funcLib.AlignPrint(indentstring + "smov " + xLoadSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize load's x coord")
  funcLib.AlignPrint(indentstring + "smov " + xAluSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize alu's x coord")

  if (bufferGroupType == BufferSurfaceMode()):
    pass
  elif (bufferGroupType == BufferRowMode()):
    pass
  else:
    br_print (indentstring + "// load col 0, and clear col-1, as previous alu must have finished")

    vgprBaseSGPRStr = funcParameterMap["vgprLoadBaseSGPRStr"]
    vgprBaseStr = funcParameterMap["vgprBase"]

    br_print (indentstring + "smovs " + vgprBaseStr + ", " + vgprBaseSGPRStr)

    loopRowStart = 1
    loopRowSize = rowSize

    if ((yBorderType & BorderTypeTop()) == 0):
      loopRowStart = 0
      loopRowSize += 1
    else:
      if (bufferGroupType == BufferColMode()):
        br_print (indentstring + "// col mode, no padding, load y=0 to gpr row 0")
        loopRowStart = 0
      else:
        br_print (indentstring + "// block mode, padding in y direction, load y=0 to gpr row 1 for block mode")
        loopRowStart = 1

    loopRowSize += 1

    coordSGPRStrList = [xLoadSGPRStr, yLoadSGPRStr, funcParameterMap["zSGPRStr"], funcParameterMap["wSGPRStr"]]
    uSharpIdList = funcParameterMap["uSharpIdList"]

    kernelLib.mov_imm_v(hwCaps.SurfaceFormatFP16(), -1 - loopRowStart, loopRowSize, "0.0", "", indentstring)

    kernelLib.load_4d_activation(hwCaps.SurfaceFormatFP16(), hwCaps.SurfaceFormatFP16(), coordSGPRStrList, \
                                 -1 - (vgprStride + loopRowStart), loopRowSize, 1, uSharpIdList[0][0], indentstring, funcParameterMap["isStride2On"])

    br_print (indentstring + "// following load start from x=" + str(hwCaps.TileSizeX()))
    br_print (indentstring + "smov " + xLoadSGPRStr + ", " + str(hwCaps.TileSizeX()))

####################################################
# called whenever starting a channel
# issue load of dwc's weight, bn's gamma/beta and reduction result
#


def do_z_initialize(funcParameterMap, flowHandler, uSharpIdList):

  bnBefore = funcParameterMap["bnBefore"]
  instrOp = funcParameterMap["instrOp"]

  indentstring = flowHandler.getIndentStr()

  newWeightSGPRStr = funcParameterMap["newWeightSGPRStr"]

  funcLib.AlignPrint(indentstring + "smov " + newWeightSGPRStr + ", 1", flowLib.GetCommentPos(), "// lddw requires all EUs to sync, reduction needs preprocess, set a flag")

  if (instrOp == "dwc"):
    euIdSGPRStr = funcParameterMap["euIdSGPRStr"]

    weightNumber = funcParameterMap["weightNumber"]
    weightAddrSGPRStr = funcParameterMap["weightAddrSGPRStr"]

    constBaseSGPRStr = funcParameterMap["constBaseSGPRStr"]
    constBaseStr = funcParameterMap["constBase"]

    br_print (indentstring + "// load weight for current channel group, only eu0 issues read, always comes with sc1")

    flowHandler.startIfLoop(euIdSGPRStr, str(0), "==", 0)
    indentstring = flowHandler.getIndentStr()

    br_print (indentstring + "// load dwc weight")
    funcLib.AlignPrint(indentstring + "smovs " + constBaseStr + ", " + constBaseSGPRStr, flowLib.GetCommentPos(), "// set csr base")
    kernelLib.lddw_load(hwCaps.SurfaceFormatFP16(), weightAddrSGPRStr, -1, weightNumber, 1, uSharpIdList[0][GetWeightUSharpIndex()], indentstring)

    flowHandler.closeIfLoop()
    indentstring = flowHandler.getIndentStr()

  if (bnBefore != 0):
    zSGPRStr = funcParameterMap["zSGPRStr"]
    gammaDataSGPRIndex = funcParameterMap["gammaDataSGPRIndex"]
    reduceResSGPRIndex = funcParameterMap["reduceResSGPRIndex"]
    surfaceChannel = funcParameterMap["surfaceChannel"]

    sldXSGPRStr = funcParameterMap["sldXSGPRStr"]
    maxSldXValue = None
    if surfaceChannel*2 >= 128:
      maxSldXValue = funcParameterMap["maxSldXValue"] 

    funcLib.AlignPrint(indentstring + "sshl " + sldXSGPRStr + ", " + zSGPRStr + ", 1", flowLib.GetCommentPos(), "// calculate the 1d weight x axis")
    br_print (indentstring + "// load gamma/beta/reduce result")
    kernelLib.scalar_load(hwCaps.SurfaceFormatFP32(), sldXSGPRStr, gammaDataSGPRIndex, 4, 0, 1, uSharpIdList[0][GetGammaUSharpIndex()], indentstring, funcParameterMap["wSGPRStr"])
    kernelLib.scalar_load(hwCaps.SurfaceFormatFP32(), sldXSGPRStr, reduceResSGPRIndex, 4, 0, 1, uSharpIdList[0][GetGammaUSharpIndex()], indentstring, funcParameterMap["wSGPRStr"], surfaceChannel, maxSldXValue)

####################################################
# preprocess lddw load, need to insert a wbar sync
# preprocess bn's gamma/beta and reduction result


def do_z_preprocess(funcParameterMap, flowHandler):

  newWeightSGPRStr = funcParameterMap["newWeightSGPRStr"]
  bnBefore = funcParameterMap["bnBefore"]
  instrOp = funcParameterMap["instrOp"]

  flowHandler.startIfLoop(newWeightSGPRStr, str(0), "!=", 0)
  indentstring = flowHandler.getIndentStr()
  br_print (indentstring + "smov " + newWeightSGPRStr + ", 0")

  if (bnBefore != 0):
    gammaDataSGPRIndex = funcParameterMap["gammaDataSGPRIndex"]
    reduceResultSGPRAddr = funcParameterMap["reduceResSGPRIndex"]
    bnCoeffVGPRAddr = funcParameterMap["bnCoeffVGPRAddr"]

    vgprTempStart = funcParameterMap["vgprTempStart"]

    br_print (indentstring + "// y = gamma * (x-u)/sigma + beta")
    br_print (indentstring + "//   = gamma * (1/sigma) * x - gamma * u * (1/sigma) + beta")
    br_print (indentstring + "// assume order in reduce sgpr is c0_x_sum, c0_x^2_sum, c1_x_sum, c1_x^2_sum")
    br_print (indentstring + "// assume order in gamma sgpr is c0_gamma, c0_beta, c1_gamma, c1_beta")

    funcLib.AlignPrint(indentstring + "movi r" + str(vgprTempStart) + ".f32, " + str(funcParameterMap["reduceSurfaceCoeff"]), flowLib.GetCommentPos(), "// 1/surface_area")
    funcLib.AlignPrint(indentstring + "movi r" + str(vgprTempStart + 1) + ".f32, 0.000001", flowLib.GetCommentPos(), "// epilson to handle rcp of 0")

    funcLib.AlignPrint(indentstring + "fmul.b32.v4 r" + str(vgprTempStart + 2) + ", q" + str(reduceResultSGPRAddr) + ".a, r" + str(vgprTempStart), flowLib.GetCommentPos(), "// scale by 1/surface_area")
    funcLib.AlignPrint(indentstring + "fadd.b32.rsqrt r" + str(vgprTempStart + 3) + ", r" + str(vgprTempStart + 3) + ", r" + str(vgprTempStart + 1), flowLib.GetCommentPos(), "// 1/sqrt(c0_sigma^2+epsilon)")
    funcLib.AlignPrint(indentstring + "fadd.b32.rsqrt r" + str(vgprTempStart + 5) + ", r" + str(vgprTempStart + 5) + ", r" + str(vgprTempStart + 1), flowLib.GetCommentPos(), "// 1/sqrt(c1_sigma^2+epsilon)")

    funcLib.AlignPrint(indentstring + "fmul.b32.sc3 r" + str(vgprTempStart) + ", r" + str(vgprTempStart + 3) + ", q" + str(gammaDataSGPRIndex), flowLib.GetCommentPos(), "// c0_gamma/c0_sigma")
    funcLib.AlignPrint(indentstring + "fmul.b32 r" + str(vgprTempStart + 1) + ", r" + str(vgprTempStart + 5) + ", q" + str(gammaDataSGPRIndex + 2), flowLib.GetCommentPos(), "// c1_gamma/c1_sigma")

    funcLib.AlignPrint(indentstring + "fmad.b32 r" + str(vgprTempStart + 2) + ", r" + str(vgprTempStart + 2) + ", r" + str(vgprTempStart + 3) + ".n, q" + str(gammaDataSGPRIndex + 1), flowLib.GetCommentPos(), "// -c0_gamma/c0_sigma*c0_u + c0_beta")
    funcLib.AlignPrint(indentstring + "fmad.b32 r" + str(vgprTempStart + 3) + ", r" + str(vgprTempStart + 4) + ", r" + str(vgprTempStart + 5) + ".n, q" + str(gammaDataSGPRIndex + 3), flowLib.GetCommentPos(), "// -c1_gamma/c1_sigma*c1_u + c1_beta")

    funcLib.AlignPrint(indentstring + "mov.rdne.v4 r" + str(bnCoeffVGPRAddr) + ".f16, r" + str(vgprTempStart) + ".a.f16", flowLib.GetCommentPos(), "// pack to fp16")

    br_print (indentstring + "// now for each pixel, r, r = r * r" + str(bnCoeffVGPRAddr) + " + r" + str(bnCoeffVGPRAddr + 1))

    # funcLib.AlignPrint(indentstring + "fmul.b32.sc3  r" + str(bnCoeffVGPRAddr) + ", r" + str(vgprTempStart+3) + ", q" + str(gammaDataSGPRIndex), flowLib.GetCommentPos(), "// c0_gamma/c0_sigma")
    # funcLib.AlignPrint(indentstring + "fmul.b32  r" + str(bnCoeffVGPRAddr+1) + ", r" + str(vgprTempStart+5) + ", q" + str(gammaDataSGPRIndex+2), flowLib.GetCommentPos(), "// c1_gamma/c1_sigma")
    #
    # funcLib.AlignPrint(indentstring + "fmad.b32 r" + str(bnCoeffVGPRAddr+2) + ", r" + str(vgprTempStart+2) + ", r" + str(vgprTempStart+3) + ".n, q" + str(gammaDataSGPRIndex+1), flowLib.GetCommentPos(), "// -c0_gamma/c0_sigma*c0_u + c0_beta")
    # funcLib.AlignPrint(indentstring + "fmad.b32 r" + str(bnCoeffVGPRAddr+3) + ", r" + str(vgprTempStart+4) + ", r" + str(vgprTempStart+5) + ".n, q" + str(gammaDataSGPRIndex+3), flowLib.GetCommentPos(), "// -c1_gamma/c1_sigma*c1_u + c1_beta")
    #
    # br_print (indentstring + "// now for each pixel, r, r = r * r" + str(bnCoeffVGPRAddr) + "/" + str(bnCoeffVGPRAddr+1) + " + r" + str(bnCoeffVGPRAddr+2) + "/" + str(bnCoeffVGPRAddr+3))

    # bnCoeffVGPRAddr = vgprTempStart + 2
    #
    #
    # br_print (indentstring + "// vgpr0 c0_x^2_sum, c1_x^2_sum")
    # br_print (indentstring + "// vgpr1 c0_x_sum, c1_x_sum")
    # br_print (indentstring + "// vgpr2 c0_gamma, c1_gamma")
    # br_print (indentstring + "// vgpr3 c0_beta, c1_beta")
    #
    #
    # for z in range (2):
    #  funcLib.AlignPrint(indentstring + "smovs wm0, " + str(1 << z), flowLib.GetCommentPos(), "// set m0 mask")
    #  funcLib.AlignPrint(indentstring + "m0.mov r" + str(bnCoeffVGPRAddr) + ".f32, q" + str(reduceResultSGPRAddr + z * 2 + 1) + ".f32", flowLib.GetCommentPos(), "// get c0_x^2_sum, c1_x^2_sum")
    #  funcLib.AlignPrint(indentstring + "m0.mov r" + str(bnCoeffVGPRAddr+1) + ".f32, q" + str(reduceResultSGPRAddr + z * 2) + ".f32", flowLib.GetCommentPos(), "// get c0_x_sum, c1_x_sum")
    #
    # funcLib.AlignPrint(indentstring + "smovs wm0, 3", flowLib.GetCommentPos(), "// set m0 mask to lane 0 and lane 1")
    # funcLib.AlignPrint(indentstring + "fmul.b32.v2 r" + str(bnCoeffVGPRAddr) + ", r" + str(bnCoeffVGPRAddr) + ".a, r" + str(vgprTempStart), flowLib.GetCommentPos(), "// scale by 1/surface_area")
    # funcLib.AlignPrint(indentstring + "fadd.b32.rsqrt   r" + str(bnCoeffVGPRAddr) + ", r" + str(bnCoeffVGPRAddr) + ", r"+ str(vgprTempStart+1), flowLib.GetCommentPos(), "// sqrt(sigma^2+epsilon)")
    #
    # for z in range (2):
    #  funcLib.AlignPrint(indentstring + "smovs wm0, " + str(1 << z), flowLib.GetCommentPos(), "// set m0 mask")
    #  funcLib.AlignPrint(indentstring + "m0.mov r" + str(bnCoeffVGPRAddr+2) + ".f32, q" + str(gammaDataSGPRIndex + z * 2) + ".f32", flowLib.GetCommentPos(), "// get c0_gamma, c1_gamma")
    #  funcLib.AlignPrint(indentstring + "m0.mov r" + str(bnCoeffVGPRAddr+3) + ".f32, q" + str(gammaDataSGPRIndex + z * 2 + 1) + ".f32", flowLib.GetCommentPos(), "// get c0_beta, c1_beta")
    #
    #
    # funcLib.AlignPrint(indentstring + "fmul.b32.sc3  r" + str(bnCoeffVGPRAddr) + ", r" + str(bnCoeffVGPRAddr) + ", r" + str(bnCoeffVGPRAddr+2), flowLib.GetCommentPos(), "// gamma/sigma")
    #
    # funcLib.AlignPrint(indentstring + "fmad.b32  r" + str(bnCoeffVGPRAddr+1) + ", r" + str(bnCoeffVGPRAddr) + ", r" + str(bnCoeffVGPRAddr+1) + ".n, r" + str(bnCoeffVGPRAddr + 3), flowLib.GetCommentPos(), "// -gamma/sigma * xbar + beta")
    #
    # funcLib.AlignPrint(indentstring + "smovs wm0, 1", flowLib.GetCommentPos(), "// set m0 mask")
    # funcLib.AlignPrint(indentstring + "m0.movw.r2q  q" + str(reduceResultSGPRAddr) + ", r" + str(bnCoeffVGPRAddr) + ".f32", flowLib.GetCommentPos(), "// mov c0 mul coeff to q0")
    # funcLib.AlignPrint(indentstring + "m0.movw.r2q  q" + str(reduceResultSGPRAddr+2) + ", r" + str(bnCoeffVGPRAddr+1) + ".f32", flowLib.GetCommentPos(), "// mov c0 add coeff to q2")
    # funcLib.AlignPrint(indentstring + "smovs wm0, 2", flowLib.GetCommentPos(), "// set m0 mask")
    # funcLib.AlignPrint(indentstring + "m0.movw.r2q  q" + str(reduceResultSGPRAddr+1) + ", r" + str(bnCoeffVGPRAddr) + ".f32", flowLib.GetCommentPos(), "// mov c1 mul coeff to q1")
    # funcLib.AlignPrint(indentstring + "m0.movw.r2q  q" + str(reduceResultSGPRAddr+3) + ", r" + str(bnCoeffVGPRAddr+1) + ".f32", flowLib.GetCommentPos(), "// mov c1 add coeff to q3")
    #
    # br_print (indentstring + "// now for each pixel, r, r = r * q" + str(reduceResultSGPRAddr) + "/" + str(reduceResultSGPRAddr+1) + " + q" + str(reduceResultSGPRAddr+2) + "/" + str(reduceResultSGPRAddr+3))

  if (instrOp == "dwc"):
    funcLib.AlignPrint(indentstring + "bar.wtg.sync.cnt " + str(bcd.BAR_CHANNELS_DWC_LDDW_BAR_ID) + ", 16", flowLib.GetCommentPos(), "// all EU to participate, what if an EU has no job")

  flowHandler.closeIfLoop()
  indentstring = flowHandler.getIndentStr()

####################################################
# bn first col if there is a need


def do_y_preprocess(yBorderFlag, vgprNumber, vgprStride, funcParameterMap, flowHandler):

  bufferMode = funcParameterMap["bufferGroupType"]
  bnCoeffVGPRAddr = funcParameterMap["bnCoeffVGPRAddr"]
  srcImageHeightRes = funcParameterMap["srcImageHeightRes"]
  vgprAluBaseSGPRStr = funcParameterMap["vgprAluBaseSGPRStr"]
  vgprBaseStr = funcParameterMap["vgprBase"]
  ySGPRStr = funcParameterMap["yAluSGPRStr"]

  indentstring = flowHandler.getIndentStr()
  bnVGPRNumber = vgprNumber

  if (bufferMode == BufferSurfaceMode() or bufferMode == BufferRowMode()):
    # no padding in x direction
    bnVGPRAddr = 0
  else:
    bnVGPRAddr = vgprStride

  isLastRowPartial = False

  # includes bottom padding (non bottom border) or bottom row (bottom border)
  bnVGPRNumber += 1

  if (bufferMode == BufferSurfaceMode()) or (bufferMode == BufferColMode()):
    # no padding in y direction
    pass
  else:
    if ((yBorderFlag & BorderTypeTop()) == 0):
      # valid data starts from vgpr 0
      # row0Index = 0

      # includes top padding
      bnVGPRNumber += 1
    else:
      bnVGPRAddr += 1

  if (srcImageHeightRes != 0):
    if (bufferMode == BufferSurfaceMode()) or (bufferMode == BufferColMode()):
      isLastRowPartial = True
    else:
      if ((yBorderFlag & BorderTypeBottom()) != 0):
        isLastRowPartial = True

  if (isLastRowPartial):
    # last row needs special handling
    bnVGPRNumber -= 1

  br_print (indentstring + "// bn scale current col")
  br_print (indentstring + "smovs " + vgprBaseStr + ", " + vgprAluBaseSGPRStr)
  bn_tile_v(bnVGPRAddr, bnVGPRNumber, bnCoeffVGPRAddr, False, indentstring, flowHandler.enableRelu)

  if (isLastRowPartial):
    br_print (indentstring + "smovs wm0, " + hex(funcLib.GetThreadActiveMask(srcImageHeightRes, 0, 0)))
    bn_tile_v(bnVGPRAddr + bnVGPRNumber, 1, bnCoeffVGPRAddr, True, indentstring, flowHandler.enableRelu)

####################################################
# process a horizontal band


def dwc_kernel_process_channel_group(layerId, warpId, wSize, surfacePartition, funcParameterMap, funcGenHandler, flowHandler):

  uSharpIdList = funcParameterMap["uSharpIdList"]

  xLoadSGPRStr = funcParameterMap["xLoadSGPRStr"]
  yLoadSGPRStr = funcParameterMap["yLoadSGPRStr"]
  xAluSGPRStr = funcParameterMap["xAluSGPRStr"]
  yAluSGPRStr = funcParameterMap["yAluSGPRStr"]
  zSGPRStr = funcParameterMap["zSGPRStr"]
  wSGPRStr = funcParameterMap["wSGPRStr"]
  vgprTempStart = funcParameterMap["vgprTempStart"]

  vgprBaseStr = funcParameterMap["vgprBase"]

  instrOp = funcParameterMap["instrOp"]
  instrModifier = funcParameterMap["instrModifier"]

  euIdSGPRStr = funcParameterMap["euIdSGPRStr"]

  bufferMode = funcParameterMap["bufferGroupType"]

  bnBefore = funcParameterMap["bnBefore"]

  filterStride = funcParameterMap["filterStride"]

  indentstring = flowHandler.getIndentStr()

  if (bnBefore != 0):
    reduce2bnBarIdSGPRStr = funcParameterMap["reduce2bnBarIdSGPRStr"]
    bn2reduceBarIdSGPRStr = funcParameterMap["bn2reduceBarIdSGPRStr"]
    br_print (indentstring + "// waiting for reduction buffer ready to use")
    br_print (indentstring + "bar.tg.sync.cnt " + reduce2bnBarIdSGPRStr + ", 8")
    br_print (indentstring)

  if (instrOp == "dwc") or (bnBefore != 0):
    newWeightSGPRStr = funcParameterMap["newWeightSGPRStr"]
    do_z_initialize(funcParameterMap, flowHandler, uSharpIdList)

  funcLib.AlignPrint(indentstring + "smov " + wSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize w")
  if (wSize > 1):
    flowHandler.startForLoop("", str(wSize), str(1), funcParameterMap["wSGPRIndex"], "loop sample/test")

  indentstring = flowHandler.getIndentStr()

  vgprStride = surfacePartition[0][0]
  ySpanList = surfacePartition[1]
  xSpanList = surfacePartition[2]

  ySpanListSize = len(ySpanList)

  isFirstSub = 1

  do_y_initialize(vgprStride, xSpanList[0], ySpanList[0][2], funcParameterMap, flowHandler)

  for ySpan in ySpanList:
    thisSpanHeight = ySpan[0]
    thisBlockHeight = ySpan[1]
    thisBorderFlagY = ySpan[2]

    indentstring = flowHandler.getIndentStr()

    br_print (indentstring + "//////////////////////////////////////////////")
    if ((thisBorderFlagY & BorderTypeTop()) or (thisBorderFlagY & BorderTypeBottom())):
      assert (thisSpanHeight == thisBlockHeight), "top or bottom border span can't be in loop"

      if ((thisBorderFlagY & BorderTypeTop()) and (thisBorderFlagY & BorderTypeBottom())):
        br_print (indentstring + "// process signle horizontal band, both top and bottom")
      elif (thisBorderFlagY & BorderTypeTop()):
        br_print (indentstring + "// process top horizontal band")
      else:
        br_print (indentstring + "// process bottom horizontal band")
    else:
      br_print (indentstring + "// process middle horizontal band")

    vgprRowNumber = thisBlockHeight
    vgprStartIndex = vgprStride

    thisSpanWidth = xSpanList[0]
    thisBlockWidth = xSpanList[1]

    blockNumberY = int (thisSpanHeight / thisBlockHeight)
    blockNumberX = int (thisSpanWidth / thisBlockWidth)

    if (blockNumberY > 1):
      flowHandler.startForLoop(str(0), str(blockNumberY), str(1), -1, "loop y")
      indentstring = flowHandler.getIndentStr()

    blockLoopNumber = blockNumberX - 3
    blockLoopNumber >>= 1

    if (blockLoopNumber < 0):
      blockLoopNumber = 0

    blockRemainNumber = blockNumberX - (blockLoopNumber << 1)

    br_print (indentstring + "// block number = " + str(blockNumberX) + ", block remain number = " + str(blockRemainNumber))

    br_print (indentstring + "// initialize whenever switching to a new horizontal band")

    do_x_initialize(vgprStride, ySpan[1], ySpan[2], funcParameterMap, flowHandler)

    br_print (indentstring + "// finish initializing horizontal band")

    functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_load_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_1_"

    if (blockNumberX == 1):
      functionName += "1"
    else:
      functionName += "0"

    funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
    flowHandler.startFunctionCall(functionName)
    flowHandler.endFunctionCall()
    if (blockNumberX > 1):
      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_load_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_2"

      if (blockNumberX == 2):
        functionName = functionName + "_1"
      else:
        functionName = functionName + "_0"

      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

    #funcLib.AlignPrint(indentstring + "nop", flowLib.GetCommentPos(), "// temp WA")
    funcLib.AlignPrint(indentstring + "nop.sc1", flowLib.GetCommentPos(), "// wait for sync channel 1")

    if (isFirstSub != 0) and ((instrOp == "dwc") or (bnBefore != 0)):
      do_z_preprocess(funcParameterMap, flowHandler)

    if (bnBefore != 0):
      do_y_preprocess(thisBorderFlagY, vgprRowNumber, vgprStride, funcParameterMap, flowHandler)

    br_print (indentstring)
    if (blockLoopNumber > 1):
      flowHandler.startForLoop(str(0), str(blockLoopNumber), str(1), -1, "loop x")
      indentstring = flowHandler.getIndentStr()

    if (blockLoopNumber > 0):
      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_alu_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_0"
      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_load_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_1_0"
      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

      funcLib.AlignPrint(indentstring + "nop.sc2", flowLib.GetCommentPos(), "// wait for sync channel 2")
      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_alu_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_0"
      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_load_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_2_0"
      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

      funcLib.AlignPrint(indentstring + "nop.sc1", flowLib.GetCommentPos(), "// wait for sync channel 1")

    if (blockLoopNumber > 1):
      flowHandler.closeForLoop(str(0), str(blockLoopNumber), str(1), -1)
      indentstring = flowHandler.getIndentStr()

    functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_alu_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_"
    if (blockNumberX == 1):
      functionName += "1"
    else:
      functionName += "0"
    funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
    flowHandler.startFunctionCall(functionName)
    flowHandler.endFunctionCall()

    if (blockRemainNumber >= 3):
      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_load_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_1"
      if (blockRemainNumber == 3):
        functionName = functionName + "_1"
      else:
        functionName = functionName + "_0"
      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

    if (blockNumberX > 1):
      funcLib.AlignPrint(indentstring + "nop.sc2", flowLib.GetCommentPos(), "// wait for sync channel 2")
      functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_alu_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight)

      if (blockNumberX == 2):
        functionName = functionName + "_1"
      else:
        functionName = functionName + "_0"

      funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
      flowHandler.startFunctionCall(functionName)
      flowHandler.endFunctionCall()

      if (blockRemainNumber >= 4):
        functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_load_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_2_1"
        funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
        flowHandler.startFunctionCall(functionName)
        flowHandler.endFunctionCall()

      if (blockRemainNumber >= 3):
        funcLib.AlignPrint(indentstring + "nop.sc1", flowLib.GetCommentPos(), "// wait for sync channel 1")
        functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_alu_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight)
        if (blockRemainNumber == 3):
          functionName = functionName + "_1"
        else:
          functionName = functionName + "_0"
        funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
        flowHandler.startFunctionCall(functionName)
        flowHandler.endFunctionCall()

      if (blockRemainNumber >= 4):
        funcLib.AlignPrint(indentstring + "nop.sc2", flowLib.GetCommentPos(), "// wait for sync channel 2")
        functionName = "layer_" + str(layerId) + "_warp_" + str(warpId) + "_sub_alu_" + str(thisBorderFlagY) + "_" + str(thisBlockHeight) + "_1"
        funcGenHandler.addFunction(functionName, [flowHandler.getQTempStart(), flowHandler.getQStackStart()])
        flowHandler.startFunctionCall(functionName)
        flowHandler.endFunctionCall()

    if ((thisBorderFlagY & BorderTypeBottom()) == 0):
      br_print (indentstring + "// adjust y to next band")
      if (thisBorderFlagY & BorderTypeTop()) and (bufferMode != BufferRowMode()):
        if (thisBlockHeight != 1):
          br_print (indentstring + "// top band starts from y=0, and next band should start from row -1")
          funcLib.AlignPrint(indentstring + "sadd " + yLoadSGPRStr + ", " + yLoadSGPRStr + ", " + str((thisBlockHeight - 1) * hwCaps.TileSizeY()), flowLib.GetCommentPos(), "// adjust load y")
      else:
        funcLib.AlignPrint(indentstring + "sadd " + yLoadSGPRStr + ", " + yLoadSGPRStr + ", " + str(thisBlockHeight * hwCaps.TileSizeY()), flowLib.GetCommentPos(), "// adjust load y")

      if (filterStride != 0):
        yShift = (thisBlockHeight >> 1) * hwCaps.TileSizeY()
      else:
        yShift = thisBlockHeight * hwCaps.TileSizeY()
      funcLib.AlignPrint(indentstring + "sadd " + yAluSGPRStr + ", " + yAluSGPRStr + ", " + str(yShift), flowLib.GetCommentPos(), "// adjust alu y")

    if (blockNumberY > 1):
      flowHandler.closeForLoop(str(0), str(blockNumberY), str(1), -1)
      indentstring = flowHandler.getIndentStr()

    isFirstSub = 0

  if (wSize > 1):
    flowHandler.closeForLoop("", str(wSize), str(1), funcParameterMap["wSGPRIndex"])

  if (bnBefore != 0):
    indentstring = flowHandler.getIndentStr()
    funcLib.AlignPrint(indentstring + "bar.tg.pass " + bn2reduceBarIdSGPRStr + ", 8", flowLib.GetCommentPos(), "// inform reduce to start next")
    funcLib.AlignPrint(indentstring + "sxor " + bn2reduceBarIdSGPRStr + ", " + bn2reduceBarIdSGPRStr + ", 1", flowLib.GetCommentPos(), "// toggle bn->reduce bar id")
    funcLib.AlignPrint(indentstring + "sxor " + reduce2bnBarIdSGPRStr + ", " + reduce2bnBarIdSGPRStr + ", 1", flowLib.GetCommentPos(), "// toggle reduce->bn bar id")


####################################################
# set_layer_parameter
#   set layer related info, does not rely on sgpr or vgpr allocation
#
def set_layer_parameter(layerInfo, funcParameterMap):

  optionsIndex = cwarp.GetOptionsIndex()

  funcParameterMap["filterStride"] = layerInfo[optionsIndex][GetFilterStrideIndex()]

  funcParameterMap["loadNextChannelWeight"] = 0

  instrOp = layerInfo[0]

  funcParameterMap["instrOp"] = instrOp
  funcParameterMap["instrModifier"] = ".bf16"

  funcParameterMap["weightNumber"] = layerInfo[optionsIndex][GetFilterSizeX()] * layerInfo[optionsIndex][GetFilterSizeY()]
  funcParameterMap["reduceOn"] = layerInfo[optionsIndex][GetReduceOnIndex()]
  bnBefore = layerInfo[optionsIndex][GetBNBeforeOnIndex()]
  funcParameterMap["bnBefore"] = bnBefore

  mate_mode = ""
  if (instrOp != "dwc"):
    mate_mode = ".mean"
    if layerInfo[optionsIndex][GetPoolModeIndex()] == 1:
      mate_mode = ".max"
    elif layerInfo[optionsIndex][GetPoolModeIndex()] == 2:
      mate_mode = ".pad"
    elif layerInfo[optionsIndex][GetPoolModeIndex()] == 3:
      mate_mode = ".idx"
    else:
      assert False, "Unsupported mate mode"

  mateInstrStr = "mate.fw" + str(layerInfo[optionsIndex][GetFilterSizeX()]) + ".fh" + str(layerInfo[optionsIndex][GetFilterSizeY()]) + \
                 ".padx" + str(layerInfo[optionsIndex][GetFilterOffsetX()]) + ".pady" + str(layerInfo[optionsIndex][GetFilterOffsetY()]) + mate_mode

  if (funcParameterMap["filterStride"] != 0):
    mateInstrStr += ".strd2"

  if (funcParameterMap["reduceOn"] != 0):
    mateInstrStr = mateInstrStr + ".ssq"

  funcParameterMap["mateInstrStr"] = mateInstrStr

  uSharpIndex = cwarp.GetUSharpIndex()

  uSharpIdList = [[layerInfo[uSharpIndex][0][usharp.GetSurfUsharpIDIndex()], -1, -1], [layerInfo[uSharpIndex][-1][usharp.GetSurfUsharpIDIndex()]]]

  usharpIndexOffset = 1
  if (instrOp == "dwc"):
    uSharpIdList[0][GetWeightUSharpIndex()] = layerInfo[uSharpIndex][usharpIndexOffset][usharp.GetSurfUsharpIDIndex()]
    usharpIndexOffset += 1

  if (bnBefore != 0):
    uSharpIdList[0][GetGammaUSharpIndex()] = layerInfo[uSharpIndex][usharpIndexOffset][usharp.GetSurfUsharpIDIndex()]

  funcParameterMap["uSharpIdList"] = uSharpIdList

  if (bnBefore != 0):
    srcSurfaceWidth = layerInfo[uSharpIndex][0][usharp.GetSurfCoordXIndex()]
    srcSurfaceHeight = layerInfo[uSharpIndex][0][usharp.GetSurfCoordYIndex()]
    funcParameterMap["reduceSurfaceCoeff"] = 1 / srcSurfaceWidth / srcSurfaceHeight
    funcParameterMap["srcImageWidthRes"] = srcSurfaceWidth & (hwCaps.TileSizeX() - 1)
    funcParameterMap["srcImageHeightRes"] = srcSurfaceHeight & (hwCaps.TileSizeY() - 1)

  dstSurfaceWidth = layerInfo[uSharpIndex][-1][usharp.GetSurfCoordXIndex()]
  dstSurfaceHeight = layerInfo[uSharpIndex][-1][usharp.GetSurfCoordYIndex()]

  funcParameterMap["dstImageWidthRes"] = dstSurfaceWidth & (hwCaps.TileSizeX() - 1)
  funcParameterMap["dstImageHeightRes"] = dstSurfaceHeight & (hwCaps.TileSizeY() - 1)


####################################################
# set_vgpr_number
#   find out how many vgprs can be used as load buffer
#
def set_vgpr_number(bnBefore, vgprPartition, funcParameterMap):
  if (vgprPartition[1] <= vgprPartition[0]):
    assert False, "  no vgpr to use"

  vgprStart = vgprPartition[0]
  vgprNumber = vgprPartition[1] - vgprPartition[0]

  # reserve 2 vgprs for bn
  if (bnBefore != 0):
    bnCoeffVGPRNumber = 2
    funcParameterMap["bnCoeffVGPRAddr"] = vgprStart
    vgprNumber -= bnCoeffVGPRNumber
    vgprStart += bnCoeffVGPRNumber

  vgprTempNumber = hwCaps.MaxSTMGranule()
  if (vgprTempNumber < 8):
    # bn needs at least 6 vgprs
    # stride 2 needs a full col to store temp result
    vgprTempNumber = 8

  vgprTempStart = vgprStart
  funcParameterMap["vgprTempStart"] = vgprTempStart
  vgprNumber -= vgprTempNumber
  vgprStart += vgprTempNumber

  if (vgprNumber <= 0):
    assert False, "  not enough vgprs to hold load data"

  funcParameterMap["vgprIndexStart"] = vgprStart
  funcParameterMap["vgprNumber"] = vgprNumber


####################################################
# find out buffer mode
#
# [ArthurDuan]: need bozhan to re-introduce this algorithm?
def get_dwc_buffer_mode(surfaceTileInfo, isStride2, vgprNumber):

  ySize = surfaceTileInfo[2]
  xSize = surfaceTileInfo[3]

  bufferMode = BufferBlockMode()
  bufferNumber = 3
  surfaceLoopSize = 0

  # limit col size to 16
   # [ArthurDuan]: why 16? slice pingpong, tlr holds temp limit to less than 8, stride2 need 8 per slice
   # TODO: 2 cols process together when it is stride2, currently process whole col
  if (vgprNumber >= (ySize * xSize * 2)) and (isStride2 == 0 or ySize <= 16):
    bufferMode = BufferSurfaceMode()

    bufferNumber = int (vgprNumber / (ySize * xSize))

    # buffer number >= 2, if we can load all sample of channel pair, pingpong between channel pair
    # maybe: 2 cols process together when it is stride2, limit to 3 slices
    # TODO: may consider pingpong in sample directions. if slice is bigger, we can pingpong between samples
    # if slice (x_size*y_size)is very small, we may pingpong between channel pair
    if (bufferNumber >= (2 * surfaceTileInfo[0])):
      surfaceLoopSize = surfaceTileInfo[0]
      bufferNumber = int (bufferNumber / surfaceLoopSize)

      if (bufferNumber > 3):
        bufferNumber = 3 if (xSize+ySize) > 2 else 1

    else:
      if (bufferNumber > surfaceTileInfo[0]):
        bufferNumber = surfaceTileInfo[0]

      # [ArthurDuan]: why 6?
      if bufferNumber < 6:
        surfaceLoopSize = 1
        if bufferNumber > 3:
          bufferNumber = 3
      else:
        surfaceLoopSize = int (bufferNumber / 3)
        bufferNumber = 3

  elif (vgprNumber >= (ySize * 3) and (xSize >= 3)) and (isStride2 == 0 or ySize <= 16):
    bufferMode = BufferColMode()
  elif (xSize <= BufferRowModeThresholdX() and vgprNumber > (3 * (BufferRowModeThresholdY() + 2) * xSize)):
    bufferMode = BufferRowMode()
  else:
    bufferMode = BufferBlockMode()

  return [bufferMode, bufferNumber, surfaceLoopSize]


####################################################
# find out block size
#
# [Arthur Duan]: need bozhan to re-introduce this algorithm
def get_dwc_block_size(ySize, xSize, isStride2, vgprNumber, bufferConfig):

  bufferMode = bufferConfig[0]
  bufferNumber = bufferConfig[1]

  if (bufferMode != BufferRowMode()):
    vgprNumber = int (vgprNumber / bufferNumber)

  if (bufferMode != BufferBlockMode()):
    if (bufferMode == BufferSurfaceMode()):
      blockSizeY = ySize
      blockSizeX = xSize
      vgprStride = blockSizeY
    elif bufferMode == BufferColMode():
      blockSizeY = ySize
      vgprStride = blockSizeY

      blockSizeXFromVGPR = int (vgprNumber / vgprStride)
      blockSizeXFromSize = int ((xSize + bufferNumber - 1) / bufferNumber)

      if (blockSizeXFromSize < blockSizeXFromVGPR):
        blockSizeX = blockSizeXFromSize
      else:
        blockSizeX = blockSizeXFromVGPR

      # if (blockSizeX & 1):
      #   blockSizeX -= 1

    else:
      blockSizeX = xSize
      blockSizeYFromVGPR = int (((int (vgprNumber / xSize)) - 2) / bufferNumber)
      blockSizeYFromSize = int ((ySize + bufferNumber - 1) / bufferNumber)

      if (blockSizeYFromSize < blockSizeYFromVGPR):
        blockSizeY = blockSizeYFromSize
      else:
        blockSizeY = blockSizeYFromVGPR

      # limit col size to 16 in case of stride 2 as we only reserve 8 temps
      if (isStride2 != 0 and blockSizeY >= 16):
        blockSizeY = 16

      if (blockSizeY & 1):
        blockSizeY -= 1

      assert (blockSizeY > 2), "should not choose this mode"

      vgprStride = 3 * blockSizeY + 2

  else:
    blockSizeY = math.floor(math.sqrt(vgprNumber))
    iteration = 0

    while (iteration < 2):
      if (isStride2 != 0) and (blockSizeY & 1):
        blockSizeY -= 1

      if (blockSizeY > 8):
        blockSizeY = int (blockSizeY / hwCaps.MaxLoadGranule()) * hwCaps.MaxLoadGranule()

      if (isStride2 != 0 and blockSizeY >= 16):
        blockSizeY = 16

      vgprStride = blockSizeY + 2
      blockSizeX = math.floor (vgprNumber / vgprStride)

      refitY = 0

      if (blockSizeX >= (xSize + 2)):
        assert False, "should  be row mode"
        blockSizeX = xSize + 2
        refitY = 1

      if (isStride2 != 0) and (blockSizeX & 1):
        if (blockSizeY > (blockSizeX + 2)):
          blockSizeX += 1
        else:
          blockSizeX -= 1
        refitY = 1

      if (refitY == 0):
        break
      else:
        blockSizeY = math.floor(math.floor(vgprNumber / blockSizeX))
        iteration += 1

    if isStride2 != 0 and (blockSizeY & 1):
      blockSizeY -= 1

    vgprStride = blockSizeY + 2

    blockSizeX -= 2

  return (vgprStride, blockSizeY, blockSizeX)

####################################################


def get_dwc_surface_partition(surfaceTileInfo, filterInfo, borderType, funcParameterMap, indendString):

  vgprNumber = funcParameterMap["vgprNumber"]

  bufferConfig = get_dwc_buffer_mode(surfaceTileInfo, filterInfo[4], vgprNumber)

  ySize = surfaceTileInfo[2]
  xSize = surfaceTileInfo[3]

  (vgprStride, yUnit, xUnit) = get_dwc_block_size(ySize, xSize, filterInfo[4], vgprNumber, bufferConfig)

  if (yUnit == 0 or xUnit == 0):
    assert False, "  not enough vgprs, can't find a block that can fit " + str(vgprNumber) + " vgprs"

  partitionList = []

  yTopFlag = borderType & BorderTypeTop()
  yBottomFlag = borderType & (BorderTypeBottom() | BorderTypeBottomPartial())

  yAlignedSize = int (ySize / yUnit) * yUnit
  yRemainder = ySize - yAlignedSize

  ySpanList = []

  if (yAlignedSize != 0 and yRemainder <= 1):
    yAlignedSize -= yUnit
    yRemainder += yUnit

  if (bufferConfig[0] == BufferRowMode()):
    if (yAlignedSize > yUnit):
      yAlignedSize -= yUnit
      ySpanList.append([yUnit, yUnit, 0])

  if (yAlignedSize != 0):
    ySpanList.append([yAlignedSize, yUnit, 0])

  if yRemainder > 1:
    ySpanList.append([yRemainder - 1, yRemainder - 1, 0])
  elif len(ySpanList) < 1:
    ySpanList.append([yRemainder, yRemainder, 0])
  

  if (ySpanList[0][0] == ySpanList[0][1]):
    ySpanList[0][2] = yTopFlag

  ySpanList[-1][2] |= yBottomFlag

  xBorderFlag = borderType & (BorderTypeRight() | BorderTypeRightPartial())

  xAlignedSize = int (xSize / xUnit) * xUnit
  partialBlockWidth = xSize - xAlignedSize

  if (partialBlockWidth <= 1):
    partialBlockWidth += xUnit
  else:
    xAlignedSize += xUnit

  partialBlockWidth -= 1

  rightBorderBlockX = xAlignedSize - xUnit

  xSpanList = [xAlignedSize, xUnit, xBorderFlag]

  return ([vgprStride, bufferConfig[0], bufferConfig[1], bufferConfig[2]], ySpanList, xSpanList, [rightBorderBlockX * hwCaps.TileSizeX(), xUnit, partialBlockWidth])


####################################################
# set_surface_parameter
#   set surface related info such as border info, block width etc
#
def set_surface_parameter(funcParameterMap, surfacePartition, surfaceWidth):

  vgprStride = surfacePartition[0][0]
  bufferGroupType = surfacePartition[0][1]
  bufferGroupNumber = surfacePartition[0][2]
  bufferSurfaceNumber = surfacePartition[0][3]

  fullBlockWidth = surfacePartition[3][1]
  fullHeight = surfacePartition[1][0][1]

  funcParameterMap["vgprStride"] = vgprStride
  funcParameterMap["bufferGroupType"] = bufferGroupType
  funcParameterMap["bufferGroupNumber"] = bufferGroupNumber
  funcParameterMap["bufferSurfaceNumber"] = bufferSurfaceNumber

  funcParameterMap["rightBorderBlockX"] = surfacePartition[3][0]
  funcParameterMap["fullBlockWidth"] = fullBlockWidth
  funcParameterMap["partialBlockWidth"] = surfacePartition[3][2]

  funcParameterMap["surfaceBorderX"] = surfaceWidth & (~(hwCaps.TileSizeX() - 1))

  if (surfacePartition[0][1] == BufferSurfaceMode()):
    vgprBufferSize = fullBlockWidth * vgprStride * bufferGroupNumber * bufferSurfaceNumber
    vgprStepBack = vgprBufferSize
  elif (surfacePartition[0][1] == BufferRowMode()):
    vgprStepBack = fullHeight * bufferGroupNumber
    vgprBufferSize = vgprStepBack
  elif (surfacePartition[0][1] == BufferColMode()):
    vgprStepBack = fullBlockWidth * bufferGroupNumber * vgprStride
    vgprBufferSize = vgprStepBack
  else:
    vgprStepBack = fullBlockWidth * bufferGroupNumber * vgprStride
    vgprBufferSize = vgprStepBack

  funcParameterMap["vgprIndexEnd"] = funcParameterMap["vgprIndexStart"] + vgprBufferSize

  funcParameterMap["vgprStepBack"] = vgprStepBack


####################################################
# set_gpr_usage
#   set vgpr/sgpr related info
#
def set_gpr_usage(funcParameterMap, layerInfo, flowHandler):
  indentstring = flowHandler.getIndentStr()

  funcParameterMap["loadNextChannelWeight"] = 0

  bufferGroupNumber = funcParameterMap["bufferGroupNumber"]
  bufferGroupType = funcParameterMap["bufferGroupType"]

  optionsIndex = cwarp.GetOptionsIndex()

  instrOp = layerInfo[cwarp.GetCMDIndex()]
  reduceOn = layerInfo[optionsIndex][GetReduceOnIndex()]
  bnBefore = layerInfo[optionsIndex][GetBNBeforeOnIndex()]

  funcParameterMap["constBase"] = "a0"
  funcParameterMap["vgprBase"] = "a1"
  funcParameterMap["sgprBase"] = "a2"

  br_print (indentstring + "// sgpr usage:")
  coordSGPRIndex = flowHandler.allocateSGPR(6)
  funcParameterMap["zSGPRIndex"] = coordSGPRIndex + 4
  funcParameterMap["wSGPRIndex"] = coordSGPRIndex + 5
  funcParameterMap["xLoadSGPRStr"] = "q" + str(coordSGPRIndex)
  funcParameterMap["yLoadSGPRStr"] = "q" + str(coordSGPRIndex + 1)
  funcParameterMap["xAluSGPRStr"] = "q" + str(coordSGPRIndex + 2)
  funcParameterMap["yAluSGPRStr"] = "q" + str(coordSGPRIndex + 3)
  funcParameterMap["zSGPRStr"] = "q" + str(coordSGPRIndex + 4)
  funcParameterMap["wSGPRStr"] = "q" + str(coordSGPRIndex + 5)


  funcParameterMap["xSGPRStr"] = funcParameterMap["xLoadSGPRStr"]
  funcParameterMap["ySGPRStr"] = funcParameterMap["yLoadSGPRStr"]

  br_print (indentstring + "//   x/y/z/w at sgpr q" + str(coordSGPRIndex) + "-q" + str(coordSGPRIndex + 5))
  br_print (indentstring + "//     load x/y uses " + funcParameterMap["xLoadSGPRStr"] + " and " + funcParameterMap["yLoadSGPRStr"])
  br_print (indentstring + "//     alu  x/y uses " + funcParameterMap["xAluSGPRStr"] + " and " + funcParameterMap["yAluSGPRStr"])

  euIdSGPRIndex = flowHandler.allocateSGPR(1)
  euIdSGPRStr = "q" + str(euIdSGPRIndex)
  funcParameterMap["euIdSGPRStr"] = euIdSGPRStr
  br_print (indentstring + "//   unique eu id at sgpr " + euIdSGPRStr)

  reduceSlotSGPRStr = "q0"

  if (reduceOn != 0):
    reduceSlotSGPRIndex = flowHandler.allocateSGPR(1)
    reduceSlotSGPRStr = "q" + str(reduceSlotSGPRIndex)
    br_print (indentstring + "//   reduce slot at sgpr " + reduceSlotSGPRStr)

  if (instrOp == "dwc" or bnBefore != 0):
    newWeightSGPRIndex = flowHandler.allocateSGPR(1)
    newWeightSGPRStr = "q" + str(newWeightSGPRIndex)
    funcParameterMap["newWeightSGPRStr"] = newWeightSGPRStr
    br_print (indentstring + "//   new weight at sgpr " + newWeightSGPRStr + ", triggered when channel switches, to wbar sync for lddw and preprocess reduction coeff")

    if (bnBefore != 0):
    # use channel to get gamma/beta
    # gammaAddrSGPRIndex = flowHandler.allocateSGPR(1)
    # gammaAddrSGPRStr  = "q" + str(gammaAddrSGPRIndex)
    # funcParameterMap["gammaAddrSGPRStr"] = gammaAddrSGPRStr
    # br_print (indentstring + "//   gamma/beta addr at sgpr " + gammaAddrSGPRStr)

      gammaDataSGPRIndex = flowHandler.allocateSGPR(4)
      gammaDataSGPRStr = "q" + str(gammaDataSGPRIndex)
      funcParameterMap["gammaDataSGPRStr"] = gammaDataSGPRStr
      funcParameterMap["gammaDataSGPRIndex"] = gammaDataSGPRIndex
      br_print (indentstring + "//   gamma/beta data at sgpr " + gammaDataSGPRStr + "-" + str(gammaDataSGPRIndex + 3))

      reduceResSGPRIndex = flowHandler.allocateSGPR(4)
      reduceResultSGPRStr = "q" + str(reduceResSGPRIndex)
      funcParameterMap["reduceResultSGPRStr"] = reduceResultSGPRStr
      funcParameterMap["reduceResSGPRIndex"] = reduceResSGPRIndex
      br_print (indentstring + "//   reduce result at sgpr q" + str(reduceResSGPRIndex) + "-" + str(reduceResSGPRIndex + 3) + ", temporarily before befor moving to vgpr")

      surfaceChannel = funcParameterMap["surfaceChannel"]
      num_sgpr = 3 if surfaceChannel*2 < 128 else 4
      reduce2bnBarIdSGPRIndex = flowHandler.allocateSGPR(num_sgpr)
      reduce2bnBarIdSGPRStr = "q" + str(reduce2bnBarIdSGPRIndex)
      bn2reduceBarIdSGPRStr = "q" + str(reduce2bnBarIdSGPRIndex + 1)
      funcParameterMap["reduce2bnBarIdSGPRStr"] = reduce2bnBarIdSGPRStr
      funcParameterMap["bn2reduceBarIdSGPRStr"] = bn2reduceBarIdSGPRStr
      funcParameterMap["sldXSGPRStr"] = "q" + str(reduce2bnBarIdSGPRIndex + 2)
      if surfaceChannel*2 >= 128:
        funcParameterMap["maxSldXValue"] = "q" + str(reduce2bnBarIdSGPRIndex + 3)

      
      br_print (indentstring + "//   channel sync bar id at sgpr " + reduce2bnBarIdSGPRStr + " and " + bn2reduceBarIdSGPRStr)
      br_print (indentstring + "//     reduce->bn uses 2 bars, from " + str(cwarp.GetReduce2BNSyncBarId()) + ", id at " + reduce2bnBarIdSGPRStr)
      br_print (indentstring + "//     bn->reduce uses 2 bars, from " + str(cwarp.GetBN2ReduceSyncBarId()) + ", id at " + bn2reduceBarIdSGPRStr)

    if (instrOp == "dwc"):
      weightAddrSGPRIndex = flowHandler.allocateSGPR(1)
      weightAddrSGPRStr = "q" + str(weightAddrSGPRIndex)
      funcParameterMap["weightAddrSGPRStr"] = weightAddrSGPRStr
      br_print (indentstring + "//   weight addr at sgpr " + weightAddrSGPRStr + ", this is for lddw address")

      constBaseSGPRIndex = flowHandler.allocateSGPR(1)
      constBaseSGPRStr = "q" + str(constBaseSGPRIndex)
      br_print (indentstring + "//   const base at sgpr " + constBaseSGPRStr + ", this is for lddw return")

      funcParameterMap["constBaseSGPRStr"] = constBaseSGPRStr

  funcParameterMap["reduceSlotSGPRStr"] = reduceSlotSGPRStr

  mateInstrSrcStr = " ic0"
  # mateInstrSrcStr = " ic0, " + reduceSlotSGPRStr
    
  funcParameterMap["mateInstrSrcStr"] = mateInstrSrcStr

  vgprBaseSGPRIndex = flowHandler.allocateSGPR(2)
  vgprLoadBaseSGPRStr = "q" + str(vgprBaseSGPRIndex)
  vgprAluBaseSGPRStr = "q" + str(vgprBaseSGPRIndex + 1)
  funcParameterMap["vgprLoadBaseSGPRStr"] = vgprLoadBaseSGPRStr
  funcParameterMap["vgprAluBaseSGPRStr"] = vgprAluBaseSGPRStr
  br_print (indentstring + "//   vgpr base at sgpr " + vgprLoadBaseSGPRStr + " and " + vgprAluBaseSGPRStr)
  br_print (indentstring + "//     load uses " + vgprLoadBaseSGPRStr)
  br_print (indentstring + "//     alu uses " + vgprAluBaseSGPRStr)

  vgprTempStart = funcParameterMap["vgprTempStart"]
  vgprStart = funcParameterMap["vgprIndexStart"]
  vgprNumber = funcParameterMap["vgprNumber"]

  br_print (indentstring + "// vgpr usage:")

  if (bnBefore != 0):
    bnCoeffVGPRAddr = funcParameterMap["bnCoeffVGPRAddr"]
    br_print (indentstring + "//   bn coeff will use vgpr[" + str(bnCoeffVGPRAddr) + ", " + str(vgprTempStart) + ")")

  br_print (indentstring + "//   temp will use vgpr[" + str(vgprTempStart) + ", " + str(vgprStart) + ")")

  br_print (indentstring + "//   load data will use vgpr[" + str(vgprStart) + ", " + str(vgprStart + vgprNumber) + ")")

####################################################
# gen_kernel_sub_function
#   generate sub functions that will be called


def gen_kernel_sub_function(funcDefMap, funcParaDict):
  flowHandler = flowLib.FlowHandler("", 0, 0, compiler.GetASMMode())

  for x, y in funcDefMap.items():
    #br_print ("// func " + x + ", q regs free to use: " + str(y))
    #br_print ("// return address at q" + str(y[1] + 1))

    funcKeys = x.split("_")

    flowHandler.startFunctionDef(x, 1)
    flowHandler.setLabelIndex(0)
    flowHandler.setLabelSuffix(x.upper())
    flowHandler.setQTempStart(y[0])
    flowHandler.setQStackStart(y[1])

    if (funcKeys[5] == "load"):
      funcType = 0
    else:
      funcType = 1

    yBorderType = int (funcKeys[6])
    blockHeight = int (funcKeys[7])

    if (funcType == 0):
      syncIndex = int (funcKeys[8])
      rightBorderMode = int (funcKeys[9])
    else:
      syncIndex = 0
      rightBorderMode = int (funcKeys[8])

    gen_dwc_sub_function(funcType, yBorderType, blockHeight, rightBorderMode, syncIndex, funcParaDict, flowHandler)

    flowHandler.closeFunctionDef(x, 1)


####################################################
#
def gen_layer_vgpr_usage(layerId, layerNumber, warpId, layerInfo):
  optionsIndex = cwarp.GetOptionsIndex()

  filterInfo = [layerInfo[optionsIndex][GetFilterSizeX()], layerInfo[optionsIndex][GetFilterSizeY()],
                layerInfo[optionsIndex][GetFilterOffsetX()], layerInfo[optionsIndex][GetFilterOffsetY()],
                layerInfo[optionsIndex][GetFilterStrideIndex()]]

  # input is used to as an intermediate space to hold input data from memory before saving them to gsm
  # after that, it is not in use anymore
  # output buffer is used for output, usually it is smaller than input buffer
  # temp buffer is used in two cases
  # 1. load all data in filter x
  # 2. load a whole col or a whole row of input buffer
  # both cases need double buffer

  minOutputBlockTileX = 1
  minOutputBlockTileY = 1

  minVGPRNumber0 = minOutputBlockTileX * minOutputBlockTileY + 2 * filterInfo[0]

  if (filterInfo[4] != 0):
    minGSMBlockTileX = minOutputBlockTileX << 1
    minGSMBlockTileY = minOutputBlockTileY << 1
  else:
    minGSMBlockTileX = minOutputBlockTileX
    minGSMBlockTileY = minOutputBlockTileY

  [leftPadding, rightPadding, topPadding, bottomPadding] = get_padding_size(layerInfo[optionsIndex])

  minGSMBlockTileX += leftPadding + rightPadding
  minGSMBlockTileY += rightPadding + bottomPadding

  minVGPRNumber1 = minGSMBlockTileX * minGSMBlockTileY

  if (minVGPRNumber1 < minVGPRNumber0):
    minVGPRNumber1 = minVGPRNumber0

  # need 3 extra vgprs to hold gsm offset (from and to), and per lane gsm address
  # laneOffsetVGPRAddr and tileAddresVGPRAddr

  return minVGPRNumber1 + 3


####################################################
#
def gen_layer_main_kernel(layerId, layerNumber, warpId, layerInfo, flowHandler, idtype, wdtype, odtype):

  cmdIndex = cwarp.GetCMDIndex()

  if (layerInfo[cmdIndex] != "dwc" and layerInfo[cmdIndex] != "pool"):
    assert False, "unsupported op " + layerInfo[cmdIndex]
    return

  flowHandler.startFunctionDef("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel", 0)
  indentstring = flowHandler.getIndentStr()

  funcGenHandler = funcgen.FuncGenHandler()
  funcParameterMap = {}

  flowHandler.setLabelSuffix("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel")

  br_print (indentstring + "// TODO bar unit")
  br_print (indentstring + "// TODO not enough loop in z dimension")

  uSharpIndex = cwarp.GetUSharpIndex()
  optionsIndex = cwarp.GetOptionsIndex()

  surfaceSample = layerInfo[uSharpIndex][0][usharp.GetSurfCoordSampleIndex()]
  surfaceChannel = layerInfo[uSharpIndex][0][usharp.GetSurfCoordChannelIndex()]
  surfaceHeight = layerInfo[uSharpIndex][0][usharp.GetSurfCoordYIndex()]
  surfaceWidth = layerInfo[uSharpIndex][0][usharp.GetSurfCoordXIndex()]

  filterInfo = [layerInfo[optionsIndex][GetFilterSizeX()], layerInfo[optionsIndex][GetFilterSizeY()],
                layerInfo[optionsIndex][GetFilterOffsetX()], layerInfo[optionsIndex][GetFilterOffsetY()],
                layerInfo[optionsIndex][GetFilterStrideIndex()]]

  br_print (indentstring + "// layer info:")
  br_print (indentstring + "//   op            - :" + layerInfo[cmdIndex])
  br_print (indentstring + "//   surface       - sample : " + str(surfaceSample) + ", channel: " + str(surfaceChannel) + ", height: " + str(surfaceHeight) + ", width: " + str(surfaceWidth))
  br_print (indentstring + "//   filter        - x size : " + str(filterInfo[0]) + ", y size: " + str(filterInfo[1]))
  br_print (indentstring + "//                 - x offset : " + str(filterInfo[2]) + ", y offset: " + str(filterInfo[3]))
  br_print (indentstring + "//                 - stride2 on : " + str(filterInfo[4]))
  br_print (indentstring + "//   bn before     - " + str(layerInfo[optionsIndex][GetBNBeforeOnIndex()]))
  br_print (indentstring + "//   reduce on     - " + str(layerInfo[optionsIndex][GetReduceOnIndex()]))

  funcParameterMap["surfaceChannel"] = surfaceChannel
  isStride2On = (filterInfo[4] & kernelLib.GetStrideEnableMask()) != 0
  funcParameterMap["isStride2On"] = isStride2On
  kernelLib.PrintUSharpList(layerInfo[uSharpIndex], indentstring)

  set_layer_parameter(layerInfo, funcParameterMap)

  set_vgpr_number(layerInfo[optionsIndex][GetBNBeforeOnIndex()], layerInfo[cwarp.GetVGPRPartitionIndex()], funcParameterMap)

  borderType = BorderTypeAll()

  tileNumberX = int ((surfaceWidth + hwCaps.TileSizeX() - 1) / hwCaps.TileSizeX())
  tileNumberY = int ((surfaceHeight + hwCaps.TileSizeY() - 1) / hwCaps.TileSizeY())
  funcParameterMap["singleTileRowMode"] = (tileNumberY == 1)

  if (surfaceHeight % hwCaps.TileSizeY()):
    borderType |= BorderTypeBottomPartial()

  if (surfaceWidth % hwCaps.TileSizeX()):
    borderType |= BorderTypeRightPartial()

  surfaceTileInfo = [surfaceSample, surfaceChannel, tileNumberY, tileNumberX]

  surfacePartition = get_dwc_surface_partition(surfaceTileInfo, filterInfo, borderType, funcParameterMap, flowHandler.getIndentStr())

  set_surface_parameter(funcParameterMap, surfacePartition, surfaceWidth)

  set_gpr_usage(funcParameterMap, layerInfo, flowHandler)

  indentstring = flowHandler.getIndentStr()

  br_print (indentstring + "// tile info:")
  br_print (indentstring + "//   tile number y = " + str(tileNumberY) + ", tile number x = " + str(tileNumberX))
  br_print (indentstring)

  br_print (indentstring + "// start preprocessing")
  br_print (indentstring)

  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "//  " + layerInfo[cwarp.GetCMDIndex()] + " parition :")

  vgprStride = surfacePartition[0][0]
  bufferMode = surfacePartition[0][1]
  br_print (indentstring + "//    vgprStride: " + str(surfacePartition[0][0]))

  if (bufferMode == BufferSurfaceMode()):
    br_print (indentstring + "//    buffer mode: surface mode, " + str(surfacePartition[0][3]) + " as a group")
  elif (bufferMode == BufferRowMode()):
    br_print (indentstring + "//    buffer mode: row mode")
  elif (bufferMode == BufferColMode()):
    br_print (indentstring + "//    buffer mode: col mode")
  else:
    br_print (indentstring + "//    buffer mode: block mode")

  br_print (indentstring + "//    buffer numbers: " + str(surfacePartition[0][2]))

  br_print (indentstring + "//    y dir partition (last row is not counted, as it needs special handling):")
  for thisSpan in surfacePartition[1]:
    br_print (indentstring + "//      height: " + str(thisSpan[0]) + ", step: " + str(thisSpan[1]) + ", border: " + str(thisSpan[2]))

  thisSpan = surfacePartition[2]
  br_print (indentstring + "//    x dir partition (last col is not counted in partial block width, as it needs special handling):")
  br_print (indentstring + "//      width:  " + str(thisSpan[0]) + ", step: " + str(thisSpan[1]) + ", border: " + str(thisSpan[2]))

  thisSpan = surfacePartition[3]
  br_print (indentstring + "//      x border block pos: " + str(thisSpan[0]))
  br_print (indentstring + "//      partial block width: " + str(thisSpan[2]))

  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "// start dwc")
  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring)

  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "// initialize relative addr")
  funcLib.AlignPrint(indentstring + "smovs up0, " + str(funcParameterMap["vgprIndexEnd"]-1), flowLib.GetCommentPos(), "// set relative addr upper bound, should be close-open")
  funcLib.AlignPrint(indentstring + "smovs sz0, " + str(funcParameterMap["vgprStepBack"]), flowLib.GetCommentPos(), "// set relative addr range")
  br_print (indentstring)

  br_print (indentstring + "//////////////////////////////////////////////")
  br_print (indentstring + "// initialize bar")

  bnBefore = funcParameterMap["bnBefore"]

  if (flowHandler.syncid_with_bn is not None):
    br_print (indentstring + "// waiting for input data from batchnorm to use")
    br_print (indentstring + "bar.tg.sync.cnt " + str(flowHandler.syncid_with_bn) + ", 8")

  if (bnBefore != 0):
    bn2reduceBarIdSGPRStr = funcParameterMap["bn2reduceBarIdSGPRStr"]
    reduce2bnBarIdSGPRStr = funcParameterMap["reduce2bnBarIdSGPRStr"]
    funcLib.AlignPrint(indentstring + "smov " + reduce2bnBarIdSGPRStr + ", " + str(bcd.VECTOR_PINGPONG_REDUCE_TO_BN_BAR_ID_1), flowLib.GetCommentPos(), "// set reduce->bn bar id")
    funcLib.AlignPrint(indentstring + "smov " + bn2reduceBarIdSGPRStr + ", " + str(bcd.VECTOR_PINGPONG_BN_TO_REDUCE_BAR_ID_1), flowLib.GetCommentPos(), "// set bn->reduce bar id")
    # funcLib.AlignPrint(indentstring + "bar.tg.pass " + str(cwarp.GetBN2ReduceSyncBarId()) + ", 8", flowLib.GetCommentPos(), "// initialize bn->reduce bar so reduce could start")
    # funcLib.AlignPrint(indentstring + "bar.tg.pass " + str(cwarp.GetBN2ReduceSyncBarId()+1) + ", 8", flowLib.GetCommentPos(), "// initialize bn->reduce bar so reduce could start")

  br_print (indentstring)
  zSGPRStr = funcParameterMap["zSGPRStr"]
  euIdSGPRStr = funcParameterMap["euIdSGPRStr"]
  br_print (indentstring + "sysid.work " + euIdSGPRStr)
  funcLib.AlignPrint(indentstring + "sand " + euIdSGPRStr + ", " + euIdSGPRStr + ", 0xf", flowLib.GetCommentPos(), "// obtain unique eu id")
  funcLib.AlignPrint(indentstring + "sshl " + zSGPRStr + ", " + euIdSGPRStr + ", 1", flowLib.GetCommentPos(), "// initialize z with channel pair start")

  reduceOn = funcParameterMap["reduceOn"]
  instrOp = funcParameterMap["instrOp"]

  if (reduceOn != 0):
    reduceSlotSGPRStr = funcParameterMap["reduceSlotSGPRStr"]
    funcLib.AlignPrint(indentstring + "smov " + reduceSlotSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize reduce slot sgpr")

  if (instrOp == "dwc"):
    constBaseSGPRStr = funcParameterMap["constBaseSGPRStr"]
    weightAddrSGPRStr = funcParameterMap["weightAddrSGPRStr"]
    funcLib.AlignPrint(indentstring + "smov " + constBaseSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize csr base sgbr")
    funcLib.AlignPrint(indentstring + "smov " + weightAddrSGPRStr + ", 0", flowLib.GetCommentPos(), "// initialize weight addr sgbr")

  vgprBaseStr = funcParameterMap["vgprBase"]
  vgprIndexStart = funcParameterMap["vgprIndexStart"]
  funcLib.AlignPrint(indentstring + "smovs " + vgprBaseStr + ", " + str(vgprIndexStart), flowLib.GetCommentPos(), "// initialize vgpr base a1")
  funcLib.AlignPrint(indentstring + "smov " + funcParameterMap["vgprLoadBaseSGPRStr"] + ", " + str(vgprIndexStart), flowLib.GetCommentPos(), "// initialize load vgpr base")
  funcLib.AlignPrint(indentstring + "smov " + funcParameterMap["vgprAluBaseSGPRStr"] + ", " + str(vgprIndexStart), flowLib.GetCommentPos(), "// initialize alu vgpr base")

  if (funcParameterMap["loadNextChannelWeight"] != 0) and (bnBefore != 0 or instrOp == "dwc"):
    br_print (indentstring + "// load weight/gamma/beta/reduce result for next channel group")
    do_z_initialize(funcParameterMap, flowHandler, funcParameterMap["uSharpIdList"])

  br_print (indentstring)
  flowHandler.startForLoop("", str(surfaceTileInfo[1]), str(32), funcParameterMap["zSGPRIndex"], "loop channel")
  indentstring = flowHandler.getIndentStr()

  dwc_kernel_process_channel_group(layerId, warpId, surfaceTileInfo[0], surfacePartition, funcParameterMap, funcGenHandler, flowHandler)

  br_print (indentstring)

  if (instrOp == "dwc"):
    funcLib.AlignPrint(indentstring + "sxor " + constBaseSGPRStr + ", " + constBaseSGPRStr + ", 32", flowLib.GetCommentPos(), "// toggle constant base")

  if (reduceOn != 0):
    funcLib.AlignPrint(indentstring + "sadd " + reduceSlotSGPRStr + ", " + reduceSlotSGPRStr + ", 1", flowLib.GetCommentPos(), "// advance reduction slot")
    funcLib.AlignPrint(indentstring + "sand " + reduceSlotSGPRStr + ", " + reduceSlotSGPRStr + ", 0xf", flowLib.GetCommentPos(), "// wrap around 16 reduction slots")

  flowHandler.closeForLoop("", str(surfaceTileInfo[1]), str(32), funcParameterMap["zSGPRIndex"])
  indentstring = flowHandler.getIndentStr()

  if (funcParameterMap["loadNextChannelWeight"] != 0) and (bnBefore != 0 or instrOp == "dwc"):
    br_print (indentstring + "// load weight for next channel group, now clear sync channel")
    flowHandler.startIfLoop(euIdSGPRStr, str(0), "==", 0)
    indentstring = flowHandler.getIndentStr()
    br_print (indentstring + "nop.sc1")
    flowHandler.closeIfLoop()
    indentstring = flowHandler.getIndentStr()

  if flowHandler.force_ackgmb:
    funcLib.AlignPrint(indentstring + "ackgmb ", flowLib.GetCommentPos(), "// ensure the kernel done")
  if flowHandler.sync_layer:
    funcLib.AlignPrint(indentstring + "bar.wtg.pass 1, 17", flowLib.GetCommentPos(), "// inform next conv layer to start")

  if (layerNumber is not None) and (layerNumber > 1):
    kernelLib.jump_to_next_layer(layerId, layerNumber, warpId, indentstring)


  flowHandler.closeFunctionDef("layer_" + str(layerId) + "_warp_" + str(warpId) + "_main_kernel", 0)

  gen_kernel_sub_function(funcGenHandler.getFuncDef(), funcParameterMap)

