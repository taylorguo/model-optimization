#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
from abc import abstractmethod
from copy import deepcopy
from code_generator.vector.br_vector_base import vector


# this is the base implementation for cooperative vector
# operator like stm and adder serving for tcore
class co_operator(vector):
    def __init__(self):
        super().__init__()

        self.bar_defs = {
                "produce": ["set", "pass"],
                "consume": ["csm", "sync"]}
        self.slot_keys = ["grb_pingpong", "tlr_pingpong"]
        self.force_ackgmb = False
        self.loop_defs = ["prolog", "epilog"]
        self.sync_defs = {
            "bar_sync":
                {"channels": 17, "sgprs": "bar_sync_sgpr",
                 "scope": "wtg", "mode": "sync", "pingpong": False,
                 "comment": {"init": None, "produce": None, "consume": None}},
            "bar_pass":
                {"channels": 17, "sgprs": "bar_pass_sgpr",
                 "scope": "wtg", "mode": "pass", "pingpong": False,
                 "comment": {"init": None, "produce": None, "consume": None}},
            "bar_csm":
                {"channels": "all", "sgprs": "bar_csm_sgpr",
                 "scope": "wtg", "mode": "csm", "pingpong": False,
                 "comment": {"init": None, "produce": None, "consume": None}},
            "tlr_bar_csm":
                {"channels": "all", "sgprs": "bar_csm_sgpr",
                 "scope": "wtg", "mode": "csm", "pingpong": False,
                 "comment": {"init": None, "produce": None, "consume": None}},
            "tlr_bar_pass":
                {"channels": 17, "sgprs": "bar_pass_sgpr",
                 "scope": "wtg", "mode": "pass", "pingpong": False,
                 "comment": {"init": None, "produce": None, "consume": None}}}
        
        self.slot_flipping = None
        self.base_reg = None
        self.merge_reduce = False
        self.slot_info = {}
        self.wred_usharpid = None
        self.wred_channelnum = None
        self.afterdwc = False
        self.loopconfig = None
        self.micro_batch_mode = False

    def _pre_func(self):
        self._parse_config()
        self.flow_man.start_function_def(self._get_layer_label(), True)
        self.flow_man.set_label_suffix(self._get_layer_label())

    def _post_func(self):
        self._jump_to_next(self.flow_man.get_indent())
        self.flow_man.close_function_def(True)

    @abstractmethod
    def _core_func(self):
        pass

    def _core_process(self):
        self._pre_func()
        self._core_func()
        self._post_func()

    def _parse_config(self):
        # name, iterations, unrolls, incremental unit，regs, dicts
        # [ ('outer_oc', 2, 1, 256, {'wset': [32, 33], 'sset': [48, 49]}),
        #   ('sample', 2, 1, 256),
        #   ('row', 7, 1, 8),
        #   ('col', 7, 1, 8),
        #   ('inner_oc', 8, 1, 32),
        # ]
        print(self.loopconfig)
        if self.loopconfig is not None:
            self.outer_z = None
            self.inner_z = None
            self.outer_x = None
            self.x = None
            self.y = None
            self.w = None
            self.stm_no_burst = False
            self.pingpongs = []

            loop_config = []
            enable_subloop = False
            self.sub_loopconfig = []
            for aloop in self.loopconfig:
                if len(aloop) < 4:
                    continue

                if aloop[1] < 2:
                    loop_iter_sgpr = None
                else:
                    loop_iter_sgpr = self._alloc_wsr(aloop[0])
                # TODO: change to oc. 20200923 by xiaoyang
                if aloop[0] == self.OUTER_OC:
                    self.outer_z = loop_iter_sgpr
                elif aloop[0] == self.SAMPLE:
                    self.w = loop_iter_sgpr
                elif aloop[0] == self.ROW:
                    self.y = loop_iter_sgpr
                    if aloop[3] == 4:
                        self.stm_no_burst = True
                elif aloop[0] == self.OUTER_COL:
                    self.outer_x = loop_iter_sgpr
                elif aloop[0] == self.COL:
                    self.x = loop_iter_sgpr
                    if aloop[3] == 4:
                        self.stm_no_burst = True
                elif aloop[0] == self.INNER_OC:
                    self.inner_z = loop_iter_sgpr
                # elif aloop[0] == "stride":
                #    self.stride = loop_iter_sgpr
                else:
                    continue  # assert False, "Unsupported loop item!"

                dict_list = None
                if len(aloop) > 4:
                    dict_list = deepcopy(aloop[4])
                    for bar_key in self.sync_defs.keys():
                        if bar_key in dict_list.keys():
                            bar_key_sgpr = self._alloc_wsr(
                                bar_key)
                            dict_list[self.sync_defs[
                                bar_key]["sgprs"]] = bar_key_sgpr
                            dict_list[self.sync_defs[
                                bar_key]["pingpong"]] = (
                                    len(dict_list[bar_key]) > 1)
                    
                max_value = (aloop[1]-1) * aloop[3]
                max_value_sgpr = None
                if (max_value >= 64) and (loop_iter_sgpr is not None):
                    max_value_sgpr = self._alloc_wsr(
                        aloop[0] + "_" + str(max_value))

                loop_config.append([aloop[0], max_value, aloop[2],
                                    aloop[3], loop_iter_sgpr, dict_list,
                                    max_value_sgpr])
                if enable_subloop:
                    self.sub_loopconfig.append([aloop[0], 0, 1,
                                    aloop[3], loop_iter_sgpr, dict_list,
                                    max_value_sgpr])

                if dict_list is not None:
                    for subloop in self.loop_defs:
                        if subloop in dict_list.keys():
                            enable_subloop = True

            self.sync_defs["bar_pass"]["channels"] = 32 \
                if self.afterdwc else 17

            self.loop_config_refined = loop_config

    def _init_variables(self):
        self.z_offset = self._alloc_wsr("z_offset_euid")
        self.sshl.generate(
            self.flow_man.get_indent(),
            dst=self.z_offset, 
            src1=self.cwarp_top.euid_reg, 
            src2=1, comment="// Initialize z offset with eu id")
        self.base_reg = self._alloc_addr_reg(type="itlr")

        if self.merge_reduce:
            self.op_wred.init_gen(
                self.flow_man.get_indent())

        if self.loop_config_refined is not None:
            for iloop in self.loop_config_refined:
                if iloop[6] is not None:
                    self.smov.generate(
                        indent_level=self.flow_man.get_indent(),
                        dst=iloop[6],
                        src1=iloop[1],
                        comment="// Move out of range imm to a sgpr")

            for iloop in self.loop_config_refined:
                if iloop[5] is not None:
                    bar_dics = iloop[5]
                    for bar_key in self.sync_defs.keys():
                        if bar_key in bar_dics.keys():
                            self.smov.generate(
                                indent_level=self.flow_man.get_indent(),
                                dst=bar_dics[self.sync_defs[
                                    bar_key]["sgprs"]],
                                src1=bar_dics[bar_key][0],
                                comment="// Init bar pairs with id")

                    for akey in self.slot_keys:
                        if akey in bar_dics.keys():
                            ping_val = bar_dics[akey][0]
                            pong_val, slot_flip = None, None
                            slot_start = self._alloc_wsr(akey)
                            if len(bar_dics[akey]) > 1:
                                pong_val = bar_dics[akey][1]
                                slot_flip = self._alloc_wsr(
                                    akey + "_flip")

                            self.slot_info[akey] = [slot_start, slot_flip,
                                                    ping_val, pong_val]
                            self.smov.generate(
                                self.flow_man.get_indent(),
                                dst=slot_start,
                                src1=ping_val,
                                comment="// Init source register")
                            if slot_flip is not None:
                                self.smov.generate(
                                    self.flow_man.get_indent(),
                                    dst=slot_flip,
                                    src1=pong_val,
                                    comment="// Init flipping register")

    def _insert_bars(self, aloop, barmode, flip_if_must, slot_type):
        if aloop is not None:
            bar_dics = aloop[5]
            if bar_dics is not None:
                for bar_key in self.sync_defs.keys():
                    if bar_key in bar_dics.keys() and \
                           (slot_type in bar_dics.keys() or (
                               not self.merge_reduce)):
                        mode = self.sync_defs[bar_key]["mode"]
                        if mode in self.bar_defs[barmode]:
                            if mode == "csm":

                                self.flow_man.start_if_loop(
                                    asource=bar_dics[self.sync_defs[
                                        bar_key]["sgprs"]],
                                    bsource=str(bar_dics[bar_key][0]),
                                    relation="==", hasElse=1)

                                self.bar.generate(
                                    self.flow_man.get_indent(),
                                    scope=self.sync_defs[bar_key]["scope"],
                                    mode=mode,
                                    src1=bar_dics[bar_key][0],
                                    src2=self.sync_defs[bar_key]["channels"],
                                    comment="// Wait signal from upperstream conv")

                                self.flow_man.start_else_loop()

                                self.bar.generate(
                                    self.flow_man.get_indent(),
                                    scope=self.sync_defs[bar_key]["scope"],
                                    mode=mode,
                                    src1=bar_dics[bar_key][0] ^ 1,
                                    src2=self.sync_defs[bar_key]["channels"],
                                    comment="// Wait signal from upperstream conv")

                                self.flow_man.close_if_loop()

                            else:
                                self.bar.generate(
                                    self.flow_man.get_indent(),
                                    scope=self.sync_defs[bar_key]["scope"],
                                    mode=mode,
                                    src1=bar_dics[self.sync_defs[
                                        bar_key]["sgprs"]],
                                    src2=self.sync_defs[bar_key]["channels"],
                                    comment=self.sync_defs[bar_key][
                                        "comment"][barmode])

                        if flip_if_must:
                            if bar_dics[self.sync_defs[bar_key]["pingpong"]]:
                                bar_sgpr = bar_dics[self.sync_defs[
                                    bar_key]["sgprs"]]
                                self.sxor.generate(
                                    self.flow_man.get_indent(),
                                    dst=bar_sgpr,
                                    src1=bar_sgpr,
                                    src2=1,
                                    comment="// Toggle bar id for pingpong")
                                
    def _gen_subloop_ext(self, subloopconfig, active_boundary):
        self._generate_loop_header(loop_config=subloopconfig)
        self._generate_loop_body(active_boundary)
        self._generate_loop_tailer(loop_config=subloopconfig)

    def _generate_loop_header(self, level=None, loop_config=None):
        target_loop_config = self.loop_config_refined
        if loop_config is not None:
            target_loop_config = loop_config

        if target_loop_config is not None:
            if loop_config is None:
                self._init_variables()
            
            for iloop in target_loop_config:
                start_value, prolog= "", None

                if iloop[5] is not None:
                    if "start" in iloop[5].keys():
                        start_value = iloop[5]["start"]
                    if "prolog" in iloop[5].keys():
                        prolog = iloop[5]["prolog"]

                iters, inc, reg, max_value = (
                    iloop[1], iloop[3], iloop[4], iloop[6])
                # skip one iters to improve performance
                if iters >= inc:
                    iters = iters if max_value is None else max_value
                    self.flow_man.for_loop_start(
                        start_value=start_value,
                        max_value=iters, inc=inc, reg=reg,
                        comment="// Do loop {}".format(iloop[0]))

                if (iloop[5] is not None) and (
                        "tlr_pingpong" in iloop[5].keys()):
                    if loop_config is None:
                        if self.base_reg is not None:
                            self.smovs.generate(
                                self.flow_man.get_indent(),
                                dst=self.base_reg,
                                src1=self.slot_info["tlr_pingpong"][0],
                                comment="// Initialize base address")

                    if self.slot_info["tlr_pingpong"][1] is not None:
                        self.smov.generate(
                            self.flow_man.get_indent(),
                            dst=self.slot_info["tlr_pingpong"][0],
                            src1=self.slot_info["tlr_pingpong"][1],
                            comment="// Initial slot register")

                        self.sxor.generate(
                            self.flow_man.get_indent(),
                            dst=self.slot_info["tlr_pingpong"][1],
                            src1=self.slot_info["tlr_pingpong"][1],
                            src2=self.slot_info["tlr_pingpong"][3],
                            comment="// Flip slot register")

                if prolog is not None:
                    self._gen_subloop_ext(self.sub_loopconfig, prolog)

                self._insert_bars(
                    iloop, barmode="consume",
                    flip_if_must=False,
                    slot_type="tlr_pingpong")

                if (level is not None) and (isinstance(level, str)):
                    if level == iloop[0]:
                        break

    def _generate_loop_tailer(self, level=None, loop_config=None):
        target_loop_config = self.loop_config_refined
        if loop_config is not None:
            target_loop_config = loop_config
        if target_loop_config is not None:
            for iloop in reversed(target_loop_config):
                if (iloop[5] is not None) and (
                        "grb_pingpong" in iloop[5].keys()):

                    if self.slot_info["grb_pingpong"][1] is not None:
                        self.smov.generate(
                            self.flow_man.get_indent(),
                            dst=self.slot_info["grb_pingpong"][0],
                            src1=self.slot_info["grb_pingpong"][1],
                            comment="// Initial slot register")

                        self.sxor.generate(
                            self.flow_man.get_indent(),
                            dst=self.slot_info["grb_pingpong"][1],
                            src1=self.slot_info["grb_pingpong"][1],
                            src2=self.slot_info["grb_pingpong"][3],
                            comment="// Flip slot register")

                    if self.merge_reduce:
                        self._insert_bars(
                            iloop, barmode="consume",
                            flip_if_must=False,
                            slot_type="grb_pingpong")
                        self.op_wred.core_gen(
                            self.flow_man.get_indent(),
                            self.wred_usharpid,
                            self.z_offset,
                            self.slot_info["grb_pingpong"][0],
                            self.outer_z,
                            self.inner_z, 
                            (self.w if self.micro_batch_mode else None),
                            self.wred_channelnum, 
                            self.spc_num)
                        self._insert_bars(
                            iloop, barmode="produce",
                            flip_if_must=True,
                            slot_type="grb_pingpong")

                self._insert_bars(
                    iloop, barmode="produce",
                    flip_if_must=True,
                    slot_type="tlr_pingpong")

                epilog = None
                if iloop[5] is not None:
                    if "epilog" in iloop[5].keys():
                        epilog = iloop[5]["epilog"]
                if epilog is not None:
                    self._gen_subloop_ext(self.sub_loopconfig, epilog)

                iters, inc = (iloop[1], iloop[3])
                if iters >= inc:
                    self.flow_man.for_loop_close()

                if (level is not None) and (isinstance(level, str)):
                    if level == iloop[0]:
                        break
    
    @abstractmethod
    def _generate_loop_body(self, epilog):
        pass
