#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
from abc import abstractmethod
from code_generator.share.br_top import top

import code_generator.share.br_const_defs as defs
import code_generator.share.br_vector_instructions_def as vop
import code_generator.share.br_resource_manager as res_man

import code_generator.vector.common.constDefs as constDefs
import code_generator.vector.common.flowLib as fhandler
from code_generator.vector.br_vector_manager import vector_top
from code_generator.vector.br_flow_manager import flow_man
import code_generator.vector.br_vector_ops as ops

layer_prefix = ["layer_{}_warp_{}_main_kernel", "warp_{}_main_kernel"]


class vector(top):

    def __init__(self):
        super().__init__()

        self.cwarp_num_max = constDefs.CWARP_NUMBER
        self.spc_num = defs.BR_SPC_NUMBER

        self.flow_handler = fhandler.get_flow_handler()
        self.flow_man = flow_man()
        self.resource_man = res_man.resource_man()
        self.vector_top = vector_top()
        self.layer_id = None
        self.layer_num = None
        self.warp_id = None
        self.layer_info = None
        self.core_func = None

        self.OUTER_OC = defs.OC_ROOT_VECTOR_LOOP_NAME
        self.SAMPLE = defs.SAMPLE_LOOP_NAME
        self.ROW = defs.ROW_LOOP_NAME
        self.OUTER_COL = defs.OUTER_COL_LOOP_NAME
        self.COL = defs.COL_LOOP_NAME
        self.INNER_OC = defs.INNER_OC_LOOP_NAME

        self.opname = "vector"

        # vector operators
        self.smov = vop.smov()
        self.smovs = vop.smovs()
        self.movi = vop.movi()
        self.bar = vop.bar()
        self.wred = vop.wred()
        self.smovg = vop.smovg()
        self.saddg = vop.saddg()
        self.sxor = vop.sxor()
        self.sadd = vop.sadd()
        self.sadda = vop.sadda()
        self.adds = vop.adds()
        self.sand = vop.sand()
        self.jump = vop.jump()
        self.fll1 = vop.fll1()
        self.ackgmb = vop.ackgmb()
        self.stm = vop.stm()
        self.fmul = vop.fmul()
        self.fmad = vop.fmad()
        self.fadd = vop.fadd()
        self.fmax = vop.fmax()
        self.sysid = vop.sysid()
        self.mov = vop.mov()
        self.ldm = vop.ldm()
        self.sshl = vop.sshl()
        self.nop = vop.nop()
        self.op_wred = ops.wreduce_op()
        self.op_mask = ops.oob_mask()
        self.sld_loader = ops.scalar_loader()
        self.sldm_loader = ops.scalar_loader_vgpr()
        self.activation_loader = ops.activation_loader()

        # sharp list
        self.ushape_0 = None
        self.ushape_1 = None
        self.ushape_2 = None
        self.ushape_3 = None
        self.ushape_4 = None
        self.ushape_5 = None

        # options
        self.options = None
        self.force_ackgmb = False
        self.sync_layer = False
        self.init_tcore_producer = True
        self.init_reduce_producer = True

        # wsr management
        self.allocated_wsrs = [] 

    def generate(self, dryrun=None):
        if dryrun is not None:
            self.flow_man.local_wsr_used = 0
            self.flow_man.peek_wsr_used = 0
            super()._set_dry_run(dryrun)

        self._pre_process()
        self._core_process()
        self._post_process()

        if dryrun is not None:
            super()._set_dry_run(False)

    def _get_indent(self):
        return self.flow_man.get_indent()

    def _get_layer_label(self, nextlayer=False):
        if self.layer_id is not None:
            layer_id = (self.layer_id + 1) if nextlayer else self.layer_id
            layer_label = layer_prefix[0].format(
                str(layer_id), str(self.warp_id))
        else:
            layer_label = layer_prefix[1].format(str(self.warp_id))
        return layer_label

    def _check_input(self):
        if (self.flow_handler is None) or (self.warp_id is None):
            assert False, "internal error as operation inputs are all none!"

    def _pre_process(self):
        self._check_input()
        self.flow_handler.saveState()
        self.flow_man.reset_status()
        self.vector_top.start_warp(
            self.warp_id, self.init_tcore_producer, self.init_reduce_producer)
        self.flow_man.set_label_suffix(self._get_layer_label())

    @abstractmethod
    def _core_process(self):
        pass

    def _post_process(self):
        self._free_resource()
        self.flow_handler.restoreState()
        self.vector_top.end_warp()

    def _jump_to_next(self, indent):
        if self.force_ackgmb:
            self.ackgmb.generate(
                indent, comment="// Ensure the kernel done")
        if self.sync_layer:
            self.bar.generate(
                indent,
                scope="wtg", mode="pass",
                src1=defs.INTER_LAYER_BARRIER_BTWEEN_BUFB_AND_VECTOR,
                src2=17,
                comment="// Signal pass to start next kernel")

    def _free_resource(self):
        self._free_wsr()

    def _alloc_wsr(self, alias):
        awsr = self.resource_man.alloc_wsr(alias)
        self.allocated_wsrs.append(awsr)
        return awsr

    def _alloc_wsr_imm(self, alias, value):
        awsr = self.resource_man.allocate_immediate_variable(alias, value)
        self.allocated_wsrs.append(awsr)
        return awsr

    def _get_wsr_imm_value(self, alias):
        v = self.resource_man.get_immediate_variable_value(alias)
        return v


    def _alloc_wsr_more(self, num):
        index = self.resource_man.alloc_wsr_more(num)
        for i in range(num):
            self.allocated_wsrs.append(('q'+str(index+i)))
        return index

    def _free_wsr(self, wsr=None):
        if wsr is not None:
            self.resource_man.free_wsr(wsr)
        else:
            for awsr in self.allocated_wsrs:
                self.resource_man.free_wsr(awsr)
            self.allocated_wsrs = []
            self.op_wred.free_wsr()

    def _alloc_addr_reg(self, type, alias=None):
        addr = self.resource_man.alloc_addr(type, alias)
        return addr

    def _free_addr_reg(self, addr):
        pass
