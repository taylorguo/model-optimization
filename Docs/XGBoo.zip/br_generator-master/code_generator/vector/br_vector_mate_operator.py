#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
from code_generator.vector.br_vector_standalone_operator import standalone_operator
import code_generator.vector.common.hwCaps as hwCaps
import code_generator.vector.common.funcLib as funcLib
import code_generator.vector.common.kernelLib as kernelLib


VECTOR_BUFFER_BLOCK_MODE = 0
VECTOR_BUFFER_SURFACE_MODE = 1
VECTOR_BUFFER_ROW_MODE = 2
VECTOR_BUFFER_COL_MODE = 3
VECTOR_BUFFER_ROW_MODE_THRESHOLD_X = 8
VECTOR_BUFFER_ROW_MODE_THRESHOLD_Y = 3
VECTOR_BUFFER_DEFAULT_NUMBER = 3

VECTOR_STRIDE_ENABLE_MASK = 1
VECTOR_STRIDE_GROUP_FLAG_X_MASK = 2
VECTOR_STRIDE_GROUP_FLAG_Y_MASK = 4

VECTOR_PARTICIPATING_EU_NUM = 16


# Include common part of dwc and pooling operators
class mate_operator(standalone_operator):

    def __init__(
            self, src_sample, src_channel,
            src_height, src_width, vgpr_range=None,
            dst_sample=None, dst_channel=None,
            dst_height=None, dst_width=None, 
            bn_fused=False, reduce_fused=False):
        super().__init__(
            src_sample=src_sample, src_channel=src_channel, src_height=src_height,
            src_width=src_width, vgpr_range=vgpr_range)

        self.bn_fused = bn_fused
        self.reduce_fused = reduce_fused
        self.usharpid_input_4d_activation = usharp_0[0]
        self.usharpid_gamma_beta_sum_ssum = usharp_1[0]
        self.usharpid_output_4d_activation = usharp_2[0]


    def _gen_main_kernel(self):
        self.smovs.generate(
            indent_level=self._get_indent(),
            dst="up0",
            src1=str(self.vgpr_index_end-1),
            comment="// Set relatvie address upper bound, should be close-open")
        self.smovs.generate(
            indent_level=self._get_indent(),
            dst="sz0",
            src1=self.vgpr_step_back,
            comment="// Set relative address range")

        if self.bn_fused:
            self._init_bn_bar_kernel()

        self._gen_euid_kernel()

        if self.reduce_fused:
            self.smov.generate(
                indent_level=self._get_indent(),
                dst=self.reduce_slot_sgpr,
                src1=0,
                comment="// Initial reduce slot sgpr")
        if self.instruction_name == "dwc":
            self.smov.generate(
                indent_level=self._get_indent(),
                dst=self.const_base_sgpr,
                src1=0,
                comment="// Initial csr base sgpr")

            self.smov.generate(   
                indent_level=self._get_indent(),
                dst=self.weight_address_sgpr,
                src1=0,
                comment="// Initialize weight address sgpr")
        
        self._init_common_vgpr_bases()
        self._process_channel_loop(self)

    def _process_channel_loop(self):
        self._gen_channel_loop_header()

        if self.instruction_name == "dwc" or self.bn_fused:
            self._load_kernel_parameters()

        self.smov.generate(
            indent_level=self._get_indent(),
            dst=self.w_axis_sgpr,
            src1=0,
            comment="// Initialize w axis")

        if self.src_sample > 1:
            self.flow_man.for_loop_start(
                "", str(self.src_sample-1), str(1), 
                self.w_axis_sgpr,
                comment="// Loop sample axis")

        self._do_y_initialize()
        has_z_preprocessed = False
        for y_span in self.y_span_list:     
            y_span_height = y_span["SpanHeight"]
            y_block_height = y_span["BlockHeight"]
            y_border_flag = y_span["BorderFlag"]

            block_number_y = int(y_space_height / y_block_height)
            block_number_x = int(self.x_align_size / self.block_size_x)

            if block_number_y > 1:
                y_sgpr = self._alloc_wsr("y_loop_sgpr")
                self.flow_man.for_loop_start(str(0), str(block_number_y-1), str(1), 
                    y_sgpr, comment="// Loop height/y axis")

            loop_num_in_x = (x_block_num - 3) >> 1
            if loop_num_in_x < 0:
                loop_num_in_x = 0
            x_block_remain_num = x_block_num - (loop_num_in_x << 1)

            self._do_x_initialize()

            self._create_subfunc_call(
                "load", y_border_flag, y_block_height,
                "1", str(1 if x_block_num == 1 else 0))

            if block_number_x > 1:
                self._create_subfunc_call(
                    "load", y_border_flag, y_block_height,
                    "2", str(1 if x_block_num == 2 else 0))

            self.nop.generate(
                indent_level=self._get_indent(),
                modifier="sc1",
                comment="// Wait for sync channel 1")

            if (not has_z_preprocessed) and ((self.instruction_name == "dwc") \
                    or (self.bn_fused)):
                self._do_z_preprocess()

            if self.bn_fused:
                self._do_y_preprocess(y_border_flag, y_block_height)

            if loop_num_in_x > 1:
                x_sgpr = self._alloc_wsr("x_loop_sgpr")
                self.flow_man.for_loop_start(
                    str(0), str(loop_num_in_x-1), str(1), 
                    x_sgpr, 
                    comment="// Loop width axis")

            if loop_num_in_x > 0:
                if not self.ENABLE_MACRO:
                    self._create_subfunc_call(
                        "alu", y_border_flag, y_block_height, "", 0)
                    self._create_subfunc_call(
                        "load", y_border_flag, y_block_height, "1", 0)
                else:
                    self._create_macro_call(
                        "alu", y_border_flag, y_block_height, "", 0)
                    self._create_macro_call(
                        "load", y_border_flag, y_block_height, "1", 0)  

                self.nop.generate(
                    indent_level=self._get_indent(),
                    modifier="sc2",
                    comment="// Wait for sync channel 2")

                if not self.ENABLE_MACRO:
                    self._create_subfunc_call(
                        "alu", y_border_flag, y_block_height, "", 0)
                    self._create_subfunc_call(
                        "load", y_border_flag, y_block_height, "2", 0)
                else:
                    self._create_macro_call(
                        "alu", y_border_flag, y_block_height, "", 0)
                    self._create_macro_call(
                        "load", y_border_flag, y_block_height, "2", 0)                                 

                self.nop.generate(
                    indent_level=self._get_indent(),
                    modifier="sc1",
                    comment="// Wait for sync channel 1")

                if loop_num_in_x > 1:
                    self.flow_man.for_loop_close()
                    self._free_wsr(x_sgpr)

                if not self.ENABLE_MACRO:
                    self._create_subfunc_call(
                        "alu", y_border_flag, y_block_height, "", 
                        str(1 if x_block_num == 1 else 0))
                else:
                    self._create_macro_call(
                        "alu", y_border_flag, y_block_height, "", 
                        str(1 if x_block_num == 1 else 0))

                if x_block_remain_num >= 3:
                    if not self.ENABLE_MACRO:
                        self._create_subfunc_call(
                            "load", y_border_flag, y_block_height, 
                            "1", str(1 if x_block_remain_num == 3 else 0))
                    else:
                        self._create_macro_call(
                            "load", y_border_flag, y_block_height, 
                            "1", str(1 if x_block_remain_num == 3 else 0))

                if x_block_num > 1:
                    self.nop.generate(
                        indent_level=self._get_indent(),
                        modifier="sc2",
                        comment="// Wait for sync channel 2")
                    if not self.ENABLE_MACRO:
                        self._create_subfunc_call(
                            "alu", y_border_flag, y_block_height,
                            "", str(1 if x_block_num == 2 else 0))
                    else:
                        self._create_macro_call(
                        "alu", y_border_flag, y_block_height,
                        "", str(1 if x_block_num == 2 else 0))                  
                
                    if x_block_remain_num >= 4:
                        if not self.ENABLE_MACRO:
                            self._create_subfunc_call(
                                "load", y_border_flag, y_block_height, 
                                "2", str(1))
                        else:
                            self._create_macro_call(
                            "load", y_border_flag, y_block_height, 
                            "2", str(1))

                    if x_block_remain_num >= 3:
                        self.nop.generate(
                            indent_level=self._get_indent(),
                            modifier="sc1",
                            comment="// Wait for sync channel 1")
                        if not self.ENABLE_MACRO:
                            self._create_subfunc_call(
                                "alu", y_border_flag, y_block_height, 
                                "", str(1 if x_block_num == 3 else 0))
                        else:
                            self._create_macro_call(
                                "alu", y_border_flag, y_block_height, 
                                "", str(1 if x_block_num == 3 else 0))

                    if x_block_remain_num >= 4:
                        self.nop.generate(
                            indent_level=self._get_indent(),
                            modifier="sc2",
                            comment="// Wait for sync channel 2")
                        if not self.ENABLE_MACRO:
                            self._create_subfunc_call(
                                "alu", y_border_flag, y_block_height, 
                                "", str(1))
                        else:
                            self._create_macro_call(
                                "alu", y_border_flag, y_block_height, 
                                "", str(1))

                if (y_border_flag & self.BORDER_TYPE_BOTTOM) == 0:
                    self.sadd.generate(
                        indent_level=self._get_indent(),
                        dst=self.load_in_y_axis_sgpr,
                        src1=self.load_in_y_axis_sgpr,
                        src2=y_block_height*self.TILE_SIZE_Y,
                        comment="// Adjust load y")
                    self.sadd.generate(
                        indent_level=self._get_indent(),
                        dst=self.alu_in_y_axis_sgpr,
                        src1=self.alu_in_y_axis_sgpr,
                        src2=y_block_height*self.TILE_SIZE_Y,
                        comment="// Adjust alu y")

            if y_block_num > 1 and y_block_num > self.HEIGHT_LOOP_UNROLL_THRESHOLD:
                self._alloc_wsr("y_loop_sgpr")
                self.flow_man.for_loop_close()

        if self.src_sample > 1:
            self.flow_man.for_loop_close()

        self._gen_channel_loop_tailer()

    def _create_all_subfuncs(self):
        func_def_map = self.fun_gen_handler.getFuncDef()
        for x, y in func_def_map.items():
            func_keys = x.split("_")
            self.flow_man.start_function_def(x, False)
            self.flow_man.set_label_index(0)
            self.flow_man.set_label_suffix(x.upper())
            self.flow_man.set_temp_start(y[0])
            self.flow_man.set_stack_start(y[1])

            func_type = func_keys[5]
            y_border_type = int(func_keys[6])
            y_block_height = int(func_keys[7])
            if func_type == self.FUNC_TYPE_LOAD:
                sync_index = int(func_keys[8])
                right_border_mode = int(func_keys[9])
            else:
                sync_index = 0
                right_border_mode = int(func_keys[8])
            self._create_single_subfunc(
                func_type, y_border_type, y_block_height,
                right_border_mode, sync_index)

            self.flow_man.close_function_def(x, False)

    def _create_single_subfunc(
            self, func_type, y_border_type, 
            y_block_height, right_border_mode, sync_index):
        if func_type == self.FUNC_TYPE_LOAD:
            x_axis_sgpr = self.load_in_x_axis_sgpr
            y_axis_sgpr = self.load_in_y_axis_sgpr
            vgpr_base_sgpr = self.vgpr_load_base_sgpr
            loop_unroll_threshold = self.DWC_LOAD_LOOP_UNROLL_THRESHOLD
        else:
            x_axis_sgpr = self.alu_in_x_axis_sgpr
            y_axis_sgpr = self.alu_in_y_axis_sgpr
            vgpr_base_sgpr = self.vgpr_alu_base_sgpr  
            loop_unroll_threshold = self.DWC_ALU_LOOP_UNROLL_THRESHOLD
        
        if self.filter_stride != 0:
            stride2_flag = VECTOR_STRIDE_ENABLE_MASK
        else:
            stride2_flag = 0

        block_border_type = y_border_type
        if right_border_mode != 0:
            block_border_type |= self.BORDER_TYPE_RIGHT

        self.smovs.generate(
            indent_level=self._get_indent(),
            dst=self.vgpr_base,
            src1=vgpr_base_sgpr,
            comment="// Restore the vgpr base address")

        if self.buffer_mode == VECTOR_BUFFER_SURFACE_MODE or \
                self.buffer_mode == VECTOR_BUFFER_COL_MODE:
            assert y_border_type & self.BORDER_TYPE_TOP, "Surface has all 4 borders"
            assert y_border_type & self.BORDER_TYPE_BOTTOM, "Surface has all 4 borders"

        if self.buffer_mode == VECTOR_BUFFER_SURFACE_MODE or \
                self.buffer_mode == VECTOR_BUFFER_COL_MODE:
                loop_row_start = 0
        elif self.buffer_mode != VECTOR_BUFFER_ROW_MODE and \
                ((y_border_type & self.BORDER_TYPE_TOP ) == 0):
            if func_type == self.FUNC_TYPE_LOAD:
                loop_row_start = 0
            else:
                loop_row_start = 1
        else:
            loop_row_start =1

        loop_row_size = y_block_height

        if func_type == self.FUNC_TYPE_LOAD:
            if self.buffer_mode != VECTOR_BUFFER_ROW_MODE:
                if y_border_type & self.BORDER_TYPE_TOP == 0:
                    loop_row_size += 1
                if not self.single_tile_row_mode:
                    loop_row_size += 1
        else:
            if y_border_type & self.BORDER_TYPE_BOTTOM:
                if not self.single_tile_row_mode:
                    loop_row_size += 1
        
        if self.partial_block_width == self.block_size_x:
            x_aligned = 1
        else:
            x_aligned = 0

        if func_type == self.FUNC_TYPE_LOAD:
            is_left_border_check = 0
        else:
            is_left_border_check = x_aligned

        is_left_border_check = 0
        loop_col_number = -1
        is_handle_left_border = 0

        if self.buffer_mode == VECTOR_BUFFER_SURFACE_MODE \
                or self.buffer_mode == VECTOR_BUFFER_ROW_MODE:
            if (self.block_size_x - 2) < loop_unroll_threshold:
                loop_mode = 0
            else:
                loop_mode = 1
        
            if func_type == self.FUNC_TYPE_LOAD:
                loop_col_number = self.block_size_x 
            else:
                loop_col_number = self.block_size_x - 1

                if self.block_size_x != 1:
                    is_handle_left_border = 1

                is_left_border_check = 0
        else:
            if right_border_mode == 2:
                loop_mode = 2
            else:
                loop_mode = 3

            if right_border_mode == 0:
                loop_col_number = self.block_size_x
            else:
                loop_col_number = self.partial_block_width

        if loop_mode == 3:
            loop_sgpr_number = 1
        else:
            loop_sgpr_number = 2

        if loop_mode != 0:
            x_index_sgpr = self._allocate_wsr("x_control_index")
            if loop_mode == 2:
                assert False, "Disabled mode"

            self.smov.generate(
                indent_level=self._get_indent(),
                dst=x_index_sgpr,
                src1=is_handle_left_border,
                comment="// Set loop start, 0 or 1 to check left border is handled separately")

        if self.buffer_mode == VECTOR_BUFFER_SURFACE_MODE or \
                self.buffer_mode == VECTOR_BUFFER_ROW_MODE:
            loop_col_start = 0
        else:
            if func_type == self.FUNC_TYPE_LOAD:
                loop_col_start = 2
            else:
                loop_col_start = 1
        
        if is_left_border_check or is_handle_left_border:
            assert False, " "

        self.flow_man.start_if_loop(
            vgpr_base_sgpr, 
            str(self.vgpr_index_end-loop_col_num*self.vgpr_stride),
            ">=", 0, local_label=self.ENABLE_MACRO, local_label_value=0)
        self.smov.generate(
            indent_level=self._get_indent(),
            dst=vgpr_base_sgpr,
            src1=self.vgpr_start,
            comment="// Check vgpr base, wrap back if exceeding the range")

        self.flow_man.close_if_loop(local_label=self.ENABLE_MACRO, local_label_value=0)

        self.smovs.generate(
            indent_level=self._get_indent(),
            dst=self.vgpr_base,
            src1=vgpr_base_sgpr,
            comment="// Restore the vgpr base address")
        
        if loop_mode != 0:
            temp_x_index_sgpr = self._alloc_wsr("temp_x_index")
            self.smov.generate(
                indent_level=self._get_indent(),
                dst=temp_x_index_sgpr,
                src1=0,
                comment="// Set loop start from 0")
            if loop_col_num > 1:
                self.flow_man.for_loop_start(
                    "", str(loop_col_num-1), "1", temp_x_index_sgpr,
                    comment="// Loop in x direction")
            loop_unroll_num = 1
        else:
            loop_unroll_num = loop_col_num

        coord_sgpr_list = [
            x_axis_sgpr, y_axis_sgpr, 
            self.z_axis_sgpr, self.w_axis_sgpr]
        loop_row_size = y_block_height
        if y_border_type & self.BORDER_TYPE_BOTTOM:
            loop_row_size +=1
        x_inc = 0
        for ele in range(loop_unroll_num):
            if func_type == self.FUNC_TYPE_LOAD:
                self.activation_loader.generate(
                    indent_obj=self._get_indent(),
                    mem_format=hwCaps.SurfaceFormatFP16(),
                    gpr_format=hwCaps.SurfaceFormatFP16(),
                    coord_sgpr_list=coord_sgpr_list,
                    vgpr_address=-(ele*self.vgpr_stride + 1),
                    vgpr_num=loop_row_size,
                    sync_id=sync_index,
                    usharp_id=self.usharpid_input_4d_activation,
                    x_inc=x_inc)
            else:
                self._do_core_alu_on_col(ele*self.vgpr_stride, loop_row_size, coord_sgpr_list, y_border_type, x_inc=x_inc)
            x_inc += hwCaps.TileSizeX()

        self.sadd.generate(
            indent_level=self._get_indent(),
            dst=coord_sgpr_list[0],
            src1=coord_sgpr_list[0],
            src2=str(x_inc),
            comment="// Move to next func call col start ")

        if loop_mode != 0:
            self.sadda.generate(
                indent_level=self._get_indent(),
                dst=self.vgpr_base,
                src1=self.vgpr_base,
                src2=self.vgpr_stride,
                comment="// Increase vgpr base address")
            self.sadd.generate(
                indent_level=self._get_indent(),
                dst=vgpr_base_sgpr,
                src1=vgpr_base_sgpr,
                src2=self.vgpr_stride,
                comment="// Save vgpr base address to sgpr")
            if loop_col_num > 1:
                self.flow_man.for_loop_close()
            right_border_shift = 0
        else:
            right_border_shift = loop_unroll_num #0 if loop_unroll_num > 1 else loop_unroll_num

        if func_type != self.FUNC_TYPE_LOAD and \
            right_border_mode != 0 and \
            self.image_width_res != 0:
            right_border_type = self.BORDER_TYPE_RIGHT | y_border_type
            self._do_core_alu_on_col(
                right_border_shift*self.vgpr_stride, loop_row_size, 
                coord_sgpr_list, right_border_type)

        if loop_mode == 0:
            x_advance_step = 0
        else:
            x_advance_step = loop_col_num

        x_advance_step = self.block_size_x - x_advance_step
        vgpr_base_shift = self.vgpr_stride * x_advance_step

        if vgpr_base_shift != 0:
            self.sadd.generate(
                indent_level=self._get_indent(),
                dst=vgpr_base_sgpr,
                src1=vgpr_base_sgpr,
                src2=str(vgpr_base_shift),
                comment="// Adjust vgpr base, most time no need")

        if loop_mode != 0:
            self.resource_man.free_wsr(temp_x_index_sgpr)    

    def _do_y_preprocess(self, y_border_flag, vgpr_number):
        if self.buffer_mode == VECTOR_BUFFER_SURFACE_MODE \
            or self.buffer_mode == VECTOR_BUFFER_ROW_MODE:
            bn_vgpr_address = 0
        else:
            bn_vgpr_address = self.vgpr_stride

        is_last_row_partial = False
        bn_vgpr_number += 1

        if self.buffer_mode == VECTOR_BUFFER_SURFACE_MODE \
            or self.buffer_mode == VECTOR_BUFFER_COL_MODE:
            pass
        else:
            if (y_border_flag & self.BORDER_TYPE_TOP) == 0:
                bn_vgpr_number += 1
            else:
                bn_vgpr_address += 1
        if self.image_height_res != 0:
            if self.buffer_mode == VECTOR_BUFFER_SURFACE_MODE \
                or self.buffer_mode == VECTOR_BUFFER_COL_MODE:
                is_last_row_partial = True
            else:
                if y_border_flag & self.BORDER_TYPE_BOTTOM != 0:
                    is_last_row_partial = True
        
        if is_last_row_partial:
            # last row needs special handling
            bn_vgpr_number -= 1

        self.smovs.generate(
            indent_level=self._get_indent(),
            dst=self.vgpr_base,
            src1=self.vgpr_alu_base_sgpr,
            comment="// Initial vgpr base address with alu base vgpr")

        self.bn_core._do_alu_tile_v(
            bn_vgpr_address, bn_vgpr_number, True, "bn")

        if is_last_row_partial:
            self.bn_core._do_alu_tile_v(
                bn_vgpr_address + bn_vgpr_number, 1 , True, "bn")
    
    def _do_y_initialize(self):
        y_border_type = self.y_span_list[0][2]
        if (self.buffer_mode == VECTOR_BUFFER_BLOCK_MODE \
            or self.buffer_mode == VECTOR_BUFFER_ROW_MODE) \
            and (y_border_type & self.BORDER_TYPE_TOP) == 0:
            self.smov.generate(
                indent_level=self._get_indent(),
                dst=self.load_in_y_axis_sgpr,
                src1=-self.TILE_SIZE_Y,
                comment="// Initialize load's y coordinate")
        else:
            self.smov.generate(
                indent_level=self._get_indent(),
                dst=self.load_in_y_axis_sgpr,
                src1=0,
                comment="// Initialize load's y coordinate")
                
        self.smov.generate(
            indent_level=self._get_indent(),
            dst=self.alu_in_y_axis_sgpr,
            src1=0,
            comment="// Initialize alu's y coordinate")

        if self.buffer_mode == VECTOR_BUFFER_ROW_MODE:

            if (y_border_type & self.BORDER_TYPE_TOP):
                row_number = 1
                row_start = 1
            else:
                row_number = 2
                row_start = 0
            
            coord_sgpr_list = [x_axis_sgpr, y_axis_sgpr, 
                               self.z_axis_sgpr, self.w_axis_sgpr]
            x_inc = 0
            for ele in range(self.x_align_size):
                self.activation_loader.generate(
                    indent_obj=self._get_indent(),
                    mem_format=hwCaps.SurfaceFormatFP16(),
                    gpr_format=hwCaps.SurfaceFormatFP16(),
                    coord_sgpr_list=coord_sgpr_list,
                    vgpr_address=-(ele*self.vgpr_stride + 1),
                    vgpr_num=row_number,
                    sync_id=1,
                    usharp_id=self.usharpid_input_4d_activation,
                    x_inc=x_inc)
                x_inc += 8
                if ele != (self.x_align_size - 1):
                    self.sadd.generate(
                        indent_level=self._get_indent(),
                        dst=self.load_in_x_axis_sgpr,
                        src1=self.TILE_SIZE_X,
                        comment= "// Increase x' load address")
            
            if self.x_align_size != 1:
                self.smov.generate(
                    indent_level=self._get_indent(),
                    dst=self.load_in_x_axis_sgpr,
                    src1=0,
                    comment="// Rollback the x' load address")

            self.smov.generate(
                indent_level=self.load_in_y_axis_sgpr,
                src1=0,
                comment="// Initialize load's y coordiate")
        

    def _load_kernel_parameters(self):

        self.smov.generate(
            indent_level=self._get_indent(),
            dst=self.new_weight_sgpr,
            src1=1,
            comment="// Set a flag for lldw as requires all eus to sync")

        if self.instruction_name == "dwc":
            self.flow_man.start_if_loop(self.eu_id_sgpr, str(0), "==", 0)
            self.smovs.generate(
                indent_level=self._get_indent(),
                dst=self.const_base,
                src1=self.const_base_sgpr,
                comment="// Init base address to load dwc weight")
            kernelLib.lddw_load(
                hwCaps.SurfaceFormatFP16(), self.weight_address_sgpr, 
                -1, self.weight_number, 1, self.weight_usharpid, indentstring)
            self.flow_man.close_if_loop()
        
        if self.bn_fused:
            self._load_gamma_beta_sum_ssum()

    def _do_z_preprocess(self):
        self.flow_man.start_if_loop(self.params_flag_sgpr, str(0), "!=", 0)
        self.smov.generate(
            indent_level=self._get_indent(), 
            dst=self.params_flag_sgpr, src1=0,
            comment="// Turn off the flag to calculate batch norm params")

        self.bn_kernel._calculate_params_for_alu()

        if self.instruction_name == "dwc":
            self.bar.generate(
                indent=self._get_indent(), 
                scope="wtg", mode="sync",
                src1=str(bcd.BAR_CHANNELS_DWC_LDDW_BAR_ID),
                src2=VECTOR_PARTICIPATING_EU_NUM,
                comment="// All eu to participate")

        self.flow_man.close_if_loop()
        
    def _do_x_initialize(
            self, vgpr_stride, row_size, y_border_type):
        self.smov.generate(
            indent_level=self._get_indent(),
            dst=self.load_in_x_axis_sgpr,
            src1=0,
            comment="// Initialize load's x coordinate")
        self.smov.generate(
            indent_level=self._get_indent(),
            dst=self.alu_in_x_axis_sgpr,
            src1=0,
            comment="// Initialize alu's x coordinate")
        self.smovs.generate(
            indent_level=self._get_indent(),
            dst=self.vgpr_base,
            src1=self.vgpr_load_base_sgpr,
            comment="// Initial base address")

        loop_row_start = 1
        loop_row_size = row_size
        if (y_border_type & self.BORDER_TYPE_TOP) == 0:
            loop_row_start = 0
            loop_row_size += 1
        else:
            if self.buffer_mode == VECTOR_BUFFER_COL_MODE:
                loop_row_start = 0
            else:
                loop_row_start = 1
        loop_row_size += 1

        kernelLib.mov_imm_v(
            hwCaps.SurfaceFormatFP16(), -1 - loop_row_start, 
            loop_row_size, "0.0", "", indentstring)

        coord_sgpr_list = [x_axis_sgpr, y_axis_sgpr, 
                            self.z_axis_sgpr, self.w_axis_sgpr]
        kernelLib.load_4d_activation(
            hwCaps.SurfaceFormatFP16(), hwCaps.SurfaceFormatFP16(), 
            coord_sgpr_list, -1 - (vgpr_stride + loop_row_start), 
            loop_row_size, 1, self.usharpid_input_4d_activation, 
            indentstring, self.is_stride2_on)

        self.smov.generate(
            indent_level=self._get_indent(),
            dst=self.load_in_x_axis_sgpr,
            src1=str(self.TILE_SIZE_X),
            comment="// Following load start from {}".format(self.TILE_SIZE_X))


    def _calculate_available_vgprs(self):
        self.vgpr_number = self.vgpr_range[1] - self.vgpr_range[0]
        vgpr_start = self.vgpr_range[0]
        if self.bn_fused:
            bn_coeff_vgpr_numbder = 2
            self.bn_coeff_vgpr_addr = vgpr_start
            self.vgpr_number -= bn_coeff_vgpr_numbder
            vgpr_start += bn_coeff_vgpr_numbder

        vgpr_temp_number = hwCaps.MaxSTMGranule()
        if vgpr_temp_number < 8:
            # bn needs at least 6 vgprs stride2 needs
            # a full column to store temp result
            vgpr_temp_number = 8

        self.vgpr_temp_start = vgpr_start
        self.vgpr_number -= self.vgpr_temp_start
        vgpr_start += vgpr_temp_number
        if self.vgpr_number <= 0:
            assert False, "  Not enough vgprs to hold load data"

        self.vgpr_index_start = vgpr_start

    def _calculate_buffer_mode(self):
        self.buffer_mode = VECTOR_BUFFER_BLOCK_MODE
        self.buffer_number = VECTOR_BUFFER_DEFAULT_NUMBER
        self.surface_loop_size = 0
            self.buffer_mode = VECTOR_BUFFER_SURFACE_MODE
            self.buffer_number = int(self.vgpr_number / (self.tile_num_y*self.tile_num_x))
            if self.buffer_number >= (2*self.src_sample):
                self.surface_loop_size = self.src_sample
                self.buffer_number = int(self.buffer_number / self.surface_loop_size)
                if self.buffer_number > 3:
                    self.buffer_number = 3 if (self.tile_num_x+self.tile_num_y) > 2 else 1
            else:
                if self.buffer_number > self.src_sample:
                    self.buffer_number = self.src_sample
                    
                if self.buffer_number < 6:
                    self.surface_loop_size = 1
                    if self.buffer_number > 3:
                        self.buffer_number = 3
                else:
                    self.surface_loop_size = int(self.buffer_number / 3)
                    self.buffer_number = 3

        elif self.vgpr_number >= (self.tile_num_y * 3) \
            and (self.tile_num_x >= 3) and (self.is_stride2 or self.tile_num_y <= 16) :
            self.buffer_mode = VECTOR_BUFFER_COL_MODE
        elif self.tile_num_x <= VECTOR_BUFFER_ROW_MODE_THRESHOLD_X:
            self.buffer_mode = VECTOR_BUFFER_ROW_MODE
        else:
            self.buffer_mode = VECTOR_BUFFER_BLOCK_MODE

    def _calculate_block_size_from_vgpr(self):
        if self.buffer_mode != VECTOR_BUFFER_ROW_MODE:
            self.vgpr_number = int(self.vgpr_number / self.buffer_number)

        if self.buffer_mode != VECTOR_BUFFER_BLOCK_MODE:
            if self.buffer_mode == VECTOR_BUFFER_SURFACE_MODE:
                self.block_size_x = self.tile_num_x
                self.block_size_y = self.tile_num_y
                self.vgpr_stride = self.block_size_y
            elif self.buffer_mode == VECTOR_BUFFER_COL_MODE:
                self.block_size_y = self.tile_num_y
                self.vgpr_stride = self.block_size_y

                block_size_x_from_vgpr = int(self.vgpr_number/self.vgpr_stride)
                block_size_x_from_size = int((self.tile_num_x + self.buffer_number - 1) / self.buffer_number)

                if (block_size_x_from_size < block_size_x_from_vgpr):
                    self.block_size_x = block_size_x_from_size
                else:
                    self.block_size_x = block_size_x_from_vgpr
            else:
                self.block_size_x = self.tile_num_x
                block_size_y_from_vgpr = int(((int(self.vgpr_number / self.tile_num_x))-2) / self.buffer_number)
                block_size_y_from_size = int((self.tile_num_y + self.buffer_number - 1) / self.buffer_number)

                if block_size_y_from_size < block_size_y_from_vgpr:
                    self.block_size_y = block_size_y_from_size
                else:
                    self.block_size_y = block_size_y_from_vgpr

                if self.is_stride2 and self.block_size_y >= 16:
                    self.block_size_y = 16
                if self.block_size_y & 1:
                    self.block_size_y -= 1
                
                assert (self.block_size_y > 2), "Should not choose this mode!"

    def _calculate_surface_partition(self):
        if self.block_size_y == 0 or self.block_size_x:
            assert False, "Not enough vgprs, can't find a block that can fit " + str(self.vgpr_number) + " vgprs"
        self.y_top_flag = self.border_type &  self.BORDER_TYPE_TOP
        self.y_bottom_flag = self.border_type & (self.BORDER_TYPE_BOTTOM | self.BORDER_TYPE_BOTTOM_PARTIAL)

        y_aligned_size = int(self.tile_num_y / self.block_size_y)
        y_remainder_size = self.tile_num_y - y_aligned_size

        self.y_span_list = []
        if y_aligned_size != 0 and y_remainder_size <= 1:
            y_aligned_size -= self.block_size_y
            y_remainder_size += self.block_size_y

        if self.buffer_mode == VECTOR_BUFFER_ROW_MODE:
            if y_aligned_size > self.block_size_y:
                y_aligned_size -= self.block_size_y
                self.y_span_list.append({"SpanHeight": self.block_size_y, "BlockHeight": self.block_size_y, "BorderFlag": 0})
        
        if y_aligned_size != 0:
            self.y_span_list.append({"SpanHeight": y_aligned_size, "BlockHeight": self.block_size_y, "BorderFlag": 0})

        if y_remainder_size > 1:
            self.y_span_list.append({"SpanHeight": y_remainder_size - 1, "BlockHeight": y_remainder_size - 1, "BorderFlag": 0})
        elif len(self.y_span_list) < 1:
            self.y_span_list.append({"SpanHeight": y_remainder_size, "BlockHeight": y_remainder_size, "BorderFlag": 0})

        if self.y_span_list[0]["SpanHeight"] == self.y_span_list[0]["BlockHeight"]:
            self.y_span_list[0]["BorderFlag"] = self.y_top_flag

        self.y_span_list[-1][2] |= self.y_bottom_flag

        self.x_border_flag = self.border_type & (self.BORDER_TYPE_RIGHT | self.BORDER_TYPE_RIGHT_PARTIAL)

        self.x_align_size = int(self.tile_num_x / self.block_size_x) * self.block_size_x
        self.partial_block_width = self.tile_num_x - self.x_align_size

        if self.partial_block_width <= 1:
            self.partial_block_width += self.block_size_x
        else:
            self.x_align_size += self.block_size_y

        self.partial_block_width -= 1
        self.right_border_block_x = self.x_align_size - self.block_size_x



        


