#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import code_generator.share.br_vector_instructions_def as bvd
import code_generator.share.br_resource_manager as resource_man
import code_generator.share.br_const_defs as bcd
import code_generator.vector.common.kernelLib as kernelLib
import code_generator.share.br_const_defs as cst
import code_generator.vector.common.funcLib as funcs

import code_generator.vector.common.hwCaps as hwCaps
import code_generator.vector.common.funcLib as funcLib


class vector_op(object):
    def __init__(self):
        self.bar = bvd.bar()
        self.saddg = bvd.saddg()
        self.adds = bvd.adds()
        self.sadd = bvd.sadd()
        self.smovg = bvd.smovg()
        self.fll1 = bvd.fll1()
        self.sxor = bvd.sxor()
        self.smov = bvd.smov()
        self.smovs = bvd.smovs()
        self.sld = bvd.sld()
        self.sldm = bvd.sldm()
        self.ldm = bvd.ldm()
        self.mov = bvd.mov()
        self.sshl = bvd.sshl()


class wreduce_op(vector_op):
    def __init__(self):
        super().__init__()
        ALL_SYNC_WBAR_ID = 1
        self.wred = bvd.wred()
        self.sgpr_syncBn2Red = None
        self.sgpr_syncRed2Bn = None
        self.sgpr_wred_x = None
        self.barid_red2bn = bcd.VECTOR_PINGPONG_REDUCE_TO_BN_BAR_ID_1
        self.barid_bn2red = bcd.VECTOR_PINGPONG_BN_TO_REDUCE_BAR_ID_1
        self.allsync_wbarid = ALL_SYNC_WBAR_ID

    def init_gen(self, indent_obj):

        self.sgpr_syncBn2Red = resource_man.wsr_alloc("bn2reduce_sync")
        self.sgpr_syncRed2Bn = resource_man.wsr_alloc("reduce2bn_sync")
        self.sgpr_wred_x = resource_man.wsr_alloc("wred_z_axis")

        self.smov.generate(
            indent_obj, dst=self.sgpr_syncBn2Red, src1=self.barid_bn2red,
            comment="// Set bn->reduce wait bar id")

        self.smov.generate(
            indent_obj, dst=self.sgpr_syncRed2Bn, src1=self.barid_red2bn,
            comment="// Set bn->reduce pass bar id")
    
    def free_wsr(self):
        if self.sgpr_wred_x is not None:
            resource_man.wsr_free(self.sgpr_wred_x)
            self.sgpr_wred_x = None
        if self.sgpr_syncBn2Red is not None:
            resource_man.wsr_free(self.sgpr_syncBn2Red)
            self.sgpr_syncBn2Red = None
        if self.sgpr_syncRed2Bn is not None:
            resource_man.wsr_free(self.sgpr_syncRed2Bn)
            self.sgpr_syncRed2Bn = None

    def core_gen(
            self, indent_obj, usharp_id, eu_id_sgpr,
            sgpr_slot, outer_z, inner_z, sample_w, base_z, 
            spc_num=20):
            
        base_z = int(base_z)
        self.bar.generate(
            indent_obj, scope="tg", mode="sync",
            src1=self.sgpr_syncBn2Red, src2=2*4,
            comment="// Wait for signal from downstream")

        if outer_z is not None:
            if inner_z is None:
                self.sadd.generate(
                    indent_obj,
                    dst=self.sgpr_wred_x, src1=outer_z, src2=base_z,
                    comment="// Calculate channel coordinate")
            else:
                self.sadd.generate(
                    indent_obj,
                    dst=self.sgpr_wred_x, src1=inner_z, src2=outer_z,
                    comment="// Calculate channel offset")
                self.sadd.generate(
                    indent_obj,
                    dst=self.sgpr_wred_x, src1=self.sgpr_wred_x, src2=base_z, 
                    comment="// Calculate channel coordinate")                          
        else:
            if inner_z is not None:
                self.sadd.generate(
                    indent_obj,
                    dst=self.sgpr_wred_x, src1=inner_z, src2=base_z, 
                    comment="// Calculate channel coordinate")
            else:
                self.smov.generate(
                    indent_obj,
                    dst=self.sgpr_wred_x, src1=base_z, 
                    comment="// Calculate channel coordinate")

        self.sadd.generate(
            indent_obj,
            dst=self.sgpr_wred_x, src1=self.sgpr_wred_x, src2=eu_id_sgpr, 
            comment="// Align 1d wred coordinate with eu id")

        self.sshl.generate(
            indent_obj,
            dst=self.sgpr_wred_x, src1=self.sgpr_wred_x, src2=1, 
            comment="// Caclulate wred axis with 2*channel index")

        self.wred.generate(
            indent_obj, modifier="add.grb.e2.gc5.rb32.mb32.float.mmat1d",
            operands="g0, g1, u"+str(usharp_id),
            comment="// Do wide reduction for x, x^2 of each spc")

        # if bcd.BR_STM_G4_FEATURE_ENABLE:
        #     self.adds.generate(
        #         indent_obj,
        #         parallel=1,
        #         modifier="v1.b32.lo",
        #         dst="z0",
        #         src1=sgpr_slot,
        #         src2=0,
        #         comment="// Assign reduce slot to staging 4")
        # else:
        self.mov.generate(
            indent_obj,
            parallel=1,
            dst="g4.u32" if not bcd.BR_STM_G4_FEATURE_ENABLE else "z0.u32",
            src1=sgpr_slot+".u32",
            comment="// Assign reduce slot to staging 4")

        self.smovg.generate(
            indent_obj,
            dst="g0", src1=self.sgpr_wred_x,
            comment="// Assign 1d x axis to staging 0")

        w_value = sample_w if sample_w is not None else 0
        self.smovg.generate(
            indent_obj, 
            modifier="eog",
            dst="g3",
            src1=w_value,
            comment="// Always set sub-usharp as 0")


        if bcd.OC64_CONV_ROW64_MMA:
            self.wred.generate(
                indent_obj, modifier="add.grb.e2.gc5.rb32.mb32.float.mmat1d",
                operands="g0, g1, u"+str(usharp_id),
                comment="// Do wide reduction for x, x^2 of each spc")
            
            self.adds.generate(
                indent_obj,
                parallel=1,
                modifier="v1.b32.lo",
                dst="z0" if bcd.BR_STM_G4_FEATURE_ENABLE else "g4",
                src1=sgpr_slot, src2=1,
                comment="// Assign reduce slot to staging 4")

            self.saddg.generate(
                indent_obj,
                #modifier="eog" ,
                dst="g0", src1=self.sgpr_wred_x, src2=32*2,
                comment="// Assign 1d x axis to staging 0")

            w_value = sample_w if sample_w is not None else 0
            self.smovg.generate(
                indent_obj, 
                modifier="eog",
                dst="g3",
                src1=w_value,
                comment="// Always set sub-usharp")
                
            # self.adds.generate(
            #   indent_obj,
            #   modifier="v1.b32.lo.eog",
            #   dst="g0", src1=self.sgpr_wred_x, src2=32*2,
            #   comment="// Assign 1d x axis to staging 0")
            
        self.fll1.generate(
            indent_obj, comment="// Flush to l1")

        # [Arthur Duan] temply comment out the dtg sync as
        # model is not ready yet.
        # self.bar.generate(
        #     indent_obj, scope="dtg", mode="sync",
        #     src1=str(self.allsync_wbarid), src2=spc_num,
        #     comment="// Do all participating SPCs sync")

        self.bar.generate(
            indent_obj, scope="tg", mode="pass",
            src1=self.sgpr_syncRed2Bn, src2=2*4,
            comment="// Inform downstream to proceed")

        self.sxor.generate(
            indent_obj, dst=self.sgpr_syncRed2Bn,
            src1=self.sgpr_syncRed2Bn, src2=1,
            comment="// Toggle pass bar id")

        self.sxor.generate(
            indent_obj, dst=self.sgpr_syncBn2Red,
            src1=self.sgpr_syncBn2Red, src2=1,
            comment="// Toggle wait bar id")

        self.sadd.generate(
            indent_obj, dst=sgpr_slot, src1=sgpr_slot,
            src2=(1 if not bcd.OC64_CONV_ROW64_MMA else 2),
            comment="// Advance reduction slot")


class bars_ini(vector_op):
    def __init__(self):
        super().__init__()
        self.producer_signal_fused_tcore = {
            "grb_pingpong":
                {"bar_id": [cst.GRB_PINGPONG_VECTOR_TO_CONV_BAR_ID_1, 
                            cst.GRB_PINGPONG_VECTOR_TO_CONV_BAR_ID_2], 
                 "channels": cst.BAR_CHANNELS_BTWEEN_TCORE_AND_VECTOR, 
                 "scope": "wtg",
                 "comment": "// Init grb pingpong bars to start conv"},
            "tlr_pingpong":
                {"bar_id": [cst.TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_1, 
                            cst.TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_2], 
                 "channels": cst.BAR_CHANNELS_BTWEEN_TCORE_AND_VECTOR,
                 "scope": "wtg",
                 "comment": "// Init tlr pingpong bars to start conv"}}
        self.producer_signal_only_vector = {
            "bn_reduce":
                {"bar_id": [cst.VECTOR_PINGPONG_BN_TO_REDUCE_BAR_ID_1, 
                            cst.VECTOR_PINGPONG_BN_TO_REDUCE_BAR_ID_2], 
                 "channels": cst.BAR_CHANNELS_WITHIN_VECTOR, 
                 "scope": "tg",
                 "comment": "// Init reduce2bn pingpong bars to start bn"}}

    def generate(self, indent_obj, init_tcore_producer=True, init_reduce_producer=True):
        if init_tcore_producer:
            for aproducer in self.producer_signal_fused_tcore.values():
                for index in range(len(aproducer["bar_id"])):
                    self.bar.generate(
                        indent_obj,
                        scope=aproducer["scope"], mode="pass",
                        src1=aproducer["bar_id"][index],
                        src2=aproducer["channels"],
                        comment=aproducer["comment"])
        if init_reduce_producer:
            for aproducer in self.producer_signal_only_vector.values():
                for index in range(len(aproducer["bar_id"])):
                    self.bar.generate(
                        indent_obj,
                        scope=aproducer["scope"], mode="pass",
                        src1=aproducer["bar_id"][index],
                        src2=aproducer["channels"],
                        comment=aproducer["comment"])


class oob_mask(vector_op):
    def __init__(self):
        super().__init__()
    
    def generate(
        self, indent_obj,
        image_height_res, image_width_res, 
        is_m0=True, active_mask=True):
        mask = hex(funcs.GetThreadActiveMask(
            image_height_res, image_width_res, (0 if active_mask else 1)))
        dst = "wm0" if is_m0 else "wm1"
        self.smovs.generate(
            indent_level=indent_obj,
            dst=dst, src1=mask, 
            comment="// Mask lane within (h_{}, w_{})".format(
                image_height_res, image_width_res))


####################################################
#
# saclar load
# sld.mt2.ca.dt.mdem.rdem.sync.aa.org.dcnt.gcnt d, g0, desc;
# dcnt = e1/e2/e3/e4/e8
# mdem = mb32, rdem = rb32

# data number means how many data we want to load
# channel number means how many data we have per element
# if channel number is 0, don't update elementIndexSGPRStr

# x is an index to the 1d image. The image has a format.
# x refers to all components of the format. If the format is RG, 
# x refers to 2 components. If the format is RGBA, 
# x refers to 4 components."


class scalar_loader(vector_op):
    def __init__(self):
        super().__init__()

    def generate(
            self, indent_obj, gpr_format, ele_index_sgpr, 
            sgpr_addr, data_num, channel_num, sync_id, 
            usharp_id, sample_index_sgpr="0", offset_info=None):

        ld_format_modifier = "mmat1d.float.mb32.rb32"
        ld_format_modifier += "" if sync_id == 0 else ".sc"+str(sync_id)

        size_list = funcLib.SplitRepeatIntoGroups(
            data_num, hwCaps.MaxLoadGranule())

        for this_size in size_list:
            for z in range(this_size[0]):
                ld_format_modifier += "" if this_size[1] == 1 else ".e" + str(this_size[1])
                ld_format_modifier += ".gc2"
                load_second_params = offset_info is not None and isinstance(offset_info, list)
                self.sld.generate(
                    indent_level=indent_obj, modifier=ld_format_modifier,
                    src1="q"+str(sgpr_addr), src2="g0", desc="u"+str(usharp_id),
                    comment="// Load x_sum, and x^2_sum" if \
                            load_second_params else "// Load gamma, and betta")
                if load_second_params:
                    offset_str = str(offset_info[0]*2)
                    if not offset_info[2]:
                        offset_str = offset_info[1] # use sgpr or csr insteadly
                    self.adds.generate(
                        indent_level=indent_obj,
                        dst="g0", modifier="v1.b32.lo", 
                        src1=ele_index_sgpr, src2=offset_str,
                        comment="// Increase in channel axis")
                    self.smovg.generate(
                        indent_level=indent_obj,
                        dst="g1", modifier="eog", src1=sample_index_sgpr,
                        comment="// Increase in sample axis")

                else:
                    self.mov.generate(
                        indent_level=indent_obj, modifier="rdne.v1",
                        src1="g0.u32", src2=ele_index_sgpr+".u32",
                        comment="// ")
                    self.smovg.generate(
                        indent_level=indent_obj, modifier="eog",
                        dst="g1", src1=sample_index_sgpr, 
                        comment="// Increase in sample axis")
                if channel_num != 0:
                    self.sadd.generate(
                        indent_level=indent_obj, src1=ele_index_sgpr,
                        src2=str(int(offset_info[1])))
                sgpr_addr += this_size[1]



####################################################
#
# saclar load to vgpr
# sldm.mt2.ca.dt.mdem.rdem.sync.aa.org.dcnt.gcnt d, g0, desc;
# dcnt = e1/e2
# mdem = mb32, rdem = rb32

# data number means how many data we want to load
# channel number means how many data we have per element
# if channel number is 0, don't update elementIndexSGPRStr

# x is an index to the 1d image. The image has a format.
# x refers to all components of the format. If the format is RG, 
# x refers to 2 components. If the format is RGBA, 
# x refers to 4 components."


class scalar_loader_vgpr(vector_op):
    def __init__(self):
        super().__init__()

    def generate(
            self, indent_obj, gpr_format, ele_index_sgpr, 
            vgprAddr, data_num, channel_num, sync_id, 
            usharp_id, sample_index_sgpr="0", offset_info=None):

        ld_format_modifier = "mmat1d.float.mb32.rb32.rw"
        ld_format_modifier += "" if sync_id == 0 else ".sc"+str(sync_id)

        size_list = funcLib.SplitRepeatIntoGroups(
            data_num, hwCaps.MaxLoadGranule())

        for this_size in size_list:
            for z in range(this_size[0]):
                e_size = this_size[1]//2
                ld_format_modifier += "" if this_size[1] == 1 else ".e" + str(e_size)
                ld_format_modifier += ".gc2" if not bcd.BR_STM_G4_FEATURE_ENABLE else ".gc4"
                load_second_params = offset_info is not None and isinstance(offset_info, list)
                self.sldm.generate(
                    indent_level=indent_obj, modifier=ld_format_modifier,
                    src1="r"+str(vgprAddr), src2="g0", desc="u"+str(usharp_id),
                    comment="// Load x_sum, and x^2_sum" if \
                            load_second_params else "// Load gamma, and betta")
                if load_second_params:
                    offset_str = str(offset_info[0]*2)
                    if not offset_info[2]:
                        offset_str = offset_info[1] # use sgpr or csr insteadly
                    self.adds.generate(
                        indent_level=indent_obj,
                        parallel=1,
                        dst="g0", modifier="v1.b32.lo", 
                        src1=ele_index_sgpr, src2=offset_str,
                        comment="// Assign x axis with euid, channel fused")
                    self.smovg.generate(
                        indent_level=indent_obj,
                        dst="g1" if not bcd.BR_STM_G4_FEATURE_ENABLE else "g3", 
                        modifier="eog", 
                        src1=sample_index_sgpr,
                        comment="// Assign sample axis")
                else:
                    self.mov.generate(
                        parallel=1,
                        indent_level=indent_obj, modifier="rdne.v1",
                        src1="g0.u32", src2=ele_index_sgpr+".u32",
                        comment="// Assign x axis with euid, channel fused")
                    self.smovg.generate(
                        indent_level=indent_obj, 
                        modifier="eog",
                        dst="g1" if not bcd.BR_STM_G4_FEATURE_ENABLE else "g3", 
                        src1=sample_index_sgpr, 
                        comment="// Assign sample axis")
                if channel_num != 0:
                    self.sadd.generate(
                        indent_level=indent_obj, src1=ele_index_sgpr,
                        src2=str(int(offset_info[1])))
                vgprAddr += (this_size[1] + (this_size[1] == 1))



####################################################
# burst load
# due to activation layout, that is y direction
# reset y coord in the end

# ldm.sync.dt.mdem.rdem.memtype.dcnt.gc d, g0, desc;
# mdem and rdem have the same dem size.
# dcnt = {e1|e2|e3|e4|e8|e16} // dem count
# memtype = {mmat2d|mmat3d} // memory type



class activation_loader(vector_op):
    def __init__(self):
        super().__init__()

    def generate(
        self, indent_obj, mem_format, gpr_format, coord_sgpr_list,
        vgpr_address, vgpr_num, sync_id, usharp_id, x_inc):
        assert mem_format == gpr_format, "Error: mdem and rdem should have same dem size"
        (ld_format_modifier, element_per_vgpr) = kernelLib.GetFormatModifier_Full(gpr_format, gpr_format)
        sync_str = kernelLib.GetSyncModifier(sync_id)
        if vgpr_address < 0:
            vgpr_type_str = "ir"
            vgpr_address = -vgpr_address - 1
        else:
            vgpr_type_str = "r"

        ele_num = vgpr_num * element_per_vgpr
        size_list = funcLib.SplitRepeatIntoGroups(ele_num, hwCaps.MaxLDMGranule())

        if coord_sgpr_list[3] == "":
            gc_count = 3
            gc_str = ".gc3 "
        else:
            gc_count = 4
            gc_str = ".gc4 "

        size_num, size_index, y_inc = len(size_list), 0, 0, 
        accu = [] #accumulative ldm size
        for i, this_size in enumerate(size_list):
            size_index += 1
            for z in range(this_size[0]):
                vector_modifier = kernelLib.GetVectorModifier(this_size[1], "e")
                self.ldm.generate(
                    indent_level=indent_obj,
                    modifier="mmat3d"+ld_format_modifier+sync_str+vector_modifier+gc_str,
                    src1=vgpr_type_str+str(vgpr_address),
                    src2="g0",
                    desc="u"+str(usharp_id),
                    comment="// Load 4D activation")
                # if i == 0 and z == 0 and x_inc > 0:
                self.adds.generate(
                    indent_level=indent_obj,
                    modifier="v1.b32.lo",
                    parallel=1,
                    dst="g0",
                    src1=coord_sgpr_list[0],
                    src2=str(x_inc),
                    comment="// Add x coordinate sgpr")
                # else:
                #     self.smovg.generate(
                #         indent_level=indent_obj,
                #         dst="g0",
                #         src1=coord_sgpr_list[0],
                #         comment="// Assign x coordinate sgpr")
                tile_num = int(this_size[1]/element_per_vgpr)
                accu.append(tile_num*hwCaps.TileSizeY())
                if len(accu) > 1:
                    accu[-1] += accu[-2]#add last two to current position, prefix sum
                if i >= 1 or z > 0:
                    self.saddg.generate(
                        indent_level=indent_obj,
                        dst="g1",
                        src1=coord_sgpr_list[1],
                        src2=str(accu[i * this_size[0] + z - 1]),
                        comment="// Assign y coordinate sgpr")
                else:
                    self.smovg.generate(
                        indent_level=indent_obj,
                        dst="g1",
                        src1=coord_sgpr_list[1],
                        comment="// Assign y coordinate sgpr")

                if gc_count == 3:
                    self.smovg.generate(
                        indent_level=indent_obj,
                        modifier="eog",
                        dst="g2",
                        src1=coord_sgpr_list[2],
                        comment="// Assign z coordinate sgpr")
                else:
                    self.smovg.generate(
                        indent_level=indent_obj,
                        dst="g2",
                        src1=coord_sgpr_list[2],
                        comment="// Assign z coordinate sgpr")
                    self.smovg.generate(
                        indent_level=indent_obj,
                        modifier="eog",
                        dst="g3",
                        src1=coord_sgpr_list[3],
                        comment="// Assign w coordinate sgpr")                    

                # tile_num = int(this_size[1]/element_per_vgpr)
                vgpr_address += tile_num

        #         if size_index != size_num or (z != (this_size[0] -1)):
        #             self.sadd.generate(
        #                 indent_level=indent_obj,
        #                 dst=coord_sgpr_list[1],
        #                 src1=coord_sgpr_list[1],
        #                 src2=str(tile_num*hwCaps.TileSizeY()),
        #                 comment="// Increase y coordinate")
        #             y_inc += tile_num
        # if y_inc != 0:
        #     self.sadd.generate(
        #         indent_level=indent_obj,
        #         dst=coord_sgpr_list[1],
        #         src1=coord_sgpr_list[1],
        #         src2=str(-y_inc*hwCaps.TileSizeY()))


