#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

from vector.br_vector_base import vector
from vector.br_vector_reduce import reduce
from vector.br_vector_stm import stm
import vector.common.hwCaps as hwCaps
import vector.common.usharp as usharp

import vector.br_vector_bn_funcs as bn_core
import vector.br_vector_dwc_funcs as dwc_core
import vector.br_vector_fc_funcs as fc_core
import vector.br_vector_loss_funcs as loss_core

''''' Summary of key interface from the vector engine
      See the br_vector_gen.py for the detailed usage!
'''''

def br_fwd_bn(warpid, vgpr_start, vgpr_end, uid_0, ushape_0, uid_1, ushape_1,
                 uid_2, ushape_2, options=None, layerid=None, layernum=None, dryrun=None):
    layer = bn()
    layer.generate(warpid=warpid, vgpr_start=vgpr_start, vgpr_end=vgpr_end,
                uid_0=uid_0, ushape_0=ushape_0, uid_1=uid_1, ushape_1=ushape_1,
                uid_2=uid_2, ushape_2=ushape_2, options=options, layerid=layerid,
                layernum=layernum, dryrun=dryrun)

def br_fwd_dwc(warpid, vgpr_start, vgpr_end, uid_0, ushape_0, uid_1, ushape_1, uid_2, ushape_2,
               uid_3, ushape_3, options=None, layerid=None, layernum=None):
    layer = dwc()
    layer.generate(warpid=warpid, vgpr_start=vgpr_start, vgpr_end=vgpr_end,
                uid_0=uid_0, ushape_0=ushape_0, uid_1=uid_1, ushape_1=ushape_1,
                uid_2=uid_2, ushape_2=ushape_2, uid_3=uid_3, ushape_3=ushape_3,
                options=options, layerid=layerid, layernum=layernum)

def br_fwd_fc1(warpid, vgpr_start, vgpr_end, uid_0, ushape_0, uid_1, ushape_1, uid_2, ushape_2,
              uid_3, ushape_3, options=None, layerid=None, layernum=None):

    layer = fc()
    layer.generate(warpid=warpid, vgpr_start=vgpr_start, vgpr_end=vgpr_end,
                uid_0=uid_0, ushape_0=ushape_0, uid_1=uid_1, ushape_1=ushape_1,
                uid_2=uid_2, ushape_2=ushape_2, uid_3=uid_3, ushape_3=ushape_3, layer_subtype=usharp.GetLayerSubtypeFcFw1(),
                options=options, layerid=layerid, layernum=layernum)


def br_fwd_fc2(warpid, vgpr_start, vgpr_end, uid_0, ushape_0, uid_1, ushape_1, uid_2, ushape_2,
              uid_3, ushape_3, options=None, layerid=None, layernum=None):

    layer = fc()
    layer.generate(warpid=warpid, vgpr_start=vgpr_start, vgpr_end=vgpr_end,
                uid_0=uid_0, ushape_0=ushape_0, uid_1=uid_1, ushape_1=ushape_1,
                uid_2=uid_2, ushape_2=ushape_2, uid_3=uid_3, ushape_3=ushape_3, layer_subtype=usharp.GetLayerSubtypeFcFw2(),
                options=options, layerid=layerid, layernum=layernum)


def br_bk_fc1(warpid, vgpr_start, vgpr_end, uid_0, ushape_0, uid_1, ushape_1, uid_2, ushape_2,
              uid_3, ushape_3, uid_4, ushape_4, options=None, layerid=None, layernum=None):

    layer = fc()
    layer.generate(warpid=warpid, vgpr_start=vgpr_start, vgpr_end=vgpr_end,
                uid_0=uid_0, ushape_0=ushape_0, uid_1=uid_1, ushape_1=ushape_1,
                uid_2=uid_2, ushape_2=ushape_2, uid_3=uid_3, ushape_3=ushape_3,
                uid_4=uid_4, ushape_4=ushape_4, layer_subtype=usharp.GetLayerSubtypeFcBk1(),
                options=options, layerid=layerid, layernum=layernum)

def br_bk_fc2(warpid, vgpr_start, vgpr_end, uid_0, ushape_0, uid_1, ushape_1, uid_2, ushape_2,
              uid_3, ushape_3, uid_4, ushape_4, options=None, layerid=None, layernum=None):

    layer = fc()
    layer.generate(warpid=warpid, vgpr_start=vgpr_start, vgpr_end=vgpr_end,
                uid_0=uid_0, ushape_0=ushape_0, uid_1=uid_1, ushape_1=ushape_1,
                uid_2=uid_2, ushape_2=ushape_2, uid_3=uid_3, ushape_3=ushape_3,
                uid_4=uid_4, ushape_4=ushape_4, layer_subtype=usharp.GetLayerSubtypeFcBk2(),
                options=options, layerid=layerid, layernum=layernum)

def br_fwd_loss(warpid, vgpr_start, vgpr_end, uid_0, ushape_0, uid_1, ushape_1, uid_2, ushape_2,
               uid_3, ushape_3, options=None, layerid=None, layernum=None):
    layer = loss()
    layer.generate(warpid=warpid, vgpr_start=vgpr_start, vgpr_end=vgpr_end,
                uid_0=uid_0, ushape_0=ushape_0, uid_1=uid_1, ushape_1=ushape_1,
                uid_2=uid_2, ushape_2=ushape_2, uid_3=uid_3, ushape_3=ushape_3,
                options=options, layerid=layerid, layernum=layernum)


def br_fwd_reduce(
        warpid, ushape_0, loopconfig, layerid=None,
        layernum=None, dryrun=None, afterdwc=None):

    layer = reduce()
    layer.generate(
        warpid=warpid, ushape_0=ushape_0, layerid=layerid,
        layernum=layernum, dryrun=dryrun, afterdwc=afterdwc,
        loopconfig=loopconfig)


def br_fwd_stm(
        warpid, ushape_0, loopconfig, layerid=None,
        layernum=None, dryrun=None, afterdwc=None):

    layer = stm()
    layer.generate(
        warpid=warpid, ushape_0=ushape_0, layerid=layerid,
        layernum=layernum, dryrun=dryrun, afterdwc=afterdwc,
        loopconfig=loopconfig)



class dwc(vector):
    def __init__(self):
        super().__init__()
        self.core_func = dwc_core.gen_layer_main_kernel

    def _core_func(self):
        pass

    def generate(self, warpid, vgpr_start, vgpr_end,
                uid_0, ushape_0, uid_1, ushape_1,
                uid_2, ushape_2, uid_3, ushape_3,
                options=None, layerid=None, layernum=None):

        usharps_list = [
                [uid_0, hwCaps.SurfaceType3DActivation(),  ushape_0[0],  ushape_0[1], ushape_0[2], ushape_0[3], "input, 3d activation"],
                [uid_1, hwCaps.SurfaceType1DVector(),      ushape_1[0],  ushape_1[1], ushape_1[2], ushape_1[3], "input weight, 1d vector"],
                [uid_2, hwCaps.SurfaceType1DVector(),      ushape_2[0],  ushape_2[1], ushape_2[2], ushape_2[3], "input gamma/beta, 1d vector"],
                [uid_3, hwCaps.SurfaceType3DActivation(),  ushape_3[0],  ushape_3[1], ushape_3[2], ushape_3[3], "output, 3d activation"]
            ]

        if layerid is not None:
            self.layer_id = layerid
        if layernum is not None:
            self.layer_num = layernum

        self.warp_id = warpid
        self.cwarp_end = cwarp_end
        self.layer_info = ["dwc", usharps_list, [vgpr_start, vgpr_end], options]

        super()._generate()


class fc(vector):
    def __init__(self):
        super().__init__()
        self.core_func = fc_core.gen_layer_main_kernel

    def _core_func(self):
        pass

    def generate(self, warpid, vgpr_start, vgpr_end,
            uid_0, ushape_0, uid_1, ushape_1,
            uid_2, ushape_2, uid_3, ushape_3,
            uid_4=None, ushape_4=None, layer_subtype=None,
            options=None, layerid=None, layernum=None):

        if (layer_subtype is None) or (layer_subtype == usharp.GetLayerSubtypeFcFw1()):
            usharps = [
                    [uid_0, hwCaps.SurfaceType4DWeight(),      ushape_0[0],  ushape_0[1], ushape_0[2], ushape_0[3], "input, 4D weight, order is row, channel, height, width, channel/height/width are packed into col"],
                    [uid_1, hwCaps.SurfaceType3DActivation(),  ushape_1[0],  ushape_1[1], ushape_1[2], ushape_1[3], "input, 3D activation, order is 1, channel, height, width, origin is previous layer's output, from hbm"],
                    [uid_2, hwCaps.SurfaceType1DVector(),      ushape_2[0],  ushape_2[1], ushape_2[2], ushape_2[3], "input, 1D vector, bias"],
                    [uid_3, hwCaps.SurfaceType1DVector(),      ushape_3[0],  ushape_3[1], ushape_3[2], ushape_3[3], "output, 1D vector, fc output, also serve as input to softmax"]
                ]
        elif (layer_subtype == usharp.GetLayerSubtypeFcFw2()):
            usharps = [
                    [uid_0, hwCaps.SurfaceType2DWeight(),  ushape_0[0],  ushape_0[1], ushape_0[2], ushape_0[3], "input, 2D weight"],
                    [uid_1, hwCaps.SurfaceType1DVector(),  ushape_1[0],  ushape_1[1], ushape_1[2], ushape_1[3], "input, 1D vector"],
                    [uid_2, hwCaps.SurfaceType1DVector(),  ushape_2[0],  ushape_2[1], ushape_2[2], ushape_2[3], "input, 1D vector, bias"],
                    [uid_3, hwCaps.SurfaceType1DVector(),  ushape_3[0],  ushape_3[1], ushape_3[2], ushape_3[3], "output, 1D vector, fc output, also serve as input to softmax"]
                ]
        elif (layer_subtype == usharp.GetLayerSubtypeFcBk1()):
            assert (uid_4 != None and ushape_4 != None), "Please input 4 usharp description!"
            usharps = [
                [uid_0, hwCaps.SurfaceType1DVector(),     ushape_0[0],  ushape_0[1], ushape_0[2], ushape_0[3], "input, 1D vector, e.g., gradient from previous layer"],
                [uid_1, hwCaps.SurfaceType2DWeight(),     ushape_1[0],  ushape_1[1], ushape_1[2], ushape_1[3], "input, 2D weight"],
                [uid_2, hwCaps.SurfaceType3DActivation(), ushape_2[0],  ushape_2[1], ushape_2[2], ushape_2[3], "output, 3D activation, gradient to 3d activation"],
                [uid_3, hwCaps.SurfaceType3DActivation(), ushape_3[0],  ushape_3[1], ushape_3[2], ushape_3[3], "input, 3D activation, order is channel, height, width, e.g., 3D activation in forward pass"],
                [uid_4, hwCaps.SurfaceType2DWeight(),     ushape_4[0],  ushape_4[1], ushape_4[2], ushape_4[3], "output, 4D weight, e.g., gradient to weight"],
                ]
        elif (layer_subtype == usharp.GetLayerSubtypeFcBk2()):
            assert (uid_4 != None and ushape_4 != None), "Please input 4 usharp description!"
            usharps = [
                [uid_0, hwCaps.SurfaceType1DVector(), ushape_0[0],  ushape_0[1], ushape_0[2], ushape_0[3], "input, 1D vector, gradient"],
                [uid_1, hwCaps.SurfaceType2DWeight(), ushape_1[0],  ushape_1[1], ushape_1[2], ushape_1[3], "input, 2D weight"],
                [uid_2, hwCaps.SurfaceType1DVector(), ushape_2[0],  ushape_2[1], ushape_2[2], ushape_2[3], "output, 1D vector, gradient to vector input in fwd pass"],
                [uid_3, hwCaps.SurfaceType2DWeight(), ushape_3[0],  ushape_3[1], ushape_3[2], ushape_3[3], "input, 1D vector input in fwd pass"],
                [uid_4, hwCaps.SurfaceType1DVector(), ushape_4[0],  ushape_4[1], ushape_4[2], ushape_4[3], "output, gradient to 2d weight"]
                ]

        if layerid is not None:
            self.layer_id = layerid
        if layernum is not None:
            self.layer_num = layernum

        self.warp_id = warpid
        self.layer_info = ["fc", usharps, [vgpr_start, vgpr_end], options]

        super()._generate()


class loss(vector):
    def __init__(self):
        super().__init__()
        self.core_func = loss_core.gen_layer_main_kernel

    def _core_func(self):
        pass

    def generate(self, warpid, vgpr_start, vgpr_end,
                uid_0, ushape_0, uid_1, ushape_1,
                uid_2, ushape_2, uid_3, ushape_3,
                options=None, layerid=None, layernum=None):

        usharps_list = [
                [uid_0, hwCaps.SurfaceType1DVector(),  ushape_0[0],  ushape_0[1], ushape_0[2], ushape_0[3], "input, 1D vector, fc output, also serve as input to softmax"],
                [uid_1, hwCaps.SurfaceType1DVector(),  ushape_1[0],  ushape_1[1], ushape_1[2], ushape_1[3], "input, 1D vector, ref"],
                [uid_2, hwCaps.SurfaceType1DVector(),  ushape_2[0],  ushape_2[1], ushape_2[2], ushape_2[3], "output, 1D vector, final loss"],
                [uid_3, hwCaps.SurfaceType1DVector(),  ushape_3[0],  ushape_3[1], ushape_3[2], ushape_3[3], "output, 1D vector, gradient for back propagation"]
            ]

        if layerid is not None:
            self.layer_id = layerid
        if layernum is not None:
            self.layer_num = layernum

        self.warp_id = warpid
        self.layer_info = ["loss", usharps_list, [vgpr_start, vgpr_end], options]

        super()._generate()
