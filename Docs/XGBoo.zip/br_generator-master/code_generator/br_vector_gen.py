#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import os
import code_generator.share.br_defined_print as bdp
import code_generator.share.br_utils as utils
from vector.br_vector_reduce import reduce
from vector.br_vector_bn import bn
from vector.br_vector_stm import stm


def test_bn():
    vector_bn = bn(
        warpid=3, vgpr_start=156, vgpr_end=256,
        usharp_0=[1, (16, 64, 56, 56)],
        usharp_1=[2, (1, 1, 1, 64)],
        usharp_2=[3, (16, 64, 56, 56)],
        usharp_3=[4, (16, 64, 56, 56)],
        options=[0], layerid=0, layernum=1, withrelu=True)

    print("[===BN WSR====] ===> ", vector_bn.get_required_wsr())

    vector_bn.generate()


def test_reduce():
    loop_config_vector = [
        ('outer_oc', 1, 1, 256, {'bar_csm': [2],
         'bar_pass': [4], 'grb_pingpong': 0}), ('inner_oc', 8, 1, 32)]

    vect_reduce = reduce(
        warpid=5, ushape_0=[0, (16, 64, 56, 56)],
        layerid=0, layernum=1, loopconfig=loop_config_vector)

    print(vect_reduce.get_required_wsr())

    vect_reduce.generate()

    print(vect_reduce.get_required_wsr())


def test_stm():

    loop_config_vector = [
        ('outer_oc', 2, 1, 256, {'wset': [32, 33], 'sset': [48, 49]}),
        ('sample', 2, 1, 256),
        ('row', 7, 1, 8),
        ('col', 7, 1, 8),
        ('inner_oc', 8, 1, 32)]

    vect_stm = stm(
        warpid=3, ushape_0=[0, (16, 64, 56, 56)],
        layerid=0, layernum=1, loopconfig=loop_config_vector)
    vect_stm.get_required_wsr()

    vect_stm.generate()


def main():
    new_file = "vector_test.s"
    bdp.set_output_file(new_file)
    new_file = str(os.path.abspath(os.path.dirname(__file__))) + "/" + new_file
    golden_file = str(os.path.abspath(os.path.dirname(__file__))) + "/vector/golden/vector_sample.s"

    test_bn()

    utils.compare_file(golden_file, new_file)


if __name__ == '__main__':
    main()

