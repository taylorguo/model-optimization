from __future__ import print_function

import time
import abc, six
import traceback
import contextlib
import numpy as np

@six.add_metaclass(abc.ABCMeta)
class Reg(object):
    '''base reg class for define different regs, also can be used to find liveness'''
    def __init__(self, no, instno, reg_type, isdst=False):
        self.name = self.__class__.__name__
        self.type = reg_type
        self.regno = no
        # which reg & inst will use this reg
        self.uses = []
        # which inst define whis reg
        self.defs = []
        self.inst_no = instno
        self.start = 0
        self.end = 0
        self.isdst = isdst
        #self.issrc1 = issrc1
        #self.issrc2 = issrc2
        self.val = -1
        if reg_type == "Imm":
            self.val = no

    def set_uses(self, inst):
        self.uses.append(inst)
    def set_defs(self, inst):
        self.defs.append(inst)
    def get_uses(self):
        return self.uses
    def get_defs(self):
        return self.defs
    def is_const(self):
        return self.type == "Imm"

