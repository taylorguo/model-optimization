import re

from code_generator.backend.TLRReg import TLR
from code_generator.backend.TLRReg import ITLR
from code_generator.backend.TLRReg import ZeroR
from code_generator.backend.CSRReg import CSR
from code_generator.backend.WSRReg import WSR
from code_generator.backend.WSRReg import WSR
from code_generator.backend.SRReg import SR
from code_generator.backend.Flag import FLAG
from code_generator.backend.Immediate import Imm
from code_generator.backend.algofunc import func
from code_generator.backend.SpecialReg import AREG
from code_generator.backend.SpecialReg import KREG

class Instruction(object):
    def __init__(self, inst_num, inst, mod=None, comm="", tab=0):
        self.inst = inst
        self.opc = inst.instr_name
        #self.dst = dst
        #self.src = src
        self.inst_num = inst_num
        self.mod = mod

        #default value below
        self.vec = 1
        self.reg_num = 1
        self.dstreg = []
        self.srcreg = []
        self.src_num = 0
        self.src1_regnum = 1
        self.dst_regnum = 1
        self.usharp = []
        self.lsc=['ld','st','atadd','stm', 'ldm']
        self.lst=['ldmma0','ldmma1','ldconv0','ldconv1','conv','mma']
        self.const_inst_table=['mov', 'smov']
        self.operands = []
        self.functable = func().get_func()
        self.dstmod = []
        self.src1mod = []
        self.src2mod = []
        self.src3mod = []
        self.comments = comm
        self.start_tab = tab

    def set_dst_modifier(self, mods):
        for mod in mods:
            self.dstmod.append(mod.strip())
    def set_src1_modifier(self, mods):
        for mod in mods:
            self.src1mod.append(mod.strip())
    def set_src2_modifier(self, mods):
        for mod in mods:
            self.src2mod.append(mod.strip())
    def set_src3_modifier(self, mods):
        for mod in mods:
            self.src3mod.append(mod.strip())

    def get_usharp(self):
        return self.usharp

    def get_srcreg(self):
        return self.srcreg

    def check_valid(self, operands):
        operands = operands.strip()
        if operands[0] in ['r', 'q', 'g', 'c', 'z'] or re.search('[\-0-9]*',operands):
            return True
        return False

    def compute_inst(self, convops):
        inst = self.inst

        if "conv" in inst.instr_name or "ldconv0" in inst.instr_name or "ldconv1" in inst.instr_name\
            or "ldmma0" in inst.instr_name\
            or "ldmma1" in inst.instr_name\
            or "mma" in inst.instr_name:

            for ops in convops:
                ops = ops.strip()
                if ops == "z0":
                    self.operands.append(ZeroR(int(ops[1:]), self.inst_num, isdst=True))
                elif ops[0] == "u":
                    self.operands.append(Imm(ops[1:], True, self.inst_num))
                elif ops[0] == "r":
                    self.operands.append(TLR(int(ops[1:]), self.inst_num, isdst=True))
                elif "ir" in ops:
                    self.operands.append(ITLR(int(ops[2:]), self.inst_num, isdst=True))
                else:
                    pass
            operlen = len(self.operands)
            # suppose always have 3 operands
            for i in range(3 - operlen):
                self.operands.append(None)
            return
        #print("process inst:", inst.instr_name, inst.dst, inst.src1)
        for mod in self.mod:
            if mod in ["v2", "v3", "v4"]:
                self.vec = mod[1:len(mod)]
            elif mod in ["b32", "b64"]:
                self.reg_num = int(mod[1:3]) // 32
                self.src1_regnum = self.reg_num
                self.dst_regnum = self.reg_num
            elif mod in ["ww"]:
                self.src1_regnum = 2
                self.dst_regnum = 2

        expand_reg = self.reg_num * self.vec

        for i in range(int(expand_reg)):
            if inst.dst is not None and self.check_valid(inst.dst):
                dst = inst.dst
                if dst.isdigit() and dst[0] == 'u':
                    #print("dst is ", self.dst)
                    isusharp = False

                    if self.opc in self.lst:
                        isusharp = True
                    #take tensor lsc source as dst
                    #print("dst is ", self.dst)
                    self.usharp.append(self.dst)
                    #self.dstreg.append(Imm(self.dst, isusharp, self.inst_num))
                elif dst[0] == "r":
                    for m in range(self.dst_regnum):
                        self.dstreg.append(TLR(int(dst[1:]) + i + m, self.inst_num, isdst=True))
                elif dst[0] == "q":
                    for m in range(self.dst_regnum):
                        self.dstreg.append(WSR(int(dst[1:]) + i + m, self.inst_num, isdst=True))
                elif dst[0] == "g":
                    for m in range(self.dst_regnum):
                        self.dstreg.append(SR(int(dst[1:]) + i + m, self.inst_num, isdst=True))
                elif dst[0] == "a":
                    self.dstreg.append(AREG(int(dst[1:]), self.inst_num, isdst=True))
                elif dst[0] == "k":
                    self.dstreg.append(KREG(int(dst[1:]), self.inst_num, isdst=True))    
                #csr should be src, but here take it as dst for inst as mate... refine later
                elif dst[0] == "c":
                    for m in range(self.dst_regnum):
                        self.dstreg.append(CSR(int(dst[1:]) + i + m, self.inst_num, isdst=True))
                # dst is flag like bne.rel
                else:
                    self.dstreg.append(FLAG(dst.strip(), self.inst_num, isdst=True))
            srcs = []
            if inst.src1 is not None and self.check_valid(inst.src1):
                srcs.append(inst.src1)

            if inst.src2 is not None and self.check_valid(inst.src2):
                srcs.append(inst.src2.strip())

            for j in range(len(srcs)):
                src = srcs[j]
                src = src.strip()
                
                if src.isdigit() or src.lstrip('-').isdigit() or src[0] == 'u':
                    #print("dst is ", self.dst)
                    isusharp = False
                    if src[0] == 'u':
                        isusharp = True

                    if self.opc in self.lst:
                        self.usharp.append(src[1:])
                    else:
                        self.srcreg.append(Imm(int(src), isusharp, self.inst_num))

                elif src[0] == "r":
                    for m in range(self.src1_regnum):
                        self.srcreg.append(TLR(int(src[1:]) + i + m, self.inst_num))
                elif src[0] == "q":
                    for m in range(self.src1_regnum):
                        self.srcreg.append(WSR(int(src[1:]) + i + m, self.inst_num))
                elif src[0] == "g":
                    for m in range(self.src1_regnum):
                        self.srcreg.append(SR(int(src[1:]) + i + m, self.inst_num))
                #csr should be src, but here take it as dst for inst as mate... refine later
                elif src[0] == "c":
                    for m in range(self.src1_regnum):
                        self.srcreg.append(CSR(int(src[1:]) + i + m, self.inst_num))
                elif src[0] == "z":
                        self.srcreg.append(ZeroR(int(src[1:]), False, self.inst_num))
                elif src[0] == "-":
                    self.srcreg.append(Imm(src[1:], False, self.inst_num))
                elif src[0] == "a":
                        self.srcreg.append(AREG(src[1:], False, self.inst_num))
                elif src[0] == "k":
                        self.srcreg.append(KREG(src[1:], False, self.inst_num))

        # dst should be at 0
        if inst.type != "SCAL_CT":
            for dst in self.dstreg:
                self.operands.append(dst)
            if len(self.operands) < 1:
                self.operands.append(None)
            # then src1, src2...
            for src in self.srcreg:
                self.operands.append(src)   
            for i in range(3 - len(self.operands)):
                self.operands.append(None)
        # CT has different operands position    
        elif inst.type == "SCAL_CT":
            # then src1, src2...
            for src in self.srcreg:
                self.operands.append(src)
            if len(self.operands) < 2:
                self.operands.append(None)
            for dst in self.dstreg:
                self.operands.append(dst)
            for i in range(3 - len(self.operands)):
                self.operands.append(None)
        #print("process inst finished:", inst.instr_name, self.mod)

    def compute_reg(self):
        opc= self.opc.split('.')
        self.opc = opc[0]
        #print("opc head is ", self.opc)
        mods = opc[1:-1]
        for mod in mods:

            if mod in ["v2", "v3", "v4"]:
                self.vec = mod[1:len(mod)]
            elif mod in ["b32", "b64"]:
                self.reg_num = int(mod[1:3]) // 32
                self.src1_regnum = self.reg_num
                self.dst_regnum = self.reg_num
            elif mod in ["ww"]:
                self.src1_regnum = 2
                self.dst_regnum = 2

        expand_reg = self.reg_num * self.vec

        #process source operands
        if self.src is not None:
            self.src_num = len(self.src)

        self.srcreg = [[] for _ in range(self.src_num)]
        self.dst = self.dst.strip()

        for i in range(int(expand_reg)):
            dsts = self.dst[1:len(self.dst)]
            #print("dsts is ", self.dst)
            #special case for tensor lsc
            if dsts.isdigit() and self.dst[0] == 'u':
                #print("dst is ", self.dst)
                isusharp = False

                if self.opc in self.lst:
                    isusharp = True
                #take tensor lsc source as dst
                #print("dst is ", self.dst)
                self.usharp.append(self.dst)
                #self.dstreg.append(Imm(self.dst, isusharp, self.inst_num))
                continue

            dstmods = dsts.split('.')
            dst = dstmods[0]
            d_mod = dstmods[1:len(dstmods)]

            if self.dst[0] == "r":
                for m in range(self.dst_regnum):
                    self.dstreg.append(TLR(int(dst) + i + m, self.inst_num))
            elif self.dst[0] == "q":
                for m in range(self.dst_regnum):
                    self.dstreg.append(WSR(int(dst) + i + m, self.inst_num))
            elif self.dst[0] == "g":
                for m in range(self.dst_regnum):
                    self.dstreg.append(SR(int(dst) + i + m, self.inst_num))
            #csr should be src, but here take it as dst for inst as mate... refine later
            elif self.dst[0] == "c":
                for m in range(self.dst_regnum):
                    self.dstreg.append(CSR(int(dst) + i + m, self.inst_num))

            for j in range(self.src_num):
                self.src[j] = self.src[j].strip()
                #src is imm
                #print(self.opc, self.src[j])
                if self.src[j].isdigit():
                    isusharp = False

                    if self.opc in self.lst or self.opc in self.lsc:
                        #print("opt is ", self.opc)
                        isusharp = True
                        self.usharp.append(self.src[j])
                    else:
                        self.srcreg[j].append(Imm(self.src[j], isusharp, self.inst_num))

                    continue
                srcs = self.src[j][1:len(self.src[j])]

                # r0 is 0 null string
                #if len(srcs) == 0:
                #    srcs = "0"
                srcsmods = srcs.strip(';').split('.')
                src = srcsmods[0]
                contain_label = re.search('[a-z,A-Z,_]+', src)
                if contain_label:
                    src = src.split()[0]
                src_mod = srcsmods[1:-1]
                
                if self.src[j][0]  == "r":
                    if j == 0:
                        for m in range(self.src1_regnum):
                            self.srcreg[j].append(TLR(int(src) + i + m, self.inst_num))
                    else:
                        self.srcreg[j].append(TLR(int(src) + i, self.inst_num))
                elif self.src[j][0]  == "c":
                    if j == 0:
                        for m in range(self.src1_regnum):
                            self.srcreg[j].append(CSR(int(src) + i + m, self.inst_num))
                    else:
                        self.srcreg[j].append(CSR(int(src) + i, self.inst_num))
                    
                elif self.src[j][0]  == "q":
                    if j == 0:
                        for m in range(self.src1_regnum):
                            self.srcreg[j].append(WSR(int(src) + i + m, self.inst_num))
                    else:
                        self.srcreg[j].append(WSR(int(src) + i, self.inst_num))

                elif self.src[j][0]  == "g":
                    if j == 0:
                        for m in range(self.src1_regnum):
                            self.srcreg[j].append(SR(int(src) + i + m, self.inst_num))
                    else:
                        self.srcreg[j].append(SR(int(src) + i, self.inst_num))
                elif self.src[j][0]  == "u":
                    if src.isdigit():
                        isusharp = False
                        if self.opc in self.lsc or self.opc in self.lst:
                            #print("opt is ", self.opc)
                            self.usharp.append(int(src))
                            isusharp = True
                        else:
                            self.srcreg[j].append(Imm(int(src), isusharp, self.inst_num))

    def replace_uses(self, reg):
        for src in self.srcreg:
            pass

    def is_const(self):
        if self.opc in self.const_inst_table:
            return True
        else:
            return False
    def set_defs(self):
        pass
    def set_const(self):
        pass

    def get_const_val(self):
        fun = self.functable[self.opc]
        fun(self.dstreg, self.srcreg)
        return self.dstreg
