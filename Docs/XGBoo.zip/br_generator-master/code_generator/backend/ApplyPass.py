from code_generator.backend.PassManager import PM
from functools import wraps
import code_generator.share.br_const_defs as bcd

#import code_generator.share.br_defined_print as inst_buf
pm = PM()
def apply_pass(func):

    @wraps(func)
    def wrapper(*args,  stream = None, file_path = None, enable = True, **kwargs):
        #bp = inst_buf.br_printer()
        if enable and bcd.BR_CODE_GEN_STYLE == 0:
            #pm.set_enable_passes("opt0")
            pm.set_enable_passes("opt1")
            #pm.set_enable_passes("opt2")
            pm.set_pass_state("cwarp", [1,2])
            #print("+++++:", file_path)
            pm.apply_pass(stream, file_path)
            pm.reset()
        func(*args, **kwargs)

    return wrapper

def enable_kernel_replace(func):

    @wraps(func)
    def wrapper(enable = False, **kwargs):
        #bp = inst_buf.br_printer()
        if enable and bcd.BR_CODE_GEN_STYLE == 0:
            pm.enable_kernle_replace = enable
        func(**kwargs)

    return wrapper
