from code_generator.backend.BaseReg import Reg

class AREG(Reg):
    def __init__(self, no, instno, isdst=False):
        super(AREG, self).__init__(no, instno, "a", isdst)
        #print("construct tlr:", no)
        self.max_reg = 3

class KREG(Reg):
    def __init__(self, no, instno, isdst=False):
        super(KREG, self).__init__(no, instno, "k", isdst)
        #print("construct tlr:", no)
        self.max_reg = 1