from code_generator.backend.BaseReg import Reg

class FLAG(Reg):
    def __init__(self, str, instno, isdst=False):
        super(FLAG, self).__init__(str, instno, "flag", isdst)
        #print("construct tlr:", no)
        self.flag = str