from code_generator.backend.BaseReg import Reg

class SR(Reg):
    def __init__(self, no, instno, isdst=False):
        super(SR, self).__init__(no, instno, "g", isdst)
        #print("construct SR:", no)
        self.max_reg = 16