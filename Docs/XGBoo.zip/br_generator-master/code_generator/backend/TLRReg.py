from code_generator.backend.BaseReg import Reg

class TLR(Reg):
    def __init__(self, no, instno, isdst=False, regtype="r"):
        super(TLR, self).__init__(no, instno, regtype, isdst)
        #print("construct tlr:", no)
        self.max_reg = 256


class ITLR(TLR):
    def __init__(self, no, instno, isdst=False):
        TLR.__init__(self, no, instno, isdst = isdst, regtype="ir")
        #print("construct tlr:", no)

class ZeroR(TLR):
    def __init__(self, no, instno, isdst=False):
        TLR.__init__(self, no, instno, isdst = isdst, regtype="z")
        #print("construct tlr:", no)