from __future__ import print_function

import argparse
import os


def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Unsupported value encountered.')
def file_path(path):
    if os.path.isfile(path):
        return path
    else:
        raise argparse.ArgumentTypeError("readable_dir:path is not a valid path")

def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        '--asmfile',
        type=file_path,
        default="tests/mat-vec.s",
        help='input asm file')
    parser.add_argument(
        '--opt',
        type=str2bool,
        default=False,
        help='Enable -O1 opt [True|False]')
    parser.add_argument(
        '--formatInst',
        type=str2bool,
        default=False,
        help='Help to check instruction is legal [True|False]')
    parser.add_argument(
        '--schedule',
        type=str2bool,
        default=False,
        help='Whether resort the instruction [True|False]')
    parser.add_argument(
        '--liveness',
        type=str2bool,
        default=False,
        help='Used for register reuse according to liveness')
    parser.add_argument(
        '--log_level',
        type=int,
        default=0,
        help='level of logging')
    args = parser.parse_args()

    return args