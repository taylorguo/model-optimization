
class func(object):
    def mov(self, dst, src1):
        # if single inst, just do assign for first val
        if len(dst) == 1 and len(src1) == 1:
            dst[0].val = src1[0].val
    def add(self, dst, src1, src2):
        dst = src1 + src2
    def __init__(self):
        self.fields = dict()
        self.fields["mov"] = self.mov
        self.fields["add"] = self.add
        self.fields["smov"] = self.mov
    def get_func(self):
        return self.fields
