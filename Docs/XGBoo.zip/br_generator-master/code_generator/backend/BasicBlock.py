import traceback

class BB(object):
    def __init__(self, name, prev=None, succ=None):
        self.bname = name
        self.insts = list()
        self.prev = prev
        self.succ = succ
        self.tlr = 0
        self.csr = 0
        self.wsr = 0
        self.RegDict = dict()
        self.inst_num = 0
    def insert_inst(self, inst):
        #print("bb inst:", inst.opc, inst.operands)
        self.insts.append(inst)
        self.inst_num += 1
    def insert_inst_pos(self, inst, pos):
        self.insts.insert(pos, inst)
        self.inst_num += 1
    def get_insts(self):
        return self.insts
    def remove_inst(self, inst):
        self.insts.remove(inst)
        self.inst_num -= 1
    
    def reset(self):
        self.bname = ""
        self.insts = list()
        self.prev = None
        self.succ = None
        self.tlr = 0
        self.csr = 0
        self.wsr = 0
        self.RegDict = dict()
        self.inst_num = 0 
