from __future__ import print_function

import os
import json
import re
import string
import math
import subprocess

import time
import abc, six
import traceback
import contextlib
import numpy as np
from code_generator.backend.args import parse_args
from code_generator.backend.function import AsmFun
from code_generator.backend.CWarps import CWarps
#import code_generator.share.br_defined_print as inst_buf

#from code_generator.backend.wrap_decorator import wrap_decorator

'''
def _insert_pass_(func):
    def __impl__(*args, **kwargs):
        stream = inst_buf.br_printer().tail_stream
        return func(stream, *args, **kwargs)

    return __impl__

insert_pass = wrap_decorator(_insert_pass_)
'''

class Singleton(type):
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]

class PM(object):

    _metaclass__ = Singleton

    def __init__(self):
        self.inst_num = 0
        self.tlr_num = 0
        self.csr_num = 0
        self.wsr_num = 0
        self.usharp_num = 0
        self.fun = list()
        self.cur_fun = None
        self.num_fun = 0
        self.cwarps = 0
        self.binsize = 0
        self.params = 0
        self.param_name = []
        self.param_csr = []
        self.atomic = False
        self.gmode = True
        self.CWarps = []
        self.warp_num = 0
        self.cur_warp = None
        self.pass_state = {}
        self.new_stream = []
        self.warppos = dict()
        self.enable_pass = []
        self.enable_kernle_replace = False

    def set_pass_state(self, key, value):
        self.pass_state[key] = value


    def parse_cwarp(self, file):
        assert(file)
        process_cwarp = []

        if "cwarp" in self.pass_state.keys():
            process_cwarp = self.pass_state["cwarp"]

        restring_start = []
        restring_end = []
        process_cwarp.sort()

        for cw in process_cwarp:
            restring_start.append("^CWARP" + str(cw) + "_START")
            restring_end.append("^CWARP" + str(cw)+"_END")

        sfile = file.split('\n')

        # process input files, if inst not changed, save into stream
        linepos = 0
        end_pos = 0

        current_cws = 0
        self.new_stream = [""] * len(sfile)
        #for line in sfile[linepos:-1]:
        while True and linepos < len(sfile):
            line = sfile[linepos]
            #line = line.strip()
            warp_start = re.search(restring_start[current_cws], line)
            start_flag = False
            #print("insert:line", linepos, " line:", line)
            if warp_start:
                print("warp start.{0}".format(line))
                start_flag = True
                warps = line.strip().split("_")[0]
                cw = CWarps(warps)
                self.CWarps.append(cw)
                self.cur_warp = cw
                start_pos = pos = sfile.index(line)
                pos += 1
                #for line in sfile[pos+1:-1]:
                while True and pos <= len(sfile):
                    line = sfile[pos]
                    origin_line = line
                    pos += 1
                    #line = line.strip()

                    warp_end = re.search(restring_end[current_cws], line)
                    x = re.search('[\w]', line)
                    #linepos += 1
                    if not warp_end:
                        if line.strip().startswith("main:"):
                            fname = line[0:-2]
                            print("functin name:", fname)
                            self.cur_warp.create_function(fname)
                            #self.cur_fun = AsmFun(fname)
                            #self.fun.append(self.cur_fun)
                            #self.num_fun += 1
                        elif not line.strip().startswith("//") \
                            and not line.strip().startswith(".") \
                            and not line.strip().startswith("#") \
                            and x:
                            #if .s not defined main function, create a default main block

                            pos1 = line.find("//")
                            pos2 = line.find("/*")
                            comment = ""
                            x = re.search('[\w]', origin_line)
                            alpha = x.start()
                            if pos1  != -1 :
                                comment = line[pos1+3:-1]
                                line = line[0:pos1]
                            if pos2  != -1 :
                                comment = line[pos2+3:-1]
                                line = line[0:pos2]
                            self.cur_warp.insert_inst(line, comment, int(alpha))
                            self.inst_num += 1
                    elif warp_end:
                        self.warp_num += 1
                        end_pos = sfile.index(line)
                        if current_cws < len(process_cwarp) - 1:
                            current_cws += 1
                        self.warppos[warps] = (start_pos,end_pos)

                        linepos = end_pos

                        print("warp:{0} finished".format(line))
                        break
            else:
                #print("insert:line", linepos, " line:", line)
                #self.new_stream.insert(linepos, line)
                # not insert end if we processed this cwarp, just move pos to next
                if line.strip() != "end" and not start_flag:
                    self.new_stream[linepos] = line
            linepos += 1

        print("all warps finised, total warps:{0}".format(self.warp_num))

    def reset(self):
        self.inst_num = 0
        self.tlr_num = 0
        self.csr_num = 0
        self.wsr_num = 0
        self.usharp_num = 0
        self.fun = list()
        self.cur_fun = None
        self.num_fun = 0
        self.cwarps = 0
        self.binsize = 0
        self.params = 0
        self.param_name = []
        self.param_csr = []
        self.atomic = False
        self.gmode = True
        self.warp_num = 0
        self.cur_warp = None
        self.pass_state = {}
        self.new_stream = []
        self.warppos = dict()
        self.enable_pass = []
        for warp in self.CWarps:
            warp.reset()
        self.CWarps = []
        self.enable_kernle_replace = False


    def analyze_cwarp(self):
        for i in range(self.warp_num):
            cw = self.CWarps[i]
            cw.analyze()

    def save_pass_file(self, name):
        f = open(name+".s", "w+")
        for i in range(self.warp_num):
            cw = self.CWarps[i]
            f.writelines(cw.cwarp + "\n")
            cw.save_pass_file(f)

        f.close()

    def print_stream(self, file, string):
        if os.path.exists(file):
            os.remove(file)
        fd = open(file, "a+") 
        print(string, file=fd)
        fd.close()

    def save_opt_to_stream(self, name):
        for i in range(self.warp_num):
            cw = self.CWarps[i]
            cw_start = self.warppos[cw.cwarp][0]
            cw_end = self.warppos[cw.cwarp][1]
            print("cwarp start:", cw_start, " cwend:", cw_end)
            self.new_stream.insert(cw_start, cw.cwarp + "_START:")
            #self.new_stream.insert(cw_end, cw.cwarp + "_END:")

            cw.save_pass_file(self.new_stream, cw_start+1, cw_end + 1)

            pstring = " \n".join(self.new_stream)

            self.print_stream(name, pstring)
            #inst_buf.set_output_file(inst_buf.br_printer().file_path)

    def combine_on_off_pass(self, streamfile=None):
        if streamfile is not None:
            self.parse_file(streamfile)
        print("Combine on/off warp num",self.warp_num)
        for i in range(self.warp_num):
            cw = self.CWarps[i]
            print("Combine warp name",cw.cwarp)
            cw.combine_on_off()
        #file_name = self.get_opt_file_name("opt1")
        #self.save_opt_to_stream(file_name)

    def extract_same_register_pass(self, streamfile=None):
        if streamfile is not None:
            self.parse_file(streamfile)
        print("Extract same reg warp num",self.warp_num)
        for i in range(self.warp_num):
            cw = self.CWarps[i]
            print("Extract same reg warp name",cw.cwarp)
            cw.extract_same_register()
        #file_name = self.get_opt_file_name("opt1")
        #self.save_opt_to_stream(file_name)

    def remove_dead_code_pass(self, streamfile=None):
        if streamfile is not None:
            self.parse_file(streamfile)
        print("Remove dead code warp num",self.warp_num)
        for i in range(self.warp_num):
            cw = self.CWarps[i]
            cw.remove_loop_dead()
        #file_name = self.get_opt_file_name("opt2")q
        #self.save_opt_to_stream(file_name)
           

    def get_opt_file_name(self, file_path, opt_pass):
        #file_path = inst_buf.br_printer().file_path
        if self.enable_kernle_replace:
            name, bak = file_path.split('.')
            newname, end = name.split('_')
            opt_name = "".join(newname)
            opt_name += "." + bak
            return opt_name

        name, bak = file_path.split('.')
        opt_name = "".join(name)
        opt_name += "_" + opt_pass + "." + bak
        return opt_name

    def test_pass(self, streamfile=None):
        if streamfile is not None:
            self.parse_file(streamfile)
        #file_name = inst_buf.br_printer().file_path+".opt0"
        #file_name = self.get_opt_file_name("opt0")
        #self.save_opt_to_stream(file_name)

    def apply_pass(self, stream, file_path):
        for ps in self.enable_pass:
            if ps == "dce":
                self.remove_dead_code_pass()
                name = self.get_opt_file_name(file_path, "dce")
                self.save_opt_to_stream(name)
            # default pass
            elif ps == "opt0":
                self.test_pass(streamfile=stream)
                name = self.get_opt_file_name(file_path, ps)
                self.save_opt_to_stream(name)
            elif ps == "opt1":
                self.combine_on_off_pass(streamfile=stream)
                name = self.get_opt_file_name(file_path, ps)
                self.save_opt_to_stream(name)
            elif ps == "opt2":
                self.extract_same_register_pass(streamfile=stream)
                name = self.get_opt_file_name(file_path, ps)
                self.save_opt_to_stream(name)


    def set_enable_passes(self, pas):
        if pas not in self.enable_pass:
            self.enable_pass.append(pas)

    def parse_file(self, streamfile):
        self.parse_cwarp(streamfile)
        self.analyze_cwarp()

def backpass(fname, dce):
        print("fname is ", fname)
        p = PM()
        p.parse_cwarp(fname)
        p.analyze_cwarp()
        #p.enable_dce = dce

        p.apply_pass()


if __name__ == "__main__":
    args = parse_args()
    files = args.asmfile
    dce = 1
    backpass(files, dce)
    #bin = gen_metadata(args.asmfile)
    #f = gen_binary(args.asmfile, args.opt)
    #if not args.opt:
    #    verify_bin(f(), bin())

