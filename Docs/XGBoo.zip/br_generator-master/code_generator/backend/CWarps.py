import code_generator.backend.BasicBlock
from code_generator.backend.function import AsmFun
from code_generator.backend.Immediate import Imm
import copy

class CWarps(object):
    def __init__(self, name):
        self.cwarp = name
        self.BBs = None
        self.bbnum = 0
        self.functions = []
        self.fun_num = 0
        self.cur_fun = None
        self.inst_num = 0

    def insert_bb(self, bb):
        self.BBs.append(bb)
        self.bbnum += 1
    def create_function(self, name):
        asm = AsmFun(name)
        self.functions.append(asm)
        self.fun_num += 1
        return asm
    def insert_inst(self, inst, comm, tab):
        if self.cur_fun is None:
            fun = AsmFun("default")
            self.cur_fun = fun
            self.functions.append(fun)
            self.fun_num += 1
        self.cur_fun.insert_inst(inst, comm, tab)
        self.inst_num += 1
    
    def analyze(self):
        for i in range(self.fun_num):
            f = self.functions[i]
            f.gen_inst()
            #self.const_prop()

    def reset(self):
   
        for fc in self.functions:
            fc.reset()
        self.cwarp = None
        self.BBs = None
        self.bbnum = 0
        self.functions = []
        self.fun_num = 0
        self.cur_fun = None
        self.inst_num = 0
        
    # if all operands is const & inst is const oper(maybe), then we can get a const result
    # const val can use dirct comp to get it
    def constant_fold(self, inst):
        for op in inst.operands:
            if op.isdst == False and op.is_const() is False:
                return None
        if inst.is_const() is False:
            return None
        imm = inst.get_const_val()
        return imm
        '''
        imm_val = -1
        if imm is not None:
            if len(imm) == 1:
                imm_val = imm[0].val
        if imm_val != -1:
            return Imm(imm_val)
        else:
            return None
        '''

    #replace all inst than use this reg
    def replace_uses_with(self, newv):
        pass
    def const_prop(self):

        for i in range(self.fun_num):
            bbs = self.functions[i].get_bbuf()
            for bb in bbs:
                alldsts=[]
                insts = bb.get_insts()
                for inst in insts:
                    const = self.constant_fold(inst)
                    # not process vector inst
                    if const is not None and len(const) == 1 and int(const[0].val) >= 0:
                        self.replace_uses_with(const)
                    dst = inst.dstreg
                    if len(dst) == 1:
                         # dst is definied by this instruction, actually many inst may definied this dst
                         # we can save all in this block and find the first one
                        dst[0].set_defs(inst)
                    #save all dst to check whether set imm to dst
                        alldsts.append(dst[0])
                    # src is used by this inst, also save all inst use src
                    for src in inst.srcreg:
                        if src is not None:
                            src.set_uses(inst)
                #check all dst's defs, to see whether inst set imm to dst
                for dst in alldsts:
                    defs = dst.get_defs()
                    #get all inst that set dst
                    for definst in defs:
                        # check inst's src
                        for srcreg in definst.get_srcreg():
                            #check src is const, and inst is const opc, such as mov only need one const src, add need 2 src const
                            if srcreg.is_const() and definst.const_inst():
                                # if we have const, then set defs as const too
                                defs.set_const()
                                #then check all inst use defs
                                for usesinst in defs.get_uses():
                                    if usesinst.is_const():
                                        #replace inst's dst to const(defs)
                                        usesinst.replace(defs)

    def save_pass_file(self, f, start, end):
        pos = 0
        for i in range(self.fun_num):
            bbs = self.functions[i].get_bbuf()
            for bb in bbs:
                    if not bb.bname.startswith("jump") and not bb.bname.startswith("flat") and bb.bname != "default":
                        flag = bb.bname + ":"
                        f.insert(start+pos, flag)
                        pos += 1
                    insts = bb.get_insts()
                    for inst in insts:
                        modstr = ""
                        if inst.mod is not None:
                            for mod in inst.mod:
                                modstr += '.' + mod

                        inst_str = inst.opc + modstr + " "
                        if inst.opc == "nop" or inst.opc == "ackgmb":
                            f[start+pos] = inst_str
                            pos += 1
                            assert(start + pos <= end)
                            continue
                        #print("save inst:", inst.opc, inst.operands)
                        dst = inst.operands[0]
                        if dst is not None:#inst.inst.type != "SCAL_CT":
                            #print(inst.opc, dst.type, dst.regno)
                            if dst.type != "flag":
                                # for ldconv dst is imm as u#
                                if dst.type == "Imm" and dst.usharp:
                                    inst_str += "u" + str(dst.regno)
                                else:
                                    inst_str += dst.type + str(dst.regno)
                            else:
                                inst_str += str(dst.regno)
                            for mod in inst.dstmod:
                                inst_str += ("." + mod)

                        src1 = inst.operands[1]
                        if src1 is not None:
                            inst_str += ", "
                            if src1.type != "Imm":
                                if src1.type != "flag":
                                    inst_str += src1.type + str(src1.regno)
                                else:
                                    inst_str += src1.flag
                                for mod in inst.src1mod:
                                    inst_str += ("." + mod)
                            else:
                                if hasattr(src1, 'usharp') and src1.usharp:
                                    inst_str += "u" + str(src1.regno)
                                else:
                                    inst_str += str(src1.regno)

                        src2 = inst.operands[2]
                        if src2 is not None:
                            inst_str +=  ","
                            if src2.type != "Imm":
                                if src2.type != "flag":
                                    inst_str += src2.type + str(src2.regno)
                                else:
                                    inst_str += src2.flag
                                for mod in inst.src2mod:
                                    inst_str += "." + mod
                            else:
                                if hasattr(src2, 'usharp') and src2.usharp:
                                    inst_str += "u" + str(src2.regno)
                                else:
                                    inst_str += str(src2.regno)
                        
                        comments = inst.comments
                        if comments != "":
                            inst_str += "   "
                            inst_str += "//"
                            inst_str += comments

                        if int(inst.start_tab) != 0:
                            for i in range(int(inst.start_tab)):
                                inst_str = " " + inst_str
                        #else:
                        #    inst_str = inst_str[0:-1]
                        #if dst is not None and inst.inst.type == "SCAL_CT":
                        #        inst_str += str(dst.regno)

                        #f.insert(start+pos, inst_str)
                        f[start+pos] = inst_str
                        pos += 1
                        assert(start + pos <= end)
        #f.insert(start + pos, self.cwarp + "_END:")
        f[start + pos] = self.cwarp + "_END:"
        # append end if processed cwarp
        f[start + pos+1]="end"
        #f.writelines(self.cwarp + "_End\n")
        #print("{0} pass is finished".format(name))
                        
                                            
    def remove_loop_dead(self):
        for i in range(self.fun_num):
            bbs = self.functions[i].get_bbuf()
            for bb in bbs:
                if bb.bname == "CWARP2_LOOP0_COL":
                    insts = bb.get_insts()
                    for inst in insts:
                        # remove dead code set x coord for row unroll case as x not changed 
                        if inst.opc == "smovg" and int(inst.dstreg[0].regno) == 2:
                            bb.remove_inst(inst)

    def amend_new_conv(self, conv):
        if len(conv) == 2:
            return conv
        else:
            has_z0 = True
            while has_z0:
                if len(conv) == 2:
                    has_z0 = False
                    break
                for i in range(len(conv) - 1):
                    key = (conv[i+1].srcreg[0].type + str(conv[i+1].srcreg[0].regno))
                    print("key is", key)
                    if key == "z0" and len(conv) > 2:
                        has_z0 = True
                        if i+1 == len(conv) - 1:
                            conv[i].mod.append("eog")
                        conv.remove(conv[i+1])
                        break
                    if i == len(conv) - 2:
                        has_z0 = False
            
            for i in range(len(conv) - 1):
                if i == 0:
                    conv[i+1].opc = "mov"
                else:
                    if conv[i+1].opc == "mov":
                        conv[i+1].opc = "smovg"
                if i == len(conv) - 2:
                    if "eog" not in conv[i+1].mod:
                        conv[i+1].mod.append("eog")
                else:
                    if "eog" in conv[i+1].mod:
                        conv[i+1].mod.remove("eog")
            
            stage_list = []
            dic_list = {}
            pos_list = {}
            #key_list = []
            for i in range(len(conv) - 1):
                key = (conv[i+1].dstreg[0].type + str(conv[i+1].dstreg[0].regno)) 
                if not (key in stage_list):
                    stage_list.append(key)
                    dic_list[key] = 1
                    pos_list[key] = i+1
                else:
                    dic_list[key] += 1
                    pos_list[key] = i+1
                    #key_list.append(key)
            print("stage list", stage_list)
            print("dic list", dic_list)
            print("pos list", pos_list)

            for key in dic_list.keys():
                if dic_list[key] > 1:
                    key_num = dic_list[key]
                    while key_num > 1:
                        for i in range(len(conv)-1):
                            if key == conv[i+1].dstreg[0].type + str(conv[i+1].dstreg[0].regno):
                                conv.remove(conv[i+1])
                                break
                        key_num -=1

            for i in range(len(conv) - 1):
                if i == 0:
                    conv[i+1].opc = "mov"
                else:
                    if conv[i+1].opc == "mov":
                        conv[i+1].opc = "smovg"
                if i == len(conv) - 2:
                    if "eog" not in conv[i+1].mod:
                        conv[i+1].mod.append("eog")
                else:
                    if "eog" in conv[i+1].mod:
                        conv[i+1].mod.remove("eog")
            if len(conv) >= 2:
                key = (conv[1].dstreg[0].type + str(conv[1].dstreg[0].regno))
                if key != "g0":
                    null_inst=copy.deepcopy(conv[1])
                    null_inst.opc = "mov"
                    null_inst.mod = []
                    null_inst.dstreg[0].type = "g"
                    null_inst.dstreg[0].regno = "0"
                    null_inst.srcreg[0].type = "z"
                    null_inst.srcreg[0].regno = "0"
                    null_inst.dstmod = []
                    null_inst.dstmod.append("u32")
                    null_inst.src1mod = []
                    null_inst.src1mod.append("u32")
                    conv.insert(1,null_inst)
                    if conv[2].opc == "mov":
                        conv[2].opc = "smovg"

            for l in range(len(conv)-1):
                if conv[l+1].opc == "smovg":
                    conv[l+1].dstmod = []
                    conv[l+1].src1mod = []

            #for p in range(len(conv)):
            #        print("conv before log", conv[p].opc, conv[p].mod)

            for l in range(len(conv) - 2):
                if conv[l+2].dstreg[0].type + str(conv[l+2].dstreg[0].regno) == "g0":
                    #print("found a delay g0",conv[l+2].opc)
                    if conv[l+2].opc == "smovg":
                        conv[1].srcreg[0].type = conv[l+2].srcreg[0].type
                        conv[1].srcreg[0].regno = conv[l+2].srcreg[0].regno
                    else:
                        new_inst = copy.deepcopy(conv[l+2])
                        print("new inst opc ", new_inst.opc)
                        conv.insert(1, new_inst)
                        conv.remove(conv[2])
                    conv.remove(conv[l+2])
                    break


            return conv


    def has_mask(self, conv, reg):
        print("check if conv has reg", reg)
        for i in range(len(conv) - 1):
            print("conv list opc dst",conv[i+1].opc, len(conv[i+1].dstreg))
            for s in range(len(conv[i+1].dstreg)):
                print("dst reg", conv[i+1].dstreg[s].name, conv[i+1].dstreg[s].type + str(conv[i+1].dstreg[s].regno))
            for s in range(len(conv[i+1].dstreg)):
                if reg == conv[i+1].dstreg[s].type + str(conv[i+1].dstreg[s].regno):
                    return True
        return False

    def has_mod(self, conv, reg):
        print("check if conv has dst mod", reg)
        dic = {"g2":"incx1","g3":"incy1","g4":"incz1"} 
        if dic[reg] in conv[0].mod:
            return True
        else:
            return False


    def mask_idx(self, conv, reg):
        print("check if conv has reg", reg)
        for i in range(len(conv) - 1):
            print("conv list opc dst",conv[i+1].opc, len(conv[i+1].dstreg))
            for s in range(len(conv[i+1].dstreg)):
                print("dst reg", conv[i+1].dstreg[s].name, conv[i+1].dstreg[s].type + str(conv[i+1].dstreg[s].regno))
            for s in range(len(conv[i+1].dstreg)):
                if reg == conv[i+1].dstreg[s].type + str(conv[i+1].dstreg[s].regno):
                    return True, i+1
        return False, 0

    def judge_combine_pair(self, conv1, conv2, conv1_pos, conv2_pos):
        #print("Judge conv1 ", conv1)
        #print("Judge conv2 ", conv2)
        #print("Judge conv1 pos", conv1_pos)
        #print("Judge conv2 pos", conv2_pos)
        if_combine = True
        if conv1_pos[1] + 1 != conv2_pos[0]: # Deal simple cases that two neibor insts
            return False, []
        else:
            if conv1[0].mod[0] == "off" and conv2[0].mod[0] == "on":
                print("Off to On combine")
                cond_sat = False
                new_conv_inst = copy.deepcopy(conv2)
                i = 1
                if new_conv_inst[1].opc == "mov":
                    new_conv_inst[1].opc = "smovg"
                for j in range(len(conv1)-1):
                    new_inst = copy.deepcopy(conv1[j+1])
                    new_conv_inst.insert(i, new_inst)
                    if len(conv1[j+1].mod) > 0 and "eog" in conv1[j+1].mod:
                        new_conv_inst[i].mod.remove("eog")
                        #conv1[j+1].mod.remove("eog")
                    i += 1
                if conv1[0].opc == "ldconv0" or conv1[0].opc == "ldconv1":
                    #Check X Start
                    if self.has_mask(conv2, "g2"):
                        print("x mask true")
                        cond_sat = True
                    else:
                        if "setx" in conv1[0].mod:
                            if "incx1" in conv2[0].mod:
                                cond_sat = True
                            elif "incx0" in conv2[0].mod:
                                cond_sat = True
                                for r in range(len(new_conv_inst[0].mod)):
                                    if new_conv_inst[0].mod[r] == "incx0":
                                        new_conv_inst[0].mod[r] = "setx"
                            else:
                                cond_sat = False
                        elif "incx0" in conv1[0].mod: 
                            if "incx1" in conv2[0].mod or "incx0" in conv2[0].mod:
                                cond_sat = True
                            else:
                                cond_sat = False
                        elif "resetx" in conv1[0].mod:
                            if "incx1" in conv2[0].mod:
                                cond_sat = True
                            else:
                                cond_sat = False
                        else:
                            cond_sat = False
                    if cond_sat == False:
                        return False, []
                    #Check Y Start
                    if self.has_mask(conv2, "g3"):
                        print("y mask true")
                        cond_sat = True
                    else:
                        if "sety" in conv1[0].mod:
                            if "incy1" in conv2[0].mod:
                                cond_sat = True
                            elif "incy0" in conv2[0].mod:
                                cond_sat = True
                                for r in range(len(new_conv_inst[0].mod)):
                                    if new_conv_inst[0].mod[r] == "incy0":
                                        new_conv_inst[0].mod[r] = "sety"
                            else:
                                cond_sat = False
                        elif "incy0" in conv1[0].mod: 
                            if "incy1" in conv2[0].mod or "incy0" in conv2[0].mod:
                                cond_sat = True
                            else:
                                cond_sat = False
                        elif "resety" in conv1[0].mod:
                            if "incy1" in conv2[0].mod:
                                cond_sat = True
                            else:
                                cond_sat = False
                        else:
                            cond_sat = False
                    if cond_sat == False:
                        return False, []

                    #Check Z Start
                    if self.has_mask(conv2, "g4"):
                        print("z mask true")
                        cond_sat = True
                    else:
                        if "setz" in conv1[0].mod:
                            if "incz1" in conv2[0].mod:
                                cond_sat = True
                            elif "incz0" in conv2[0].mod:
                                cond_sat = True
                                for r in range(len(new_conv_inst[0].mod)):
                                    if new_conv_inst[0].mod[r] == "incz0":
                                        new_conv_inst[0].mod[r] = "setz"
                            else:
                                cond_sat = False
                        elif "incz0" in conv1[0].mod: 
                            if "incz1" in conv2[0].mod or "incz0" in conv2[0].mod:
                                cond_sat = True
                            else:
                                cond_sat = False
                        elif "resetz" in conv1[0].mod:
                            if "incz1" in conv2[0].mod:
                                cond_sat = True
                            else:
                                cond_sat = False
                        else:
                            cond_sat = False
                    if cond_sat == False:
                        return False, []

                if conv1[0].opc == "conv":
                    cond_sat = True

                if "wset" in conv1[0].mod:
                    if "wnil" not in conv2[0].mod:
                        print("wset out false")
                        return False, []
                    else:
                        cond_sat = True
                        for r in range(len(new_conv_inst[0].mod)):
                            if new_conv_inst[0].mod[r] == "wnil":
                                new_conv_inst[0].mod[r] = "wset"
                if cond_sat == True:
                    new_conv_inst[0].comments += "   "
                    new_conv_inst[0].comments += "Off to On Combine merge"
                    return True, new_conv_inst
                else:
                    return False, []
            elif conv1[0].mod[0] == "on" and conv2[0].mod[0] == "off":
                print("On to Off combine")
                cond_sat = False
                new_conv_inst = copy.deepcopy(conv1)
                new_conv_inst[-1].mod.remove("eog")
                for j in range(len(conv2)-1):
                    new_inst = copy.deepcopy(conv2[j+1])
                    new_conv_inst.append(new_inst)
                if "incx0" in conv1[0].mod:
                    if "incx1" in conv2[0].mod:
                        cond_sat = True
                        for r in range(len(new_conv_inst[0].mod)):
                            if new_conv_inst[0].mod[r] == "incx0":
                                new_conv_inst[0].mod[r] = "incx1"
                    elif "incx0" in conv2[0].mod:
                        cond_sat = True
                    else:
                        cond_sat = False
                elif "incx1" in conv1[0].mod:
                    if "incx0" in conv2[0].mod and (not self.has_mask(conv2, "g2")):
                        cond_sat = True
                    elif "setx" in conv2[0].mod or "resetx" in conv2[0].mod:
                        cond_sat = False
                
                if cond_sat == False:
                        return False, []

                if "incy0" in conv1[0].mod:
                    if "incy1" in conv2[0].mod:
                        cond_sat = True
                        for r in range(len(new_conv_inst[0].mod)):
                            if new_conv_inst[0].mod[r] == "incy0":
                                new_conv_inst[0].mod[r] = "incy1"
                    elif "incy0" in conv2[0].mod:
                        cond_sat = True
                    else:
                        cond_sat = False
                elif "incy1" in conv1[0].mod:
                    if "incy0" in conv2[0].mod and (not self.has_mask(conv2, "g3")):
                        cond_sat = True
                    elif "sety" in conv2[0].mod or "resety" in conv2[0].mod:
                        cond_sat = False


                if cond_sat == False:
                        return False, []

                if "incz0" in conv1[0].mod:
                    if "incz1" in conv2[0].mod:
                        cond_sat = True
                        for r in range(len(new_conv_inst[0].mod)):
                            if new_conv_inst[0].mod[r] == "incz0":
                                new_conv_inst[0].mod[r] = "incz1"
                    elif "incz0" in conv2[0].mod:
                        cond_sat = True
                    else:
                        cond_sat = False
                elif "incz1" in conv1[0].mod:
                    if "incz0" in conv2[0].mod and (not self.has_mask(conv2, "g4")):
                        cond_sat = True
                    elif "setz" in conv2[0].mod or "resetz" in conv2[0].mod:
                        cond_sat = False

                if cond_sat == False:
                        return False, []

                if "snil" in conv1[0].mod:
                    if "sset" in conv2[0].mod:
                        cond_sat = True
                        for r in range(len(new_conv_inst[0].mod)):
                            if new_conv_inst[0].mod[r] == "snil":
                                new_conv_inst[0].mod[r] = "sset"
                    elif "sinc" in conv2[0].mod:
                        cond_sat = True
                        for r in range(len(new_conv_inst[0].mod)):
                            if new_conv_inst[0].mod[r] == "snil":
                                new_conv_inst[0].mod[r] = "sinc"
                    elif "snil" in conv2[0].mod:
                        cond_sat = True
                    else:
                        cond_sat = False
                if cond_sat == False:
                        return False, []
                if cond_sat == True:
                    new_conv_inst[0].comments += "   "
                    new_conv_inst[0].comments += "On to Off Combine merge"
                    return True, new_conv_inst
                else:
                    return False, []
            else:
                return False, [] 
        #return if_combine
    """
    def reorg_bb(self, bb, conv1, conv2, conv1_pos, conv2_pos):
        print("Reorg conv1", conv1)
        print("Reorg conv2", conv2)
        print("Reorg conv1 pos", conv1_pos)
        print("Reorg conv2 pos", conv2_pos)
        return True
    """

    def combine_on_off(self):
         for i in range(self.fun_num):
             bbs = self.functions[i].get_bbuf()
             #print("Print len bbs",len(bbs))
             for bb in bbs:
                 bb_canbe_combine = True
                 round_id = 0
                 while bb_canbe_combine:
                    insts = bb.get_insts()
                    conv_inst_num = 0
                    #print("BB name and inst size in round", bb.bname, len(insts), round_id)
                    for inst in insts:
                        #print("Inst opc, inst mod", inst.opc, inst.mod)
                        # remove dead code set x coord for row unroll case as x not changed
                        if inst.opc == "ldconv0" or inst.opc == "ldconv1" or inst.opc == "conv":
                            conv_inst_num = conv_inst_num + 1
                    #print("conv inst num", conv_inst_num)
                    if conv_inst_num > 1:
                        #print("Stastic combine candidate")
                        conv_inst_lists = [[] for i in range(conv_inst_num)]
                        conv_inst_pos = [[] for i in range(conv_inst_num)]
                        i = 0
                        for index, inst in enumerate(insts):
                            #print("b1 inst opc, inst mod", inst.opc, inst.mod)
                            if inst.opc == "ldconv0" or inst.opc == "ldconv1" or inst.opc == "conv":
                                #conv_inst_lists[i].append(inst)
                                inner_index = index
                                inner_inst = insts[index]
                                conv_inst_pos[i].append(inner_index) ## Conv inst Start
                                #print("inner_index and inner_inst", inner_index, inner_inst.opc)
                                while not ((inner_inst.opc == "smovg" or inner_inst.opc == "mov" or inner_inst.opc == "xor" or inner_inst.opc == "saddg")  
                                   and (len(inner_inst.mod) > 0) and (inner_inst.mod[-1] == "eog")):
                                    #print("b2 inst opc, inst mod", inner_inst.opc, inner_inst.mod)
                                    conv_inst_lists[i].append(inner_inst)
                                    inner_index += 1
                                    inner_inst = insts[inner_index]
                                conv_inst_lists[i].append(inner_inst)
                                conv_inst_pos[i].append(inner_index) ## Conv inst End
                                #print("conv inst list i len", i, len(conv_inst_lists[i]))
                                i+=1
                            """
                            (1) Find first combine candidate or find nothing
                            """
                        found_candidate = False
                        for s in range(len(conv_inst_lists) - 1):
                            if_c, new_conv_inst = self.judge_combine_pair(conv_inst_lists[s], conv_inst_lists[s+1], conv_inst_pos[s], conv_inst_pos[s+1])
                            if if_c:
                                print("found a combine pair in round id", round_id)
                                new_conv_inst = self.amend_new_conv(new_conv_inst)
                            if if_c:
                                for r in range(len(conv_inst_lists[s])):
                                   bb.remove_inst(conv_inst_lists[s][r])
                                for r in range(len(conv_inst_lists[s+1])):
                                   bb.remove_inst(conv_inst_lists[s+1][r]) 
                                for r in range(len(new_conv_inst)):
                                    bb.insert_inst_pos(new_conv_inst[r], conv_inst_pos[s][0] + r)
                                bb_canbe_combine = True
                                break
                            if not if_c and s == len(conv_inst_lists) - 2:
                                bb_canbe_combine = False

                                #rm_len = len(conv_inst_list[s]) + len(conv_inst_lists[s+1])
                                #self.reorg_bb(bb, conv_inst_lists[s], conv_inst_lists[s+1], conv_inst_pos[s], conv_inst_pos[s+1])
                            """
                            (2) If find candidate reorg the bb
                            """
                    else:
                        bb_canbe_combine = False
                        break
                    round_id +=1
                    #bb_canbe_combine = False
                    #    bb.remove_inst(inst)

    def extract_same_register(self): #use use-def relation implicity
        for i in range(self.fun_num):
            bbs = self.functions[i].get_bbuf()
            print("bbs size is ", len(bbs))
            for bb in bbs:
                insts = bb.get_insts()
                print("BB name and inst size in round", bb.bname, len(insts))
                conv_inst_num = 0
                for inst in insts:
                    if inst.opc == "ldconv0" or inst.opc == "ldconv1" or inst.opc == "conv"\
                    or inst.opc == "ldm" or inst.opc == "stm":
                        conv_inst_num = conv_inst_num + 1
                if conv_inst_num > 1:
                    conv_inst_lists = [[] for i in range(conv_inst_num)]
                    conv_inst_pos = [[] for i in range(conv_inst_num)]
                    i = 0
                    for index, inst in enumerate(insts):
                        if inst.opc == "ldconv0" or inst.opc == "ldconv1" or inst.opc == "conv"\
                        or inst.opc == "ldm" or inst.opc == "stm":
                            inner_index = index
                            inner_inst = insts[index]
                            conv_inst_pos[i].append(inner_index) ## Conv inst Start
                            while not ((inner_inst.opc == "smovg" or inner_inst.opc == "mov" or inner_inst.opc == "xor" or inner_inst.opc == "saddg")  
                            and (len(inner_inst.mod) > 0) and (inner_inst.mod[-1] == "eog")):
                                conv_inst_lists[i].append(inner_inst)
                                inner_index += 1
                                inner_inst = insts[inner_index]
                            conv_inst_lists[i].append(inner_inst)
                            conv_inst_pos[i].append(inner_index) ## Conv inst End
                            i+=1
                    print("conv_inst_num is ", conv_inst_num)
                    for l in range(len(conv_inst_pos)):
                        print("PYN conv i start and end", conv_inst_pos[l][0], conv_inst_pos[l][1])
                    conv_list_start=[]
                    conv_list_end=[]
                    start = 0
                    end = 0
                    s = 0
                    while s <= len(conv_inst_lists) - 1 and start <= len(conv_inst_lists) - 2:
                        start = s
                        end = start
                        while conv_inst_pos[end][1] + 1 == conv_inst_pos[end+1][0]:
                            if end + 1 != len(conv_inst_lists):
                                end += 1
                                if end == len(conv_inst_lists) - 1:
                                    break
                            else:
                                break
                        if start == end:
                            start += 1
                            end = start
                        else:
                            conv_list_start.append(start)
                            conv_list_end.append(end)
                            start = end + 1
                            end = start
                        s = end
                    if len(conv_list_start ) > 0:
                        l = 0
                        while l < len(conv_list_start):
                            found_sub_list = False
                            print("conv list start and end",conv_list_start[l], conv_list_end[l])
                            for si in range(conv_list_start[l], conv_list_end[l]):
                                for ei in range(conv_list_end[l], si, -1):
                                    print("PYN si is", si)
                                    print("PYN ei is", ei)
                                    start = si
                                    end = ei
                                    staging_redunt_chain = False
                                    for k in range(2, 5):
                                        staging_redunt_chain = False
                                        dst = "g"+str(k)
                                        if self.has_mask(conv_inst_lists[start], dst):
                                            print("found start g", dst)
                                            staging_redunt_chain = True
                                            if_mask, src = self.mask_idx(conv_inst_lists[start], dst)
                                            for li in range(start+1, end+1):
                                                if not self.has_mask(conv_inst_lists[li], dst):
                                                    if not self.has_mod(conv_inst_lists[li], dst):
                                                        continue
                                                    else:
                                                        staging_redunt_chain = False
                                                        break
                                                else:
                                                    if_mask, src_tail = self.mask_idx(conv_inst_lists[li], dst) 
                                                    if conv_inst_lists[start][src].srcreg[0].type + str(conv_inst_lists[start][src].srcreg[0].regno) ==\
                                                    conv_inst_lists[li][src_tail].srcreg[0].type + str(conv_inst_lists[li][src_tail].srcreg[0].regno):
                                                        continue
                                                    else:
                                                        staging_redunt_chain = False
                                                        break
                                            if staging_redunt_chain:
                                                found_sub_list = True
                                                print("found end g", dst)
                                                for di in range(start+1, end+1):
                                                    if_mask, src_idx = self.mask_idx(conv_inst_lists[di], dst)
                                                    if if_mask:
                                                        idx = conv_inst_pos[di][0] + src_idx
                                                        print("idx is ", idx)
                                                        insts[idx].opc = "DEL"
                                        else:
                                            continue
                                    if found_sub_list == True:
                                        print("found sub list in si ei",si, ei)
                                        break
                                if found_sub_list == True:
                                    break
                            l += 1
                        has_del = True
                        while has_del:
                            insts = bb.get_insts()
                            for ll in range(len(insts)):
                                if insts[ll].opc == "DEL":
                                    if len(insts[ll].mod) == 0 or (len(insts[ll].mod) > 0 and insts[ll].mod[-1] != "eog"):
                                        bb.remove_inst(insts[ll])
                                        break
                                    elif len(insts[ll].mod) > 0 and insts[ll].mod[-1] == "eog" and ll >= 2 and \
                                            (insts[ll-2].opc == "ldconv0" or insts[ll-2].opc == "ldconv1" or insts[ll-2].opc == "conv"):
                                        bb.remove_inst(insts[ll])
                                        break
                                    elif len(insts[ll].mod) > 0 and insts[ll].mod[-1] == "eog" and ll >= 2 and \
                                            (insts[ll-2].opc != "ldconv0" and insts[ll-2].opc != "ldconv1" and insts[ll-2].opc != "conv"):
                                        insts[ll-1].mod.append("eog")
                                        bb.remove_inst(insts[ll])
                                        break
                                if ll == len(insts) - 1:
                                    has_del = False

                else:
                    continue




            
                        
                    

