from code_generator.backend.BaseReg import Reg

class WSR(Reg):
    def __init__(self, no, instno, isdst=False):
        super(WSR, self).__init__(no, instno, "q", isdst)
        #print("construct WSR:", no)
        self.max_reg = 32
