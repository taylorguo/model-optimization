# Backend
Used to process generated instructions

## Arguments
+ asmfile
  - this argument is used to mark the file need to be processed. usage: **python xxx.py --style 0**

## example
```python test_stride2_width1.py --style 0```

## output
- After program finished，will generate optimized .S files，such as xxx.s.opt0.
- You can compare xxx.s.opt with xxx.s to verify optimization results.

