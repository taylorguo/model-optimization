from code_generator.backend.BaseReg import Reg

class CSR(Reg):
    def __init__(self, no, instno, isdst=False):
        super(CSR, self).__init__(no, instno, "c", isdst)
        # print("construct CSR:", no)
        self.max_reg = 1024
