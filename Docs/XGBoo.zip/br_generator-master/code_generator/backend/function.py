from __future__ import print_function

import os
import json
import re
import string
from code_generator.backend.BasicBlock import BB
from code_generator.backend.Instruction import Instruction
import sys

from code_generator.backend.Instdef import InstMapping

class AsmFun(object):
    def __init__(self, name):
        self.fname = name
        self.BBbuf = list()
        self.num_bb = 0
        self.cur_bb = None
        self.inst_num = 0
        self.usharp_num = 0
        self.inst_buf = list()
        self.insts = list()
        self.reg_dict = dict()
        self.reg_dict["tlr"]=[]
        self.reg_dict["wsr"]=[]
        self.reg_dict["csr"]=[]
        self.reg_dict["sr"]=[]
        self.reg_dict["Imm"]=[]
        self.reg_dict['usharp']=[]
        self.inst_table = InstMapping().get_inst_table()

    def reset(self):

        for bb in self.BBbuf:
            bb.reset()

        self.fname = ""
        self.BBbuf = list()
        self.num_bb = 0
        self.cur_bb = None
        self.inst_num = 0
        self.usharp_num = 0
        self.inst_buf = list(tuple())
        self.insts = list()
        self.reg_dict = dict()
        self.reg_dict["tlr"]=[]
        self.reg_dict["wsr"]=[]
        self.reg_dict["csr"]=[]
        self.reg_dict["sr"]=[]
        self.reg_dict["Imm"]=[]
        self.reg_dict['usharp']=[]

    def build_function(self, inst):
        self.inst_buf.append(inst)
        #if self.cur_bb == None:
        #    self.cur_bb = BB()
        #self.cur_bb.insert_inst(inst)
    def insert_inst(self, inst, comm, tab):
        self.inst_buf.append((inst, comm, tab))
    def analyze_function(self):
        inst_num = 0
        jump = False
        bbname = None
        if self.cur_bb is None:
            self.cur_bb = BB("default")
            self.BBbuf.append(self.cur_bb)
            self.num_bb += 1
        for line in self.inst_buf:
            if line.find(":") != -1 or line.find("blts") != -1:
                if line.find("blts") != -1:
                    ss = line.split(',')
                    bbname = "jump" + ss[-1].strip()
                    jump = True
                else:
                    bbname = line[:-1]
                self.cur_bb = BB(bbname)
                self.BBbuf.append(self.cur_bb)
                self.num_bb += 1
                # skip label
                continue
            inst = line.split(',')

            #skip bundle & signW
            if inst[0].startswith("&"):
                inst[0] = inst[0][1:len(inst[0])]
            #check nop and end inst
            if inst[0].find("nop") != -1 or inst[0].find("end") != -1:
                mcinst = Instruction(inst_num, inst, None, None)
                self.insts.append(mcinst)
                self.cur_bb.insert_inst(mcinst)
                inst_num += 1
                continue #skip nop
            #check single inst, no src
            if len(inst) == 1:
                sp = inst[0].split(" ")
                #check no dsr
                if len(sp) == 1:
                    mcinst = Instruction(inst_num, inst, None, None)
                    self.insts.append(mcinst)
                    self.cur_bb.insert_inst(mcinst)
                elif len(sp) == 2:
                    mcinst = Instruction(inst_num, sp[0], sp[1], None)
                    self.insts.append(mcinst)
                    self.cur_bb.insert_inst(mcinst)
                    mcinst.compute_reg()
                inst_num += 1
                continue
            try:
                opc, dst = inst[0].split()
            except ValueError:
                raise Exception("process instruction {0} failed, please check it!".format(inst))
            #remove inst0 as opc & dst
            inst.pop(0)

            oprands_num = len(inst)
            operands = []
            src = []
            for i in range(oprands_num):
                src.append(inst[i])
            #print(opc, dst, src)

            mcinst =  Instruction(inst_num, opc, dst, src)
            mcinst.compute_reg()

            self.insts.append(mcinst)
            self.cur_bb.insert_inst(mcinst)
            dst_type, dst_regno = dst[0], dst[1:-1]

            src_num = len(src)
            inst_num += 1

            if jump:# after jump should be a new block
                bbname += "flat"
                self.cur_bb = BB(bbname)
                self.BBbuf.append(self.cur_bb)
                self.num_bb += 1
                jump = False
        self.inst_num = inst_num
            #for i in range(src_num):
            #    src + str(i) + "_type" =  src[i][0]
            #    src + str(i) + "regno" = src[i][1:-1]
    def compute_regs(self):
        for inst in self.insts:

            for dst in inst.dstreg:
                if dst.regno not in self.reg_dict[dst.type]:
                    self.reg_dict[dst.type].append(dst.regno)
                    #if dst.type == "Imm" and dst.usharp:
                    #    print(dst.type)
                    #    self.usharp_num += 1
            for i in range(inst.src_num):
                for src1 in inst.srcreg[i]:
                    if src1.regno not in self.reg_dict[src1.type]:
                        self.reg_dict[src1.type].append(src1.regno)
                        #if src1.type == "Imm" and src1.usharp:
                        #    self.usharp_num += 1

        #for key, value in self.reg_dict.items():
        #    print(key, value)
        return self.reg_dict

    def compute_usharp(self):
        for inst in self.insts:
            #print("get_usharp is ", inst.get_usharp())
            for u in inst.get_usharp():
                if u not in self.reg_dict['usharp']:
                    self.reg_dict['usharp'].append(u)
        #print("reg_dict is ", self.reg_dict)
        return len(self.reg_dict['usharp'])

    def get_insts(self):
        return self.inst_num
    
    def get_bbuf(self):
        return self.BBbuf

    def gen_inst(self):
        inst_num = 0
        jump = False
        bbname = None
        jump_flag = False
        if self.cur_bb is None:
            self.cur_bb = BB("default")
            self.BBbuf.append(self.cur_bb)
            self.num_bb += 1
        for tups in self.inst_buf:
            # strip & for bundle inst
            line = tups[0].strip()
            comm = tups[1]
            tab = tups[2]
            opc = ""
            if line.find(":") != -1 or line.find("blts") != -1:
                # blts should be a single block, jump to another block
                if line.find("blts") != -1:
                    ss = line.split(',')
                    bbname = "jump_" + ss[-1].strip()
                    jump = True
                    
                else:
                    bbname = line[:-1]
                    jump_flag = True
                newbb = BB(bbname, prev=self.cur_bb)
                self.cur_bb = newbb
                self.BBbuf.append(self.cur_bb)
                self.num_bb += 1
                print("bb num:", self.num_bb, " name:", bbname)
                # skip label
                if jump_flag:
                    jump_flag = False
                    continue

            inst = line.split(',')

            #skip bundle & signW
            if inst[0].startswith("&"):
                inst[0] = inst[0][1:len(inst[0])]
            #check nop and end inst
            if inst[0].find("nop") != -1 or inst[0].find("end") != -1:
                insts = inst[0].split('.')
                opc = insts[0]
                mods = insts[1:]
                #print("nop inst:", line, " opc:", opc)
                inst = self.inst_table[opc]
                mcinst = Instruction(inst_num, inst, mod=mods, comm=comm, tab=tab)
                self.insts.append(mcinst)
                self.cur_bb.insert_inst(mcinst)
                inst_num += 1
                continue #skip nop
            #check single inst, no src, like ackgmb
            if len(inst) == 1:
                sp = inst[0].split(" ")
                #print("inst is ", inst[0])
                #check no dsr
                if len(sp) == 1:
                    insts = sp[0].split('.')
                    opc = insts[0]
                    mods = insts[1:]
                    inst = self.inst_table[opc]
                    mcinst = Instruction(inst_num, inst, mod=mods, comm=comm, tab=tab)
                    self.insts.append(mcinst)
                    #print("single inst :", line)
                    self.cur_bb.insert_inst(mcinst)
                elif len(sp) == 2:# this is gemm instr
                    insts = sp[0].split('.')
                    opc = insts[0]
                    mods = insts[1:]
                    operands = []
                    operands.append(sp[1].strip())
                    inst = self.inst_table[opc]
                    inst.fill_inst(operands = operands)

                    mcinst = Instruction(inst_num, inst, mods, comm=comm, tab=tab)
                    mcinst.compute_inst(operands)

                    self.insts.append(mcinst)
                    self.cur_bb.insert_inst(mcinst)
                    #mcinst.compute_reg()
                inst_num += 1
                # optinize jump with last jump later
                if jump:# after jump should be a new block
                    bbname += "flat_"
                    newbb = BB(bbname, prev=self.cur_bb)
                    self.cur_bb = newbb
                    self.BBbuf.append(self.cur_bb)
                    self.num_bb += 1
                    print("bb num:", self.num_bb, " name:", bbname)
                    jump = False
                    self.inst_num = inst_num
                continue
            try:
                opc, dst = inst[0].split()
            except ValueError:
                raise Exception("process instruction {0} failed, please check it!".format(inst))
            #remove inst0 as opc & dst
            inst.pop(0)

            oprands_num = len(inst)
            operands = []
            src = []
            srcmods = []
            dstmod = None
            srcmod = None

            if len(dst.split('.')) > 1:
                dst, dstmod = dst.split('.')
            operands.append(dst)
            for i in range(oprands_num):
                srcl = []
                if len(inst[i].split('.')) > 1:
                    srcl = inst[i].split('.')
                    srci = srcl[0]
                else:
                    srci = inst[i]
                src.append(srci)
                if len(srcl)>1:
                    #for l in range(len(srcl)-1):
                    srcmods.append(srcl[1:-1])
                        #srcmod = None

                operands.append(srci)
            #print(opc, dst, src)
            opcm= opc.split('.')
            opc = opcm[0]
            mods = opcm[1:]

            inst = self.inst_table[opc]
            inst.fill_inst(operands = operands)
            mcinst =  Instruction(inst_num, inst, mods, comm=comm, tab=tab)
            #print(mcinst, opc, operands)
            mcinst.compute_inst(operands)

            if dstmod:
                mcinst.set_dst_modifier(dstmod)
            result = {
                0: lambda x: x,#print(x)
                1: lambda x: mcinst.set_src1_modifier(x[0]),
                2: lambda x: {mcinst.set_src2_modifier(x[0]), mcinst.set_src2_modifier(x[1])},
                3: lambda x: {mcinst.set_src2_modifier(x[0]), mcinst.set_src2_modifier(x[1]), mcinst.set_src3_modifier(x[2])}
            }
            try:
                result[len(srcmods)](srcmods)
            except KeyError:
                raise Exception("Set instruction {0} failed, please check operands {1}".format(opc, srcmods))

            self.insts.append(mcinst)
            self.cur_bb.insert_inst(mcinst)
            #dst_type, dst_regno = dst[0], dst[1:-1]

            #src_num = len(src)
            inst_num += 1

            if jump:# after jump should be a new block
                bbname += "flat_"
                newbb = BB(bbname, prev=self.cur_bb)
                self.cur_bb = newbb
                self.BBbuf.append(self.cur_bb)
                self.num_bb += 1
                print("bb num:", self.num_bb, " name:", bbname)
                jump = False
        self.inst_num = inst_num
            #for i in range(src_num):
            #    src + str(i) + "_type" =  src[i][0]
            #    src + str(i) + "regno" = src[i][1:-1]
