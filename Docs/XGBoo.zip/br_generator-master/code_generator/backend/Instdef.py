import sys
#sys.path.append('../')

import code_generator.share.br_vector_instructions_def as vid

class InstMapping(object):
    def __init__(self):
        self.name_2_inst = dict()
        self.name_2_inst["sadd"] = vid.sadd()
        self.name_2_inst["sadda"] = vid.sadda()
        self.name_2_inst["saddg"] = vid.saddg()
        self.name_2_inst["smov"] = vid.smov()
        self.name_2_inst["smovs"] = vid.smovs()
        self.name_2_inst["smovg"] = vid.smovg()
        self.name_2_inst["sxor"] = vid.sxor()
        self.name_2_inst["bne"] = vid.bne()
        self.name_2_inst["blts"] = vid.blts()
        self.name_2_inst["bltu"] = vid.bltu()
        self.name_2_inst["bles"] = vid.bles()
        self.name_2_inst["bleu"] = vid.bleu()
        self.name_2_inst["beq"] = vid.beq()
        self.name_2_inst["nop"] = vid.nop()
        self.name_2_inst["snop"] = vid.snop()
        self.name_2_inst["ackgmb"] = vid.ackgmb()

        self.name_2_inst["bar"] = vid.bar()
        self.name_2_inst["sleep"] = vid.sleep()
        self.name_2_inst["call"] = vid.call()
        self.name_2_inst["sand"] = vid.sand()
        self.name_2_inst["sor"] = vid.sor()
        self.name_2_inst["sshl"] = vid.sshl()
        self.name_2_inst["sshr"] = vid.sshr()
        self.name_2_inst["addu"] = vid.addu()
        self.name_2_inst["movi"] = vid.movi()
        self.name_2_inst["mov"] = vid.mov()
        self.name_2_inst["movw"] = vid.movw()
        self.name_2_inst["xor"] = vid.xor()
        self.name_2_inst["fadd"] = vid.fadd()
        self.name_2_inst["fmax"] = vid.fmax()
        self.name_2_inst["fmul"] = vid.fmul()
        self.name_2_inst["mulu"] = vid.mulu()
        self.name_2_inst["adds"] = vid.adds()
        self.name_2_inst["cmpu"] = vid.cmpu()
        self.name_2_inst["shl"] = vid.shl()
        self.name_2_inst["shr"] = vid.shr()
        self.name_2_inst["or"] = vid.vor()
        self.name_2_inst["fmad"] = vid.fmad()
        self.name_2_inst["madu"] = vid.madu()
    
        self.name_2_inst["stm"] = vid.stm()
        self.name_2_inst["sld"] = vid.sld()
        self.name_2_inst["sldm"] = vid.sldm()
        self.name_2_inst["ldm"] = vid.ldm()
        self.name_2_inst["lddw"] = vid.lddw()
        self.name_2_inst["wred"] = vid.wred()
        self.name_2_inst["sysid"] = vid.sysid()

        import code_generator.tcore.br_tcore_instructions_def as tid
        self.name_2_inst["ldconv0"] = tid.ldconv0()
        self.name_2_inst["ldconv1"] = tid.ldconv1()
        self.name_2_inst["conv"] = tid.conv()
        self.name_2_inst["ldmma0"] = tid.ldmma0()
        self.name_2_inst["ldmma1"] = tid.ldmma1()
        self.name_2_inst["mma"] = tid.mma()

    def get_inst_table(self):
        return self.name_2_inst
