import math as m

def gen_loop_begin(label, indent, q_n, n_iterations, comment):
    print(" "*indent+"smov q"+str(q_n)+",", str(n_iterations), "\t"*1+"//loop "+comment)
    print(" "*indent+label+":")
    print(" "*(indent+4)+"sadd q"+str(q_n)+",", "-1,", "q"+str(q_n))

def gen_loop_end(indent, q_n, label):
    print(" "*(indent+4)+"bne.rel 0, q"+str(q_n)+",", label, "\t"*1+"//end of "+label)


def gen_conv2d(inH, inW, inC, filterH, filterW, outC, weightUsharp, inUsharp, outUsharp, stride=1, dilation=1, padH=0, padW=0, sample=1, dtw="bf16", dta="bf16", dtr="bf16"):
    print("")
    print("//Conv2d")
    print("")
    
    '''
            print("MAIN_WARP_ENTRY_0:")
        
            print("smov q0, "+hex((dilation-1<<17) | (stride-1<<16) | (padH<<12) | (padW<<8) | (filterH<<4) | filterW))
            print("ldconv0.off.bs0.ich8.8x8.bf16.pb.setx.resety.resetz.tp0.moff.wnil.snil.ro.gc1 u"+str(inUsharp)+"\t//")
            print("&movi.eog g0.u32, 0")
            weightOchsInner = int(outC/32)
            print("smov q4, 0\t\t//")
            gen_loop_begin("loop_weight_ochs_inner", 0, 7, weightOchsInner, "och loop of weight")
            gen_loop_begin("loop_weight_ichs", 4, 12, m.ceil(inC/128), "ceil(inC/128), loop through input channels")
            print(" "*8+"ldconv0.on.bs0.och32.ich128."+dtw+".pb.incy0.incz1.tp0.dtg.wnil.snil.ro.gc1 "+"u"+str(inUsharp)+"\t//")
            print(" "*8+"&mov g0.u32, q4.u32")
            print(" "*8+"smovg.eog g1, 0")
            print(" "*8+"sadd q4, q4, 8")
            gen_loop_end(4, 12, "loop_weight_ichs")
            gen_loop_end(0, 7, "loop_weight_ochs_inner")
            print("")
    '''
    if (outC*inC*filterH*filterW<=128*1024):
        if (sample*inC*inH*inW > 128*1024):
            print("MAIN_WARP_ENTRY_0:")
        
            print("smov q0, "+hex((dilation-1<<17) | (stride-1<<16) | (padH<<12) | (padW<<8) | (filterH<<4) | filterW))
            print("ldconv0.off.bs0.ich128.bf16.pb.setx.resety.resetz.tp0.moff.wnil.snil.ro.gc1 u"+str(inUsharp)+"\t//")
            print("&movi.eog g0.u32, 0")
            weightOchsInner = int(outC/32)
            print("smov q4, 0\t\t//")
            gen_loop_begin("loop_weight_ochs_inner", 0, 7, weightOchsInner, "och loop of weight")
            gen_loop_begin("loop_weight_ichs", 4, 12, m.ceil(inC/128), "ceil(inC/128), loop through input channels")
            print(" "*8+"ldconv0.on.bs0.ich128."+dtw+".pb.incy0.incz1.tp0.dtg.wnil.snil.ro.gc1 "+"u"+str(inUsharp)+"\t//")
            print(" "*8+"&mov g0.u32, q4.u32")
            print(" "*8+"smovg.eog g1, 0")
            print(" "*8+"sadd q4, q4, 8")
            gen_loop_end(4, 12, "loop_weight_ichs")
            gen_loop_end(0, 7, "loop_weight_ochs_inner")
            print("")
            
            print("MAIN_WARP_ENTRY_1:")
            ochsInnerCount = 8 #min(m.ceilint(outC/32)), 8)
            
            indent = 0
            print("smov q5, 0")
            print("smov q4, 0\t\t//")
            print("ldconv1.off.bs0.ich128.8x8.bf16.pb.resetx.resety.resetz.tp0.moff.wset.sset.ro.gc1 "+"u"+str(inUsharp)+"\t//")
            print("&movi g0.u32, 0")
            print("smovg g8, 0")
            print("smovg.eog g9, 0")
     
            gen_loop_begin("loop_bbuf_ochs_outer", indent, 7, int(outC/ochsInnerCount), "och outer loop")
            indent += 4
            
            if sample >1:
                gen_loop_begin("loop_bbuf_samples", indent, 9, sample, "sample, loop for #samples")
                indent += 4
                print(" "*(indent+0)+"sadd q5, q5, 1")
            gen_loop_begin("loop_bbuf_rows", indent+0, 10, m.ceil(inH/8), "ceil(inH/8), loop through all rows of 8*8 blocks")
            gen_loop_begin("loop_bbufcolumns", indent+4, 11, m.ceil(inW/8), "ceil(inW/8), loop through one row of 8*8 blocks")
            
            k = 0
            for k in range(int(inC/128)):     #loop through input channels for 16K data blocks
                if inC == ((int(inC/128))*128) and k == (int(inC/128) - 1):
                    print(" "*(indent+8)+"ldconv1.on.bs0.ich128.8x8."+dta+".pb.incx1.incy0.resetz.tp0.moff.winc.sinc.ro.gc1 "+"u"+str(inUsharp)+"\t//16KB")
                else:
                    print(" "*(indent+8)+"ldconv1.on.bs0.ich128.8x8."+dta+".pb.incx0.incy0.incz1.tp0.moff.winc.sinc.ro.gc1 "+"u"+str(inUsharp)+"\t//16KB")
                print(" "*(indent+8)+"&addu.b32.eog g0, "+str(k%8*16)+", q4")
                if k%8 == 7:
                    print(" "*(indent+8)+"sadd q4, 128, q4")

            if int(inC/128) != 0:
                k += 1    
            inCLeft = inC - ((int(inC/128))*128)
            waitgsc = "winc"
            offset = k%8*16
            waitgsc = "winc"

            if inCLeft > 64:
                print(" "*(indent+8)+"ldconv1.on.bs0.ich64.8x8."+dta+".pb.incx0.incy0.incz1.tp0.moff.winc.snil.ro.gc1 "+"u"+str(inUsharp)+"\t//8KB")
                print(" "*(indent+8)+"&addu.b32.eog g0, "+str(offset)+", q4")
                offset += 8
                waitgsc = "wnil"
                inCLeft = inCLeft - 64
            if inCLeft == 64:
                print(" "*(indent+8)+"ldconv1.on.bs0.ich64.8x8."+dta+".pb.incx1.incy0.resetz.tp0.moff."+str(waitgsc)+".sinc.ro.gc1 "+"u"+str(inUsharp)+"\t//8KB")
                print(" "*(indent+8)+"&addu.b32.b32.eog g0, "+str(offset)+", q4")
                offset += 8
                inCLeft = 0
            if inCLeft > 32:
                print(" "*(indent+8)+"ldconv1.on.bs0.ich32.8x8."+dta+".pb.incx0.incy0.incz1.tp0.moff."+str(waitgsc)+".snil.ro.gc1 "+"u"+str(inUsharp)+"\t//4KB")
                print(" "*(indent+8)+"&addu.b32.b32.eog g0, "+str(offset)+", q4")
                offset += 4
                waitgsc = "wnil"
                inCLeft = inCLeft - 32
            if inCLeft == 32:
                print(" "*(indent+8)+"ldconv1.on.bs0.ich32.8x8."+dta+".pb.incx1.incy0.resetz.tp0.moff."+str(waitgsc)+".sinc.ro.gc1 "+"u"+str(inUsharp)+"\t//8KB")
                print(" "*(indent+8)+"&addu.b32.b32.eog g0, "+str(offset)+", q4")
                offset += 4
                inCLeft = 0
            if inCLeft > 24:
                print(" "*(indent+8)+"ldconv1.on.bs0.ich8.8x8."+dta+".pb.incx0.incy0.incz1.tp0.moff."+str(waitgsc)+".snil.ro.gc1 "+"u"+str(inUsharp)+"\t//1KB")
                print(" "*(indent+8)+"&addu.b32.eog g0, "+str(offset)+", q4")
                offset += 1
                waitgsc = "wnil"
                inCLeft = inCLeft - 8
            if inCLeft > 16:
                print(" "*(indent+8)+"ldconv1.on.bs0.ich8.8x8."+dta+".pb.incx0.incy0.incz1.tp0.moff."+str(waitgsc)+".snil.ro.gc1 "+"u"+str(inUsharp)+"\t//1KB")
                print(" "*(indent+8)+"&addu.b32.eog g0, "+str(offset)+", q4")
                offset += 1
                waitgsc = "wnil"
                inCLeft = inCLeft - 8
            if inCLeft > 8:
                print(" "*(indent+8)+"ldconv1.on.bs0.ich8.8x8."+dta+".pb.incx0.incy0.incz1.tp0.moff."+str(waitgsc)+".snil.ro.gc1 "+"u"+str(inUsharp)+"\t//1KB")
                print(" "*(indent+8)+"&addu.b32.eog g0, "+str(offset)+", q4")
                offset += 1
                waitgsc = "wnil"
                inCLeft = inCLeft - 8
            if inCLeft == 8:
                print(" "*(indent+8)+"ldconv1.on.bs0.ich8.8x8."+dta+".pb.incx1.incy0.resetz.tp0.moff."+str(waitgsc)+".sinc.ro.gc1 "+"u"+str(inUsharp)+"\t//1KB")
                print(" "*(indent+8)+"&addu.b32.eog g0, "+str(offset)+", q4")
                offset += 1
                inCLeft = 0
            if inCLeft > 0:
                print(" "*(indent+8)+"ldconv1.on.bs0.ich8.8x8."+dta+".pb.incx1.incy0.resetz.tp0.moff."+str(waitgsc)+".sinc.ro.gc1 "+"u"+str(inUsharp)+"\t//1KB")
                print(" "*(indent+8)+"&addu.b32.eog g0, "+str(offset)+", q4")
                offset += 1
            print(" "*(indent+8)+"sadd q4, "+str(offset)+", q4")

            gen_loop_end(indent+4, 11, "loop_bbuf_columns")
            print("")
            print(" "*(indent+4)+"ldconv1.off.bs0.ich64.8x8.bf16.pb.resetx.incy1.incz0.tp0.moff.wnil.snil.ro.gc1 u"+str(inUsharp)+"\t//")
            print(" "*(indent+4)+"&movi.eog g0.u32, 0")
            gen_loop_end(indent, 10, "loop_bbuf_rows")

            if sample >1:
                print(" "*(indent+0)+"ldconv1.off.bs0.ich64.8x8.bf16.pb.resetx.resety.incz0.tp0.moff.wnil.snil.ro.gc1 u"+str(inUsharp)+"\t//")
                print(" "*(indent+0)+"&movi g0.u32, 0")
                print(" "*(indent+0)+"&mov.eog g4.u32, q5.u32")
                gen_loop_end(indent-4, 9, "loop_bbuf_samples")
            gen_loop_end(0, 7, "loop_bbuf_ochs_outer")
            print("")
            
            #conv
            print("MAIN_WARP_ENTRY_2:")

            print("smov q1, 0\t\t//")
            print("smov q4, 0\t\t//")
            print("smov q3, 0\t\t//")
            print("smov q16, 0\t\t//")
            print("conv.off.oc32.ich128."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff.wset.sset r0, "+"u"+str(outUsharp)+"\t//")
            print("&movi g0.u32, 0")
            print("smovg g8, 0")
            print("smovg.eog g9, 0")
            print("")
            
            gen_loop_begin("loop_conv_ochs_outer", 0, 7, int(outC/ochsInnerCount), "och outer loop")
            
            indent = 0
            print("    smov q5, 0\t\t//sample index")
            print("    smov q6, q1\t\t//")
            print("    sxor q1, q1, 8\t\t//")
            
            if sample > 1:
                gen_loop_begin("loop_conv_samples", 4, 9, sample, "sample, loop for #samples")
                indent = 8
                print(" "*(indent+0)+"sadd q5, q5, 1")
            gen_loop_begin("loop_conv_rows", indent+0, 10, m.ceil(inH/8), "ceil(inH/8), loop through all rows of 8*8 blocks")
            gen_loop_begin("loop_conv_columns", indent+4, 11, m.ceil(inW/8), "ceil(inW/8), loop through one row of 8*8 blocks")
                        
            print(" "*(indent+8)+"smov q2, q16\t\t//")
            
            if ochsInnerCount >= 2:
                k = 0
                for k in range(int(inC/128)):     #loop through input channels for 16K data blocks
                    if k == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich128."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.winc.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    elif inC == ((int(inC/128))*128) and k == (int(inC/128) - 1):
                        print(" "*(indent+8)+"conv.on.oc32.ich128."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff.winc.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich128."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff.winc.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                        
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(k%8*16)+", q4")
                                        
                    if k%8 == 7:
                        print(" "*(indent+8)+"sadd q4, 128, q4")
                    if k == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(filterH * filterW * 16 * k)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(filterH * filterW * 16 * k)+", q3")

                if int(inC/128) != 0:
                    k += 1    
                                
                inCLeft = inC - ((int(inC/128))*128)
                waitgsc = "winc"
                offsetA = filterH * filterW * 16 * k
                offsetB = k%8*16
                l = k
                if inCLeft > 64:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich64."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.winc.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich64."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff.winc.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW * 8
                    offsetB += 8
                    waitgsc = "wnil"
                    inCLeft -= 64
                    l += 1
                if inCLeft == 64:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich64."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.winc.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich64."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff.winc.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW * 8
                    offsetB += 8
                    inCLeft -= 64
                if inCLeft > 32:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich32."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.winc.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich32."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW * 4
                    offsetB += 4
                    waitgsc = "wnil"
                    inCLeft -= 32
                    l += 1
                if inCLeft == 32:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich32."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.winc.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich32."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW * 4
                    offsetB += 4
                    inCLeft -= 32
                if inCLeft > 24:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.winc.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW
                    offsetB += 1
                    waitgsc = "wnil"
                    inCLeft -= 8
                    l += 1
                if inCLeft > 16:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.winc.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW
                    offsetB += 1
                    waitgsc = "wnil"
                    inCLeft -= 8
                    l += 1
                if inCLeft > 8:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.winc.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW
                    offsetB += 1
                    waitgsc = "wnil"
                    inCLeft -= 8
                    l += 1 
                if inCLeft == 8:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.winc.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW
                    offsetB += 1
                    inCLeft -= 8
                if inCLeft > 0:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.winc.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW
                    offsetB += 1
                print(" "*(indent+8)+"sadd q4, "+str(offsetB)+", q4")
                print(" "*(indent+8)+"sadd q3, "+str(offsetA)+", q3")
                print(" "*(indent+8)+"sadd q2, 32, q2")
                print(" "*(indent+8)+"sadd q6, 1, q6")
                
                gen_loop_begin("loop_ochs_inner_1st", indent+8, 12, ochsInnerCount-2, "8, loop through 8 32 channels")
                indent += 4

                k = 0
                for k in range(int(inC/128)):     #loop through input channels for 16K data blocks
                    if k == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich128."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.wnil.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    elif inC == ((int(inC/128))*128) and k == (int(inC/128) - 1):
                        print(" "*(indent+8)+"conv.on.oc32.ich128."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff.wnil.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich128."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff.wnil.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                        
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(k%8*16)+", q4")
                                        
                    if k%8 == 7:
                        print(" "*(indent+8)+"sadd q4, 128, q4")
                    if k == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(filterH * filterW * 16 * k)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(filterH * filterW * 16 * k)+", q3")

                if int(inC/128) != 0:
                    k += 1    
                                
                inCLeft = inC - ((int(inC/128))*128)
                waitgsc = "wnil"
                offsetA = filterH * filterW * 16 * k
                offsetB = k%8*16
                l = k
                if inCLeft > 64:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich64."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.wnil.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich64."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff.wnil.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW * 8
                    offsetB += 8
                    waitgsc = "wnil"
                    inCLeft -= 64
                    l += 1
                if inCLeft == 64:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich64."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.wnil.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich64."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff.wnil.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW * 8
                    offsetB += 8
                    inCLeft -= 64
                if inCLeft > 32:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich32."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.wnil.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich32."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW * 4
                    offsetB += 4
                    waitgsc = "wnil"
                    inCLeft -= 32
                    l += 1
                if inCLeft == 32:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich32."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.wnil.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich32."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW * 4
                    offsetB += 4
                    inCLeft -= 32
                if inCLeft > 24:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.wnil.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW
                    offsetB += 1
                    waitgsc = "wnil"
                    inCLeft -= 8
                    l += 1
                if inCLeft > 16:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.wnil.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW
                    offsetB += 1
                    waitgsc = "wnil"
                    inCLeft -= 8
                    l += 1
                if inCLeft > 8:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.wnil.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW
                    offsetB += 1
                    waitgsc = "wnil"
                    inCLeft -= 8
                    l += 1 
                if inCLeft == 8:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.wnil.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW
                    offsetB += 1
                    inCLeft -= 8
                if inCLeft > 0:
                    if l == 0: 
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff.wnil.snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    else:
                        print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                    if l == 0: 
                        print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                        print(" "*(indent+8)+"smovg g4, q2")
                        print(" "*(indent+8)+"smovg.eog g7, q6")
                    else:
                        print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                    offsetA += filterH * filterW
                    offsetB += 1
                print(" "*(indent+8)+"sadd q4, "+str(offsetB)+", q4")
                print(" "*(indent+8)+"sadd q3, "+str(offsetA)+", q3")
                print(" "*(indent+8)+"sadd q2, 32, q2")
                print(" "*(indent+8)+"sadd q6, 1, q6")
                gen_loop_end(indent+4, 12, "loop_ochs_inner_1st")            
                indent -= 4
                waitgsc0 = "wnil"
            else:
                waitgsc0 = "winc"
            
            waitgsc = waitgsc0
            k = 0
            for k in range(int(inC/128)):     #loop through input channels for 16K data blocks
                if k == 0: 
                    print(" "*(indent+8)+"conv.on.oc32.ich128."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff."+waitgsc0+".sinc.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                elif inC == ((int(inC/128))*128) and k == (int(inC/128) - 1):
                    print(" "*(indent+8)+"conv.on.oc32.ich128."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff."+waitgsc0+".sinc.wb1.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                else:
                    print(" "*(indent+8)+"conv.on.oc32.ich128."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff."+waitgsc0+".sinc.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                    
                print(" "*(indent+8)+"&addu.b32 g0, "+str(k%8*16)+", q4")
                
                if inC == ((int(inC/128))*128) and k == (int(inC/128) - 1):
                    print(" "*(indent+8)+"smovg g6, 16")
                    
                if k%8 == 7:
                    print(" "*(indent+8)+"sadd q4, 128, q4")
                if k == 0: 
                    print(" "*(indent+8)+"saddg g1, "+str(filterH * filterW * 16 * k)+", q3")
                    print(" "*(indent+8)+"smovg g4, q2")
                    print(" "*(indent+8)+"smovg.eog g7, q6")
                else:
                    print(" "*(indent+8)+"saddg.eog g1, "+str(filterH * filterW * 16 * k)+", q3")

            if int(inC/128) != 0:
                k += 1    
                            
            inCLeft = inC - ((int(inC/128))*128)
            offsetA = filterH * filterW * 16 * k
            offsetB = k%8*16
            l = k
            if inCLeft > 64:
                if l == 0: 
                    print(" "*(indent+8)+"conv.on.oc32.ich64."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff."+waitgsc0+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                else:
                    print(" "*(indent+8)+"conv.on.oc32.ich64."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff."+waitgsc0+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                if l == 0: 
                    print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                    print(" "*(indent+8)+"smovg g4, q2")
                    print(" "*(indent+8)+"smovg.eog g7, q6")
                else:
                    print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                offsetA += filterH * filterW * 8
                offsetB += 8
                waitgsc = "wnil"
                inCLeft -= 64
                l += 1
            if inCLeft == 64:
                if l == 0: 
                    print(" "*(indent+8)+"conv.on.oc32.ich64."+dtw+"."+dta+"."+dtr+".ini1.out1.wt.roff."+waitgsc0+".sinc.wb1.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                else:
                    print(" "*(indent+8)+"conv.on.oc32.ich64."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff."+waitgsc0+".sinc.wb1.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                if l == 0: 
                    print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                    print(" "*(indent+8)+"smovg g4, q2")
                    print(" "*(indent+8)+"smovg g6, 16")
                    print(" "*(indent+8)+"smovg.eog g7, q6")
                else:
                    print(" "*(indent+8)+"smovg g6, 16")
                    print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                offsetA += filterH * filterW * 8
                offsetB += 8
                inCLeft -= 64
            if inCLeft > 32:
                if l == 0: 
                    print(" "*(indent+8)+"conv.on.oc32.ich32."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff."+waitgsc0+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                else:
                    print(" "*(indent+8)+"conv.on.oc32.ich32."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                if l == 0: 
                    print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                    print(" "*(indent+8)+"smovg g4, q2")
                    print(" "*(indent+8)+"smovg.eog g7, q6")
                else:
                    print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                offsetA += filterH * filterW * 4
                offsetB += 4
                waitgsc = "wnil"
                inCLeft -= 32
                l += 1
            if inCLeft == 32:
                if l == 0: 
                    print(" "*(indent+8)+"conv.on.oc32.ich32."+dtw+"."+dta+"."+dtr+".ini1.out1.wt.roff."+waitgsc0+".sinc.wb1.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                else:
                    print(" "*(indent+8)+"conv.on.oc32.ich32."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff."+waitgsc+".sinc.wb1.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                if l == 0: 
                    print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                    print(" "*(indent+8)+"smovg g4, q2")
                    print(" "*(indent+8)+"smovg g6, 16")
                    print(" "*(indent+8)+"smovg.eog g7, q6")
                else:
                    print(" "*(indent+8)+"smovg g6, 16")
                    print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                offsetA += filterH * filterW * 4
                offsetB += 4
                inCLeft -= 32
            if inCLeft > 24:
                if l == 0: 
                    print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff."+waitgsc0+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                else:
                    print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                if l == 0: 
                    print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                    print(" "*(indent+8)+"smovg g4, q2")
                    print(" "*(indent+8)+"smovg.eog g7, q6")
                else:
                    print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                offsetA += filterH * filterW
                offsetB += 1
                waitgsc = "wnil"
                inCLeft -= 8
                l += 1
            if inCLeft > 16:
                if l == 0: 
                    print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff."+waitgsc0+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                else:
                    print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                if l == 0: 
                    print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                    print(" "*(indent+8)+"smovg g4, q2")
                    print(" "*(indent+8)+"smovg.eog g7, q6")
                else:
                    print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                offsetA += filterH * filterW
                offsetB += 1
                waitgsc = "wnil"
                inCLeft -= 8
                l += 1
            if inCLeft > 8:
                if l == 0: 
                    print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out0.wt.roff."+waitgsc0+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                else:
                    print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out0.wt.roff."+waitgsc+".snil.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                if l == 0: 
                    print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                    print(" "*(indent+8)+"smovg g4, q2")
                    print(" "*(indent+8)+"smovg.eog g7, q6")
                else:
                    print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                offsetA += filterH * filterW
                offsetB += 1
                waitgsc = "wnil"
                inCLeft -= 8
                l += 1 
            if inCLeft == 8:
                if l == 0: 
                    print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out1.wt.roff."+waitgsc0+".sinc.wb1.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                else:
                    print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff."+waitgsc+".sinc.wb1.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                if l == 0: 
                    print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                    print(" "*(indent+8)+"smovg g4, q2")
                    print(" "*(indent+8)+"smovg g6, 16")
                    print(" "*(indent+8)+"smovg.eog g7, q6")
                else:
                    print(" "*(indent+8)+"smovg g6, 16")
                    print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                offsetA += filterH * filterW
                offsetB += 1
                inCLeft -= 8
            if inCLeft > 0:
                if l == 0: 
                    print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini1.out1.wt.roff."+waitgsc0+".sinc.wb1.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                else:
                    print(" "*(indent+8)+"conv.on.oc32.ich8."+dtw+"."+dta+"."+dtr+".ini0.out1.wt.roff."+waitgsc+".sinc.wb1.gc1 r0, "+"u"+str(outUsharp)+"\t//")
                print(" "*(indent+8)+"&addu.b32 g0, "+str(offsetB)+", q4")
                if l == 0: 
                    print(" "*(indent+8)+"saddg g1, "+str(offsetA)+", q3")
                    print(" "*(indent+8)+"smovg g4, q2")
                    print(" "*(indent+8)+"smovg g6, 16")
                    print(" "*(indent+8)+"smovg.eog g7, q6")
                else:
                    print(" "*(indent+8)+"smovg g6, 16")
                    print(" "*(indent+8)+"saddg.eog g1, "+str(offsetA)+", q3")
                offsetA += filterH * filterW
                offsetB += 1
            print(" "*(indent+8)+"sadd q4, "+str(offsetB)+", q4")
            print(" "*(indent+8)+"sadd q3, "+str(offsetA)+", q3")
            print(" "*(indent+8)+"sadd q2, 32, q2")
            print(" "*(indent+8)+"sadd q6, 1, q6")
            
            gen_loop_end(indent+4, 11, "loop_conv_columns")
            gen_loop_end(indent, 10, "loop_conv_rows")
            if sample >1:
                gen_loop_end(4, 9, "loop_conv_samples")
            print(" "*4+"sadd q16, "+str(ochsInnerCount*32)+", q16")
            gen_loop_end(0, 7, "loop_conv_ochs_outer")




#gen_conv2d(inH=56, inW=56, inC=80, filterH=1, filterW=1, outC=64, stride=1, dilation=1, padH=0, padW=0, sample=2, weightUsharp=0, inUsharp=1, outUsharp=2)
#gen_conv2d(inH=56, inW=56, inC=512, filterH=1, filterW=1, outC=128, stride=1, dilation=1, padH=0, padW=0, sample=2, weightUsharp=0, inUsharp=1, outUsharp=2)
#gen_conv2d(inH=56, inW=56, inC=512, filterH=1, filterW=1, outC=1024, stride=1, dilation=1, padH=0, padW=0, sample=2, weightUsharp=0, inUsharp=1, outUsharp=2)
#gen_conv2d(inH=56, inW=56, inC=64, filterH=1, filterW=1, outC=64, stride=1, dilation=1, padH=0, padW=0, sample=2, weightUsharp=0, inUsharp=1, outUsharp=2)

#gen_conv2d(inH=56, inW=56, inC=256, filterH=1, filterW=1, outC=64, stride=1, dilation=1, padH=0, padW=0, sample=2, weightUsharp=0, inUsharp=1, outUsharp=2)
gen_conv2d(inH=56, inW=56, inC=512, filterH=1, filterW=1, outC=128, stride=1, dilation=1, padH=0, padW=0, sample=2, weightUsharp=0, inUsharp=1, outUsharp=2)







