#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import code_generator.share.br_defined_print as bdp
import code_generator.tcore.br_tcore_fwd_conv as tfc
import code_generator.br_vector_core as vector


def main():
    # parser = argparse.ArgumentParser()

    # parser.add_argument('--input_folder', '-i')
    # parser.add_argument('--output_folder', '-o')
    # args = parser.parse_args()

    wshape = (512, 512, 3, 3)
    ishape = (1, 512, 56, 56)
    dt = ("bf16", "bf16", "bf16")

    bdp.set_output_file("test.s")

    vgpr_start = 0
    vgpr_num = 10

    tfc.br_fwd_conv(
        ishape, wshape, dt, stride=1, dilation=1, padx=0, pady=0,
        u_i=1, u_w=0, u_o=2, vgpr_start=vgpr_start, vgpr_num=vgpr_num)

    vector.br_fwd_bn(
        warpid=0, vgpr_start=156, vgpr_end=256,
        uid_0=1, ushape_0=(16,64,56,56),
        uid_1=2, ushape_1=(1,1,1,64   ),
        uid_2=3, ushape_2=(16,64,56,56),
        options=[0], layerid=0, layernum=1)
#
    #vector.br_fwd_dwc(
    #    warpid=3, vgpr_start=16, vgpr_end=156,
    #    uid_0=0, ushape_0=(16,64,56,56),
    #    uid_1=1, ushape_1=(1,1,1,64   ),
    #    uid_2=2, ushape_2=(1,1,1,64   ),
    #    uid_3=3, ushape_3=(16,64,56,56),
    #    options=[3, 3, 1, 1, 1, 1, 0], layerid=0, layernum=1)
#
    #vector.br_fwd_fc1(
    #    warpid=3, vgpr_start=0, vgpr_end=200,
    #    uid_0=0, ushape_0=(500,20,10,10),
    #    uid_1=1, ushape_1=(1,20,10,10  ),
    #    uid_2=1, ushape_2=(1,1,1,500   ),
    #    uid_3=1, ushape_3=(1,1,1,500   ),
    #    options=[0], layerid=2, layernum=1)
#
    #vector.br_fwd_fc2(
    #    warpid=3, vgpr_start=0, vgpr_end=200,
    #    uid_0=0, ushape_0=(1,1,10,500),
    #    uid_1=1, ushape_1=(1,1,1,500 ),
    #    uid_2=1, ushape_2=(1,1,1,10  ),
    #    uid_3=1, ushape_3=(1,1,1,10  ),
    #    options=[0], layerid=2, layernum=1)
#
    #vector.br_bk_fc1(
    #    warpid=3, vgpr_start=0, vgpr_end=200,
    #    uid_0=0, ushape_0=(1,  1,   1,  500),
    #    uid_1=1, ushape_1=(1,  1, 500, 2000),
    #    uid_2=1, ushape_2=(1, 20, 10,    10),
    #    uid_3=1, ushape_3=(1, 20, 10,    10),
    #    uid_4=1, ushape_4=(1,  1, 500, 2000),
    #    options=[0], layerid=2, layernum=1)
#
    #vector.br_bk_fc2(
    #    warpid=3, vgpr_start=0, vgpr_end=200,
    #    uid_0=0, ushape_0=(1,  1,   1,   10),
    #    uid_1=1, ushape_1=(1,  1,  10,  500),
    #    uid_2=1, ushape_2=(1,  1,   1,  500),
    #    uid_3=1, ushape_3=(1,  1,   1,  500),
    #    uid_4=1, ushape_4=(1,  1,  10,  500),
    #    options=[0], layerid=2, layernum=1, cwarp_end=True)
#
if __name__ == '__main__':
    main()
