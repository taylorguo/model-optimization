#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

from code_generator.kernel_gen.inst import *

class stream:
    def __init__(self):
        self.s = []
        self.declare = []
        self.tensor_pool = {}
        self.dump_header = []
    def add_dump_header(self, field):
        self.dump_header += field
    def insert_before(self, pos,i):
        pass
    def insert_after(self,pos, i):
        pass
    def append(self, i):
        #if isinstance(i, alloca_inst):
            #self.tensor_pool[i.name]=i
        #elif isinstance(i, dealloca_inst):
            #del self.tensor_pool[i.t.name] 
        self.s.append(i)
        return i
    def set_stream(self, s):
        self.s = s
    def stream(self):
        return self.s
    def __str__(self):
        out= ""
        for i in self.s:
            out += str(i) + "\n"
        return out
    def get_tensor_by_name(self, tname):
        pass


