import math
import code_generator.share.br_const_defs as bcd


class kernel_selector_fwd_pass:
    def __init__(self, hw, wl):
        self.hw = hw
        self.wl = wl

    def run_on_kernel(self, k):
        pass

