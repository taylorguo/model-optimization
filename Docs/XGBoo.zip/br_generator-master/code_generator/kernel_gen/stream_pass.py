#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.


from code_generator.kernel_gen.inst import *
from code_generator.kernel_gen import hardware


class stream_pass:
    def __init__(self, my_hw, my_wl):
        self.hw = my_hw
        self.wl=my_wl
    def run_on_stream(self):
        pass
