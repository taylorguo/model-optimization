from copy import deepcopy
import code_generator.kernel_gen.math_utils as utils
from code_generator.kernel_gen.stream_pass import *
from code_generator.kernel_gen.inst import *

# Purpose: 
# 1. axis expansion 
# 2. spc <-> vmc
# 3. adjust hw_shape based on the above two

# When transform hw_shape, the previous hw_shape should be kept. 
# The optimization target is to minimize unaligned access in graph level.
class infer_hw_shape_pass(stream_pass):
    def __init__(self, hw, wl):
        super().__init__(hw, wl)
    def set_hw_shape_n(self,AI, n_h, n_w):
        # shape: N, C, H, W
        # tiled_hw_shape: N, C, H, N_H, W, N_W
        # hw_shape: N, C, H*N_H, W*N_W
        #assert AI.layout=='4DA', 'Must expand n on 4DA tensor.'
        (N, C, H, W) = AI.shape
        AI.tiled_hw_shape = (utils.to_int(N / (n_h*n_w)), C, H, n_h, W, n_w)
        AI.hw_shape = (utils.to_int(N / (n_h*n_w)), C, H * n_h, W * n_w)
    def set_hw_shape_c(self, AI):
        pass
    def set_hw_shape_default(self, AI):
        AI.hw_shape = deepcopy(AI.shape)
        AI.tiled_hw_shape = None
    def run_on_stream(self):
        for i in self.wl.get_stream().stream():
            if isinstance(i, op_inst):
                if i.ty=="BRForwardConv2" or \
                        i.ty=="BRForwardConv2BatchNormRelu" or \
                        i.ty=="BRForwardConv2BatchNormReluMaxPool" or \
                        i.ty=='BRForwardConv2BatchNormAdderRelu' or \
                        i.ty=='BRForwardConv2BatchNorm' or \
                        i.ty=='BRBackConv2' or \
                        i.ty=='BRBackConv2ReluBatchNorm' or \
                        i.ty=='BRBackConv2AdderMaxpoolReluBatchNorm' or \
                        i.ty=='BRBackConv2AdderReluBatchNormBatchNorm' or \
                        i.ty=='BRBackConv2AdderReluBypassBatchNorm':
                    if i.ty=="BRForwardConv2" or \
                            i.ty=="BRForwardConv2BatchNormRelu" or \
                            i.ty=="BRForwardConv2BatchNormReluMaxPool" or \
                            i.ty=='BRForwardConv2BatchNormAdderRelu' or \
                            i.ty=='BRForwardConv2BatchNorm':
                        # Forward
                        N, IC, IH, IW = i.in_tensor[0].shape
                        SH, SW = i.params['conv']['strides']
                    else:
                        # Backward
                        N, IC, IH, IW = i.out_tensor[0].shape
                        if i.ty=="BRBackConv2":
                            SH, SW = i.params['strides']
                        else:
                            SH, SW = i.params['conv']['strides']
                    
                    # Hard coding of axis expansion
                    if self.wl.ty=='resnet':
                        if IW==224:
                            N_H = 1
                            N_W = 1
                        elif IW==56:
                            if SW==1:
                                N_H = 1
                                N_W = 1
                            else:
                                # 56x56 -> 28x28
                                N_H = 1
                                N_W = 1
                        elif IW==28:
                            if SW==1:
                                N_H = 2
                                N_W = 1
                            else:
                                # 28x28 -> 14x14
                                N_H = 2
                                N_W = 1
                        elif IW==14:
                            if SW==1:
                                N_H = 4
                                N_W = 1
                            else:
                                # 14x14 -> 7x7
                                N_H = 4
                                N_W = 1
                        elif IW==7:
                            N_H = 8
                            N_W = 1
                    else:
                        # unit test mode. do not inherit previous hw_shape
                        # TODO: must inherit previous hw_shape
                        N_W = 1
                        #if IW % self.hw.tcore_w ==0: 
                            #N_W = 1
                        #else:
                            #assert False, "Unaligned or not ResNet-50 feature map size. "
                        N_H = 1
                        #if IH % self.hw.tcore_w ==0:
                            #N_H = 1
                        #else:
                            #assert False, "Unaligned or not ResNet-50 feature map size. "
                    for tensor_list in [i.in_tensor, i.out_tensor, i.internal_tensor, i.debug_tensor, i.tensor]:
                        for t in tensor_list:
                            if t == i.in_tensor[0] or t==i.out_tensor[0]:
                                if isinstance(t, alloca_inst):
                                    self.set_hw_shape_n(t, N_H, N_W)
                            else:
                                self.set_hw_shape_default(t)
