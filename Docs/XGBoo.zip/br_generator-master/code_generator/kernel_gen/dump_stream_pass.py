#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import code_generator.kernel_gen.math_utils as utils
from code_generator.kernel_gen.stream_pass import *
from code_generator.kernel_gen.inst import *
class dump_stream_pass(stream_pass):
    def __init__(self, hw, wl):
        super().__init__(hw, wl)
        self.csv_format='xlsx'
    def run_on_stream(self, dump_all=False):
        csv_fancy_header = ['Ty', 'Name','Optional','Batch', 'In C', 'In H', 'In W', 'Out C','Out H', 'Out W', 
                'Kernel', 'Stride', 'Padding']
                #'Reshape', 'Kernel Type','Task longpole','HW longpole',
                #'In Act SPC (KiB)', 'Weight (KiB)', 'Out Act SPC (KiB)',
                #'fwd GEMM (kCycle)', 'fwd L1P5 (kCycle)',  'fwd L2 (kCycle)', 'fwd HBM (kCycle)', 'fwd (kCycle)', 'fwdGEMM %', 
                #'bpk GEMM (kCycle)', 'bpk L1P5 (kCycle)', 'bpk L2 (kCycle)', 'bpk HBM (kCycle)', 'bpk (kCycle)', 'bpkGEMM %', 
                #'bpi GEMM (kCycle)', 'bpi L1P5 (kCycle)', 'bpi L2 (kCycle)', 'bpi HBM (kCycle)', 'bpi (kCycle)', 'bpiGEMM %' ]
        if self.csv_format=='csv':
            import csv
            self.csvfile = open('perf.csv', 'w')
            self.csv = csv.writer(self.csvfile, delimiter=',')
            self.write_csv(csv_fancy_header)
        else:
            import xlsxwriter
            self.csvfile = xlsxwriter.Workbook(self.wl.name + '.xlsx')
            self.worksheet = self.csvfile.add_worksheet()
            self.csv_row=0
            self.write_csv(csv_fancy_header + self.wl.get_stream().dump_header)
            self.worksheet.freeze_panes(1, 0)  # Freeze the first row.
            
            self.fmt_green = self.csvfile.add_format()
            self.fmt_green.set_pattern(1)  # This is optional when using a solid fill.
            self.fmt_green.set_bg_color('green')
        for i in self.wl.get_stream().stream():
            if isinstance(i, op_inst):
                if "Conv2" in i.ty: 
                    N, IC, IH, IW = i.in_tensor[0].shape
                    N, OC, OH, OW = i.out_tensor[0].shape

                    dem_sz = i.in_tensor[0].get_dem_sz()
                    #print(60*"-","\n",i.ty, i.params)
                    if i.ty=='BRBackConv2' or i.ty=='BRForwardConv2':
                        KH, KW = i.params['k']
                        PH, PW = i.params['padding']
                        SH, SW = i.params['strides']
                    else:    
                        KH, KW = i.params['conv']['k']
                        PH, PW = i.params['conv']['padding']
                        SH, SW = i.params['conv']['strides']
                    tensor_str= 'IN='
                    for t in i.in_tensor:
                        tensor_str+=','+t.name
                    tensor_str += ' OUT='
                    for t in i.out_tensor:
                        tensor_str+=','+t.name
                    tensor_str += ' TENSOR='
                    for t in i.tensor:
                        tensor_str+=','+t.name

                    csv_algo = [i.ty, i.name,tensor_str, N, IC, IH, IW, OC,OH, OW, KW, SW, PW] #, ifm_spc_sz/1024, w_sz/1024, ofm_spc_sz/1024]
                    #csv_perf = [i.reshape, i.kernel_ty, i.task_longpole , i.hw_longpole]
                    
                    #self.worksheet.set_row(1, None, cell_format)
                    self.write_csv(csv_algo + i.dump_field) # + csv_fwd + csv_bpk + csv_bpi)
                else:
                    self.write_csv([i.name])
            elif dump_all:
                if isinstance(i, alloca_inst):
                    self.write_csv(['alloca', i.name, f'{i.layout}, {i.scope}, {i.shape}'])
                elif isinstance(i, dealloca_inst):
                    t = i.t
                    self.write_csv(['dealloca', t.name, f'{t.layout}, {t.scope}, {t.shape}'])
        self.csvfile.close()
    def write_csv(self, field):
            if self.csv_format=='csv':
                self.csv.writerow(field)
            else:
                self.worksheet.write_row(self.csv_row,0,  field)
                self.csv_row += 1

