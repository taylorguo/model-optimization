#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import math

from code_generator.kernel_gen import math_utils

from code_generator.kernel_gen.stream_pass import *
from code_generator.kernel_gen import stream
from code_generator.kernel_gen.inst import *


class memory_pass(stream_pass):
    def __init__(self, my_hw, my_wl):
        super().__init__(my_hw, my_wl)
        self.memory_pool = []
        self.total_slots = int(self.hw.gmb_sz / self.hw.gmb_granularity)
        self.allocate_from='top'
        
        self.hbm_base_addr = 100*1024*1024 # Start from 100MiB
        self.hbm_cur_addr = self.hbm_base_addr

        self.hbm_spill_addr = 0x0
        self.hbm_slot = 0
        self.free_list = [ 
                {'begin':0, 
                 'slots': self.total_slots},
                {'begin':self.total_slots, 
                'slots': 0}
           ]
    def static_allocate(self, AI):
        sz = AI.get_sz()
        AI.addr = self.hbm_cur_addr
        #self.hbm_cur_addr += math_utils.ceil_block(sz, 1024)
        self.hbm_cur_addr += math_utils.ceil_block(sz, 1024*1024)
    def get_hbm_spill_addr(self):
        return self.hbm_spill_addr
    def allocate(self, AI):
        slots = math.ceil(AI.get_sz() / self.hw.gmb_granularity)
        # Step 1: We have available slots
        for i in range(len(self.free_list)):
            b= self.free_list[i]
            if slots < b['slots']:
                AI.slot_begin = b['begin']
                AI.slots = slots
                self.free_list[i]= {'begin': b['begin'] + slots,
                     'slots': b['slots'] - slots
                    }
                #print(AI.slot_begin, AI.slots) 
                AI.gmb_addr = int(AI.slot_begin * self.hw.gmb_granularity /512)
                AI.gmb_sz = int(slots * self.hw.gmb_granularity /512)
                #print(self.free_list)
                return 
        
        # Step 2: Part of tensor in GMB
        hbm_slots = slots 
        for i in range(len(self.free_list)):
            b=self.free_list[i]
            hbm_slots -= b['slots'] 
            AI.slot_begin = b['begin']
            AI.slots = b['slots']
            self.free_list.pop(i)
            break

        # Every GMB memory objects have a copy in HBM.
        # Step 3: Allocate the rest of tensors to HBM
        #AI.addr = get_hbm_spill_addr(hbm_slots)

    def deallocate(self, AI):
        for i in range(len(self.free_list)-1):
            b = self.free_list[i]
            b_next = self.free_list[i+1]
            cur_begin = b['begin']
            cur_slots = b['slots']
            next_begin = b_next['begin']
            next_slots = b_next['slots']
            if AI.slot_begin > cur_begin:
                if AI.slot_begin == cur_begin+ cur_slots:
                    # Align to previous free list
                    b['slots']=  cur_slots + AI.slots
                elif AI.slot_begin + AI.slots == next_begin:
                    # Align to successive freelist
                    b_next['begin'] = AI.slot_begin
            else:
                # Create new free list
                b_new = {'begin':AI.slot_begin,
                        'slots':AI.slots}
                self.free_list.insert(i, b_new)
        #print(self.free_list)
    def run_on_stream(self):
        for i in self.wl.get_stream().stream():
            if isinstance(i, alloca_inst):
                if i.scope=="gmb":
                    self.static_allocate(i)
                    self.allocate(i)
                if i.scope=='hbm':
                    self.static_allocate(i)
            if isinstance(i, dealloca_inst):
                if i.t.scope == "gmb":
                    self.deallocate(i.t)

if __name__=="__main__":
    import code_generator.kernel_gen.workload
    wl = kernel_gen.workload.workload('test')
    s = wl.get_stream()
    a0 = s.append(alloca_inst(shape= (2, 3, 224, 244), scope='gmb', dtype='bf16', uma_mode='numa', layout='4DA'))
    a1 = s.append(alloca_inst(shape=(2, 64, 112, 112), scope='gmb', layout='4DA')) 
    a2 = s.append(alloca_inst(shape=(2, 64, 56, 56), scope='gmb', layout='4DA')) 
    s.append(dealloca_inst(a0))
    import code_generator.kernel_gen.hardware 
    hw = kernel_gen.hardware.hardware()
    pass_mm = memory_pass(hw, wl)
    pass_mm.run_on_stream() 
    #print(a0.gmb_addr, a0.gmb_sz) 
