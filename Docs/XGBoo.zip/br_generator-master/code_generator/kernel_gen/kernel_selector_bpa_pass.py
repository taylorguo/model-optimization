import math
import code_generator.share.br_const_defs as bcd
from code_generator.share.br_const_defs import INNER_IC_LOOP_NAME, SAMPLE_LOOP_NAME

class kernel_selector_bpa_pass:
    def __init__(self, hw, wl):
        self.hw = hw
        self.wl = wl

    def run_on_kernel(self, k, optimization_policy):
        # grad_in is the same shape of output activation
        (_, IC, IH, IW) = k.in_tensor[0].shape
        # grad_out is the same shape of input activation
        (N, OC, OH, OW) = k.out_tensor[0].shape

        if k.ty == 'BRBRBackConv2ReluBatchNorm':
            weight = k.tensor[1]
        elif k.ty == 'BRBackConv2AdderMaxpoolReluBatchNorm':
            weight = k.tensor[3]
        elif k.ty == 'BRBackConv2AdderReluBatchNormBatchNorm':
            weight = k.tensor[2]
        elif k.ty == 'BRBackConv2AdderReluBypassBatchNorm':
            weight = k.tensor[2]
        elif k.ty == 'BRBackConv2':
            weight = k.tensor[1]
        else:
            assert False, "Unrecognized backward conv kernel type." 

        dem_sz = k.in_tensor[0].get_dem_sz()
        if k.ty == "BRBackConv2":
            KH, KW = k.params["k"]
            PH, PW = k.params["padding"]
            SH, SW = k.params["strides"]
        else:
            KH, KW = k.params["conv"]["k"]
            PH, PW = k.params["conv"]["padding"]
            SH, SW = k.params["conv"]["strides"]

        grad_in_dem_sz = k.in_tensor[0].get_dem_sz()
        grad_out_dem_sz = k.out_tensor[0].get_dem_sz()
        w_dem_sz = weight.get_dem_sz()

        # Step 1: Pee-hole transforms
        IC = utils.ceil_block(IC, HIC)
        OC = utils.ceil_block(OC, HOC)

        if k.in_tensor[0].tiled_hw_shape == None:
            N_H = 1
            N_W = 1
        else:
            (N, _, _, N_H, _, N_W) = k.in_tensor[0].tiled_hw_shape

        ############# BPA
        TLR_TCORE_VECTOR_NUM = 64
        def is_satisfied(tic, toc, tw, th, ttoc, tcore_output='tlr', tcore_grb_constraint = False):
            # do not exceed bufferA size
            occupied_bufa_size = toc * ttoc * tic * KH * KW * \
                (self.hw.tcore_h * self.hw.tcore_w * self.hw.tcore_oc * self.hw.tcore_oc_accum) * \
                w_dem_sz
            # bufferB size contraints
            if KW > 1:
                if KH > 1:
                    # 16h8w * tic * 2 <= 256KiB
                    occupied_bufb_size = tic  * 2 * 1 * 2 * \
                    (self.hw.tcore_ic * self.hw.tcore_h *
                     self.hw.tcore_w ) * grad_in_dem_sz
                else:
                    # 8h8w * tic * 2 <= 256KiB
                    occupied_bufb_size = tic * 1 * 1 * 2 * \
                        (self.hw.tcore_ic * self.hw.tcore_h *
                         self.hw.tcore_w) * grad_in_dem_sz
            else:
                if KH > 1:
                    # 8h8w * tic <= 256KiB
                    occupied_bufb_size = tic * 1 * 1 * \
                        (self.hw.tcore_ic * self.hw.tcore_h *
                         self.hw.tcore_w) * grad_in_dem_sz
                else:
                    # 16h8w * tic <= 256KiB
                    occupied_bufb_size = tic * 1 * 1 * \
                        (self.hw.tcore_ic * self.hw.tcore_h *
                         self.hw.tcore_w) * grad_in_dem_sz
            # TLR 
            if tcore_output=='tlr':
                if KW > 1:
                    occupied_tlr_block = toc[1] * (th[1] / SH) * (tw[1] / SW) 
                    occupied_tlr = inner_oc * tw / (SW * SH)
                        # toc[1] toc[2] * tw[0]  
                else:
                    # KW ==1
                    pass
                    # occupied_tlr_block = toc[1] *  
                    # occupied_tlr = toc * th / (SW * SH)

            if occupied_bufa_size <= self.hw.bufa_sz and \
                occupied_bufb_size <= self.hw.bufb_sz:
                if tcore_output=='tlr':
                    if occupied_tlr_sz <= TLR_TCORE_VECTOR_NUM:
                        return True
                    else: return False
                else:
                    # GMB
                    return True
            else:
                return False

        # Meet reuse requirement
        m_min = math.ceil(
             * self.hw.tcore_oc_accum / (KH * KW))

        if m_min * HOC * HACCUM > OC:
            m_min = 1
        toc = m_min
        tic = 1
        oc_root = OC / (toc * HOC * HACCUM)
        ic_root = IC / (tic * HIC)
        occupied_bufa_sz = toc * tic * (HIC * HACCUM * HOC * KH * KW) * w_dem_sz / 1024

        changed = True
        while changed:
            changed = False
            # Enlarge tic
            if tic * HIC < IC:
                if is_satisfied(toc, tic + 1):
                    tic += 1
                    changed = True
            # Enlarge toc
            elif toc * HOC * HACCUM < OC:
                if is_satisfied(toc + 1, tic):
                    toc += 1
                    changed = True
        oc_root = OC / (toc * HOC * HACCUM)
        ic_root = IC / (tic * HIC)
        occupied_bufa_sz = toc * tic * (HIC * HACCUM * HOC * KH * KW) * w_dem_sz / 1024
        # Remove IC epilog
        if optimization_policy["remove_ic_epilog"]:
            if not ic_root.is_integer():
                # Move total epilog to TIC
                ic_root = utils.ceil_block(ic_root, 2)
                tic = IC / ((ic_root) * HIC)
                toc = self.hw.bufa_sz / (tic * KH * KW * (HIC * HACCUM * HOC) * w_dem_sz)
                oc_root = OC / (toc * HOC * HACCUM)
        else:
            ic_root = math.ceil(ic_root)

        if optimization_policy["remove_oc_epilog"]:
            # Remove epilog
            if not oc_root.is_integer():
                oc_root = math.ceil(oc_root)
                # Move total epilog to TOC
                toc = OC / (oc_root * HOC * HACCUM)
            # Remove TOC epilog
            if isinstance(toc, int) or not toc.is_integer():
                toc = math.floor(toc)
                oc_root = OC / (toc * HOC * HACCUM)
        else:
            oc_root = math.ceil(oc_root)
        occupied_bufa_sz = toc * tic * (HIC * HACCUM * HOC * KH * KW) * w_dem_sz / 1024
        # print(f'oc_root={oc_root}, ic_root={ic_root}, tic={tic}, toc={toc},bufa={occupied_bufa_sz}')
        if ic_root == 1:
            # Split toc to toc and m
            # Exchange TOC and m. Tradeoffs: more weight reuse, or more grb pingpong.
            m = toc
            m_max = 8
            toc = 1
            while m >= 2:
                if m > m_max:
                    m /= 2
                    toc *= 2
                else:
                    break
        else:
            m = toc
            toc = 1
        TOC = toc
        TIC = tic
        # Output constraints: TLR sz < 64
        if ic_root > 1:
            if KW > 1:
                assert (
                    TOC * m * IW <= 64 * 32 * 4
                ), "Exceed TLR ping-pong size constraints."
            else:
                assert (
                    TOC * m * IH <= 64 * 32 * 4
                ), "Exceed TLR ping-pong size constraints."
        if SW > 1:
            if KW > 1:
                assert m * IW <= 64 * 32 * 4, "Exceed TLR size constraints."
            else:
                assert m * IH <= 64 * 32 * 4, "Exceed TLR size constraints."
        oc_root = utils.to_int(oc_root)
        ic_root = utils.to_int(ic_root)
        TOC = utils.to_int(TOC)
        TIC = utils.to_int(TIC)
        
        m = utils.to_int(m)
        k.kernel_ty.add(vmc_mode)
        if ic_root > 1:
            k.kernel_ty.add("ic_partition")
        # kw>1, 8*64c16h8w should not exceed 128KiB
        self.wl.log.info(
            "kernel_selector: {}, m={:<4}, oc_root={:<4}, TOC={:<4}, ic_root={:<4}, TIC={:<4}, w_buf={:3.0f}KiB".format(
                vmc_mode, m, oc_root, TOC, ic_root, TIC, 
                (HOC * HACCUM * m * TOC) * (HIC * TIC) * (KH * KW) * dem_sz / 1024,
            )
        )
        self.wl.log.debug(
            [
                "{},  N={:<4}, IC={:<4}, IH={:<4} , IW={:<4},OH={:<4} , OW={:<4}, OC={:<4}, KW={}, SW={}".format(
                    k.name, N, IC, IH, IW, OH, OW, OC, KW, SW
                )
            ]
        )
        ##################### Loop dicts #####################
        # ic_step = 128 if TIC*HIC >= 128 else utils.ceil_block(TIC*HIC, 64)
        # w_oc_begin = 0
        # w_ic_begin = 0
        # if isinstance(weight, slice_inst):
        # w_oc_begin= weight.slice_begin[0]
        # w_ic_begin= weight.slice_begin[1]
        top_config_tcore = {}
        ldconv0_oc_root_dict = {"start": 0}
        ldconv0_ic_root_dict = {"start": 0}
        ldconv0_oc_dict = {"start": 0}
        ldconv0_ic_dict = {"start": 0}

        # if isinstance(ifm, slice_inst):
        # ifm_n_begin = ifm.slice_begin[0]
        # ifm_ic_begin = ifm.slice_begin[1]

        ldconv1_oc_root_dict = {"start": 0}
        ldconv1_ic_root_dict = {"start": 0}
        ldconv1_toc_dict = {"start": 0}
        ldconv1_n_dict = {"start": 0}
        ldconv1_h_dict = {"start": 0}
        ldconv1_w_dict = {"start": 0}
        ldconv1_ic_dict = {"start": 0}

        conv_oc_root_dict = {"start": 0}
        conv_ic_root_dict = {"start": 0}
        conv_toc_dict = {"start": 0}
        conv_n_dict = {"start": 0}
        conv_th_dict = {"start": 0}
        conv_tw_dict = {"start": 0}
        conv_h_dict = {"start": 0}
        conv_w_dict = {"start": 0}
        conv_oc_dict = {"start": 0}
        conv_ic_dict = {"start": 0}

        if isinstance(ofm, slice_inst):
            ofm_n_begin = ofm.hw_shape_slice_begin[0]
            # ofm_c_begin = ofm.hw_shape_slice_begin[1]
            ofm_h_begin = ofm.hw_shape_slice_begin[2]
            ofm_w_begin = ofm.hw_shape_slice_begin[3]
        else:
            ofm_n_begin = 0
            # ofm_c_begin = 0
            ofm_h_begin = 0
            ofm_w_begin = 0
        ### Apply sync channels
        
        ##################### BPA Output #####################
        # ldconv0
        loop_config_ldconv0 = [
            [bcd.OC_ROOT_LOOP_NAME, oc_root, 1, HOC * HACCUM * m * TOC, ldconv0_oc_root_dict],
            [bcd.IC_ROOT_LOOP_NAME, ic_root, 1, TIC * HIC, ldconv0_ic_root_dict],
            [bcd.TOC_LOOP_NAME, TOC * m, 1, HOC * HACCUM, ldconv0_oc_dict],
            [bcd.INNER_IC_LOOP_NAME, 1, 1, TIC * HIC, ldconv0_ic_dict],
        ]
        if KW > 1:
            # KW > 1
            # ldconv1
            loop_config_ldconv1 = [
                [bcd.OC_ROOT_LOOP_NAME, oc_root, 1, HOC * HACCUM * m * TOC, ldconv1_oc_root_dict,],
                [bcd.IC_ROOT_LOOP_NAME, ic_root, 1, TIC * HIC, ldconv1_ic_root_dict],
                [bcd.TOC_LOOP_NAME, TOC, 1, HOC * m, ldconv1_toc_dict],
                [bcd.SAMPLE_LOOP_NAME, N, 1, 1, ldconv1_n_dict],
                [bcd.ROW_LOOP_NAME, math.ceil(IH * N_H / (HIH * 2)), 1, HIH * 2, ldconv1_h_dict],
                [bcd.COL_LOOP_NAME, math.ceil(IW * N_W / HIW), 1, HIW, ldconv1_w_dict],
                [bcd.INNER_IC_LOOP_NAME, 1, 1, TIC * HIC, ldconv1_ic_dict],
            ]
            # conv
            if ic_root == 1:
                # not ic partition
                loop_config_conv = [
                    [bcd.OC_ROOT_LOOP_NAME, oc_root, 1, HOC * HACCUM * TOC * m, conv_oc_root_dict, ],
                    [bcd.TOC_LOOP_NAME, TOC, 1, HOC * HACCUM * m, conv_toc_dict],
                    [bcd.SAMPLE_LOOP_NAME, N, 1, 1, conv_n_dict],
                    ["row", math.ceil(IH * N_H / (HIH * 2)), 1, HIH * 2, conv_h_dict],
                    ["col", math.ceil(IW * N_W / HIW), 1, HIW, conv_w_dict],
                    ["inner_oc", m, 1, HOC * HACCUM, conv_oc_dict],  # 8*32
                    ["ich", 1, 1, TIC * HIC, conv_ic_dict],
                ]
            else:
                # ic partition
                loop_config_conv = [
                    [bcd.OC_ROOT_LOOP_NAME, oc_root, 1, TOC * HOC * HACCUM * m, conv_oc_root_dict, ],
                    [bcd.IC_ROOT_LOOP_NAME, ic_root, 1, TIC * HIC, conv_ic_root_dict],
                    ["sample", N, 1, 1, conv_n_dict],
                    ["row", math.ceil(IH * N_H / (HIH * 2)), 1, HIH * 2, conv_h_dict],
                    ["col", math.ceil(IW * N_W / HIW), 1, HIW, conv_w_dict],
                    ["inner_oc", m * TOC, 1, HOC * HACCUM, conv_oc_dict],  # 8*32
                    ["ich", 1, 1, TIC * HIC, conv_ic_dict],
                ]
        else:
            # KW ==1
            # ldconv1
            loop_config_ldconv1 = [
                [bcd.OC_ROOT_LOOP_NAME, oc_root, 1, HOC * HACCUM * m * TOC, ldconv1_oc_root_dict, ],
                [bcd.IC_ROOT_LOOP_NAME, ic_root, 1, TIC * HIC, ldconv1_ic_root_dict],
                ["oc", TOC, 1, HOC * HACCUM * m, ldconv1_toc_dict],
                ["sample", N, 1, 1, ldconv1_n_dict],
                ["col", math.ceil(IW * N_W / HIW), 1, HIW, ldconv1_w_dict],
                [ "row", math.ceil(IH * N_H / (self.hw.tcore_h)), 1, self.hw.tcore_h, ldconv1_h_dict, ],
                ["ich", 1, 1, TIC * HIC, ldconv1_ic_dict],
            ]
            # conv
            if ic_root == 1:
                loop_config_conv = [
                    [bcd.OC_ROOT_LOOP_NAME, oc_root, 1, HOC *
                        HACCUM * TOC * m, conv_oc_root_dict, ],
                    ["oc", TOC, 1, HACCUM * HOC * m, conv_toc_dict],
                    ["sample", N, 1, 1, conv_n_dict],
                    [ "col", math.ceil(IW * N_W / (self.hw.tcore_w)), 1, self.hw.tcore_w, conv_w_dict, ],
                    [ "row", math.ceil(IH * N_H / (self.hw.tcore_h)), 1, self.hw.tcore_h, conv_h_dict, ],
                    ["inner_oc", m, 1, HOC * HACCUM, conv_oc_dict],  # 8*32
                    ["ich", 1, 1, TIC * HIC, conv_ic_dict],
                ]
            else:
                # ic partition
                loop_config_conv = [
                    [ bcd.OC_ROOT_LOOP_NAME, oc_root, 1, TOC * HOC * HACCUM * m, conv_oc_root_dict, ],
                    [bcd.IC_ROOT_LOOP_NAME, ic_root, 1, TIC * HIC, conv_ic_root_dict],
                    ["sample", N, 1, 1, conv_n_dict],
                    ["col", math.ceil(IW * N_W / HIW), 1, HIW, conv_w_dict],
                    ["row", math.ceil(IH * N_H / (HIH * 2)), 1, HIH * 2, conv_h_dict],
                    ["inner_oc", m * TOC, 1, HOC * HACCUM, conv_oc_dict],  # 8*32
                    ["ich", 1, 1, TIC * HIC, conv_ic_dict],
                ]
        k.loop_config_bpa_ldconv0 = loop_config_ldconv0
        k.loop_config_bpa_ldconv1 = loop_config_ldconv1
        k.loop_config_bpa_conv = loop_config_conv
        k.top_config_tcore_bpa = top_config_tcore
