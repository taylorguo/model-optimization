import sys

import code_generator.kernel_gen.stream
from code_generator.kernel_gen.inst import *
import code_generator.kernel_gen.workload
import code_generator.kernel_gen.hardware
import code_generator.kernel_gen.memory_pass
import code_generator.kernel_gen.infer_hw_shape_pass
import code_generator.kernel_gen.kernel_selector_pass
import code_generator.kernel_gen.dump_stream_pass
import code_generator.kernel_gen.list2asm
def codegen(wl, output_dir=None):
    hw = code_generator.kernel_gen.hardware.hardware()
    pass_mm = code_generator.kernel_gen.memory_pass.memory_pass(hw, wl)
    pass_mm.run_on_stream() 
    
    pass_hw_shape = code_generator.kernel_gen.infer_hw_shape_pass.infer_hw_shape_pass(hw, wl)
    pass_hw_shape.run_on_stream() 

    pass_ks = code_generator.kernel_gen.kernel_selector_pass.kernel_selector_pass(hw, wl)
    pass_ks.run_on_stream()
    
    pass_bk = code_generator.kernel_gen.list2asm.list2asm(hw, wl, output_dir=output_dir)
    pass_bk.run_on_stream()
    
    #pass_ds = kernel_gen.dump_stream_pass.dump_stream_pass(hw, wl)
    #pass_ds.run_on_stream(dump_all=True) 
    
    pass_bk = code_generator.kernel_gen.list2asm.list2asm(hw, wl, debug_mode=True ,output_dir=output_dir)
    pass_bk.run_on_stream()

