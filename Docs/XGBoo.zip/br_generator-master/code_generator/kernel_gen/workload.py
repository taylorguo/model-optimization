#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import os
from code_generator.kernel_gen import stream
from code_generator.share import br_logging


class workload:
    def __init__(self,
                 name='workload',
                 ty='resnet',
                 vector_home=None,
                 enable_log=False,
                 running_stage="gen_asm",
                 timeout=10,
                 compare_policy="only_last",
                 abs_threshold=0.04,
                 relative_threshold=0.04,
                 weight_pattern=None,
                 activation_pattern=None,
                 specified_value=None):
        self.name = name
        if vector_home == None:
            vector_home = os.path.dirname(__file__)
            vector_home = os.path.dirname(vector_home)
            vector_home = os.path.dirname(vector_home)
            self.vector_home = os.path.join(vector_home, 'tests', 'code_gen',
                                            'vector', self.name)
        else:
            self.vector_home = vector_home
        # self.vector_home = os.path.join('vector', self.name)
        self.output_dir = os.path.join(self.vector_home, 'input')
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        if 'BRG_LOG_LEVEL' in os.environ:
            debug_level = os.environ['BRG_LOG_LEVEL']
            self.enable_log = True
        else:
            self.enable_log = enable_log
        self.log = br_logging.br_logging(self.name, self.output_dir,
                                         self.enable_log)
        self.ty = ty
        self.kernel_names = []
        self.stream_pool = []
        self.stream_pool.append(stream.stream())
        # set default optimization policy
        self.set_optimization_policy()
        self.running_stage= running_stage
        self.timeout=timeout
        self.compare_policy = compare_policy
        self.abs_threshold = abs_threshold
        self.relative_threshold = relative_threshold
        self.golden_data_list = []
        ### add pattern for weight and activation
        self.weight_pattern = weight_pattern
        self.activation_pattern = activation_pattern
        self.specified_value = specified_value

    def get_stream(self, stream_id=0):
        return self.stream_pool[stream_id]

    def set_stream(self, s, stream_id=0):
        self.stream_pool[stream_id] = s

    def get_instr_list(self, list_id=0):
        return self.stream_pool[list_id]

    def dump_asm_list(self):
        f = open(os.path.join(self.output_dir, 'asm_list.txt'), 'w')
        for i in self.kernel_names:
            f.write(i + '.s\n')
        f.close()

    def set_csr_table(self, csr_table):
        self.csr_table = csr_table

    def set_usharp_desc_list(self, usharp_desc_list):
        self.usharp_desc_list = usharp_desc_list

    def get_usharp_for_checkpoint(self, kernel_seq=0):
        return self.usharp_for_checkpoint_list[kernel_seq]

    def get_usharp_for_clear_contents(self, kernel_seq=0):
        return self.usharp_for_clear_contents_list[kernel_seq]

    def set_optimization_policy(self, optimization_policy=None):
        if optimization_policy == None:
            # self.optimization_policy = {
            #         'unroll_policy': 'legacy',  # 'threshold' / 'target_count', 'legacy', 'unroll2', 'all'
            #         'unroll_target_instruction_count': [120, 120, 120, 0, 0], #ldconv0, ldconv1, conv, reduce, elemwise
            #         'force_bufa_pingpong': False,
            #         'force_grb_pingpong': False,
            #         'remove_ic_epilog': True,
            #         'remove_oc_epilog': True,
            #         }
            # the default
            self.optimization_policy = {
                'unroll_policy':
                'threshold',  # 'threshold' / 'target_count', 'legacy'
                'unroll_target_instruction_count':
                [120, 120, 120, 0,
                 0],  #ldconv0, ldconv1, conv, reduce, elemwise
                'force_bufa_pingpong': False,
                'force_grb_pingpong': False,
                'remove_ic_epilog': False,
                'remove_oc_epilog': False,
                'bpa_tiling': 'oc',  # oc or feature_map
            }
        else:
            self.optimization_policy = optimization_policy

    ### interface to GC
    def get_vector_home(self):
        return self.vector_home

    def get_asm_list(self):
        return self.kernel_names

    def get_csr_table(self):
        return self.csr_table

    def get_metadata(self):
        target_file_path = os.path.join(self.vector_home, "input",
                                        self.name + "_00.json")
        assert os.path.exists(target_file_path), "{} is not found!".format(
            target_file_path)
        content = None
        with open(target_file_path, 'r') as f:
            content = f.read()
        return content

    def get_usharp_desc(self):
        return self.usharp_desc_list
