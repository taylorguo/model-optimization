import math
import code_generator.share.br_const_defs as bcd


class kernel_selector_bpw_pass:
    def __init__(self, hw, wl):
        self.hw = hw
        self.wl = wl

    def run_on_kernel(self, k):
        print(
            [
                "{},  N={:<4}, IC={:<4}, N_H={:<4}, IH={:<4} , N_W={:<4}, IW={:<4},OH={:<4} , OW={:<4}, OC={:<4}, KW={}, SW={}".format(
                    i.name, N, IC, N_H, IH, N_W, IW, OH, OW, OC, KW, SW
                )
            ]
        )
        # Constraints
        TLR_ACCUM_NUM = 72
        TLR_PINGPONG_NUM = 36

        # 16KiB for grad and activation
        HOC = 64  # actually hardware width is 32
        HIC = 64
        # hardware minimum reduce: 32 -- 256 for bf16, HH*HW=128
        HIH = 16
        HIW = 8
        # Hard constraints:
        #   bufferA: [1, toc, ttih * tih, tiw] * dem_sz <= bufa_sz
        #   bufferB: [1, tic, ttih * tih, tiw] * dem_sz <= bufb_sz
        #   TLR sz (partial sum buffer): toc * tic * kh * kw * 4 <= 72
        # Performance constraints:
        #   bufA -> GEMM reuse: kw * kh * tic >= 4
        #   bufB -> GEMM reuse: kh * toc >= 4

        # Step 1. Meet IC and OC reuse
        tic_min = math.ceil(4 / (KH * KW))
        toc_min = math.ceil(4 / KH)
        tiw_max = math.ceil(N_W * IW / HIW)

        tic = tic_min
        toc = toc_min
        tiw = 1
        tih = math.ceil(N_H * IH / HIH)

        def is_satisfied(toc, tic, tih, tiw):
            occupied_bufa_sz = (tih * tiw * toc) * (HOC * HIH * HIW) * grad_dem_sz
            occupied_bufb_sz = (KW * tih * tiw * tic) * (HIC * HIH * HIW) * ifm_dem_sz
            occupied_tlr_num = (toc * tic * KH * KW) * 4  # 4 TLR per output
            if (
                occupied_bufa_sz <= self.hw.bufa_sz
                and occupied_bufb_sz <= self.hw.bufb_sz
                and occupied_tlr_num <= TLR_ACCUM_NUM
            ):
                return True
            else:
                return False

        # Step 2: Enlarge with constraints
        # Reuse the bigger one
        if KW * OC * ifm_dem_sz >= IC:
            # grad stationary
            changed = True
            while changed:
                changed = False
                # enlarge
                if tiw < tiw_max:
                    if is_satisfied(toc, tic, tih, tiw + 1):
                        tiw += 1
                        changed = True
                elif tic < math.ceil(IC / HIC):
                    if is_satisfied(toc, tic + 1, tih, tiw):
                        tic += 1
                        changed = True
                elif toc < math.ceil(OC / HOC):
                    if is_satisfied(toc + 1, tic, tih, tiw):
                        toc += 1
                        changed = True
            occupied_bufa_sz = (tih * tiw * toc) * (HOC * HIH * HIW) * grad_dem_sz
            occupied_bufb_sz = (KW * tih * tiw * tic) * (HIC * HIH * HIW) * ifm_dem_sz
            occupied_tlr_num = (toc * tic * KH * KW) * 4  # 4 TLR per output
            print(f"grad stationary: tic={tic}, toc={toc}, tih={tih}, tiw={tiw}")
            print(
                f"bufa={occupied_bufa_sz/1024}, bufb={occupied_bufb_sz/1024}, tlr={occupied_tlr_num}\n"
            )
            i.add_dump_field(
                field=[
                    f"g tic={tic}, toc={toc}, tih={tih}, tiw={tiw}, bufa={occupied_bufa_sz/1024}, bufb={occupied_bufb_sz/1024}, tlr={occupied_tlr_num}"
                ]
            )
            # Compute shared axis
            soc = OC / TOC

        else:
            # activation stationary
            print("acti stationary:")
            i.add_dump_field(field=[f"a"])

        shared_loops = [
            ("oc", soc, 1, 1, {}),
            ("ic", sic, 1, 1, {}),
            ("sample", sn, 1, 1, {}),
            ("col", siw, 1, 1, {}),
        ]

        i.loop_config_ld_grad = shared_loops + [
            ("oc", toc, 1, 1, {}),
            ("col", tiw, 1, 1, {}),
            ("row", tih, 1, 1, {}),
        ]
        i.loop_config_ld_act = shared_loops + [
            ("oc", toc, 1, 1, {}),
            ("col", tiw, 1, 1, {}),
            ("row", tih, 1, 1, {}),
        ]
