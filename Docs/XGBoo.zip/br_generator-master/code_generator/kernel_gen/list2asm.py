#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import sys, os
import collections
import struct
from pprint import pformat
from code_generator.kernel_gen import stream
from code_generator.kernel_gen.inst import *
from code_generator.kernel_gen.stream_pass import *
from code_generator.kernel_gen import math_utils
import code_generator.tcore.br_tcore_utils as tcore_utils
from code_generator.br_code_gen_interface import *
import code_generator.share.br_state_manager as state_man
import code_generator.share.br_const_defs as bcd
import code_generator.br_code_gen_interface as br_code_gen_interface
from code_generator.share import br_defined_print as bdp
from command_generator import br_command_gen_interface
from command_generator import utils


class list2asm(stream_pass):
    def __init__(self, hw, wl, debug_mode=False, output_dir=None, gen_desc=True, backend=False):
        super().__init__(hw, wl)
        self.vector_tlr_begin = 156
        self.vector_tlr_end = 256
        self.debug_mode = debug_mode
        self.gen_desc = gen_desc
        if output_dir == None:
            self.output_dir = self.wl.output_dir
        else:
            self.output_dir = output_dir
        self.kernel_seq = 0
        self.usharp_desc_list = []
        self.csr_table_list = []

        # for verification purpose
        self.wl.usharp_for_checkpoint_list = []
        self.wl.usharp_for_clear_contents_list = []

        self.backend = backend

    def generate_desc(self, usharp_list, csr_list):
        self.wl.set_csr_table(csr_list)
        Cjobd = {
            "workMode": 0,
            "numCwarp": 0,
            "taskSplit": 11,
            "reserved3": 0,
            "cwarpEn": 1,
        }
        Cud = {
            "kernel_name": self.kernel_name,
            "usharpOffsetSel": 0,
            "reserved_0": 0,
            # "pc": "0x0000000000000001",
            # "bsharpAddr": 0,
            "cnstAddr": csr_list,
            "cnst_file_name": "cnst.bin",
            "cnstCnt": self.csr_addr,
            "cnstLayout": 0,
            "reserved0": 0,
            "reserved1": 0,
            "reserved2": 0,
        }
        Tmd = {
            "tlmBaseAddr": 0,
            "gsmBaseAddr": 0,
            "tlmSize": 0,
            "atomicEn": 0,
            "gsmSize": 0,
            "tgSlots": 0,
            "gsmPartition": 0,
            "reserved0": 0,
            "reserved1": 0,
        }
        desc = {"Cjobd": Cjobd, "Cud": Cud, "Tmd": Tmd, "Usharp": usharp_list}
        if not self.debug_mode:
            if self.gen_desc:
                case_path = br_command_gen_interface.br_gen_descriptor(
                    desc, self.output_dir
                )

    def assign_usharp(self, k):
        for tensor_list in [k.in_tensor, k.internal_tensor, k.tensor,k.debug_tensor, k.out_tensor]:
            for t in tensor_list:
                if isinstance(t, alloca_inst):
                    if t.scope != "tlr" and not t in self.usharp_dict:
                        self.usharp_dict[t] = self.usharp_count
                        t.usharp_id = self.usharp_count
                        self.usharp_count += 1

    def get_usharp_id(self, t):
        #  get usharp for alloca_inst, not slice_inst
        if isinstance(t, alloca_inst):
            assert t in self.usharp_dict, f"{t.name} is not assigned usharp."
            return self.usharp_dict[t]
        elif isinstance(t, slice_inst):
            return self.get_usharp_id(t.AI)

    def update_or_insert_boundary_dict(self, x):
        if (x % 8 != 0) and not x in self.boundary_dict:
            table = br_get_boundary_coordinate_table(x)
            addr = self.csr_addr
            length = len(table)  # uint8
            self.boundary_dict[x] = [addr, length, table]
            # 4B aligned
            self.csr_addr += math_utils.ceil_block(length, 4)

    def save_boundary_dict(self, file_name):
        # Pack to a struct
        buf = "".encode("ascii")
        f = open(file_name, "w+b")
        for k, v in self.boundary_dict.items():
            # flat table
            length = v[1]
            table = []
            for i in v[2]:
                table.append(i[1] << 3 | i[0])
            # align to 4x
            for i in range(length % 4):
                table.append(0)
            # little endian, uint8
            f.write(struct.pack("<{}B".format(len(table)), *table))
        f.close()
    def save_csr_table(self, file_name='cnst.bin'):
        table = br_code_gen_interface.br_get_csr_table()
        f = open(file_name, "w+b")
        f.write(struct.pack("<{}i".format(len(table)), *table))
        f.close()

    def generate_launch_codes(self):
        self.wl.log.debug("generate_launch_codes for " + self.kernel_name)
        usharp_list = []
        self.wl.log.debug('usharp list:')
        for k, v in self.usharp_dict.items():
            self.wl.log.debug('usharp id=' + str(v) + ', name=' + k.name +
                              ', addr=' + hex(k.addr) + ', filename=' + k.data_file)
            usharp_list.append(k.get_usharp_desc())
        self.usharp_desc_list.append(usharp_list)
        #self.save_boundary_dict(os.path.join(self.output_dir, "cnst.bin"))
        # Log ushap mapping table
        self.wl.log.debug(pformat(usharp_list))
        self.generate_desc(usharp_list, br_code_gen_interface.br_get_csr_table())
        # Gather usharp for checkpoint and clearing contents
        usharp_checkpoint_list = []
        usharp_clear_contents_list = []
        for k, v in self.usharp_dict.items():
            if k.is_checkpoint:
                usharp_checkpoint_list.append(v)
            if k.is_clear_contents:
                usharp_clear_contents_list.append(v)
        self.wl.usharp_for_checkpoint_list.append(usharp_checkpoint_list)
        self.wl.usharp_for_clear_contents_list.append(usharp_clear_contents_list)

        # Next kernel
        state_man.reset_kernel()
        self.kernel_seq += 1

    def clean_launch_state(self):
        self.usharp_count = 0
        self.usharp_dict = {}
        self.vector_layer_id = 0
        # x: addr, sz, list
        self.csr_addr = 0
        self.boundary_dict = collections.OrderedDict()
        self.kernel_name = self.wl.name + "_{:02d}".format(self.kernel_seq)
        self.wl.kernel_names.append(self.kernel_name)

        if self.debug_mode:
            import code_generator.share.br_const_defs as cst

            cst.set_code_style(1)
            bdp.set_output_file(self.kernel_name + "_pseudo.s", self.output_dir)
        else:
            import code_generator.share.br_const_defs as cst

            cst.set_code_style(0)
            bdp.set_output_file(self.kernel_name + ".s", self.output_dir)

        if (isinstance(self.backend, str)
                and self.backend == "True") or (isinstance(self.backend, bool)
                                                and self.backend == True):
            bdp.enable_backend(True)

    def run_on_stream(self):
        self.wl.log.debug(
            "generate .s for workload "
            + self.wl.name
            + " debug mode = "
            + str(self.debug_mode)
        )
        self.clean_launch_state()
        for i in self.wl.get_stream().stream():
            if isinstance(i, op_inst):
                kernel_usharp = i.get_usharp_num()
                if self.usharp_count + kernel_usharp > 256:
                    self.generate_launch_codes()
                    self.clean_launch()
                self.run_on_kernel(i)
                self.vector_layer_id += 1
        self.generate_launch_codes()

        # save fields to workload
        self.wl.dump_asm_list()
        # self.wl.set_csr_table([])
        self.wl.set_usharp_desc_list(self.usharp_desc_list)

    def run_on_kernel(self, k):
        if (
            k.ty == "BRForwardConv2"
            or k.ty == "BRForwardConv2BatchNormRelu"
            or k.ty == "BRForwardConv2BatchNormReluMaxPool"
            or k.ty == "BRForwardConv2BatchNormAdderRelu"
            or k.ty == "BRForwardConv2BatchNorm"
        ):
            if k.ty == "BRForwardConv2":
                w = k.tensor[0]
                ofm = k.out_tensor[0]
            elif k.ty == "BRForwardConv2BatchNormRelu":
                w = k.tensor[1]
                ofm = k.out_tensor[0]
                bn_cache = k.tensor[2]
            elif k.ty == "BRForwardConv2BatchNormReluMaxPool":
                w = k.tensor[1]
                ofm = k.tensor[0]
                bn_cache = k.tensor[2]
            elif k.ty == "BRForwardConv2BatchNormAdderRelu":
                ofm = k.out_tensor[0]
                w = k.tensor[2]
                bn_cache = k.tensor[3]
            elif k.ty == "BRForwardConv2BatchNorm":
                w = k.tensor[0]
                ofm = k.out_tensor[0]
                bn_cache = k.tensor[1]
            if k.debug_mode:
                # TODO: debug tensor for other ops
                ofm = k.debug_tensor[0]
            self.assign_usharp(k)
            ##################################### TCORE begin #####################################
            self.wl.log.debug("loop_config_ldconv0=\n" + pformat(k.loop_config_ldconv0))
            self.wl.log.debug("loop_config_ldconv1=\n" + pformat(k.loop_config_ldconv1))
            self.wl.log.debug("loop_config_conv=\n" + pformat(k.loop_config_conv))
            self.wl.log.debug("top_config_tcore=\n" + pformat(k.top_config_tcore))

            if k.ty == "BRForwardConv2":
                # No reduce required
                loop_config_vector_reduce = []
            else:
                loop_config_vector_reduce = k.loop_config_vector_reduce
            self.wl.log.debug("loop_config_vector_reduce=\n" + pformat(loop_config_vector_reduce))

            # Boundary
            (N, IC, IH, IW) = k.in_tensor[0].shape
            # self.update_or_insert_boundary_dict(IW)
            # self.update_or_insert_boundary_dict(IH)
            # csr format
            csr_dict = {
                # unaligned val: addr, size
                k: (v[0], v[1])
                for k, v in self.boundary_dict.items()
            }
            if "tlr_pingpong" in k.kernel_ty:
                tcore_out_dict = {
                    "tlr": k.top_config_tcore["tlr_pingpong"],
                    "usharp": self.get_usharp_id(ofm),
                }
            else:
                tcore_out_dict = {"usharp": self.get_usharp_id(ofm)}

            # NOTE: ackgmb for BRConv2d should be done in cwarp2, and for the "reduce" cases,
            # it is done in cwarp3
            tcore_asm = br_code_gen_interface.br_fwd_conv(
                tensor_b=k.in_tensor[0].shape,  # NCHW
                tensor_a=w.shape,  # O.I.KH.KW
                dt=[k.in_tensor[0].dtype, w.dtype, ofm.dtype],
                stride=k.params["conv"]["strides"][0],
                dilation=1,
                padx=k.params["conv"]["padding"][0],
                pady=k.params["conv"]["padding"][1],
                usharps={
                    "tensor_b": {"usharp": self.get_usharp_id(k.in_tensor[0])},
                    "tensor_a": {"usharp": self.get_usharp_id(w)},
                    "tensor_o": tcore_out_dict,
                    "reduce": {"usharp": self.get_usharp_id(bn_cache)},
                },
                loop_configs=[
                    k.loop_config_ldconv0,
                    k.loop_config_ldconv1,
                    k.loop_config_conv,
                    loop_config_vector_reduce,
                ],
                pingpong_a=k.top_config_tcore["pingpong_a"],
                pingpong_b=k.top_config_tcore["pingpong_b"],
                red_mode=k.top_config_tcore["redmode"],
                write_through=k.debug_mode,
                csrs=csr_dict,
                hwshape=k.in_tensor[0].hw_shape,
                gmb_mapping = False,
                ic_partition = "ic_partition" in k.kernel_ty,
                spc_num = bcd.BR_SPC_NUMBER,
                sync_layer = True,
                force_ackgmb= True,
                extension = False,
                micro_batch_mode=k.attr["bn_include_sample_loop"],
            )
            self.wl.log.debug("tcore_wsr_number = " + str(tcore_asm.get_required_wsr()))
            self.wl.log.debug("tcore_tlr_number = " + str(tcore_asm.get_required_tlr()))
            tcore_asm.generate()
            ##################################### TCORE end #####################################

            ##################################### VECTOR begin #####################################
            ### CWARP3: reduce
            # if (
            #     k.ty == "BRForwardConv2"
            #     or k.ty == "BRForwardConv2BatchNorm"
            #     or k.ty == "BRForwardConv2BatchNormRelu"
            #     or k.ty == "BRForwardConv2BatchNormAdderRelu"
            #     or k.ty == "BRForwardConv2BatchNormReluMaxPool"
            # ):
            #     # vector.br_fwd_reduce.get_required_wsr()
            #     # vector.br_fwd_reduce.get_required_tlr()
            #     if k.params["conv"]["strides"][1] >= 2 or "ic_partition" in k.kernel_ty:
            #         # strides > 1 or ic partition
            #         self.wl.log.debug("vector type = s2_stm or ic_partiton")
            #         self.wl.log.debug(
            #             "loop_config_vector = " + pformat(k.loop_config_vector_reduce)
            #         )
            #         self.wl.log.debug(
            #             "bn_cache shape = "
            #             + str(bn_cache.shape)
            #             + " ofm hw_shape "
            #             + str(ofm.hw_shape)
            #         )
            #         self.wl.log.debug("layer_id = " + str(self.vector_layer_id))
            #         vector_reduce_asm = br_fwd_stm(
            #             warpid=3,
            #             usharpid=self.get_usharp_id(ofm),
            #             loopconfig=k.loop_config_vector_reduce,
            #             merge_reduce=True if k.ty != "BRForwardConv2" else False,
            #             with_icpartition=True if "ic_partition" in k.kernel_ty else False,
            #             wred_usharpid=self.get_usharp_id(bn_cache),
            #             wred_channelnum=bn_cache.shape[0] / 4,
            #             force_ackgmb=False if k.ty != "BRForwardConv2" else True,
            #             sync_layer=False if k.ty != "BRForwardConv2" else True,
            #             layerid=self.vector_layer_id,
            #             layernum=1,
            #         )
            #         vector_reduce_asm.generate()
            #     else:
            #         self.wl.log.debug(
            #             "loop_config_vector_reduce = "
            #             + pformat(k.loop_config_vector_reduce)
            #         )
            #         vector_reduce_asm = br_fwd_reduce(
            #             warpid=3,
            #             loopconfig=k.loop_config_vector_reduce,
            #             usharpid=self.get_usharp_id(bn_cache),
            #             channelnum=bn_cache.shape[0] / 4,
            #             layerid=self.vector_layer_id,
            #             layernum=1,
            #             force_ackgmb=False,
            #             sync_layer=False,
            #         )
            #         vector_reduce_asm.generate()

            ### CWARP4: elementwise and maxpool
            if k.ty == "BRForwardConv2BatchNorm":
                vector_bn = br_fwd_bn(
                    warpid=4,
                    vgpr_start=self.vector_tlr_begin,
                    vgpr_end=self.vector_tlr_end,
                    # input activation 4DA
                    usharp_0=[self.get_usharp_id(ofm), ofm.hw_shape],
                    # bn_weight
                    usharp_1=[
                        self.get_usharp_id(bn_cache),
                        [1, 1, 1, bn_cache.hw_shape[0]],
                    ],
                    # activation after relu. invalid if withrelu==False
                    usharp_2=[
                        self.get_usharp_id(k.out_tensor[0]),
                        k.out_tensor[0].hw_shape,
                    ],
                    withrelu=False,
                    force_ackgmb=True,
                    sync_layer=True,
                    loop_config=k.loop_config_vector_elemwise,
                    layerid=self.vector_layer_id,
                    layernum=1,
                    micro_batch_mode=k.attr["bn_include_sample_loop"],
                )
                vector_bn.generate()
            elif k.ty == "BRForwardConv2BatchNormRelu":
                self.wl.log.debug("vector: apply_bn")
                vector_bn = br_fwd_bn(
                    warpid=4,
                    vgpr_start=self.vector_tlr_begin,
                    vgpr_end=self.vector_tlr_end,
                    # input activation 4DA
                    usharp_0=[self.get_usharp_id(ofm), ofm.hw_shape],
                    # bn_weight
                    usharp_1=[
                        self.get_usharp_id(bn_cache),
                        [1, 1, 1, bn_cache.hw_shape[0]],
                    ],
                    # activation after bn
                    usharp_2=[self.get_usharp_id(k.tensor[0]), k.tensor[0].hw_shape],
                    # activation after relu. invalid if withrelu==False
                    usharp_3=[
                        self.get_usharp_id(k.out_tensor[0]),
                        k.out_tensor[0].hw_shape,
                    ],
                    withrelu=True,
                    force_ackgmb=True,
                    sync_layer=True,
                    loop_config=k.loop_config_vector_elemwise,
                    layerid=self.vector_layer_id,
                    layernum=1,
                    micro_batch_mode=k.attr["bn_include_sample_loop"],
                )
                vector_bn.generate()
            elif k.ty == "BRForwardConv2BatchNormAdderRelu":
                self.wl.log.debug("vector: bn+adder+relu")
                vector_bn = br_fwd_bn(
                    warpid=4,
                    vgpr_start=self.vector_tlr_begin,
                    vgpr_end=self.vector_tlr_end,
                    # input activation 4DA
                    usharp_0=[self.get_usharp_id(ofm), ofm.hw_shape],
                    # bn_weight
                    usharp_1=[
                        self.get_usharp_id(bn_cache),
                        [1, 1, 1, bn_cache.hw_shape[0]],
                    ],
                    # activation after bn
                    usharp_2=[self.get_usharp_id(k.tensor[0]), k.tensor[0].hw_shape],
                    # activation after relu. invalid if withrelu==False
                    usharp_3=[
                        self.get_usharp_id(k.out_tensor[0]),
                        k.out_tensor[0].hw_shape,
                    ],
                    withrelu=True,
                    withadder=True,
                    force_ackgmb=True,
                    sync_layer=True,
                    loop_config=k.loop_config_vector_elemwise,
                    layerid=self.vector_layer_id,
                    layernum=1,
                    micro_batch_mode=k.attr["bn_include_sample_loop"],
                )
                vector_bn.generate()
            elif k.ty == "BRForwardConv2BatchNormReluMaxPool":
                # WARNING: This logic only works in debug mode.
                # We should not store the output of relu to a usharp.

                # BN + Relu + Maxpooling
                if k.debug_mode:
                    relu_out = k.debug_tensor[1]
                else:
                    # This is incorrect. This usharp should not exist.
                    assert False, "Ask Arthur to remove the usharp after relu in ReluMaxpool"
                    relu_out = ofm
                self.wl.log.debug("vector: apply_bn")
                vector_bn = br_fwd_bn(
                    warpid=4,
                    vgpr_start=self.vector_tlr_begin,
                    vgpr_end=self.vector_tlr_end,
                    # input activation 4DA
                    usharp_0=[self.get_usharp_id(ofm), ofm.hw_shape],
                    # bn_weight
                    usharp_1=[
                        self.get_usharp_id(bn_cache),
                        [1, 1, 1, bn_cache.hw_shape[0]],
                    ],
                    # activation after bn
                    usharp_2=[self.get_usharp_id(k.tensor[0]), k.tensor[0].hw_shape],
                    # activation after relu. invalid if withrelu==False
                    usharp_3=[self.get_usharp_id(relu_out), relu_out.hw_shape],
                    withrelu=True,
                    force_ackgmb=True,
                    sync_layer=True,
                    loop_config=k.loop_config_vector_elemwise,
                    layerid=self.vector_layer_id,
                    layernum=1,
                    syncid_with_maxpool=bcd.BAR_CHANNELS_BETWEEN_BN_AND_MAXPOOL,
                    micro_batch_mode=k.attr["bn_include_sample_loop"],
                )
                vector_bn.generate()

                vector_maxpooling = br_fwd_maxpooling(
                    warpid=5,
                    vgpr_start=self.vector_tlr_begin,
                    vgpr_end=self.vector_tlr_end,
                    # input activation: from relu
                    usharp_0=[self.get_usharp_id(relu_out), relu_out.hw_shape],
                    # output activation
                    usharp_1=[self.get_usharp_id(k.out_tensor[0]),
                              k.out_tensor[0].hw_shape],
                    # [FilterSizex, FilterSizeY, FilterOffsetx, FilterOffsety, FilterStride2_on, BnBeforeOnFlag, ReduceOnFlag, Mate_mode]
                    options=[
                        k.params["maxpool"]["k"][0],
                        k.params["maxpool"]["k"][1],
                        k.params["maxpool"]["padding"][0],
                        k.params["maxpool"]["padding"][1],
                        1 if k.params["maxpool"]["strides"][0] == 2 else 0,
                        0,
                        0,
                        1,
                    ],  # mode is max
                    force_ackgmb=True,
                    sync_layer=True,
                    withrelu=True,
                    layerid=self.vector_layer_id,
                    layernum=1,
                    syncid_with_bn=bcd.BAR_CHANNELS_BETWEEN_BN_AND_MAXPOOL
                )
                vector_maxpooling.generate()
            else:
                assert "unsupported SIMT kernel."
        ##################################### VECTOR end #####################################
        elif k.ty == "BRForwardBatchNorm":
            vector_bn = br_fwd_bn(
                warpid=4,
                vgpr_start=168,
                vgpr_end=256,
                # input activation 4DA
                usharp_0=[self.get_usharp_id(k.in_tensor[0]), i.in_tensor[0].shape],
                # bn_weight
                usharp_1=[
                    self.get_usharp_id(k.tensor[0]),
                    [1, 1, 1, k.tensor[0].shape[0]],
                ],
                # activation after bn
                usharp_2=[self.get_usharp_id(k.out_tensor[0]), k.out_tensor[0].shape],
                # activation after relu. invalid if withrelu==False
                usharp_3=[self.get_usharp_id(k.out_tensor[0]), k.out_tensor[0].shape],
                withrelu=False,
                force_ackgmb=True,
                loop_config=k.loop_config_vector_elemwise,
                layerid=layid,
                layernum=1,
                micro_batch_mode=k.attr["bn_include_sample_loop"],
            )
            vector_bn.generate()
        elif k.ty == "BRSPCReduce":
            self.wl.log.debug(
                "loop_config_vector_reduce = " + pformat(k.loop_config_vector_reduce)
            )
            vector_reduce_asm = br_fwd_reduce(
                warpid=3,
                loopconfig=k.loop_config_vector_reduce,
                usharp=[self.get_usharp_id(bn_cache), bn_cache.hw_shape],
                layerid=self.vector_layer_id,
                layernum=1,
                micro_batch_mode=k.attr["bn_include_sample_loop"],
            )
            vector_reduce_asm.generate()
        elif k.ty == "BRForwardAveragePool":
            # TODO:
            # - pass hw_shape and shape
            # -
            vector_reduce_asm = br_fwd_reduce(
                warpid=3,
                loopconfig=k.loop_config_vector_reduce,
                usharpid=self.get_usharp_id(bn_cache),
                layerid=self.vector_layer_id,
                layernum=1,
                force_ackgmb=False,
                sync_layer=False,
                micro_batch_mode=k.attr["bn_include_sample_loop"],
            )
            vector_reduce_asm.generate()
        elif k.ty == "BRFowardFullConnectBiasSoftmaxLoss":
            tcore_asm = br_mma(
                mata_shape=k.in_tensor[0].hw_shape,  # activation
                matb_shape=k.tensor[0].hw_shape,  # weight
                dt=[k.in_tensor[0].dtype, k.tensor[0].dtype, k.out_tensor[0].dtype],
                usharps=None,
                loop_configs={
                    "tensor_b": {"usharp": self.get_usharp_id(k.in_tensor[0])},
                    "tensor_a": {"usharp": self.get_usharp_id(k.tensor[0])},
                    "tensor_o": {"usharp": self.get_usharp_id(k.out_tensor[0])},
                },
                pingpong_a=k.top_config_tcore["pingpong_a"],
                pingpong_b=k.top_config_tcore["pingpong_b"],
                red_mode=k.top_config_tcore["redmode"],
                write_through=None,
            )
            tcore_asm.generate()
        elif k.ty == "BRFowardFullConnect":
            tcore_asm = br_mma(
                mata_shape=k.in_tensor[0].hw_shape,  # activation
                matb_shape=k.tensor[0].hw_shape,  # weight
                dt=[k.in_tensor[0].dtype, k.tensor[0].dtype, k.out_tensor[0].dtype],
                usharps=None,
                loop_configs={
                    "tensor_b": {"usharp": self.get_usharp_id(k.in_tensor[0])},
                    "tensor_a": {"usharp": self.get_usharp_id(k.tensor[0])},
                    "tensor_o": {"usharp": self.get_usharp_id(k.out_tensor[0])},
                },
                pingpong_a=k.top_config_tcore["pingpong_a"],
                pingpong_b=k.top_config_tcore["pingpong_b"],
                red_mode=k.top_config_tcore["redmode"],
                write_through=None,
            )
            tcore_asm.generate()
        elif k.ty == "BRFowardSoftmax":
            pass
        elif (
            self.ty == "BRBackConv2"
            or self.ty == "BRBackConv2ReluBatchNorm"
            or self.ty == "BRBackConv2AdderMaxpoolReluBatchNorm"
            or self.ty == "BRBackConv2AdderReluBatchNormBatchNorm"
            or self.ty == "BRBackConv2AdderReluBypassBatchNorm"
        ):
            # BPW
            # BPA
            pass
        elif self.ty == "BRBackAveragePool":
            pass
        elif self.ty == "BRBackFullConnect":
            pass
        elif self.ty == "BRBackSoftmax":
            pass
