#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.


import math


class hardware:
    def __init__(self):
        # default parameters
        self.core_freq=800.e6
        self.noc_freq= 1.5e9

        # One-die view
        self.spc_num=16
        # EU. SPC-view
        self.eu_lane=16*4*4
        self.eu_h = 4
        self.eu_w = 8 
        self.eu_oc = 32

        # tcore
        self.tcore_h = 8
        self.tcore_w = 8
        self.tcore_ic = 32
        self.tcore_oc = 32

        self.tcore_eu_ratio = (self.tcore_h * self.tcore_w * self.tcore_oc) // (self.eu_h * self.eu_w * self.eu_oc)

        # GEMM  
        self.gemm_mac = 16384
        
        # GIB
        self.bufb_rd_width = 8192
        self.bufa_rd_width = 4096
        self.bufa_sz=256*1024
        self.bufa_entries = self.bufa_sz / (self.bufa_rd_width / 8)
        self.bufb_sz=256*1024
        self.bufb_entries = self.bufb_sz / (self.bufb_rd_width / 8)
        
        # L1P5
        self.l1p5_sz = 4*1024*1024 # 4MiB
        self.l1p5_rd_width = 1024
        self.l1p5_granularity = 2*1024 # 2KiB 
        # L2: one-die view
        self.l2_pad_sz = 3*1024*1024 # 3MiB 
        self.l2_sz=(4*1024*1024 - self.l2_pad_sz)*16 # maximum 64MiB
        self.l2_rd_uma_bw=48e9*self.spc_num # one-die uma
        self.l2_wr_uma_bw=38.4e9*self.spc_num # one-die uma
        self.l2_rd_numa_bw=154e9
        self.l2_wr_numa_bw=96e9
        
        self.gmb_sz= self.l1p5_sz + self.l2_pad_sz
        self.gmb_granularity = 2*1024 # 2KiB 

        # HBM: one-die view
        # hbm2e / hbm2
        #self.hbm_type='hbm2e'
        self.hbm_stacks = 4
        self.hbm_sz = self.hbm_stacks * 16*1024*1024*1024 # 16GiB
        #if self.hbm_type=='hbm2e':
            #self.hbm_bw = 2*self.hbm_stacks*50e9 
        #elif self.hbm_type='hbm2':
            #self.hbm_bw = 2*self.hbm_stacks*30e9 
        #else:
            #assert(0, "unknown hbm type")
        
        # code_generator.shared rd/wr
        #self.hbm2_mnode_rd_bw = 1024*self.noc_freq
        #self.hbm2_mnode_wr_bw = 1024*self.noc_freq
         
        self.hbm_rd_uma_bw=48e9*self.spc_num # one-die uma
        self.hbm_wr_uma_bw=38.4e9*self.spc_num # one-die uma
        self.hbm_uma_bw=80e9*self.spc_num # one-die uma
        
        self.hbm_rd_numa_bw=80e9
        self.hbm_wr_numa_bw=80e9
    

        self.d2d_bw = 224e9 #GBps
        self.p2p_bw = 64e9 #GBps
        
    def get_eu_t(self, ops):
        return (ops / self.eu_lane) / self.core_freq
    
    def get_gemm_t(self, ops):
        return (ops / self.gemm_mac) / self.core_freq

    def get_memory_t(self, rd_traffic=0, wr_traffic=0, scope="hbm", uma_mode="uma"):
        if scope=="hbm":
            return self.get_hbm_t(rd_traffic=rd_traffic, wr_traffic=wr_traffic, uma_mode=uma_mode)
        elif scope=="l2":
            return self.get_l2_t(rd_traffic=rd_traffic, wr_traffic=wr_traffic, uma_mode=uma_mode)
        elif scope=="l1p5":
            return self.get_l1p5_t(rd_traffic=rd_traffic, wr_traffic=wr_traffic)
        elif scope=="gib":
            return self.get_gib_t(rd_traffic)
        else:
            assert 0, "invalid scope"
        
    def get_gib_t(self, rd_traffic):
        return rd_traffic / self.gib_width / self.core_freq
    def get_l1p5_t(self, rd_traffic=0, wr_traffic=0):
        return rd_traffic / self.l1p5_rd_width / self.core_freq
    def get_l2_t(self, tr):
        t_rd = 0
        t_wr = 0
        for i in tr:
            rd=i['rd']
            wr=i['wr']
            uma_mode=i['uma_mode']
            if uma_mode=="uma":
                t_rd+= rd / self.l2_rd_uma_bw
                t_wr+= wr / self.l2_wr_uma_bw
            elif uma_mode == 'numa':
                t_rd+= rd / self.l2_rd_numa_bw
                t_wr+= wr / self.l2_wr_numa_bw
            else:
                assert 0, "Unrecognized uma mode"
        return max(t_rd, t_wr)
        
    def get_hbm_t(self, tr):
        t = 0
        for i in tr:
            rd=i['rd']
            wr=i['wr']
            uma_mode=i['uma_mode']
            if uma_mode=="uma":
                t_rd= rd / self.hbm_rd_uma_bw
                t_wr= wr / self.hbm_wr_uma_bw
                t_total = (rd + wr)/ self.hbm_uma_bw
                t += max(t_rd, t_wr, t_total)
            elif uma_mode == 'numa':
                t_rd= rd / self.hbm_rd_numa_bw
                t_wr= wr / self.hbm_wr_numa_bw
                t+= t_rd + t_wr
            else:
                assert 0, "Unrecognized uma mode"
        return t

    def set_harvest_mode(self, faulty_set):
        pass

if __name__=="__main__":
    H=hw()

