from pprint import pformat
import code_generator.kernel_gen.math_utils as utils
from code_generator.kernel_gen.stream_pass import *
from code_generator.kernel_gen.inst import *
from code_generator.kernel_gen.channel import *
from code_generator.share.br_const_defs import *
from code_generator.kernel_gen.kernel_loop_unroll_pass import kernel_loop_unroll_pass
from code_generator.kernel_gen.kernel_selector_fwd_pass import kernel_selector_fwd_pass
from code_generator.kernel_gen.kernel_selector_bpa_pass import kernel_selector_bpa_pass
from code_generator.kernel_gen.kernel_selector_bpw_pass import kernel_selector_bpw_pass


class kernel_selector_pass(stream_pass):
    def __init__(self, hw, wl):
        super().__init__(hw, wl)
        self.pass_klr = kernel_loop_unroll_pass(hw, wl)
        self.pass_fwd = kernel_selector_fwd_pass(hw, wl)
        self.pass_bpw = kernel_selector_bpw_pass(hw, wl)
        self.pass_bpa = kernel_selector_bpa_pass(hw, wl)

    def run_on_stream(self):
        self.wl.get_stream().add_dump_header(["Reshape", "Kernel Ty"])
        ld_bufa_ch = channel(
            name="ld_bufa_ch",
            scope="gib",
            sync_ty="gsc",
            sz=2,
            token_sz=256,
            forward_start=32,
            backward_start=48,
        )
        ld_bufb_ch = channel(
            name="ld_bufb_ch",
            scope="gib",
            sync_ty="gsc",
            sz=16,
            token_sz=32,
            forward_start=0,
            backward_start=16,
        )
        tlr_ch = channel(
            name="tlr_ch",
            scope="tlr",
            sync_ty="bar.wtg",
            sz=2,
            token_sz=64,
            forward_start=6,
            backward_start=8,
        )
        grb_ch = channel(
            name="grb_ch",
            scope="grb_ch",
            sync_ty="bar.wtg",
            sz=2,
            token_sz=8,
            forward_start=2,
            backward_start=4,
        )
        reduce_bn_ch = channel(
            name="reduce_bn_ch",
            scope="grb",
            sync_ty="bar.wtg",
            sz=2,
            forward_start=4,
            backward_start=6,
        )
        inter_kernel_ch = channel(
            name="inter_kernel_ch",
            scope="",
            sync_ty="bar_wtg",
            sz=1,  # no back pressure
            back_pressure=False,
        )

        for i in self.wl.get_stream().stream():
            if isinstance(i, op_inst):
                if i.optimization_policy != None:
                    optimization_policy = i.optimization_policy
                else:
                    optimization_policy = self.wl.optimization_policy
                i.kernel_ty = set()
                if (
                    i.ty == "BRForwardConv2"
                    or i.ty == "BRForwardConv2BatchNormRelu"
                    or i.ty == "BRForwardConv2BatchNormReluMaxPool"
                    or i.ty == "BRForwardConv2BatchNormAdderRelu"
                    or i.ty == "BRForwardConv2BatchNorm"
                ):
                    ifm = i.in_tensor[0]
                    if i.ty == "BRForwardConv2":
                        weight = i.tensor[0]
                        ofm = i.out_tensor[0]
                    elif i.ty == "BRForwardConv2BatchNormRelu":
                        weight = i.tensor[1]
                        ofm = i.tensor[0]
                        bn_cache = i.tensor[2]
                    elif i.ty == "BRForwardConv2BatchNormReluMaxPool":
                        weight = i.tensor[1]
                        ofm = i.tensor[0]
                        bn_cache = i.tensor[2]
                    elif i.ty == "BRForwardConv2BatchNormAdderRelu":
                        ofm = i.tensor[0]
                        weight = i.tensor[2]
                        bn_cache = i.tensor[3]
                    elif i.ty == "BRForwardConv2BatchNorm":
                        weight = i.tensor[0]
                        ofm = i.out_tensor[0]
                        bn_cache = i.tensor[1]

                    N, IC, IH, IW = ifm.shape
                    N, OC, OH, OW = ofm.shape

                    dem_sz = i.in_tensor[0].get_dem_sz()
                    ifm_dem_sz = ifm.get_dem_sz()
                    w_dem_sz = weight.get_dem_sz()
                    ofm_dem_sz = ofm.get_dem_sz()
                    KH, KW = i.params["conv"]["k"]
                    PH, PW = i.params["conv"]["padding"]
                    SH, SW = i.params["conv"]["strides"]

                    HOC = 32
                    HIC = 8
                    HIH = 4
                    HIW = 8
                    if OC64_CONV_ROW64_MMA:
                        HACCUM = 2
                    else:
                        HACCUM = 1

                    # Attr:
                    #    vmc_mode: spc|vmc|auto
                    #    remove_epilog: True|False,
                    #    grb_size: 0..32. 0 for do not output to grb. invalid if ic_partition
                    # Output parameters:
                    # - kernel_ty: vmc_mode:spc|vmc, ic_partition: True|False, tlr_pingpong: True|False
                    # - ic_root, oc_root, toc, m

                    ####################### Step 1: Pee-hole transforms
                    IC = utils.ceil_block(IC, HIC)
                    OC = utils.ceil_block(OC, HOC)

                    # User input: vmc_mode, TIC
                    # if IH==7:
                    # vmc_mode='vmc'
                    # else:
                    # vmc_mode='spc'
                    vmc_mode = "spc"

                    if vmc_mode == "vmc":
                        N_spc = N
                        N = N * 4
                        OC_spc = OC
                        assert OC % 4 == 0
                        OC = OC // 4
                    if i.in_tensor[0].tiled_hw_shape == None:
                        N_H = 1
                        N_W = 1
                    else:
                        (N, _, _, N_H, _, N_W) = i.in_tensor[0].tiled_hw_shape
                    TIH = math.ceil(IH * N_H / HIH)
                    TIW = math.ceil(IW * N_W / HIW)

                    if KW > 1:
                        avail_bufb_sz = self.hw.bufb_sz / 2
                    else:
                        avail_bufb_sz = self.hw.bufb_sz

                    avail_bufa_sz = self.hw.bufa_sz

                    ########################  Step 2:
                    # oc reuse factor
                    """
                    m_min = math.ceil(4 / (KH * KW * HACCUM))

                    if m_min*HOC > OC:
                        m_min=math.floor(OC/HOC)

                    m_max = 8
                    TIC = avail_bufa_sz / (HIC*HACCUM*HOC*m_min*KH*KW*dem_sz)
                    if TIC*HIC < IC:
                        TIC = math.floor(TIC)
                        assert(TIC >= HIC)
                        ic_root = IC / (TIC * HIC)
                        ic_root = math.floor(ic_root)
                    else:
                        ic_root = 1
                        TIC = math.floor(IC / HIC)
                    IC_epilog = IC - ic_root * TIC * HIC
                    if IC_epilog!=0:
                        # Move total epilog to TIC
                        TIC = IC / ((ic_root+1)*HIC)
                        ic_root += 1
                        IC_epilog = 0
                    TOC = avail_bufa_sz / (TIC*HIC*HACCUM*HOC*m_min*KH*KW*dem_sz)
                    if TOC*HOC*m_min <= OC:
                        TOC = math.floor(TOC)
                        oc_root = OC / (TOC * m_min * HOC)
                        oc_root = math.floor(oc_root)
                    else:
                        oc_root = 1
                        TOC = math.floor(OC / (HOC*m_min))
                    
                    # Exchange TOC and m. Tradeoffs: more weight reuse, or more grb pingpong.
                    m = m_min
                    while(m <= m_max/2 and TOC>=2):
                        m*=2
                        TOC = TOC / 2
                    TOC= math.floor(TOC)
                    
                    # Remove epilog
                    OC_epilog = OC - oc_root * TOC * HOC * m
                    if OC_epilog!=0:
                        # Move total epilog to TOC
                        TOC =  OC / ((oc_root+1)*m*HOC)
                        oc_root += 1
                        OC_epilog = 0
                    """
                    # print(['N={:<4}, IC={:<4}, IH={:<4} , IW={:<4},OH={:<4} , OW={:<4}, OC={:<4}, KW={}, SW={}'.format(N, IC, IH, IW, OH, OW, OC, KW, SW)])
                    def is_satisfied(toc, tic):
                        occupied_bufa_sz = (
                            toc * tic * (HIC * HACCUM * HOC * KH * KW) * w_dem_sz
                        )

                        if occupied_bufa_sz <= self.hw.bufa_sz:
                            return True
                        else:
                            return False

                    # Meet reuse requirement
                    m_min = math.ceil(2 * HACCUM / (KH * KW))

                    if m_min * HOC * HACCUM > OC:
                        m_min = 1
                    toc = m_min
                    tic = 1
                    oc_root = OC / (toc * HOC * HACCUM)
                    ic_root = IC / (tic * HIC)
                    occupied_bufa_sz = (
                        toc * tic * (HIC * HACCUM * HOC * KH * KW) * w_dem_sz / 1024
                    )

                    changed = True
                    while changed:
                        changed = False
                        if tic * HIC < IC:
                            if is_satisfied(toc, tic + 1):
                                tic += 1
                                changed = True
                        elif toc * HOC * HACCUM < OC:
                            if is_satisfied(toc + 1, tic):
                                toc += 1
                                changed = True
                    oc_root = OC / (toc * HOC * HACCUM)
                    ic_root = IC / (tic * HIC)
                    occupied_bufa_sz = (
                        toc * tic * (HIC * HACCUM * HOC * KH * KW) * w_dem_sz / 1024
                    )
                    # Remove IC epilog
                    if optimization_policy["remove_ic_epilog"]:
                        if not ic_root.is_integer():
                            # Move total epilog to TIC
                            ic_root = utils.ceil_block(ic_root, 2)
                            tic = IC / ((ic_root) * HIC)
                            toc = self.hw.bufa_sz / (
                                tic * KH * KW * (HIC * HACCUM * HOC) * w_dem_sz
                            )
                            oc_root = OC / (toc * HOC * HACCUM)
                    else:
                        ic_root = math.ceil(ic_root)

                    if optimization_policy["remove_oc_epilog"]:
                        # Remove epilog
                        if not oc_root.is_integer():
                            oc_root = math.ceil(oc_root)
                            # Move total epilog to TOC
                            toc = OC / (oc_root * HOC * HACCUM)
                        # Remove TOC epilog
                        if isinstance(toc, int) or not toc.is_integer():
                            toc = math.floor(toc)
                            oc_root = OC / (toc * HOC * HACCUM)
                    else:
                        oc_root = math.ceil(oc_root)
                    occupied_bufa_sz = (
                        toc * tic * (HIC * HACCUM * HOC * KH * KW) * w_dem_sz / 1024
                    )
                    # print(f'oc_root={oc_root}, ic_root={ic_root}, tic={tic}, toc={toc},bufa={occupied_bufa_sz}')
                    if ic_root == 1:
                        # Split toc to toc and m
                        # Exchange TOC and m. Tradeoffs: more weight reuse, or more grb pingpong.
                        m = toc
                        m_max = 8
                        toc = 1
                        while m >= 2:
                            if m > m_max:
                                m /= 2
                                toc *= 2
                            else:
                                break
                    else:
                        m = toc
                        toc = 1
                    TOC = toc
                    TIC = tic
                    # Output constraints: TLR sz < 64
                    if ic_root > 1:
                        if KW > 1:
                            assert (
                                TOC * m * IW <= 64 * 32 * 4
                            ), "Exceed TLR ping-pong size constraints."
                        else:
                            assert (
                                TOC * m * IH <= 64 * 32 * 4
                            ), "Exceed TLR ping-pong size constraints."
                    if SW > 1:
                        if KW > 1:
                            assert m * IW <= 64 * 32 * 4, "Exceed TLR size constraints."
                        else:
                            assert m * IH <= 64 * 32 * 4, "Exceed TLR size constraints."

                    if ic_root > 1 or SW > 1:
                        if KW > 1:
                            # KW >1: loop order H, W, C
                            TOW = TIW // SW
                            TTOW = 1
                            while TOW >= 2:
                                tcore_out_tlr_num = TOW * m
                                if tcore_out_tlr_num > tlr_ch.token_sz:
                                    TOW /= 2
                                    TTOW *= 2
                                else:
                                    break
                            TIW = TOW * SW
                            TTIW = TTOW
                            if TTIW > 1:
                                self.wl.log.debug(
                                    f"tlr size constraints: furthur tiling w to {TTOW} / {TOW}"
                                )
                        else:
                            assert TOC * IH <= 64 * 32 * 4, "Exceed TLR size constraints."
                            # KW==1: loop order W, H, C
                            TOH = TIH // SW
                            TTOH = 1
                            while TOH >= 2:
                                tcore_out_tlr_num = TOH * m
                                if tcore_out_tlr_num > tlr_ch.token_sz:
                                    TOH /= 2
                                    TTOH *= 2
                                else:
                                    break
                            TIH = TOH * SH
                            TTIH = TTOH
                            if TTIH > 1:
                                self.wl.log.debug(
                                    f"tlr size constraints: furthur tiling h to {TTOH} / {TOH}"
                                )
                    oc_root = utils.to_int(oc_root)
                    ic_root = utils.to_int(ic_root)
                    TOC = utils.to_int(TOC)
                    TIC = utils.to_int(TIC)
                    # print(f'oc_root={oc_root}, ic_root={ic_root}, tic={tic}, toc={toc},bufa={occupied_bufa_sz}')
                    m = utils.to_int(m)
                    i.kernel_ty.add(vmc_mode)
                    if ic_root > 1:
                        i.kernel_ty.add("ic_partition")
                    # kw>1, 8*64c16h8w should not exceed 128KiB
                    if KW > 1:
                        assert (
                            TIC * HIC * (HIH * 4) * HIW * dem_sz <= avail_bufb_sz
                        ), "Further divide IC by bufB constraint. kw>1 "
                    else:
                        assert (
                            TIC * HIC * (HIH * 2) * HIW * dem_sz <= avail_bufb_sz
                        ), "Further divide IC by bufB constraint. kw==1"
                    self.wl.log.info(
                        "kernel_selector: {}, m={:<4}, oc_root={:<4}, TOC={:<4}, ic_root={:<4}, TIC={:<4}, w_buf={:3.0f}KiB".format(
                            vmc_mode,
                            m,
                            oc_root,
                            TOC,
                            ic_root,
                            TIC,
                            (HOC * HACCUM * m * TOC)
                            * (HIC * TIC)
                            * (KH * KW)
                            * dem_sz
                            / 1024,
                        )
                    )
                    self.wl.log.debug(
                        [
                            "{},  N={:<4}, IC={:<4}, IH={:<4} , IW={:<4},OH={:<4} , OW={:<4}, OC={:<4}, KW={}, SW={}".format(
                                i.name, N, IC, IH, IW, OH, OW, OC, KW, SW
                            )
                        ]
                    )
                    if bcd.ENABLE_ROW_ACCUMULATION:
                        hburst = True
                        tlr_h_step = 2  # 8 tlr for 64c16h8w
                    else:
                        hburst = False
                        tlr_h_step = 1

                    ########### Inter-kernel states ###########

                    # ic_step = 128 if TIC*HIC >= 128 else utils.ceil_block(TIC*HIC, 64)
                    # w_oc_begin = 0
                    # w_ic_begin = 0
                    # if isinstance(weight, slice_inst):
                    # w_oc_begin= weight.slice_begin[0]
                    # w_ic_begin= weight.slice_begin[1]
                    top_config_tcore = {}
                    ldconv0_oc_root_dict = {"start": 0}
                    ldconv0_ic_root_dict = {"start": 0}
                    ldconv0_oc_dict = {"start": 0}
                    ldconv0_ic_dict = {"start": 0}

                    # if isinstance(ifm, slice_inst):
                    # ifm_n_begin = ifm.slice_begin[0]
                    # ifm_ic_begin = ifm.slice_begin[1]

                    ldconv1_oc_root_dict = {"start": 0}
                    ldconv1_ic_root_dict = {"start": 0}
                    ldconv1_toc_dict = {"start": 0}
                    ldconv1_n_dict = {"start": 0}
                    ldconv1_h_dict = {"start": 0}
                    ldconv1_w_dict = {"start": 0}
                    ldconv1_ic_dict = {"start": 0}

                    conv_oc_root_dict = {"start": 0}
                    conv_ic_root_dict = {"start": 0}
                    conv_toc_dict = {"start": 0}
                    conv_n_dict = {"start": 0}
                    conv_th_dict = {"start": 0}
                    conv_tw_dict = {"start": 0}
                    conv_h_dict = {"start": 0}
                    conv_w_dict = {"start": 0}
                    conv_oc_dict = {"start": 0}
                    conv_ic_dict = {"start": 0}

                    if isinstance(ofm, slice_inst):
                        ofm_n_begin = ofm.hw_shape_slice_begin[0]
                        # ofm_c_begin = ofm.hw_shape_slice_begin[1]
                        ofm_h_begin = ofm.hw_shape_slice_begin[2]
                        ofm_w_begin = ofm.hw_shape_slice_begin[3]
                    else:
                        ofm_n_begin = 0
                        # ofm_c_begin = 0
                        ofm_h_begin = 0
                        ofm_w_begin = 0

                    vector_oc_root_dict = {"start": 0}
                    vector_ic_root_dict = {"start": 0}
                    vector_toc_dict = {"start": 0}
                    vector_n_dict = {"start": ofm_n_begin}
                    vector_h_dict = {"start": ofm_h_begin}
                    vector_w_dict = {"start": ofm_w_begin}
                    vector_oc_dict = {"start": 0}

                    # BufferA Channel
                    ld_bufa_ch_counts = oc_root
                    if (HACCUM * HOC * m * TOC) * (HIC * TIC) * (KH * KW) * dem_sz <= (
                        self.hw.bufb_sz // 2
                    ):
                        # Pingpong
                        ld_bufa_ch.set_prolog_state(True)
                        ldconv0_oc_root_dict.update(
                            ld_bufa_ch.get_loop_config_dict("producer", ld_bufa_ch_counts)
                        )
                        conv_oc_root_dict.update(
                            ld_bufa_ch.get_loop_config_dict("consumer", ld_bufa_ch_counts)
                        )
                        top_config_tcore["pingpong_a"] = ld_bufa_ch.get_token_addr(
                            oc_root
                        )  # ping [0, 256] | pong [256, 0]
                        ld_bufa_ch.forward_to_epilog_state(1, ld_bufa_ch_counts)
                    else:
                        # single buffer
                        ld_bufa_ch.set_prolog_state(False)
                        ldconv0_oc_root_dict.update(
                            ld_bufa_ch.get_loop_config_dict("producer", 1)
                        )
                        conv_oc_root_dict.update(
                            ld_bufa_ch.get_loop_config_dict("consumer", 1)
                        )
                        top_config_tcore["pingpong_a"] = ld_bufa_ch.get_token_addr(
                            oc_root
                        )  # ping [0, 256] | pong [256, 0]
                        ld_bufa_ch.forward_to_epilog_state(1, ld_bufa_ch_counts)

                    # BufferB Channel
                    if KW > 1:
                        # TODO: Incorrect. Policy unclear. 
                        # First iteration of W
                        ld_bufb_outer_counts = (
                            oc_root * ic_root * TOC * N * math.ceil(IH * N_H / HIH)
                        )
                        ld_bufb_inner_counts = (
                            oc_root
                            * ic_root
                            * TOC
                            * N
                            * math.ceil(IH * N_H / HIH)
                            * math.ceil(IC / 128)
                        )
                        ld_bufb_ch.set_prolog_state(True)
                        top_config_tcore["pingpong_b"] = ld_bufb_ch.get_token_addr(
                            ld_bufb_inner_counts
                        )
                        ld_bufb_ch.forward_to_epilog_state(
                            ld_bufb_outer_counts, ld_bufb_inner_counts
                        )
                    else:
                        # TODO: Incorrect. Policy unclear. 
                        # KW==1
                        ld_bufb_counts = (
                            oc_root
                            * ic_root
                            * TOC
                            * N
                            * math.ceil(IW * N_W / HIW)
                            * math.ceil(IH * N_H / HIH)
                            * math.ceil(IC / 128)
                        )
                        ld_bufb_ch.set_prolog_state(False)
                        top_config_tcore["pingpong_b"] = ld_bufb_ch.get_token_addr(1)
                        ld_bufb_ch.forward_to_epilog_state(1, ld_bufb_counts)

                    if ic_root == 1:
                        rmode = "ssq"
                        # GRB pingpong
                        if i.ty != "BRForwardConv2":
                            grb_ch.set_prolog_state(True)
                            # bn_include_sample_loop
                            if (
                                "bn_include_sample_loop" in i.attr
                                and i.attr["bn_include_sample_loop"] == True
                            ):
                                grb_ch_counts = TOC * oc_root * N
                                conv_n_dict.update(
                                    grb_ch.get_loop_config_dict("producer", grb_ch_counts)
                                )
                                vector_n_dict.update(
                                    grb_ch.get_loop_config_dict("consumer", grb_ch_counts)
                                )
                                conv_n_dict["grb_pingpong"] = grb_ch.get_token_addr(
                                    grb_ch_counts
                                )
                                vector_n_dict["grb_pingpong"] = grb_ch.get_token_addr(
                                    grb_ch_counts
                                )
                            else:
                                grb_ch_counts = TOC * oc_root
                                conv_toc_dict.update(
                                    grb_ch.get_loop_config_dict("producer", grb_ch_counts)
                                )
                                vector_toc_dict.update(
                                    grb_ch.get_loop_config_dict("consumer", grb_ch_counts)
                                )
                                conv_toc_dict["grb_pingpong"] = grb_ch.get_token_addr(
                                    grb_ch_counts
                                )
                                vector_toc_dict["grb_pingpong"] = grb_ch.get_token_addr(
                                    grb_ch_counts
                                )
                            grb_ch.forward_to_epilog_state(1, grb_ch_counts)
                    else:
                        # IC partition
                        rmode = "roff"
                    top_config_tcore["redmode"] = rmode

                    # TLR Pingpong Channel
                    if SW > 1 or ic_root > 1:
                        i.kernel_ty.add("tlr_pingpong")
                        if (SW > 1 and ic_root > 1) or (SW > 1):
                            ic_root_body = ic_root
                            # Output of prolog ic_root is written to GMB, instead of TLR.
                        else:
                            # ic_root >1:
                            ic_root_body = ic_root - 1
                        if KW > 1 and not hburst:
                            tlr_ch_counts = (
                                oc_root
                                * ic_root_body
                                * TOC
                                * N
                                * math.ceil(IH * N_H // SH / HIH)
                            )
                            tlr_ch.set_prolog_state(True)
                            conv_h_dict.update(
                                tlr_ch.get_loop_config_dict("producer", tlr_ch_counts)
                            )
                            vector_h_dict.update(
                                tlr_ch.get_loop_config_dict("consumer", tlr_ch_counts)
                            )
                            conv_h_dict["tlr_pingpong"] = tlr_ch.get_token_addr(
                                tlr_ch_counts
                            )
                            vector_h_dict["tlr_pingpong"] = tlr_ch.get_token_addr(
                                tlr_ch_counts
                            )
                            top_config_tcore["tlr_pingpong"] = tlr_ch.get_token_addr(
                                tlr_ch_counts
                            )
                            tlr_ch.forward_to_epilog_state(1, tlr_ch_counts)
                        else:
                            # KW==1
                            tlr_ch_counts = (
                                oc_root
                                * ic_root_body
                                * TOC
                                * N
                                * math.ceil(IW * N_W // SW / HIW)
                            )
                            tlr_ch.set_prolog_state(True)
                            conv_w_dict.update(
                                tlr_ch.get_loop_config_dict("producer", tlr_ch_counts)
                            )
                            vector_w_dict.update(
                                tlr_ch.get_loop_config_dict("consumer", tlr_ch_counts)
                            )
                            conv_w_dict["tlr_pingpong"] = tlr_ch.get_token_addr(
                                tlr_ch_counts
                            )
                            vector_w_dict["tlr_pingpong"] = tlr_ch.get_token_addr(
                                tlr_ch_counts
                            )
                            top_config_tcore["tlr_pingpong"] = tlr_ch.get_token_addr(
                                tlr_ch_counts
                            )
                            tlr_ch.forward_to_epilog_state(1, tlr_ch_counts)
                    ##################### Output #####################
                    # ldconv0
                    loop_config_ldconv0 = [
                        [
                            OC_ROOT_LOOP_NAME,
                            oc_root,
                            1,
                            HOC * HACCUM * m * TOC,
                            ldconv0_oc_root_dict,
                        ],
                        [IC_ROOT_LOOP_NAME, ic_root, 1, TIC * HIC, ldconv0_ic_root_dict],
                        ["oc", TOC * m, 1, HOC * HACCUM, ldconv0_oc_dict],
                        ["ich", 1, 1, TIC * HIC, ldconv0_ic_dict],
                    ]
                    if KW > 1 and not hburst:
                        # KW > 1
                        # ldconv1
                        loop_config_ldconv1 = [
                            [
                                OC_ROOT_LOOP_NAME,
                                oc_root,
                                1,
                                HOC * HACCUM * m * TOC,
                                ldconv1_oc_root_dict,
                            ],
                            [
                                IC_ROOT_LOOP_NAME,
                                ic_root,
                                1,
                                TIC * HIC,
                                ldconv1_ic_root_dict,
                            ],
                            ["oc", TOC, 1, HOC * HACCUM * m, ldconv1_toc_dict],
                            ["sample", N, 1, 1, ldconv1_n_dict],
                            [
                                "row",
                                math.ceil(IH * N_H / (HIH * 2)),
                                1,
                                HIH * 2,
                                ldconv1_h_dict,
                            ],
                            ["col", math.ceil(IW * N_W / HIW), 1, HIW, ldconv1_w_dict],
                            ["ich", 1, 1, TIC * HIC, ldconv1_ic_dict],
                        ]
                        # conv
                        if ic_root == 1:
                            # not ic partition
                            loop_config_conv = [
                                [
                                    OC_ROOT_LOOP_NAME,
                                    oc_root,
                                    1,
                                    HOC * HACCUM * TOC * m,
                                    conv_oc_root_dict,
                                ],
                                ["oc", TOC, 1, HOC * HACCUM * m, conv_toc_dict],
                                ["sample", N, 1, 1, conv_n_dict],
                                [
                                    "row",
                                    math.ceil(IH * N_H / (HIH * 2)),
                                    1,
                                    HIH * 2,
                                    conv_h_dict,
                                ],
                                ["col", math.ceil(IW * N_W / HIW), 1, HIW, conv_w_dict],
                                ["inner_oc", m, 1, HOC * HACCUM, conv_oc_dict],  # 8*32
                                ["ich", 1, 1, TIC * HIC, conv_ic_dict],
                            ]
                        else:
                            # ic partition
                            loop_config_conv = [
                                [
                                    OC_ROOT_LOOP_NAME,
                                    oc_root,
                                    1,
                                    TOC * HOC * HACCUM * m,
                                    conv_oc_root_dict,
                                ],
                                [
                                    IC_ROOT_LOOP_NAME,
                                    ic_root,
                                    1,
                                    TIC * HIC,
                                    conv_ic_root_dict,
                                ],
                                ["sample", N, 1, 1, conv_n_dict],
                                [
                                    "row",
                                    math.ceil(IH * N_H / (HIH * 2)),
                                    1,
                                    HIH * 2,
                                    conv_h_dict,
                                ],
                                ["col", math.ceil(IW * N_W / HIW), 1, HIW, conv_w_dict],
                                [
                                    "inner_oc",
                                    m * TOC,
                                    1,
                                    HOC * HACCUM,
                                    conv_oc_dict,
                                ],  # 8*32
                                ["ich", 1, 1, TIC * HIC, conv_ic_dict],
                            ]
                    else:
                        # KW ==1 or hburst
                        # ldconv1
                        loop_config_ldconv1 = [
                            [
                                OC_ROOT_LOOP_NAME,
                                oc_root,
                                1,
                                HOC * HACCUM * m * TOC,
                                ldconv1_oc_root_dict,
                            ],
                            [
                                IC_ROOT_LOOP_NAME,
                                ic_root,
                                1,
                                TIC * HIC,
                                ldconv1_ic_root_dict,
                            ],
                            ["oc", TOC, 1, HOC * HACCUM * m, ldconv1_toc_dict],
                            ["sample", N, 1, 1, ldconv1_n_dict],
                            ["col", math.ceil(IW * N_W / HIW), 1, HIW, ldconv1_w_dict],
                            [
                                "row",
                                math.ceil(IH * N_H / (self.hw.tcore_h)),
                                1,
                                self.hw.tcore_h,
                                ldconv1_h_dict,
                            ],
                            ["ich", 1, 1, TIC * HIC, ldconv1_ic_dict],
                        ]
                        # conv
                        if ic_root == 1:
                            loop_config_conv = [
                                [
                                    OC_ROOT_LOOP_NAME,
                                    oc_root,
                                    1,
                                    HOC * HACCUM * TOC * m,
                                    conv_oc_root_dict,
                                ],
                                ["oc", TOC, 1, HACCUM * HOC * m, conv_toc_dict],
                                ["sample", N, 1, 1, conv_n_dict],
                                [
                                    "col",
                                    math.ceil(IW * N_W / (self.hw.tcore_w)),
                                    1,
                                    self.hw.tcore_w,
                                    conv_w_dict,
                                ],
                                [
                                    "row",
                                    math.ceil(IH * N_H / (self.hw.tcore_h)),
                                    1,
                                    self.hw.tcore_h,
                                    conv_h_dict,
                                ],
                                ["inner_oc", m, 1, HOC * HACCUM, conv_oc_dict],  # 8*32
                                ["ich", 1, 1, TIC * HIC, conv_ic_dict],
                            ]
                        else:
                            # ic partition
                            loop_config_conv = [
                                [
                                    OC_ROOT_LOOP_NAME,
                                    oc_root,
                                    1,
                                    TOC * HOC * HACCUM * m,
                                    conv_oc_root_dict,
                                ],
                                [
                                    IC_ROOT_LOOP_NAME,
                                    ic_root,
                                    1,
                                    TIC * HIC,
                                    conv_ic_root_dict,
                                ],
                                ["sample", N, 1, 1, conv_n_dict],
                                ["col", math.ceil(IW * N_W / HIW), 1, HIW, conv_w_dict],
                                [
                                    "row",
                                    math.ceil(IH * N_H / (HIH * 2)),
                                    1,
                                    HIH * 2,
                                    conv_h_dict,
                                ],
                                [
                                    "inner_oc",
                                    m * TOC,
                                    1,
                                    HOC * HACCUM,
                                    conv_oc_dict,
                                ],  # 8*32
                                ["ich", 1, 1, TIC * HIC, conv_ic_dict],
                            ]
                    if i.loop_config_ldconv0 == []:
                        i.loop_config_ldconv0 = loop_config_ldconv0
                    if i.loop_config_ldconv1 == []:
                        i.loop_config_ldconv1 = loop_config_ldconv1
                    if i.loop_config_conv == []:
                        i.loop_config_conv = loop_config_conv
                    i.top_config_tcore = top_config_tcore

                    # vector
                    if SW > 1 and ic_root > 1:
                        # strides ==2 and IC partition
                        if KW > 1 and not hburst:
                            # stm and reduce
                            loop_config_vector_reduce = [
                                [
                                    OC_ROOT_VECTOR_LOOP_NAME,
                                    oc_root,
                                    1,
                                    TOC * HOC * HACCUM * m,
                                    vector_oc_root_dict,
                                ],
                                [
                                    IC_ROOT_VECTOR_LOOP_NAME,
                                    ic_root - 1,
                                    1,
                                    TIC * HIC,
                                    vector_ic_root_dict,
                                ],
                                ["sample", N, 1, 1, vector_n_dict],
                                [
                                    "row",
                                    math.ceil(IH * N_H / 8),
                                    1,
                                    4,
                                    vector_h_dict,
                                ],  # Use 1 TLR
                                [
                                    "col",
                                    math.ceil(IW * N_W / (8 * SW)),
                                    1,
                                    8,
                                    vector_w_dict,
                                ],
                                ["inner_oc", TOC * m, 1, HOC * HACCUM, vector_oc_dict],
                            ]
                            self.wl.log.debug(
                                "vector_s2_stm_reduce=\n"
                                + pformat(i.loop_config_vector_reduce)
                            )
                        else:
                            # KW==1 or hburst
                            # stm and reduce
                            loop_config_vector_reduce = [
                                [
                                    OC_ROOT_VECTOR_LOOP_NAME,
                                    oc_root,
                                    1,
                                    TOC * HOC * HACCUM * m,
                                    vector_oc_root_dict,
                                ],
                                [
                                    IC_ROOT_VECTOR_LOOP_NAME,
                                    ic_root - 1,
                                    1,
                                    TIC * HIC,
                                    vector_ic_root_dict,
                                ],
                                ["sample", N, 1, 1, vector_n_dict],
                                [
                                    "col",
                                    math.ceil(IW * N_W / (8 * SW)),
                                    1,
                                    8,
                                    vector_w_dict,
                                ],
                                ["row", math.ceil(IH * N_H / (8*SH*tlr_h_step)), 1, 8*tlr_h_step, vector_h_dict],
                                ["inner_oc", TOC * m, 1, HOC * HACCUM, vector_oc_dict],
                            ]
                            self.wl.log.debug(
                                "vector_s2_stm_reduce=\n"
                                + pformat(i.loop_config_vector_reduce)
                            )
                    elif SW > 1:
                        # strides ==2
                        if KW > 1 and not hburst:
                            # stm and reduce
                            loop_config_vector_reduce = [
                                [
                                    OC_ROOT_VECTOR_LOOP_NAME,
                                    oc_root,
                                    1,
                                    TOC * HOC * HACCUM * m,
                                    vector_oc_root_dict,
                                ],
                                [
                                    TOC_VECTOR_LOOP_NAME,
                                    TOC,
                                    1,
                                    HOC * HACCUM * m,
                                    vector_toc_dict,
                                ],
                                ["sample", N, 1, 1, vector_n_dict],
                                [
                                    "row",
                                    math.ceil(IH * N_H / 8),
                                    1,
                                    4,
                                    vector_h_dict,
                                ],  # Use 1 TLR
                                [
                                    "col",
                                    math.ceil(IW * N_W / (8 * SW)),
                                    1,
                                    8,
                                    vector_w_dict,
                                ],
                                ["inner_oc", m, 1, HOC * HACCUM, vector_oc_dict],
                            ]
                            self.wl.log.debug(
                                "vector_s2_stm_reduce=\n"
                                + pformat(i.loop_config_vector_reduce)
                            )
                        else:
                            # KW==1 or hburst
                            # stm and reduce
                            loop_config_vector_reduce = [
                                [
                                    OC_ROOT_VECTOR_LOOP_NAME,
                                    oc_root,
                                    1,
                                    TOC * HOC * HACCUM * m,
                                    vector_oc_root_dict,
                                ],
                                [
                                    TOC_VECTOR_LOOP_NAME,
                                    TOC,
                                    1,
                                    HOC * HACCUM * m,
                                    vector_toc_dict,
                                ],
                                ["sample", N, 1, 1, vector_n_dict],
                                [
                                    "col",
                                    math.ceil(IW * N_W / (8 * SW)),
                                    1,
                                    8,
                                    vector_w_dict,
                                ],
                                ["row", math.ceil(IH * N_H / (8*SH*tlr_h_step)), 1, 8*tlr_h_step, vector_h_dict],
                                ["inner_oc", m, 1, HOC * HACCUM, vector_oc_dict],
                            ]
                            self.wl.log.debug(
                                "vector_s2_stm_reduce=\n"
                                + pformat(i.loop_config_vector_reduce)
                            )
                    elif ic_root > 1:
                        # IC partition
                        if KW > 1 and not hburst:
                            loop_config_vector_reduce = [
                                [
                                    OC_ROOT_VECTOR_LOOP_NAME,
                                    oc_root,
                                    1,
                                    TOC * HOC * HACCUM * m,
                                    vector_oc_root_dict,
                                ],
                                [
                                    IC_ROOT_VECTOR_LOOP_NAME,
                                    ic_root - 1,
                                    1,
                                    TIC * HIC,
                                    vector_ic_root_dict,
                                ],
                                ["sample", N, 1, 1, vector_n_dict],
                                [
                                    "row",
                                    math.ceil((N_H * OH) / (HIH * 2)),
                                    1,
                                    HIH * 2,
                                    vector_h_dict,
                                ],
                                [
                                    "col",
                                    math.ceil((N_W * OW) / HIW),
                                    1,
                                    HIW,
                                    vector_w_dict,
                                ],
                                ["inner_oc", TOC * m, 1, HOC * HACCUM, vector_oc_dict],
                            ]
                            self.wl.log.debug(
                                "vector_ic_partition_reduce=\n"
                                + pformat(i.loop_config_vector_reduce)
                            )
                        else:
                            # KW==1
                            loop_config_vector_reduce = [
                                [
                                    OC_ROOT_VECTOR_LOOP_NAME,
                                    oc_root,
                                    1,
                                    TOC * HOC * HACCUM * m,
                                    vector_oc_root_dict,
                                ],
                                [
                                    IC_ROOT_VECTOR_LOOP_NAME,
                                    ic_root - 1,
                                    1,
                                    TIC * HIC,
                                    vector_ic_root_dict,
                                ],
                                ["sample", N, 1, 1, vector_n_dict],
                                [
                                    "col",
                                    math.ceil((N_W * OW) / HIW),
                                    1,
                                    HIW,
                                    vector_w_dict,
                                ],
                                [
                                    "row",
                                    math.ceil((N_H * OH) / (HIH * 2 * tlr_h_step)),
                                    1,
                                    HIH * 2 * tlr_h_step,
                                    vector_h_dict,
                                ],
                                ["inner_oc", TOC * m, 1, HOC * HACCUM, vector_oc_dict],
                            ]
                            self.wl.log.debug(
                                "vector_ic_partition_reduce=\n"
                                + pformat(i.loop_config_vector_reduce)
                            )
                    else:
                        # default. only reduce
                        if (
                            "bn_include_sample_loop" in i.attr
                            and i.attr["bn_include_sample_loop"] == True
                        ):
                            loop_config_vector_reduce = [
                                [
                                    OC_ROOT_VECTOR_LOOP_NAME,
                                    oc_root,
                                    1,
                                    TOC * HOC * HACCUM * m,
                                    vector_oc_root_dict,
                                ],
                                [
                                    TOC_VECTOR_LOOP_NAME,
                                    TOC,
                                    1,
                                    HOC * HACCUM * m,
                                    vector_toc_dict,
                                ],
                                ["sample", N, 1, 1, vector_n_dict],
                                ["inner_oc", m, 1, HOC * HACCUM, vector_oc_dict],
                            ]
                        else:
                            loop_config_vector_reduce = [
                                [
                                    OC_ROOT_VECTOR_LOOP_NAME,
                                    oc_root,
                                    1,
                                    TOC * HOC * HACCUM * m,
                                    vector_oc_root_dict,
                                ],
                                [
                                    TOC_VECTOR_LOOP_NAME,
                                    TOC,
                                    1,
                                    HOC * HACCUM * m,
                                    vector_toc_dict,
                                ],
                                ["inner_oc", m, 1, HOC * HACCUM, vector_oc_dict],
                            ]
                        self.wl.log.debug(
                            "vector_reduce=\n" + pformat(loop_config_vector_reduce)
                        )
                    if i.loop_config_vector_reduce == []:
                        i.loop_config_vector_reduce = loop_config_vector_reduce
                    # cwarp4
                    if (
                        "bn_include_sample_loop" in i.attr
                        and i.attr["bn_include_sample_loop"] == True
                    ):
                        loop_config_vector_elemwise = [
                            [
                                OC_ROOT_VECTOR_LOOP_NAME,
                                oc_root * TOC,
                                1,
                                TOC * m * HOC * HACCUM,
                                {},
                            ],

                            ["sample", N, 1, 1, {}],    # reduce-bn sync
                            ["inner_oc", m, 1, HOC * HACCUM, {}],
                        ]
                    else:
                        loop_config_vector_elemwise = [
                            [
                                OC_ROOT_VECTOR_LOOP_NAME,
                                oc_root * TOC,
                                1,
                                TOC * m * HOC * HACCUM,
                                {},
                            ],  # reduce-bn sync
                            ["inner_oc", m, 1, HOC * HACCUM, {}],
                        ]
                    self.wl.log.debug(
                        "vector_elemwise=\n" + pformat(loop_config_vector_elemwise))
                    if i.loop_config_vector_elemwise == []:
                        i.loop_config_vector_elemwise = loop_config_vector_elemwise
                    #### loop unroll
                    self.pass_klr.run_on_kernel(i)
                    self.wl.log.debug(
                        pformat(i.loop_config_ldconv0) + '\n' +
                        pformat(i.loop_config_ldconv1) + '\n' +
                        pformat(i.loop_config_conv)
                    )
                    i.kernel_loop_vars = {
                        "oc_root": oc_root,
                        "ic_root": ic_root,
                        "toc": TOC,
                        "n": N,
                        "h": math.ceil(IH / HIH),
                        "w": math.ceil(IW / HIW),
                        "tic": TIC,
                    }
                    i.add_dump_field(
                        field=[
                            "{}, m={:<4}, oc_root={:<4}, TOC={:<4}, ic_root={:<4}, TIC={:<4}, w_buf={:3.0f}KiB".format(
                                vmc_mode,
                                m,
                                oc_root,
                                TOC,
                                ic_root,
                                TIC,
                                (HOC * HACCUM * m * TOC)
                                * (HIC * TIC)
                                * (KH * KW)
                                * dem_sz
                                / 1024,
                            )
                        ]
                    )
                    # cost model
                    i.hw_cost = {"bufa": 0, "bufb": 0, "gemm": 0}
                    i.task_cost = {
                        "cwarp0": 0,
                        "cwarp1": 0,
                        "cwarp2": 0,
                        "cwarp3": 0,
                        "cwarp4": 0,
                    }
                    #print("loop_config_vector_reduce = \n" + pformat(loop_config_vector_reduce))
                elif "BRFullConnect" in i.ty:
                    (M, K) = i.in_tensor[0].shape
                    (N, _) = i.tensor[0].shape  # actual K N

                    HM = 64
                    HN = 64

                    # occupied_bufa_sz
                    # occupied_bufb_sz

                # elif self.ty == 'BRBackConv2AdderMaxpoolReluBatchNorm' or \
                # self.ty == 'BRBackConv2AdderReluBatchNormBatchNorm' or \
                # self.ty == 'BRBackConv2AdderReluBypassBatchNorm':
                elif "BRBackConv2" in i.ty:
                    if i.optimization_policy != None:
                        optimization_policy = i.optimization_policy
                    else:
                        optimization_policy = self.wl.optimization_policy
                    # self.pass_bpw.run_on_kernel(i, optimization_policy)
                    # self.pass_bpa.run_on_kernel(i, optimization_policy)

    def summarize_kernels(self):
        for i in self.wl.get_stream():
            pass
