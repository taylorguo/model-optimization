import code_generator.kernel_gen.math_utils as utils
from code_generator.kernel_gen.inst import *
class channel:
    def __init__(self, name, scope='tlr', sync_ty='bar', shape=None, 
            sz=1, token_sz = 1, 
            forward_start=0, backward_start=0,
            producer='', consumer='', back_pressure=True):
        self.name = name
        # tlr, gib, gmb 
        self.scope= scope
        # gsc, bar.wtg, sc
        self.sync_ty= sync_ty
        self.forward_start = forward_start
        self.backward_start = backward_start
        self.sz = sz
        self.token_sz = token_sz
        self.ptr = -1  
        self.pingpong = False
        self.producer = producer
        self.consumer = consumer
        self.back_pressure= back_pressure 
        self.initialized = False
    def get_token_addr(self, token_num):
        sz = self.sz if token_num > self.sz else token_num 
        if self.name=='ld_bufb_ch' and self.pingpong:
            l = [ self.ptr, (self.ptr + self.sz//2) % self.sz]
        else: 
            l = utils.get_wrap_list(0 ,self.sz, self.ptr, sz)
        return [i*self.token_sz for i in l]
    def get_loop_config_dict(self, producer_consumer, token_num):
        sz = self.sz if token_num > self.sz else token_num 
        # producer wait, producer signal,consumer wait, consumer signal
        if self.name=='ld_bufa_ch':
            loop_config_keys = ['wset', 'sset', 'wset', 'sset']
        elif self.name=='ld_bufb_ch':
            loop_config_keys = ['bufb_wset', 'bufb_sset', 'bufb_wset', 'bufb_sset']
        elif self.name=='tlr_ch':
            loop_config_keys = ['tlr_bar_sync', 'tlr_bar_set', 'tlr_bar_csm', 'tlr_bar_pass'] 
        elif self.name=='grb_ch':
            loop_config_keys =['bar_sync', 'bar_set', 'bar_csm', 'bar_pass']
        elif self.name=='reduce_bn_ch':
            loop_config_keys =['bar.tg.sync', 'bar.tg.pass', 'bar.tg.sync', 'bar.tg.pass']
        elif self.name=='inter_kernel_ch':
            loop_config_keys =['', 'bar.wtg.pass', '', 'bar.wtg.sync']
        if producer_consumer=='producer':
            if self.back_pressure:
                loop_config_dict = {loop_config_keys[0]: utils.get_wrap_list(self.backward_start, self.sz, self.ptr, sz),
                    loop_config_keys[1]: utils.get_wrap_list(self.forward_start ,self.sz, self.ptr, sz) }
            else:
                loop_config_dict = { 
                    loop_config_keys[1]: utils.get_wrap_list(self.forward_start ,self.sz, self.ptr, sz) }
        else:
            #consumer 
            if self.back_pressure:
                loop_config_dict = {loop_config_keys[2]: utils.get_wrap_list(self.forward_start, self.sz, self.ptr, sz),
                    loop_config_keys[3]: utils.get_wrap_list(self.backward_start ,self.sz, self.ptr, sz) }
            else:
                loop_config_dict = {loop_config_keys[2]: utils.get_wrap_list(self.forward_start, self.sz, self.ptr, sz)}
        return loop_config_dict
    def inc(self, pingpong=False, outer_ch_inc=0, inner_ch_inc=0):
        if self.name=='ld_bufb_ch' and pingpong:
            outer_ch = (self.ptr // (self.sz //2) + outer_ch_inc) % 2
            inner_ch = (self.ptr + inner_ch_inc) % (self.sz//2)
            self.ptr = int(outer_ch * self.sz//2 + inner_ch)
        elif self.name =='ld_bufa_ch' and not pingpong:
            return 
        else:
            self.ptr = (self.ptr + inner_ch_inc) % self.sz

    def set_prolog_state(self, cur_pp):
        if not self.initialized:
            self.ptr = 0
            self.initialized = True
            self.pingpong = cur_pp
            return
        if self.name =='ld_bufa_ch': 
            if self.pingpong and cur_pp:
                # pp -> pp
                self.inc(True, 0, 1)
            else: 
                # other cases, keep last ptr
                self.inc(False, 0, 0)
        elif self.name == 'ld_bufb_ch':
            if not self.pingpong and not cur_pp:
                # 1x1 -> 1x1
                self.inc(False, 0, 1)
            elif not self.pingpong and cur_pp:
                # 1x1 -> 3x3
                self.inc(True, 1, 1)
            elif self.pingpong and not cur_pp:
                # 3x3 -> 1x1
                self.inc(True, 1,1)
            elif self.pingpong and cur_pp:
                # 3x3 -> 3x3
                self.inc(True, 0,1)
        else:
            # Circular buffer / pingpong 
            self.inc(False, 0, 1)
        self.pingpong = cur_pp
    def forward_to_epilog_state(self, outer_ch_inc=0, inner_ch_inc=0):
        self.inc(self.pingpong, outer_ch_inc-1, inner_ch_inc-1) 
        
if __name__=='__main__':
    ld_bufa_ch = channel(name='ld_bufa_ch', scope='gib', sync_ty='gsc',
        sz=2, token_sz=256, 
        forward_start=32, backward_start=48)
    ld_bufb_ch = channel(name='ld_bufb_ch', scope='gib', sync_ty='gsc',
        sz=16,  token_sz=32,
        forward_start=0, backward_start=16)
    tlr_ch = channel(name='tlr_ch', scope='tlr', sync_ty='bar.wtg', 
            sz=2, token_sz=64,
            forward_start=6, backward_start=8)
    grb_ch = channel(name='grb_ch', scope='grb_ch', sync_ty='bar.wtg', 
            sz=2, 
            forward_start=2, backward_start=4)
    reduce_bn_ch = channel(name='reduce_bn_ch', scope='grb', sync_ty='bar.wtg',
            sz=2,
            forward_start =4, backward_start =6)
    inter_kernel_ch = channel(name='inter_kernel_ch', scope= '', sync_ty='bar_wtg', 
            sz=1,  # no back pressure
            back_pressure=False)
    ##
    print(ld_bufa_ch.get_loop_config_dict('producer', 1))
    print(ld_bufa_ch.get_loop_config_dict('consumer', 1))
    ld_bufa_ch.set_prolog_state(True) 
    print('pingpong_a', ld_bufa_ch.get_token_addr(1))
    ld_bufa_ch.forward_to_epilog_state(1, 1)
    
    ld_bufa_ch.set_prolog_state(True) 
    print('pingpong_a', ld_bufa_ch.get_token_addr(1))
    ld_bufa_ch.forward_to_epilog_state(1, 1)
    
    ld_bufa_ch.set_prolog_state(True) 
    print('pingpong_a', ld_bufa_ch.get_token_addr(1))
    ld_bufa_ch.forward_to_epilog_state(1, 1)
    
    #print(ld_bufa_ch.get_loop_config_dict('producer', 1))
    #print(ld_bufa_ch.get_loop_config_dict('consumer', 1))
    #print(ld_bufa_ch.get_token_addr(1))

    #print(ld_bufb_ch.get_loop_config_dict('producer', 16))
    #print(ld_bufb_ch.get_loop_config_dict('consumer', 16))
    #print(ld_bufb_ch.get_token_addr(16))
    #ld_bufa_ch.set_prolog_state(True)
    #print(ld_bufa_ch.ptr)
    #ld_bufa_ch.forward_to_epilog_state(1, 12)
    #print(ld_bufa_ch.ptr)
    
    #ld_bufa_ch.set_prolog_state(True)
    #print(ld_bufa_ch.ptr)
    #ld_bufa_ch.forward_to_epilog_state(1, 12)
    #print(ld_bufa_ch.ptr)
   
    #ld_bufa_ch.set_prolog_state(False)
    #print(ld_bufa_ch.ptr)
    #ld_bufa_ch.forward_to_epilog_state(1, 12)
    #print(ld_bufa_ch.ptr)
    #####################
    #ld_bufb_ch.set_prolog_state(True)
    #ld_bufb_ch.forward_to_epilog_state(28, 1)
    #print(ld_bufb_ch.get_token_addr(1))
    
    #ld_bufb_ch.set_prolog_state(False)
    #ld_bufb_ch.forward_to_epilog_state(7, 1)
    #print(ld_bufb_ch.get_token_addr(1))
   
    #ld_bufb_ch.set_prolog_state(False)
    #ld_bufb_ch.forward_to_epilog_state(7, 1)
    #print(ld_bufb_ch.get_token_addr(1))
    
    #ld_bufb_ch.set_prolog_state(True)
    #ld_bufb_ch.forward_to_epilog_state(7, 1)
    #print(ld_bufb_ch.get_token_addr(1))
    #exit()
    ################
    #ld_bufb_ch.set_prolog_state(True)
    #print(ld_bufb_ch.get_token_addr(1))
    #ld_bufb_ch.forward_to_epilog_state(1, 1)
    #print(ld_bufb_ch.ptr)
    
    #ld_bufb_ch.set_prolog_state(True)
    #print(ld_bufb_ch.ptr)
    #ld_bufb_ch.forward_to_epilog_state(4, 11)
    #print(ld_bufb_ch.ptr)
    #print()

    #ld_bufb_ch.set_prolog_state(False)
    #print(ld_bufb_ch.ptr)
    #ld_bufb_ch.forward_to_epilog_state(0, 11)
    #print(ld_bufb_ch.ptr)
    #print()
    
    #ld_bufb_ch.set_prolog_state(False)
    #print(ld_bufb_ch.ptr)
    #ld_bufb_ch.forward_to_epilog_state(0, 15)
    #print(ld_bufb_ch.ptr)
    #print()
    
    #ld_bufb_ch.set_prolog_state(True)
    #print(ld_bufb_ch.ptr)
    #ld_bufb_ch.forward_to_epilog_state(2, 7)
    #print(ld_bufb_ch.ptr)
    #print()
    
    #ld_bufb_ch.set_prolog_state(True)
    #print(ld_bufb_ch.ptr)
    #ld_bufb_ch.forward_to_epilog_state(3, 2)
    #print(ld_bufb_ch.ptr)
    #print()
    
    #ld_bufb_ch.set_prolog_state(True)
    #print(ld_bufb_ch.ptr)
    #ld_bufb_ch.forward_to_epilog_state(1, 7)
    #print(ld_bufb_ch.ptr)
    #print()

    ####
    tlr_ch.set_prolog_state(True)
    print('tlr_pingpong', tlr_ch.get_token_addr(20))
    tlr_ch.forward_to_epilog_state(1, 20)

