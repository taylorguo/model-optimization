#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.


import numpy as np
import math
import code_generator.kernel_gen.math_utils as math_utils
import code_generator.share.br_const_defs as bcd 
class alloca_inst:
    def __init__(self,shape=None, dtype='bf16',\
            scope="hbm",uma_mode="uma", name="", layout= None, overwrite=None, attr=[], data_file =''):
        self.name= name
        self.data_file = data_file
        self.shape = shape
        self.dtype = dtype
        # Matrix, Matrix3D, MatrixWeight, ConvWeight, Activation
        self.layout = layout 
        self.uma_mode = uma_mode
        self.scope = scope 
        self.addr = 0x0
        self.attr = attr
        self.gmb_addr = 0x0
        self.gmb_sz = 0x0
        self.max_gmb_sz = 0 
        self.hw_shape = None
        self.usharp_id=-1
        self.is_checkpoint = False
        self.is_clear_contents = False
    def add_view(self):
        # GMB + GMB + ... + HBM + HBM
        # SPC, SPC, SPC, SPC 
        pass 
    def get_dem_sz(self):    
        if self.dtype=='s8' or self.dtype=='u8' or self.dtype=='s4' or \
                self.dtype=='f8_2' or self.dtype=='f8_3':
            dem_sz = 1
        elif self.dtype=="bf16" or self.dtype=="fp16":
            dem_sz = 2
        elif self.dtype=='fp32':
            dem_sz = 4
        else:
            assert 0, "unsupported dtype"
        return dem_sz
    def get_sz(self):
        dem_sz=self.get_dem_sz()
        assert self.shape!=None, 'invalid shape for {}'.format(self.name)
        return np.prod(self.shape)* dem_sz
    def get_shape(self):
        pass
    def set_shape(self):
        pass
    def get_usharp_desc(self):
        # actual num of subusharp is (configured_value + 1)
        numSubUSharp = 1
        depthT = 1
        heightT =1
        widthT = 1
        viewType = '4D'
        if self.layout == '4DW':
            # O, I, KH, KW
            viewType = '4D'
            (O, I, KH, KW) = self.hw_shape
            widthT = KH*KW
            heightT = I  
            depthT = O 
            numSubUSharp = 1
        elif self.layout == '4DA':
            # NCHW
            viewType = '4D'
            (N, C, H, W) = self.hw_shape
            numSubUSharp = N 
            depthT = C
            heightT = H
            widthT = W
        elif self.layout == '2DA':
            viewType = "2D"
            (N, C, H, W) = self.hw_shape
            numSubUSharp = N 
            depthT = C
            heightT = H
            widthT = W
        elif self.layout == 'linear' or self.layout == '1DV':
            viewType = '1D'
            if len(self.hw_shape)==1:
                (L, ) = self.hw_shape
                N=1
            else: 
                (L, N) = self.hw_shape
            numSubUSharp = N  
            widthT = L
            depthT = 1
            heightT = 1
        #if isinstance(widthT, list) or isinstance(widthT, tuple):
            #widthT = widthT[0]
        #print("width ", widthT)
        return {
            "name": self.name,
            "id": self.usharp_id,
            'file_name': self.data_file,
            "address": str(hex(self.addr)),
            # 2D: 2DA 2DW, 3D: 4DA 4DW. 1D
            "viewType": viewType,
            "viewFormat": self.dtype,
            # linear. 2DA, 2DW, 4DA, 4DW
            "viewImageLayout": self.layout,
            "tensorFormatDimension": {
                "widthT": widthT,
                "heightT": heightT,
                "depthT": depthT,
                "reserved1": 0
            },
            "reserved2": 0,
            "numSubUSharp": numSubUSharp,
            "padBaseOffset": self.gmb_addr,
            "padSize": self.gmb_sz,
            "Reserved5": 0,
            'l15Mode': 0,
            'is_numa': 0 if self.uma_mode == 'uma' else 1,
            'pixelInterleaveDisabled': 1,
        }
        
        #u['embeddingTableEntrySize']=0
        return u

    def __str__(self):
        return "alloca: shape="+str(self.shape)+' '+self.scope+' '+self.uma_mode

class dealloca_inst:
    def __init__(self, tensor):
        self.t = tensor
    def __str__(self):
        return "dealloca" + self.t.name

class slice_inst(alloca_inst):
    def __init__(self, AI, slice_begin, slice_size, hw_shape_slice_begin, hw_shape_slice_size):
        super().__init__(AI.shape, AI.dtype,
            scope= AI.scope,uma_mode=AI.uma_mode,
            name=AI.name,
            layout=AI.layout, 
            data_file=AI.data_file)
        self.slice_begin = slice_begin
        self.slice_size = slice_size
        self.hw_shape_slice_begin = hw_shape_slice_begin
        self.hw_shape_slice_size = hw_shape_slice_size
        self.shape= self.slice_size
    def __str__(self):
        return 'slice'
class op_inst:
    def __init__(self, ty, name, in_tensor, out_tensor, tensor= [], debug_tensor=[], internal_tensor=[], params=None, attr={}, infer_type=True):
        self.ty= ty
        self.kernel_ty = []
        self.name=name
        self.in_tensor=in_tensor
        self.out_tensor=out_tensor
        self.tensor = tensor
        self.debug_tensor = debug_tensor
        self.tcore_out_tensor = []
        self.internal_tensor=internal_tensor
        self.params= params
        self.attr = attr
        self.optimization_policy = None 
        self.dump_field = []
        if "bn_include_sample_loop" not in self.attr:
            self.attr["bn_include_sample_loop"] = False
        if len(debug_tensor) > 0:
            self.debug_mode = True
        else:
            self.debug_mode = False
        if infer_type:
            # Infer types
            if self.ty=="BRForwardConv2BatchNormRelu" or \
                    self.ty=="BRForwardConv2BatchNormReluMaxPool" or \
                    self.ty=='BRForwardConv2BatchNormAdderRelu' or \
                    self.ty=='BRForwardConv2BatchNorm' or \
                    self.ty=='BRForwardConv2':
                # Intialize br_loop_config so the user may override it in the beginning
                self.loop_config_ldconv0 = []
                self.loop_config_ldconv1 = []
                self.loop_config_conv = []
                self.loop_config_vector_reduce = []
                self.loop_config_vector_elemwise = []

                N, IC, IH, IW = in_tensor[0].shape
                KH, KW = self.params['conv']['k']
                PH, PW = self.params['conv']['padding']
                SH, SW = self.params['conv']['strides']
                if 'dilations' in self.params['conv']:
                    DH, DW = self.params['conv']['dilations']
                else:
                    DH = 1
                    DW = 1
                OH = (IH + 2*PH - DH*(KH -1) -1) // SH + 1
                OW = (IW + 2*PW - DW*(KW -1) -1) // SW + 1
                OC = self.params['conv']['oc']
                
                bn_cache_length = math_utils.ceil_block(OC, bcd.WEIGHT_OCH_LD_SIZE) * 4
                if "bn_include_sample_loop" in self.attr and self.attr['bn_include_sample_loop']:
                    bn_cache_sample = N
                else:
                    bn_cache_sample = 1

                if self.ty=="BRForwardConv2BatchNormReluMaxPool":
                    KH_pool, KW_pool = self.params['maxpool']['k']
                    PH_pool, PW_pool = self.params['maxpool']['padding']
                    SH_pool, SW_pool = self.params['maxpool']['strides']
                    OH_pool = (OH - KH_pool + 2*PH_pool) // SH_pool + 1
                    OW_pool = (OW - KW_pool + 2*PW_pool) // SW_pool + 1
                    
                    out_tensor[0].shape= (N, OC, OH_pool, OW_pool)
                    # bn paramters: var, mean, sigma, beta
                    # 0 activation after bn 1 weight 2 bn_cache
                    tensor[0].shape = (N, OC, OH, OW)
                    tensor[1].shape = (OC, IC, KH, KW)
                    tensor[2].shape = (bn_cache_length, bn_cache_sample)
                    if self.debug_mode:
                        # activation after conv
                        self.debug_tensor[0].shape =(N, OC, OH, OW)
                        # activation after rulu
                        self.debug_tensor[1].shape =(N, OC, OH, OW)
                else:
                    out_tensor[0].shape=(N, OC, OH, OW)
                    if self.ty=='BRForwardConv2':
                        tensor[0].shape = (OC, IC, KH, KW)
                    elif self.ty=='BRForwardConv2BatchNorm':
                        # 0 weight 1 bn_cache
                        tensor[0].shape = (OC, IC, KH, KW)
                        tensor[1].shape = (bn_cache_length, bn_cache_sample)
                        if self.debug_mode:
                            self.debug_tensor[0].shape =(N, OC, OH, OW)
                    elif self.ty=="BRForwardConv2BatchNormRelu":
                        # 0 activation after bn 1 weight 2 bn_cache 
                        tensor[0].shape = (N, OC, OH, OW)
                        tensor[1].shape = (OC, IC, KH, KW)
                        tensor[2].shape = (bn_cache_length, bn_cache_sample)
                        out_tensor[0].shape=(N, OC, OH, OW)
                        if self.debug_mode:
                            self.debug_tensor[0].shape =(N, OC, OH, OW)
                    elif self.ty=='BRForwardConv2BatchNormAdderRelu':
                        in_tensor[1].shape = (N, IC, IH, IW)
                        # 0 activation after bn 1 activation after adder 2 weight 3 bn_cache
                        tensor[0].shape = (N, OC, OH, OW)
                        tensor[1].shape = (N, OC, OH, OW)
                        tensor[2].shape = (OC, IC, KH, KW)
                        tensor[3].shape = (bn_cache_length, bn_cache_sample)
                        if self.debug_mode:
                            self.debug_tensor[0].shape =(N, OC, OH, OW)
            elif self.ty=="BRForwardAveragePool":
                # Adaptive Average Pool 2D
                N, IC, IH, IW = self.in_tensor[0].shape
                out_tensor[0].shape=(N, IC)
            elif self.ty=="BRForwardFullConnect":
                # in [M, K] * w [K, N] -> [M, N]
                out_features = self.params['out_features']
                N, IC= in_tensor[0].shape
                out_tensor[0].shape=(N, out_features)
            elif self.type == 'BRBackConv2ReluBatchNorm':
                self.out_tensor.shape = self.params['conv']['weight']

            elif self.ty == 'BRBackConv2AdderMaxpoolReluBatchNorm' or \
                    self.ty == 'BRBackConv2AdderReluBatchNormBatchNorm' or \
                    self.ty == 'BRBackConv2AdderReluBypassBatchNorm':
                grad_bottom=self.in_tensor[0]
                act_top=self.in_tensor[1]
                act_bottom=self.in_tensor[2]
                if self.ty=="cbr_back" or self.ty=="cb_back":
                    bn_cache=self.in_tensor[3]
                grad_top=self.out_tensor[0]
                weight_grad=self.out_tensor[1]

                N, IC, IH, IW = act_top.shape
                N, OC, OH, OW = act_bottom.shape
                
                KH, KW = self.params['k']
                PH, PW = self.params['padding']
                SH, SW = self.params['strides']
                
                grad_top.shape=act_top.act_top.shape
                weight_grad.shape=(OC,IC,KH,KW) 
                bn_act_bottom = tensor[0]
                N, OC, OH, OW = bn_act_bottom

                if self.type == 'BRBackConv2AdderReluBatchNormBatchNorm':
                    pass
                elif self.type == 'BRBackConv2AdderReluBypassBatchNorm':
                    pass
                elif self.type == 'BRBackConv2':
                    pass
                # In tensor 0.grad_bottom, 
                # Out tensor: 0.grad_top 
                # Tensor: 1.weight_grad            1.act_top 2.act_bottom 3. weight 4. bn_cache

            elif self.ty=="BRBackAveragePool":
                # in_tensor: grad_bottom, act_top
                # out_tensor: grad_top
                pass
            elif self.ty=="BRBackFullConnect":
                # Agrad =  grad * wT = [M, N] * [N, K]
                # Wgrad = xT * grad = [K, M] * [M, N] 
                # in_tensor: 0.grad, 1.act_top, 2.weight
                # out_tensor: 0.grad_top  1.weight_grad
                grad=in_tensor[0]
                act_top=in_tensor[1]
                weight=in_tensor[2]
                grad_top=out_tensor[0]
                weight_grad=out_tensor[1]
                
                grad_top.shape= act_top.shape
                weight_grad.shape = weight.shape
            elif self.ty=="BRBackSoftmax":
                out_tensor[0].shape=(1)
            else:
                assert False, "Not recognized kernel type "+ self.ty
                assert(in_tensor[0].shape!=None)
                out_tensor[0].shape=in_tensor[0].shape
    def add_dump_field(self, field):
        self.dump_field += field
    def get_usharp_num(self):
        return len(self.in_tensor) + len(self.out_tensor) + len(self.tensor) + len(self.internal_tensor)
    def __str__(self):
        return self.ty + '(' + self.name +')'
        #if self.ty=="conv2d" or self.ty=="cbr" or self.ty=='cb':
            #N, IC, IH, IW = self.in_tensor[0].shape
            #(N, OC, OH, OW)= self.out_tensor[0].shape
            #return(self.ty+ "("+ self.name+ "): ic="+str(IC)+" ,oc="+str(OC)+ str(self.params))
        #elif self.ty=='adaptive_avg_pool2d' or self.ty=='max_pool2d':
            #return(self.ty+ ","+ self.name+ str(self.in_tensor[0].shape)+ \
                    #"->" + str(self.out_tensor[0].shape))
        #else:
            #return(self.ty+ ","+ self.name+ str(self.in_tensor[0].shape)) + "->" + \
                    #str(self.out_tensor[0].shape)
