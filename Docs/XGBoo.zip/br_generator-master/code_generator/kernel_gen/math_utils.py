#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import math
import pprint

pp = pprint.PrettyPrinter(indent=4)
def floor_exp2(x):
    return int(math.pow(2, math.floor(math.log(x)/math.log(2))))

def ceil_block(x, block_sz):
    return math.ceil(float(x)/block_sz)*block_sz
def floor_block(x, block_sz):
    return math.floor(float(x)/block_sz)*block_sz

def to_int(v):
    if isinstance(v, float):
        assert v.is_integer(), f'{v} is not integer. Double check prolog / epilog!'
    return int(v)
def get_wrap_list(start, length, cur_start, cur_length):
    cur_start = start + cur_start 
    wrap_len = cur_start + cur_length - (start + length) 
    assert wrap_len <= length, f'wrap_len = {wrap_len}, length = {length}'

    if wrap_len > 0:
        return list(range(cur_start, length + start )) + list(range(start, start+wrap_len))
    else:
        return list(range(cur_start, cur_start + cur_length))


def floor_set(x, x_set):
    pass
def ceil_set(x, x_set):
    pass
