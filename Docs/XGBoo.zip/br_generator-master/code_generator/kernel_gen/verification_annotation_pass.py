from code_generator.kernel_gen.stream_pass import stream_pass
from code_generator.kernel_gen.inst import alloca_inst
from code_generator.kernel_gen.inst import op_inst

class verification_annotation_pass(stream_pass):
    def __init__(self, my_hw, my_wl):
        super().__init__(my_hw, my_wl)
    def set_clear_contents(self, AI): 
        AI.is_clear_contents = True
    def set_checkpoint(self, AI, eps=0.05):
        AI.is_checkpoint = True
        AI.eps = eps
    def run_on_stream(self):
        for i in self.wl.get_stream().stream():
            if isinstance(i, op_inst):
                for t in i.out_tensor:
                    self.set_checkpoint(t)
                    self.set_clear_contents(t)
                if i.debug_mode:
                    for t in i.debug_tensor:
                        self.set_checkpoint(t)
                        self.set_clear_contents(t)
                if  i.ty=="BRForwardConv2BatchNorm":
                    self.set_checkpoint(i.tensor[1])
                elif  i.ty=="BRForwardConv2BatchNormRelu":
                    self.set_checkpoint(i.tensor[0])
                    self.set_checkpoint(i.tensor[2])
                    self.set_clear_contents(i.tensor[0])
                elif i.ty=="BRForwardConv2BatchNormReluMaxPool":
                    self.set_checkpoint(i.tensor[0])
                    self.set_checkpoint(i.tensor[2])
                    self.set_clear_contents(i.tensor[0])
                elif i.ty=='BRForwardConv2BatchNormAdderRelu':
                    self.set_checkpoint(i.tensor[0])
                    self.set_checkpoint(i.tensor[1])
                    self.set_checkpoint(i.tensor[3])
                    self.set_clear_contents(i.tensor[0])

                
