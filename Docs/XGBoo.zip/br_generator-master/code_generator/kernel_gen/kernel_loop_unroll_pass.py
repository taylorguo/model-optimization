import math
import code_generator.share.br_const_defs as bcd
class kernel_loop_unroll_pass():
    def __init__(self, hw, wl):
        self.hw = hw
        self.wl = wl
    def run_on_kernel(self, k):
        if k.optimization_policy!=None:
            optimization_policy = k.optimization_policy
        else:
            optimization_policy = self.wl.optimization_policy
        
        # Unroll ic and oc loops. IC loops are automatically unrolled.
        if optimization_policy['unroll_policy']=='legacy':
            for loop_config in [
                    k.loop_config_ldconv0,
                    k.loop_config_conv]: 
                    # k.loop_config_vector_reduce,
                    # k.loop_config_vector_elemwise]:
                for loop_level in loop_config[-2::]:
                    loop_var = loop_level[0]
                    loop_iter = loop_level[1]
                    loop_unroll = loop_level[2]
                    loop_step = loop_level[3]
                    loop_dict = loop_level[4]

                    if loop_var != bcd.INNER_IC_LOOP_NAME:
                        loop_level[2] = loop_iter
        # Unroll innermost 2 loops
        elif optimization_policy['unroll_policy'] == 'unroll2':
            for loop_config in [k.loop_config_ldconv0,
                    k.loop_config_ldconv1,  
                    k.loop_config_conv]: 
                    # k.loop_config_vector_reduce,
                    # k.loop_config_vector_elemwise]:
                for loop_level in loop_config[-2::]:
                    loop_var = loop_level[0]
                    loop_iter = loop_level[1]
                    loop_unroll = loop_level[2]
                    loop_step = loop_level[3]
                    loop_dict = loop_level[4]
        
                    if loop_var != bcd.INNER_IC_LOOP_NAME:
                        loop_level[2] = loop_iter
        elif optimization_policy['unroll_policy'] == 'all':            
            for loop_config in [k.loop_config_ldconv0,
                    k.loop_config_ldconv1,  
                    k.loop_config_conv, 
                    k.loop_config_vector_reduce,
                    k.loop_config_vector_elemwise]:
                for loop_level in loop_config:
                    loop_var = loop_level[0]
                    if loop_var != bcd.INNER_IC_LOOP_NAME:
                        loop_level[2] = loop_iter
        elif optimization_policy['unroll_policy'] == 'threshold' or \
                optimization_policy['unroll_policy'] == 'target_count':
            loop_config_index = 0
            for loop_config in [k.loop_config_ldconv0,
                    k.loop_config_ldconv1,  
                    k.loop_config_conv, 
                    k.loop_config_vector_reduce,
                    k.loop_config_vector_elemwise]:
                threshold = optimization_policy['unroll_target_instruction_count'][loop_config_index]
                loop_config_index +=1
                counts = 1
                for loop_level in loop_config[::-1]:
                    loop_var = loop_level[0]
                    loop_iter = loop_level[1]
                    loop_unroll = loop_level[2]
                    loop_step = loop_level[3]
                    if loop_var == bcd.INNER_IC_LOOP_NAME: 
                        counts = math.ceil(loop_step / 128)
                    counts *= loop_iter
                    if counts < threshold:
                        # Unroll
                        loop_level[2] = loop_iter
                    else:
                        # We have unrolled enough loop levels
                        break
        elif optimization_policy['unroll_policy'] == 'only_ic':
            # Unroll IC loop level and do not touch others
            pass
        else:
            assert False, 'Unrecognized unroll_policy.'
        
        # Finalize: Update to tuple
        k.loop_config_ldconv0 = [ tuple(i) for i in k.loop_config_ldconv0]
        k.loop_config_ldconv1 = [tuple(i) for i in k.loop_config_ldconv1]
        k.loop_config_conv = [tuple(i) for i in k.loop_config_conv]
        k.loop_config_vector_reduce= [tuple(i) for i in k.loop_config_vector_reduce]
        k.loop_config_vector_elemwise = [tuple(i) for i in k.loop_config_vector_elemwise]
            
            
        

