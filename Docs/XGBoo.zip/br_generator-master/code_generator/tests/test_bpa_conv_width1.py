#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import pytest
import sys
from unittest import TestCase
sys.path.append('../')
import code_generator.share.br_defined_print as bdp
import code_generator.tcore.br_tcore_bpa_conv as bpa

class TestBPAConvWidth3(TestCase):

    def Conv(self):
        # fwd parameter
        wshape = (256, 512, 1, 1)
        ishape = (1, 512, 56, 56)
        stride=1
        dilation=1
        padx=0
        pady=0
        #(1, 256, 54, 54)
        #(512, 256, 3, 3)
        dt = ("bf16", "bf16", "bf16")

        bdp.set_output_file("TestBPAConvWidth1.s")
        usharps0 = {
        "tensor_b": {"usharp": 0},
        "tensor_a": {"usharp": 1},
        "tensor_o": {"usharp": 2}}

        # compute bwd gradient shape
        nc, cin, iw, ih = ishape
        wcout, wcin, ww, wh = wshape
        ow = int((iw - ww + 2*padx) / stride) + 1
        oh = int((ih - wh + 2*pady) / stride) + 1
        bpaishape = (nc, wcout, ow, oh)
        bpapadx = int(((iw - 1) * stride + ww - ow) / 2)
        bpapady = int(((ih - 1) * stride + wh - oh) / 2)
        #reshape weight as cin became out
        bpawshape = (wcin, wcout, ww, wh)

        loop_configa = [
                    #   name,   iterations, unrolls, incremental unit
                    ("outer_oc", 2, 1, 256,
                     {"wset": [48], "sset": [32]}),
                    ("inner_oc", 8, 1, 32),
                    ("ich", 1, 1, 256)]   # unfold by default

        loop_configb = [
                    #   name,   iterations, unrolls, incremental unit
                    ("outer_oc", 2, 1, 256,
                     {"wset": [32], "sset": [48]}),
                    ("sample", 1, 1, 1),
                    ("row", 7, 1, 8),
                    ("col", 7, 1, 8),
                     ("ich", 1, 1, 256)]   # unfold by default

        loop_configc = [
                    #   name,   iterations, unrolls, incremental unit
                    ("outer_oc", 2, 1, 256,
                     {"wset": [32], "sset": [48]}),
                    ("sample", 1, 1, 1),
                    ("row", 7, 1, 8),
                    ("col", 7, 1, 8),
                    ("inner_oc", 8, 1, 32),
                     ("ich", 1, 1, 256)]   # unfold by default

        operator0 = bpa.br_bpa_conv(
            bpaishape, bpawshape, dt, stride=1, dilation=1, padx=bpapadx, pady=bpapady,
            usharps=usharps0, pingpong_a=[256, 0], red_mode="ssq", loop_configs=[loop_configa, loop_configb, loop_configc])
        wsr_num = operator0.get_required_wsr()
        operator0.generate()


    def test(self):
        self.Conv()
        self.assertTrue(True)


if __name__ == '__main__':
    c = TestBPAConvWidth3()
    c.Conv()
    #pytest.main(['test_inc_not_aligned.py','-s'])
    
