#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

from unittest import TestCase

import code_generator.share.br_defined_print as bdp
import code_generator.tcore.br_tcore_fwd_conv as tfc


class TestStride1Width1(TestCase):
    def Conv(self):
        wshape = (128, 256, 3, 3)
        ishape = (1, 256, 56, 56)
        dt = ("bf16", "bf16", "bf16")

        bdp.set_output_file("Test1x256x56x56_128x256x3x3_s1.s")
        usharps0 = {
            "tensor_b": {"usharp": 0},
            "tensor_a": {"usharp": 1},
            "tensor_o": {"usharp": 2},
            "reduce": {"usharp": 3}
        }

        operator0 = tfc.br_fwd_conv(
            ishape,
            wshape,
            dt,
            stride=1,
            dilation=1,
            padx=0,
            pady=0,
            usharps=usharps0,
            pingpong_a=[256, 0],
            red_mode="ssq",
        )
        operator0.generate()

    def test(self):
        self.Conv()
        self.assertTrue(True)


if __name__ == "__main__":
    c = TestStride1Width1()
    c.Conv()
    # pytest.main(['test_inc_not_aligned.py','-s'])
