#!/usr/bin/env python3
import unittest, os, shutil, filecmp
from code_generator.kernel_gen import codegen
from code_generator.kernel_gen import workload
from code_generator.kernel_gen.inst import *
from command_generator import utils

class single_op_tests(unittest.TestCase):
    def test_ch3_s2(self):
        wl = workload.workload('ch3_s2')
        s = wl.get_stream()
        
        cb_top = s.append(alloca_inst(shape= (16,3,224,224), scope='l1p5', dtype='bf16', uma_mode='numa', layout='4DA'))
        cb_weight = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='uma'))
        cb_bn_weight = s.append(alloca_inst(scope='hbm', layout='linear'))
        cb_bn_bottom = s.append(alloca_inst(scope='hbm', layout='4DA'))
        
        s.append(op_inst(
                ty='BRForwardConv2BatchNorm', 
                name='cb_test',
                in_tensor=[cb_top],
                out_tensor=[cb_bn_bottom], 
                tensor = [cb_weight,cb_bn_weight],
                params={
                    'conv': {'oc': int(64), 'k':(7,7), 'strides':(2,2), 'padding':(3,3) },
                    }))
        s.append(dealloca_inst(cb_top))
        codegen.codegen(wl)
    def test_ch64(self):
        wl = workload.workload('ch64')
        s = wl.get_stream()
        
        cb_top = s.append(alloca_inst(shape= (16,64,56,56), scope='l1p5', dtype='bf16', uma_mode='numa', layout='4DA'))
        cb_weight = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='uma'))
        cb_bn_weight = s.append(alloca_inst(scope='hbm', layout='linear'))
        cb_bn_bottom = s.append(alloca_inst(scope='hbm', layout='4DA'))
        
        s.append(op_inst(
                ty='BRForwardConv2BatchNorm', 
                name='cb_test',
                in_tensor=[cb_top],
                out_tensor=[cb_bn_bottom], 
                tensor = [cb_weight,cb_bn_weight],
                params={
                    'conv': {'oc': int(256), 'k':(1,1), 'strides':(1,1), 'padding':(0,0) },
                    }))
        s.append(dealloca_inst(cb_top))
        codegen.codegen(wl)
    def test_k1(self):
        wl = workload.workload('k1')
        s = wl.get_stream()
        
        cb_top = s.append(alloca_inst(shape= (16,512,14,14), scope='l1p5', dtype='bf16', uma_mode='numa', layout='4DA'))
        cb_weight = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='uma'))
        cb_bn_weight = s.append(alloca_inst(scope='hbm', layout='linear'))
        cb_bn_bottom = s.append(alloca_inst(scope='hbm', layout='4DA'))
        
        s.append(op_inst(
                ty='BRForwardConv2BatchNorm', 
                name='cb_test',
                in_tensor=[cb_top],
                out_tensor=[cb_bn_bottom], 
                tensor = [cb_weight,cb_bn_weight],
                params={
                    'conv': {'oc': int(256), 'k':(1,1), 'strides':(1,1), 'padding':(0,0) },
                    }))
        s.append(dealloca_inst(cb_top))
        codegen.codegen(wl)
    
    def test_k3(self):
        wl = workload.workload('k3')
        s = wl.get_stream()
        
        cb_top = s.append(alloca_inst(shape= (16,128,28,28), scope='l1p5', dtype='bf16', uma_mode='numa', layout='4DA'))
        cb_weight = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='uma'))
        cb_bn_weight = s.append(alloca_inst(scope='hbm', layout='linear'))
        cb_bn_bottom = s.append(alloca_inst(scope='hbm', layout='4DA'))

        s.append(op_inst(
                ty='BRForwardConv2BatchNorm', 
                name='cb_test',
                in_tensor=[cb_top],
                out_tensor=[cb_bn_bottom], 
                tensor = [cb_weight,cb_bn_weight],
                params={
                    'conv': {'oc': int(128), 'k':(3,3), 'strides':(1,1), 'padding':(1,1) },
                    }))
        s.append(dealloca_inst(cb_top))
        
        codegen.codegen(wl)
    
    def test_k3_s2(self):
        wl = workload.workload('k3_s2')
        s = wl.get_stream()
        cb_top = s.append(alloca_inst(shape= (16,512,14,14), scope='l1p5', dtype='bf16', uma_mode='numa', layout='4DA'))
        cb_weight = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='uma'))
        cb_bn_weight = s.append(alloca_inst(scope='hbm', layout='linear'))
        cb_bn_bottom = s.append(alloca_inst(scope='hbm', layout='4DA'))

        s.append(op_inst(
                ty='BRForwardConv2BatchNorm', 
                name='cb_test',
                in_tensor=[cb_top],
                out_tensor=[cb_bn_bottom], 
                tensor = [cb_weight,cb_bn_weight],
                params={
                    'conv': {'oc': int(512), 'k':(3,3), 'strides':(2,2), 'padding':(1,1) },
                    }))
        s.append(dealloca_inst(cb_top))
        codegen.codegen(wl)
    def test_k1_wpp(self):
        wl = workload.workload('k1_wpp')
        s = wl.get_stream()
        
        cb_top = s.append(alloca_inst(shape= (16,128,28,28), scope='l1p5', dtype='bf16', uma_mode='numa', layout='4DA'))
        cb_weight = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='uma'))
        cb_bn_weight = s.append(alloca_inst(scope='hbm', layout='linear'))
        cb_bn_bottom = s.append(alloca_inst(scope='hbm', layout='4DA'))

        s.append(op_inst(
                ty='BRForwardConv2BatchNorm', 
                name='cb_test',
                in_tensor=[cb_top],
                out_tensor=[cb_bn_bottom], 
                tensor = [cb_weight,cb_bn_weight],
                params={
                    'conv': {'oc': int(512), 'k':(1,1), 'strides':(1,1), 'padding':(0,0) },
                    }))
        s.append(dealloca_inst(cb_top))
        codegen.codegen(wl)
    
    def test_k1_s2(self):
        wl = workload.workload('k1_s2')
        s = wl.get_stream()
        
        cb_top = s.append(alloca_inst(shape= (16,1024,14,14), scope='l1p5', dtype='bf16', uma_mode='numa', layout='4DA'))
        cb_weight = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='uma'))
        cb_bn_weight = s.append(alloca_inst(scope='hbm', layout='linear'))
        cb_bn_bottom = s.append(alloca_inst(scope='hbm', layout='4DA'))

        s.append(op_inst(
                ty='BRForwardConv2BatchNorm', 
                name='cb_test',
                in_tensor=[cb_top],
                out_tensor=[cb_bn_bottom], 
                tensor = [cb_weight,cb_bn_weight],
                params={
                    'conv': {'oc': int(2048), 'k':(1,1), 'strides':(2,2), 'padding':(0,0) },
                    }))
        s.append(dealloca_inst(cb_top))
        codegen.codegen(wl)
    def test_vmc_k1_icd(self):
        wl = workload.workload('vmc_k1_icd')
        s = wl.get_stream()
        
        cb_top = s.append(alloca_inst(shape= (16,2048,7,7), scope='l1p5', dtype='bf16', uma_mode='numa', layout='4DA'))
        cb_weight = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='uma'))
        cb_bn_weight = s.append(alloca_inst(scope='hbm', layout='linear'))
        cb_bn_bottom = s.append(alloca_inst(scope='hbm', layout='4DA'))

        s.append(op_inst(
                ty='BRForwardConv2BatchNorm', 
                name='cb_test',
                in_tensor=[cb_top],
                out_tensor=[cb_bn_bottom], 
                tensor = [cb_weight,cb_bn_weight],
                params={
                    'conv': {'oc': int(512), 'k':(1,1), 'strides':(1,1), 'padding':(0,0) },
                    }))
        s.append(dealloca_inst(cb_top))
        codegen.codegen(wl)
    def test_vmc_k3_icd(self):
        wl = workload.workload('vmc_k3_icd')
        s = wl.get_stream()
        
        cb_top = s.append(alloca_inst(shape= (16,512,7,7), scope='l1p5', dtype='bf16', uma_mode='numa', layout='4DA'))
        cb_weight = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='uma'))
        cb_bn_weight = s.append(alloca_inst(scope='hbm', layout='linear'))
        cb_bn_bottom = s.append(alloca_inst(scope='hbm', layout='4DA'))

        s.append(op_inst(
                ty='BRForwardConv2BatchNorm', 
                name='cb_test',
                in_tensor=[cb_top],
                out_tensor=[cb_bn_bottom], 
                tensor = [cb_weight,cb_bn_weight],
                params={
                    'conv': {'oc': int(512), 'k':(3,3), 'strides':(1,1), 'padding':(1,1) },
                    }))
        s.append(dealloca_inst(cb_top))
        codegen.codegen(wl)
    def test_vmc_k1(self):
        wl = workload.workload('vmc_k1')
        s = wl.get_stream()
        
        cb_top = s.append(alloca_inst(shape= (16,512,7,7), scope='l1p5', dtype='bf16', uma_mode='numa', layout='4DA'))
        cb_weight = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='uma'))
        cb_bn_weight = s.append(alloca_inst(scope='hbm', layout='linear'))
        cb_bn_bottom = s.append(alloca_inst(scope='hbm', layout='4DA'))

        s.append(op_inst(
                ty='BRForwardConv2BatchNorm', 
                name='cb_test',
                in_tensor=[cb_top],
                out_tensor=[cb_bn_bottom], 
                tensor = [cb_weight,cb_bn_weight],
                params={
                    'conv': {'oc': int(2048), 'k':(1,1), 'strides':(1,1), 'padding':(0,0) },
                    }))
        s.append(dealloca_inst(cb_top))
        codegen.codegen(wl)
    
if __name__ == '__main__':
    unittest.main()
