#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import code_generator.share.br_defined_print as bdp
import code_generator.br_code_gen_interface as bcgi
import code_generator.share.br_const_defs as bcd
import math


def get_best_input_channel_number_per_ld(wshape):
    if wshape[2] == 1 and wshape[0] > 128:
        return min(128, wshape[0])
    elif wshape[2] == 2 or wshape[2] == 3:
        return min(64, wshape[0])
    elif self.filter_h >= 4:
        return 32


def calculate_amount_buffer_a_entries_needed_per_col(wshape, gshape):
    entries_per_ld = calculate_buffer_a_entries_needed_per_ld(wshape)
    amount_entries_per_col = int(math.ceil(
        gshape[2] / bcd.ACTIVATION_BLOCK_H_SIZE) * entries_per_ld)
    return amount_entries_per_col


def calculate_buffer_a_entries_needed_per_ld(wshape):
    ich_number_per_ld = get_best_input_channel_number_per_ld(wshape)
    entries = bcd.ACTIVATION_BLOCK_H_SIZE * bcd.ACTIVATION_BLOCK_W_SIZE
    entries *= ich_number_per_ld
    entries = int(
        entries / bcd.BUFFER_A_ENTRY_PIXEL_NUM)
    entries = int(entries / bcd.BUFFER_B_ENTRY_ICH_NUM)

    return entries


def main():
    och_num = 64
    ich_num = 32
    kh = 3
    kw = 3

    sample_num = 1
    height = 24
    width = 24

    fwd_padx = 1
    fwd_pady = 1
    stride = 1

    g_width = int((width - kw + 2*fwd_padx) / stride) + 1
    g_height = int((height - kh + 2*fwd_pady) / stride) + 1

    wshape = (och_num, ich_num, kh, kw)
    ishape = (sample_num, ich_num, height, width)
    gshape = (sample_num, och_num, g_height, g_width)
    dt = ("bf16", "bf16", "bf16")

    row_orig_iter = math.ceil(
        gshape[2] / bcd.ACTIVATION_BLOCK_H_SIZE)
    col_orig_iter = math.ceil(
        gshape[3] / bcd.ACTIVATION_BLOCK_W_SIZE)

    row_divide = 1
    col_divide = 1
    col_inner = 1
    row_inner = row_orig_iter
    best_ich_num_per_ld = get_best_input_channel_number_per_ld(wshape)
    bufa_entries_per_ld = calculate_buffer_a_entries_needed_per_ld(wshape)

    amount_bufa_entries_per_col = (
        calculate_amount_buffer_a_entries_needed_per_col(wshape, gshape))
    if amount_bufa_entries_per_col > bcd.BUFFER_A_ENTRY_NUM:
        row_divide = math.ceil(
            amount_bufa_entries_per_col/bcd.BUFFER_A_ENTRY_NUM)
        row_inner = int(amount_bufa_entries_per_col/row_divide)
        row_inner = int(math.ceil(row_inner/bufa_entries_per_ld))
    else:
        bufa_entries_per_inner_col = amount_bufa_entries_per_col
        col_inner = math.ceil(
            bcd.BUFFER_A_ENTRY_NUM/bufa_entries_per_inner_col)
        col_divide = int(math.ceil(col_orig_iter/col_inner))

    usharps0 = {
        "tensor_b": {"usharp": 0},
        "tensor_a": {"usharp": 1},
        "tensor_o": {"usharp": 2}}

    usharps0 = {
        "tensor_b": {"usharp": 0},
        "tensor_a": {"usharp": 1},
        "tensor_o": {"usharp": 2}}


    loop_config_ldbufa = []
    # loop_config_ldbufa.append(("row", row_inner, 1,
    #                            bcd.ACTIVATION_BLOCK_H_SIZE, {"start": 0}))
    # if row_divide > 1:
    #     loop_config_ldbufa.append(("outer_row", row_divide, row_divide,
    #                                row_inner * bcd.ACTIVATION_BLOCK_H_SIZE,
    #                                {"start": 0}))

    # loop_config_ldbufa.append(("col", col_inner, 1,
    #                            bcd.ACTIVATION_BLOCK_W_SIZE,
    #                            {"start": 0}))
    # if col_divide > 1:
    #     loop_config_ldbufa.append(("outer_col", col_divide,
    #                                1, bcd.ACTIVATION_BLOCK_W_SIZE,
    #                                {"start": 0}))

    # loop_config_ldbufa.append(("sample", sample_num, 1, 1, {"start": 0}))

    loop_config_ldbufa = [
        # name, iterations, unrolls, incremental unit
        ("oc", 1, 1, 64, {"start": 0, "bufa_start": [0,]}),
        # ("ich", 1, 1, 32, {"start": 0}),
        # ("kw", 1, 1, 3, {"start": 0}),
        ("sample", 1, 1, 1, {"start": 0}),
        ("col", 1, 1, 24, {"start": 0}),
        ("col", 3, 3, 8, {"start": 0}),
        ("row", 3, 3, 8, {"start": 0})]

    loop_config_ldbufb = [
        # name, iterations, unrolls, incremental unit
        ("oc", 1, 1, 64, {"start": 0}),
        ("ich", 1, 1, 32, {"start": 0, "bufb_start": [0,]}),
        ("kw", 1, 1, 3, {"start": 0}),
        ("sample", 1, 1, 1, {"start": 0}),
        ("col", 1, 1, 24, {"start": 0}),
        ("ich", 1, 1, 32, {"start": 0}),
        ("kw", 3, 3, 1, {"start": 0}),
        ("ich", 1, 1, 32, {"start": 0}),
        ("col", 3, 3, 8, {"start": 0}),
        ("row", 3, 3, 8, {"start": 0})]

    loop_config_mma = [
        # name, iterations, unrolls, incremental unit
        ("oc", 1, 1, 64, {"start": 0, "bufa_start": [0,]}),
        ("ich", 1, 1, 32, {"start": 0,  "bufb_start": [0,]}),
        ("kw", 1, 1, 3, {"start": 0}),
        ("sample", 1, 1, 1, {"start": 0}),
        ("col", 1, 1, 24, {"start": 0}),
        ("ich", 1, 1, 32, {"start": 0}),
        ("kw", 3, 3, 1, {"start": 0}),
        ("kh", 3, 3, 1, {"start": 0}),
        ("oc", 1, 1, 64, {"start": 0}),
        ("ich", 1, 1, 32, {"start": 0}),
        ("col", 3, 3, 8, {"start": 0}),
        ("row", 3, 1, 8, {"start": 0})]   # unfold by default

    loop_configs = [loop_config_ldbufa, loop_config_ldbufb, loop_config_mma]

    bdp.set_output_file("test_bpw.s")
    mma1 = bcgi.br_bpw_mma(
        tensor_b=ishape, tensor_w=wshape,
        tensor_a=gshape, dt=dt, stride=1, dilation=1, padx=fwd_padx,
        pady=fwd_pady, usharps=usharps0, loop_configs=loop_configs)
    wsr_num = mma1.get_required_wsr()
    mma1.generate()

    # wshape = (512, 512, 3, 3)
    # ishape = (2, 512, 64, 64)
    # dt = ("bf16", "bf16", "bf16")
    # usharps1 = {
    #     "tensor_b": {"usharp": 3},
    #     "tensor_a": {"usharp": 4},
    #     "tensor_o": {"usharp": 5}}
    #     # "output": {"vgpr": vgpr_start, "len": vgpr_num}}

    # mma2 = tfc.br_fwd_conv(
    #     ishape, wshape, dt, stride=1, dilation=1, padx=0, pady=0,
    #     usharps=usharps1, pingpong_a=[256, 0], red_mode="ssq")
    # wsr_num = mma2.get_required_wsr()
    # mma2.generate()


if __name__ == '__main__':
    main()
