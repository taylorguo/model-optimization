#!/usr/bin/env python3
import unittest
import sys
sys.path.append('../')
sys.path.append('../kernel_gen')

class inter_kernel_states_tests(unittest.TestCase):
    def test_spc_vmc(self):
        pass
    def test_dynamic_batch(self):
        pass
    def test_back_vmc_spc(self):
        pass
    

