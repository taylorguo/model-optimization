#!/usr/bin/env python3
import unittest
import sys
sys.path.append('../')
import code_generator.kernel_gen.codegen
import code_generator.kernel_gen.workload
from code_generator.kernel_gen.inst import *

class single_op_tests(unittest.TestCase):
    def test_k1(self):
        wl = kernel_gen.workload.workload('test')
        s = wl.get_stream()
        
        cb_top = s.append(alloca_inst(shape= (16,256,56,56), scope='gmb', dtype='bf16', uma_mode='numa', layout='4DA'))
        cb_weight = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='uma'))
        cb_bn_weight = s.append(alloca_inst(scope='hbm', layout='linear'))
        cb_bn_bottom = s.append(alloca_inst(scope='gmb', layout='4DA'))

        s.append(op_inst(
                ty='BRForwardConv2BatchNorm', 
                name='cb_test',
                in_tensor=[cb_top],
                out_tensor=[cb_bn_bottom], 
                tensor = [cb_weight,cb_bn_weight],
                params={
                    'conv': {'oc': int(64), 'k':(1,1), 'strides':(1,1), 'padding':(0,0) },
                    }))
        s.append(dealloca_inst(cb_top))
        kernel_gen.codegen.codegen(wl)
    
if __name__ == '__main__':
    unittest.main()
