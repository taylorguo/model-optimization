1.How to use make_descriptors.py  
==============================================  

The entrance of ***make_descriptors.py*** is ***make_descriptor(desc, dest_path=None)***  
  
where   
***desc*** is descriptor dictionary as shown in make_descriptors.py  
and the destination path is set by ***dest_path*** in ***br_generator/command_generator/make_descriptors.py:20***
```angular2
    dest_path = 'br_generator/command_generator/unit/test_case'
```
Example:  
  
Under ***br_generator/code_generator/tests***, run 
```
    python3 make_descriptors.py
```

Or if you want to set the destination path, you can run
```
    python3 make_descriptors.py [dest_path]
    // Eg. [dest_path] = /home/S00002/code/br_generator/command_generator/
```

2.How to use make_simple_conv.py  
==============================================  

Under ***br_generator/code_generator/tests***, run the following command:
```
    python3 make_simple_conv.py [activation shape] [weight shape] [dilation] [stride] [padx] [pady] [type] [style] [debug]
    // Eg. python3 make_simple_conv.py 1x8x8x8 1x8x3x3 --dilation=1 --stride=1 --padx=1 --pady=1 --type=fwd 
```
**[activation shape]** and **[weight shape]** are necessary.  
**[dilation]**, **[stride]**, **[padx]**, **[pady]**, **[type]**, **[style]** and **[debug]** are optional.  
The default value for optional parameters are  
+ --dilation=1
+ --stride=1
+ --padx=0
+ --pady=0
+ --type='fwd'
+ --style=0
+ --debug=0

The output files will be stored at ***br_generator/command_generator/unit/fwd_in_1x8x8x8_w_1x8x8x8_out_1x1x3x3_dt_bf16xbf16xbf16/***