#!/usr/bin/env python3
import unittest
import sys
sys.path.append('../')
import code_generator.kernel_gen.codegen
import code_generator.kernel_gen.workload
from code_generator.kernel_gen.inst import *

class single_op_tests(unittest.TestCase):
    def test_cbr_k7(self):
        wl = kernel_gen.workload.workload('cbr_k7')
        s = wl.get_stream()
        top = s.append(alloca_inst(shape= (16, 3, 224, 244), scope='gmb', dtype='bf16', uma_mode='numa', layout='4DA'))
        weight = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='uma', dtype='bf16'))
        bn_bottom = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='numa'))
        bn_cache = s.append(alloca_inst(scope='hbm', layout='linear', dtype='fp32'))
        bottom = s.append(alloca_inst(scope='gmb', layout='4DA'))

        s.append(op_inst(
                ty='BRForwardConv2BatchNormRelu', 
                name='cbr_maxpool',
                in_tensor=[top],
                out_tensor=[bottom], 
                tensor = [bn_bottom, weight,bn_cache],
                params={
                    'conv': {'oc': int(64), 'k':(7,7), 'strides':(2,2), 'padding':(3,3) }
                    }))
        s.append(dealloca_inst(top))
        kernel_gen.codegen.codegen(wl)
    def test_cbr_k7_maxpool(self):
        wl = kernel_gen.workload.workload('cbr_k7_maxpool')
        s = wl.get_stream()
        top = s.append(alloca_inst(shape= (16, 3, 224, 224), scope='gmb', dtype='bf16', uma_mode='numa', layout='4DA'))
        weight = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='uma'))
        bn_bottom = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='numa'))
        bn_cache = s.append(alloca_inst(scope='hbm', layout='linear'))
        bottom = s.append(alloca_inst(scope='gmb', layout='4DA'))

        s.append(op_inst(
                ty='BRForwardConv2BatchNormReluMaxPool', 
                name='cbr_maxpool',
                in_tensor=[top],
                out_tensor=[bottom], 
                tensor = [bn_bottom,weight,bn_cache],
                params={
                    'conv': {'oc': int(64), 'k':(7,7), 'strides':(2,2), 'padding':(3,3) },
                    'maxpool': {'k': (7,7),'strides':(2,2),'padding': (1,1), 'dilation': (1,1), 'ceil_mode':False}
                    }))
        s.append(dealloca_inst(top))
        kernel_gen.codegen.codegen(wl)
    def test_cbr_k1(self):
        wl = kernel_gen.workload.workload('cbr_k1')
        s = wl.get_stream()
        top = s.append(alloca_inst(shape= (16, 64, 56, 56), scope='gmb', dtype='bf16', uma_mode='numa', layout='4DA'))
        weight = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='uma'))
        bn_bottom = s.append(alloca_inst(scope='hbm', layout='4DW', uma_mode='numa'))
        bn_weight = s.append(alloca_inst(scope='hbm', layout='linear'))
        bottom = s.append(alloca_inst(scope='gmb', layout='4DA'))

        s.append(op_inst(
                ty='BRForwardConv2BatchNormRelu', 
                name='cbr',
                in_tensor=[top],
                out_tensor=[bottom], 
                tensor = [bn_bottom,weight,bn_weight],
                params={
                    'conv': {'oc': int(64), 'k':(1,1), 'strides':(1,1), 'padding':(0,0) },
                    }))
        s.append(dealloca_inst(top))
        kernel_gen.codegen.codegen(wl)
    def test_cbr_k7_maxpool_cbr(self):
        wl = kernel_gen.workload.workload('cbr_k7_maxpool_cbr')
        s = wl.get_stream()
        
        top = s.append(alloca_inst(name='cbrp_top', shape= (16, 3, 224, 224), scope='gmb', dtype='bf16', uma_mode='numa', layout='4DA'))
        weight = s.append(alloca_inst(name='cbrp_w',scope='hbm', layout='4DW', uma_mode='uma'))
        bn_bottom = s.append(alloca_inst(name='cbrp_bn_bottom', scope='hbm', layout='4DW', uma_mode='numa'))
        bn_cache = s.append(alloca_inst(name='cbrp_bn_cache', scope='hbm', layout='linear'))
        bottom = s.append(alloca_inst(name='cbrp_bottom',scope='gmb', layout='4DA'))

        s.append(op_inst(
                ty='BRForwardConv2BatchNormReluMaxPool', 
                name='cbr_maxpool',
                in_tensor=[top],
                out_tensor=[bottom], 
                tensor = [bn_bottom,weight,bn_cache],
                params={
                    'conv': {'oc': int(64), 'k':(7,7), 'strides':(2,2), 'padding':(3,3) },
                    'maxpool': {'k': (7,7),'strides':(2,2),'padding': (1,1), 'dilation': (1,1), 'ceil_mode':False}
                    }))
        s.append(dealloca_inst(top))
        
        top = bottom
        weight = s.append(alloca_inst(name='cbr_w', scope='hbm', layout='4DW', uma_mode='uma'))
        bn_bottom = s.append(alloca_inst(name='cbr_bn_bottom', scope='hbm', layout='4DW', uma_mode='numa'))
        bn_cache = s.append(alloca_inst(name='cbr_bn_weight', scope='hbm', layout='linear'))
        bottom = s.append(alloca_inst(name='cbr_bottom',scope='gmb', layout='4DA'))

        s.append(op_inst(
                ty='BRForwardConv2BatchNormRelu', 
                name='cbr',
                in_tensor=[top],
                out_tensor=[bottom], 
                tensor = [bn_bottom, weight,bn_cache],
                params={
                    'conv': {'oc': int(64), 'k':(1,1), 'strides':(1,1), 'padding':(0,0) },
                    }))
        s.append(dealloca_inst(top))
        kernel_gen.codegen.codegen(wl)
        
        
if __name__ == '__main__':
    unittest.main()

