#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import math

import code_generator.tcore.br_tcore_mma as mma
import code_generator.share.br_defined_print as bdp


def main():
    #             height, width
    mata_shape = (128, 512)
    matb_shape = (512, 256)
    dt = ("bf16", "bf16", "bf16")

    bdp.set_output_file("test_mma.s")

    mata_h_unit, mata_w_unit = mma.find_best_buffer_a_load_size(mata_shape)
    matb_h_unit, matb_w_unit = mma.find_best_buffer_b_load_size(matb_shape)

    mata_h_iter, mata_w_iter = mma.calculate_load_iterations(
        mata_shape, mata_h_unit, mata_w_unit)
    matb_h_iter, matb_w_iter = mma.calculate_load_iterations(
        matb_shape, matb_h_unit, matb_w_unit)

    if (mata_w_iter != matb_h_iter or mata_w_unit != matb_h_unit):
        print("Error: The column size of matrix a does not match with "
              "the row size of matrix b")
        exit()
    else:
        common_iter = mata_w_iter
        common_unit = mata_w_unit

    loop_config_ldmma0 = [
        # name,   iterations, unrolls, incremental unit
        ("bufa_mma_sync", 1, 1, 1,
            {"wset": [48], "sset": [32]}),
        ("row_a", mata_h_iter, 1, mata_h_unit),
        ("common", common_iter, common_iter, common_unit)]

    loop_config_ldmma1 = [
        # name,   iterations, unrolls, incremental unit
        ("col_b", matb_w_iter, 1, matb_w_unit),
        ("common", common_iter, common_iter, common_unit)]

    loop_config_mma = [
        #   name,   iterations, unrolls, incremental unit
        # name,   iterations, unrolls, incremental unit
        ("bufa_mma_sync", 1, 1, 1, {"wset": [32], "sset": [48]}),
        ("row_a", mata_h_iter, 1, mata_h_unit),
        ("col_b", matb_w_iter, 1, matb_w_unit),
        ("common", common_iter, common_iter, common_unit)]

    loop_configs = [loop_config_ldmma0, loop_config_ldmma1, loop_config_mma]

    usharps0 = {
        "mat_a": {"usharp": 0},
        "mat_b": {"usharp": 1},
        "output": {"usharp": 2}}

    mma0 = mma.br_mma(
        mata_shape, matb_shape, dt, usharps=usharps0,
        pingpong_a=[0], pingpong_b=[0], loop_configs=loop_configs)
    wsr_num = mma0.get_required_wsr()
    mma0.generate()
    mma0.flush()

if __name__ == '__main__':
    main()

