#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

from unittest import TestCase

import code_generator.share.br_defined_print as bdp
import code_generator.tcore.br_tcore_fwd_conv as tfc


class TestStride2Width3(TestCase):

    def Conv(self):
        wshape = (256, 512, 3, 3)
        ishape = (1, 512, 56, 56)
        dt = ("bf16", "bf16", "bf16")

        bdp.set_output_file("TestStride2Width3.s")
        usharps0 = {
        "tensor_b": {"usharp": 0},
        "tensor_a": {"usharp": 1},
        "tensor_o": {"usharp": 2},
        "reduce": {"usharp": 3}}

        loop_configa = [
                    #   name,   iterations, unrolls, incremental unit
                    ("outer_oc", 1, 1, 256,
                     {"wset": [48], "sset": [32]}),
                    ("inner_oc", 8, 1, 32),
                    ("ich", 1, 1, 512)]   # unfold by default

        loop_configb = [
                    #   name,   iterations, unrolls, incremental unit
                    ("outer_oc", 1, 1, 256,
                     {"wset": [32], "sset": [48]}),
                    ("sample", 1, 1, 1),
                    ("row", 7, 1, 8),
                    ("col", 7, 1, 8),
                     ("ich", 1, 1, 512)]   # unfold by default

        loop_configc = [
                    #   name,   iterations, unrolls, incremental unit
                    ("outer_oc", 1, 1, 256,
                     {"wset": [32], "sset": [48]}),
                    ("sample", 1, 1, 1),
                    ("row", 7, 1, 8, {'tlr_bar_sync': [12], 'tlr_bar_set': [14]}),
                    ("col", 7, 1, 8),
                    ("inner_oc", 8, 1, 32),
                     ("ich", 1, 1, 512)]   # unfold by default

        operator0 = tfc.br_fwd_conv(
            ishape, wshape, dt, stride=2, dilation=1, padx=0, pady=0,
            usharps=usharps0, pingpong_a=[256, 0], red_mode="ssq")
        wsr_num = operator0.get_required_wsr()
        operator0.generate()


    def test(self):
        self.Conv()
        self.assertTrue(True)


if __name__ == '__main__':
    c = TestStride2Width3()
    c.Conv()
    #pytest.main(['test_inc_not_aligned.py','-s'])
    
