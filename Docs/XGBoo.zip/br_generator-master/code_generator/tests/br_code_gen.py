#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import code_generator.share.br_defined_print as bdp
import code_generator.tcore.br_tcore_fwd_conv as tfc


def main():
    # parser = argparse.ArgumentParser()

    # parser.add_argument('--input_folder', '-i')
    # parser.add_argument('--output_folder', '-o')
    # args = parser.parse_args()

    wshape = (16, 512, 3, 3)
    ishape = (1, 512, 56, 56)
    dt = ("bf16", "bf16", "bf16")

    bdp.set_output_file("test_fwd.s")

    loop_config_ldconv0 = [
        # name,   iterations, unrolls, incremental unit
        ("outer_oc", 2, 1, 1,
         {"wset": [48], "sset": [32]}),
        ("outer_ic", 2, 1, 8),
        ("oc", 8, 1, 32),
        ("ich", 1, 1, 512)]

    loop_config_ldconv1 = [
        #   name,   iterations, unrolls, incremental unit
        ("outer_oc", 3, 1, 1),
        ("outer_ic", 2, 1, 128),
        ("outer_oc", 2, 1, 256),
        ("sample", 1, 1, 1),
        ("row", 7, 1, 8),
        ("col", 7, 1, 8),
        # ("inner_oc", och_inner_grannular, 1, och_inc),
        ("ich", 1, 1, 512)]   # unfold by default

    loop_config_conv = [
        #   name,   iterations, unrolls, incremental unit
        ("outer_oc", 3, 1, 1,
         {"wset": [32, 33], "sset": [48, 49]}),
        ("outer_ic", 2, 1, 128),
        ("outer_oc", 2, 1, 256,
         {"bar_set": [2, 3], "bar_sync": [4, 5]}),
        ("sample", 1, 1, 1),
        ("row", 7, 1, 8),
        ("col", 7, 1, 8),
        ("inner_oc", 8, 1, 32),
        ("ich", 1, 1, 512)]   # unfold by default

    loop_configs = [loop_config_ldconv0, loop_config_ldconv1, loop_config_conv]

    usharps0 = {
        "tensor_b": {"usharp": 0, "gmb_size": 1},
        "tensor_a": {"usharp": 1},
        "tensor_o": {"usharp": 2, "gmb_size": 1},
        "reduce": {"usharp": 3}}

    conv1 = tfc.br_fwd_conv(
        ishape, wshape, dt, stride=1, dilation=1, padx=0, pady=0,
        usharps=usharps0, loop_configs=loop_configs, gmb_mapping=True)
    wsr_num = conv1.get_required_wsr()
    conv1.generate()

    # wshape = (512, 512, 3, 3)
    # ishape = (2, 512, 64, 64)
    # dt = ("bf16", "bf16", "bf16")
    # usharps1 = {
    #     "tensor_b": {"usharp": 3},
    #     "tensor_a": {"usharp": 4},
    #     "tensor_o": {"usharp": 5}}
    # conv2 = tfc.br_fwd_conv(
    #     ishape, wshape, dt, stride=1, dilation=1, padx=0, pady=0,
    #     usharps=usharps1, pingpong_a=[256, 0], pingpong_b=[288, 32],
    #     red_mode="ssq")
    # wsr_num = conv1.get_required_wsr()
    # conv2.generate()
    # conv2.flush()


if __name__ == '__main__':
    main()
