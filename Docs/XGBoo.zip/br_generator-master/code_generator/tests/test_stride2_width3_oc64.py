#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

from unittest import TestCase

import code_generator.share.br_defined_print as bdp
import code_generator.tcore.br_tcore_fwd_conv as tfc


class TestStride2Width1(TestCase):
    def Conv(self):
        wshape = (64, 8, 3, 3)
        ishape = (1, 8, 112, 112)
        dt = ("bf16", "bf16", "bf16")

        bdp.set_output_file("TestStride2Width3OC64.s")
        usharps0 = {
            "tensor_b": {"usharp": 0},
            "tensor_a": {"usharp": 1},
            "tensor_o": {"usharp": 2},
            "reduce": {"usharp": 3},
        }

        operator0 = tfc.br_fwd_conv(
            ishape,
            wshape,
            dt,
            stride=2,
            dilation=1,
            padx=0,
            pady=0,
            usharps=usharps0,
            pingpong_a=[256, 0],
            red_mode="ssq",
        )
        operator0.generate()

    def test(self):
        self.Conv()
        self.assertTrue(True)


if __name__ == "__main__":
    c = TestStride2Width1()
    c.Conv()
    # pytest.main(['test_inc_not_aligned.py','-s'])
