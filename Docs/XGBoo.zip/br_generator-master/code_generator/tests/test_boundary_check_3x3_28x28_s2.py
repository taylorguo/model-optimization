#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

from unittest import TestCase

import code_generator.share.br_defined_print as bdp
import code_generator.tcore.br_tcore_fwd_conv as tfc

class TestAccu16k(TestCase):

    def Conv(self):
        wshape = (64, 128, 3, 3)
        ishape = (4, 128, 28, 28)
        hwshape = (1, 128, 56, 56)
        dt = ("bf16", "bf16", "bf16")

        bdp.set_output_file("TestBoundary_w3x3_i28x28_s2.s")
        usharps0 = {
        "tensor_b": {"usharp": 0},
        "tensor_a": {"usharp": 1},
        "tensor_o": {"usharp": 2},
        "reduce": {"usharp": 3}}

        loop_configa = [
                    #   name,   iterations, unrolls, incremental unit
                    ("outer_oc", 1, 1, 64,
                     {"wset": [32], "sset": [48]}),
                    ("inner_oc", 2, 2, 32),
                    ("ich", 1, 1, 8)]   # unfold by default

        loop_configb = [
                    #   name,   iterations, unrolls, incremental unit
                    ("outer_oc", 1, 1, 64,
                     {"wset": [32], "sset": [48]}),
                    ("sample", 1, 1, 1),
                    ("col", 8, 1, 8),
                    ("row", 8, 1, 8),
                     ("ich", 1, 1, 8)]   # unfold by default

        loop_configc = [
                    #   name,   iterations, unrolls, incremental unit
                    ("outer_oc", 1, 1, 64,
                     {"wset": [48], "sset": [32]}),
                    ("sample", 1, 1, 1),
                    ("col", 8, 1, 8),
                    ("row", 8, 1, 8),
                    ("inner_oc", 2, 2, 32),
                     ("ich", 1, 1, 8)]   # unfold by default

        operator0 = tfc.br_fwd_conv(
            ishape, wshape, dt, stride=2, dilation=1, padx=0, pady=0,
            usharps=usharps0, pingpong_a=[256, 0], red_mode="ssq",
            csrs={"28":(0, 7)}, hwshape=hwshape)
        wsr_num = operator0.get_required_wsr()
        operator0.generate()

    def test(self):
        self.Conv()
        self.assertTrue(True)


if __name__ == '__main__':
    c = TestAccu16k()
    c.Conv()
    #pytest.main(['test_inc_not_aligned.py','-s'])
    
