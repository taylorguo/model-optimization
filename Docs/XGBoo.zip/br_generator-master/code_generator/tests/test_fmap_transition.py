#!/usr/bin/env python3
import unittest, os, shutil, filecmp
from code_generator.kernel_gen import codegen
from code_generator.kernel_gen import workload
from code_generator.kernel_gen.inst import *
from command_generator import utils

class transition_test(unittest.TestCase):
    #@unittest.skip("WIP")
    def test_56x56_28x28_k1(self):
        wl = workload.workload('56x56_28x28_k1')
        s=wl.get_stream()
        w = s.append(alloca_inst(shape=(512, 256, 1,1), scope='hbm', layout='4DW', uma_mode='uma', 
                                    dtype='bf16'))
        ofm = s.append(alloca_inst(shape= (4, 512, 28, 28), scope='hbm', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bottom branch is 1, top branch is 2
        ofm1 = s.append(slice_inst(AI=ofm, slice_begin=[2, 0, 0, 0], slice_size=[2, 512, 28, 28], 
                hw_shape_slice_begin =[0, 0, 28, 0], hw_shape_slice_size=[1, 512, 28, 56]))
        ofm2 = s.append(slice_inst(AI=ofm, slice_begin= [0, 0, 0, 0], slice_size = [2, 512, 28,28 ], 
                hw_shape_slice_begin =[0, 0, 0, 0], hw_shape_slice_size = [1, 512, 28, 56]))
        ### bottom branch
        # ifm
        ifm1= s.append(alloca_inst(shape= (2, 256, 56, 56), scope='gmb', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bn
        bn1 = s.append(alloca_inst(shape=(2, 512, 28, 28), scope='hbm', layout='4DW', uma_mode='numa')) 
        bn_cache1 = s.append(alloca_inst(shape=(512*4,), scope='hbm', layout='linear', 
                                        dtype='fp32'))
        # weight
        s.append(op_inst(
            ty='BRForwardConv2BatchNormRelu',
            name='cbr_56x56_k1s2_bottom',
            in_tensor=[ifm1],
            out_tensor=[ofm1],
            tensor = [bn1, w, bn_cache1],
            params={
                'conv': {'oc': int(512), 'k':(1,1), 'strides':(2,2), 'padding':(0,0)}
                },
            infer_type=False))
        s.append(dealloca_inst(ifm1))
        ### top branch
        # ifm
        ifm2= s.append(alloca_inst(shape= (2, 256, 56, 56), scope='gmb', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bn
        bn2 = s.append(alloca_inst(shape=(2, 512, 28, 28), scope='hbm', layout='4DW', uma_mode='numa')) 
        bn_cache2 = s.append(alloca_inst(shape=(512*4,), scope='hbm', layout='linear', 
                                        dtype='fp32'))
        s.append(op_inst(
            ty='BRForwardConv2BatchNormRelu',
            name='cbr_56x56_k1s2_top',
            in_tensor=[ifm2],
            out_tensor=[ofm2],
            tensor = [bn2, w,bn_cache2],
            params={
                'conv': {'oc': int(512), 'k':(1,1), 'strides':(2,2), 'padding':(0,0)}
                },
            infer_type=False))
        s.append(dealloca_inst(ifm2))
        codegen.codegen(wl)
    #@unittest.skip("WIP")
    def test_56x56_28x28_k3(self):
        wl = workload.workload('56x56_28x28_k3')
        s=wl.get_stream()
        w = s.append(alloca_inst(shape=(128, 128, 3, 3), scope='hbm', layout='4DW', uma_mode='uma', dtype='bf16'))
        ofm = s.append(alloca_inst(shape= (4, 128, 28, 28), scope='hbm', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bottom branch is 1, top branch is 2
        ofm1 = s.append(slice_inst(AI=ofm, slice_begin=[2, 0, 0, 0], slice_size=[2, 128, 28, 28], 
                hw_shape_slice_begin =[0, 0, 28, 0], hw_shape_slice_size=[1, 128, 28, 56]))
        ofm2 = s.append(slice_inst(AI=ofm, slice_begin= [0, 0, 0, 0], slice_size = [2, 128, 28,28 ], 
                hw_shape_slice_begin =[0, 0, 0, 0], hw_shape_slice_size = [1, 128, 28, 56]))
        ### bottom branch
        # ifm
        ifm1= s.append(alloca_inst(shape= (2, 128, 56, 56), scope='gmb', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bn
        bn1 = s.append(alloca_inst(shape=(2, 128, 28, 28), scope='hbm', layout='4DW', uma_mode='numa')) 
        bn_cache1 = s.append(alloca_inst(shape=(128*4,), scope='hbm', layout='linear', 
                                        dtype='fp32'))
        # weight
        s.append(op_inst(
            ty='BRForwardConv2BatchNormRelu',
            name='cbr_56x56_k1s2_bottom',
            in_tensor=[ifm1],
            out_tensor=[ofm1],
            tensor = [bn1, w, bn_cache1],
            params={
                'conv': {'oc': int(128), 'k':(3,3), 'strides':(2,2), 'padding':(1,1)}
                },
            infer_type=False))
        s.append(dealloca_inst(ifm1))
        ### top branch
        # ifm
        ifm2= s.append(alloca_inst(shape= (2, 128, 56, 56), scope='gmb', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bn
        bn2 = s.append(alloca_inst(shape=(2, 128, 28, 28), scope='hbm', layout='4DW', uma_mode='numa')) 
        bn_cache2 = s.append(alloca_inst(shape=(128*4,), scope='hbm', layout='linear', 
                                        dtype='fp32'))
        s.append(op_inst(
            ty='BRForwardConv2BatchNormRelu',
            name='cbr_56x56_k1s2_top',
            in_tensor=[ifm2],
            out_tensor=[ofm2],
            tensor = [bn2, w,bn_cache2],
            params={
                'conv': {'oc': int(128), 'k':(3,3), 'strides':(2,2), 'padding':(1,1)}
                },
            infer_type=False))
        s.append(dealloca_inst(ifm2))
        codegen.codegen(wl)
    #@unittest.skip("WIP")
    def test_28x28_14x14_k1(self):
        wl = workload.workload('28x28_14x14_k1')
        s=wl.get_stream()
        w = s.append(alloca_inst(shape=(1024, 512, 1,1), scope='hbm', layout='4DW', uma_mode='uma', 
                                    dtype='bf16'))
        ofm = s.append(alloca_inst(shape= (8, 512, 14, 14), scope='gmb', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bottom branch is 1, top branch is 2
        ofm1 = s.append(slice_inst(AI=ofm, slice_begin=[4, 0, 0, 0], slice_size=[4, 1024, 14, 14], 
                hw_shape_slice_begin =[0, 0, 28, 0], hw_shape_slice_size=[1, 1024, 28, 28]))
        ofm2 = s.append(slice_inst(AI=ofm, slice_begin= [0, 0, 0, 0], slice_size = [4, 1024, 14,14 ], 
                hw_shape_slice_begin =[0, 0, 0, 0], hw_shape_slice_size = [1, 1024, 28, 28]))
        ### bottom branch
        # ifm
        ifm1= s.append(alloca_inst(shape= (4, 512, 28, 28), scope='gmb', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bn
        bn1 = s.append(alloca_inst(shape=(4, 1024, 14, 14), scope='hbm', layout='4DW', uma_mode='numa')) 
        bn_cache1 = s.append(alloca_inst(shape=(1024*4,), scope='hbm', layout='linear', 
                                        dtype='fp32'))
        # weight
        s.append(op_inst(
            ty='BRForwardConv2BatchNormRelu',
            name='cbr_28x28_k1s2_bottom',
            in_tensor=[ifm1],
            out_tensor=[ofm1],
            tensor = [bn1, w, bn_cache1],
            params={
                'conv': {'oc': int(512), 'k':(1,1), 'strides':(2,2), 'padding':(0,0)}
                },
            infer_type=False))
        s.append(dealloca_inst(ifm1))
        ### top branch
        # ifm
        ifm2= s.append(alloca_inst(shape= (4, 512, 28, 28), scope='gmb', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bn
        bn2 = s.append(alloca_inst(shape=(4, 1024, 14, 14), scope='hbm', layout='4DW', uma_mode='numa')) 
        bn_cache2 = s.append(alloca_inst(shape=(1024*4,), scope='hbm', layout='linear', 
                                        dtype='fp32'))
        s.append(op_inst(
            ty='BRForwardConv2BatchNormRelu',
            name='cbr_28x28_k1s2_top',
            in_tensor=[ifm2],
            out_tensor=[ofm2],
            tensor = [bn2, w,bn_cache2],
            params={
                'conv': {'oc': int(1024), 'k':(1,1), 'strides':(2,2), 'padding':(0,0)}
                },
            infer_type=False))
        s.append(dealloca_inst(ifm2))
        codegen.codegen(wl)
    #@unittest.skip("WIP")
    def test_28x28_14x14_k3(self):
        wl = workload.workload('28x28_14x14_k3')
        s=wl.get_stream()
        w = s.append(alloca_inst(shape=(256, 256, 1,1), scope='hbm', layout='4DW', uma_mode='uma', 
                                    dtype='bf16'))
        ofm = s.append(alloca_inst(shape= (8, 256, 14, 14), scope='hbm', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bottom branch is 1, top branch is 2
        ofm1 = s.append(slice_inst(AI=ofm, slice_begin=[4, 0, 0, 0], slice_size=[4, 256, 14, 14], 
                hw_shape_slice_begin =[0, 0, 28, 0], hw_shape_slice_size=[1, 256, 28, 28]))
        ofm2 = s.append(slice_inst(AI=ofm, slice_begin= [0, 0, 0, 0], slice_size = [4, 256, 14,14 ], 
                hw_shape_slice_begin =[0, 0, 0, 0], hw_shape_slice_size = [1, 256, 28, 28]))
        ### bottom branch
        # ifm
        ifm1= s.append(alloca_inst(shape= (4, 256, 28, 28), scope='gmb', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bn
        bn1 = s.append(alloca_inst(shape=(4, 256, 14, 14), scope='hbm', layout='4DW', uma_mode='numa')) 
        bn_cache1 = s.append(alloca_inst(shape=(256*4,), scope='hbm', layout='linear', 
                                        dtype='fp32'))
        # weight
        s.append(op_inst(
            ty='BRForwardConv2BatchNormRelu',
            name='cbr_28x28_k1s2_bottom',
            in_tensor=[ifm1],
            out_tensor=[ofm1],
            tensor = [bn1, w, bn_cache1],
            params={
                'conv': {'oc': int(256), 'k':(3,3), 'strides':(2,2), 'padding':(1,1)}
                },
            infer_type=False))
        s.append(dealloca_inst(ifm1))
            #pass_mm = kernel_gen.memory_pass.memory_pass(hw, wl)
    #pass_mm.run_on_stream() 
### top branch
        # ifm
        ifm2= s.append(alloca_inst(shape= (4, 256, 28, 28), scope='gmb', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bn
        bn2 = s.append(alloca_inst(shape=(4, 256, 14, 14), scope='hbm', layout='4DW', uma_mode='numa')) 
        bn_cache2 = s.append(alloca_inst(shape=(256*4,), scope='hbm', layout='linear', 
                                        dtype='fp32'))
        s.append(op_inst(
            ty='BRForwardConv2BatchNormRelu',
            name='cbr_28x28_k1s2_top',
            in_tensor=[ifm2],
            out_tensor=[ofm2],
            tensor = [bn2, w,bn_cache2],
            params={
                'conv': {'oc': int(256), 'k':(3,3), 'strides':(2,2), 'padding':(1,1)}
                },
            infer_type=False))
        s.append(dealloca_inst(ifm2))
        codegen.codegen(wl)
    #@unittest.skip("WIP")
    def test_14x14_7x7_k1(self):
        # 7x7 spc mode
        wl = workload.workload('14x14_7x7_k1')
        s=wl.get_stream()
        w = s.append(alloca_inst(shape=(2048,1024, 1,1), scope='hbm', layout='4DW', uma_mode='uma', 
                                    dtype='bf16'))
        ofm = s.append(alloca_inst(shape= (16, 2048, 7, 7), scope='hbm', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bottom branch is 1, top branch is 2
        ofm1 = s.append(slice_inst(AI=ofm, slice_begin=[8, 0, 0, 0], slice_size=[8, 1024, 7, 7], 
                hw_shape_slice_begin =[0, 0, 28, 0], hw_shape_slice_size=[1, 1024, 28, 14]))
        ofm2 = s.append(slice_inst(AI=ofm, slice_begin= [0, 0, 0, 0], slice_size = [8, 1024, 7, 7], 
                hw_shape_slice_begin =[0, 0, 0, 0], hw_shape_slice_size = [1, 1024, 28, 14]))
        ### bottom branch
        # ifm
        ifm1= s.append(alloca_inst(shape= (8, 1024, 14, 14), scope='gmb', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bn
        bn1 = s.append(alloca_inst(shape=(8, 2048, 7, 7), scope='hbm', layout='4DW', uma_mode='numa')) 
        bn_cache1 = s.append(alloca_inst(shape=(2048*4,), scope='hbm', layout='linear', 
                                        dtype='fp32'))
        # weight
        s.append(op_inst(
            ty='BRForwardConv2BatchNormRelu',
            name='cbr_28x28_k1s2_bottom',
            in_tensor=[ifm1],
            out_tensor=[ofm1],
            tensor = [bn1, w, bn_cache1],
            params={
                'conv': {'oc': int(2048), 'k':(1,1), 'strides':(2,2), 'padding':(0,0)}
                },
            infer_type=False))
        s.append(dealloca_inst(ifm1))
        ### top branch
        # ifm
        ifm2= s.append(alloca_inst(shape= (8, 1024, 14, 14), scope='gmb', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bn
        bn2 = s.append(alloca_inst(shape=(8, 2048, 7, 7), scope='hbm', layout='4DW', uma_mode='numa')) 
        bn_cache2 = s.append(alloca_inst(shape=(2048*4,), scope='hbm', layout='linear', 
                                        dtype='fp32'))
        s.append(op_inst(
            ty='BRForwardConv2BatchNormRelu',
            name='cbr_28x28_k1s2_top',
            in_tensor=[ifm2],
            out_tensor=[ofm2],
            tensor = [bn2, w,bn_cache2],
            params={
                'conv': {'oc': int(2048), 'k':(1,1), 'strides':(2,2), 'padding':(0,0)}
                },
            infer_type=False))
        s.append(dealloca_inst(ifm2))
        codegen.codegen(wl)
    #@unittest.skip("WIP")
    def test_14x14_7x7_k3(self):
        # 7x7 spc mode
        wl = workload.workload('14x14_7x7_k3')
        s=wl.get_stream()
        w = s.append(alloca_inst(shape=(512, 512, 1,1), scope='hbm', layout='4DW', uma_mode='uma', 
                                    dtype='bf16'))
        ofm = s.append(alloca_inst(shape= (16, 256, 7, 7), scope='hbm', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bottom branch is 1, top branch is 2
        ofm1 = s.append(slice_inst(AI=ofm, slice_begin=[8, 0, 0, 0], slice_size=[8, 512, 7, 7], 
                hw_shape_slice_begin =[0, 0, 28, 0], hw_shape_slice_size=[1, 512, 28, 14]))
        ofm2 = s.append(slice_inst(AI=ofm, slice_begin= [0, 0, 0, 0], slice_size = [8, 512, 7, 7], 
                hw_shape_slice_begin =[0, 0, 0, 0], hw_shape_slice_size = [1, 512, 28, 14]))
        ### bottom branch
        # ifm
        ifm1= s.append(alloca_inst(shape= (8, 512, 14, 14), scope='gmb', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bn
        bn1 = s.append(alloca_inst(shape=(8, 512, 7,7), scope='hbm', layout='4DW', uma_mode='numa')) 
        bn_cache1 = s.append(alloca_inst(shape=(512*4,), scope='hbm', layout='linear', 
                                        dtype='fp32'))
        # weight
        s.append(op_inst(
            ty='BRForwardConv2BatchNormRelu',
            name='cbr_28x28_k1s2_bottom',
            in_tensor=[ifm1],
            out_tensor=[ofm1],
            tensor = [bn1, w, bn_cache1],
            params={
                'conv': {'oc': int(512), 'k':(3,3), 'strides':(2,2), 'padding':(1,1)}
                },
            infer_type=False))
        s.append(dealloca_inst(ifm1))
        ### top branch
        # ifm
        ifm2= s.append(alloca_inst(shape= (8, 512, 14,14), scope='gmb', 
                                dtype='bf16', uma_mode='numa', layout='4DA'))
        # bn
        bn2 = s.append(alloca_inst(shape=(8, 512, 7, 7), scope='hbm', layout='4DW', uma_mode='numa')) 
        bn_cache2 = s.append(alloca_inst(shape=(512*4,), scope='hbm', layout='linear', 
                                        dtype='fp32'))
        s.append(op_inst(
            ty='BRForwardConv2BatchNormRelu',
            name='cbr_28x28_k1s2_top',
            in_tensor=[ifm2],
            out_tensor=[ofm2],
            tensor = [bn2, w,bn_cache2],
            params={
                'conv': {'oc': int(512), 'k':(3,3), 'strides':(2,2), 'padding':(1,1)}
                },
            infer_type=False))
        s.append(dealloca_inst(ifm2))
        codegen.codegen(wl)

if __name__=='__main__':
   T=transition_test()
   #T.test_56x56_28x28_k1()
   #T.test_56x56_28x28_k3()
   #T.test_28x28_14x14_k1()
   #T.test_28x28_14x14_k1()
   T.test_14x14_7x7_k1()
   T.test_14x14_7x7_k3()
