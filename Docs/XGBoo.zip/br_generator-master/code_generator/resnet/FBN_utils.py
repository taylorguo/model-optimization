class stream():
    def __init__(self):
        self.s = []
        self.declare = []
        self.shape_pool = {}

    def append(self, i):
        #if isinstance(i, alloca_inst):
            #self.shape_pool[i.name]=i
        #elif isinstance(i, dealloca_inst):
            #del self.shape_pool[i.t.name]
        self.s.append(i)
        return i

    def stream(self):
        return self.s

    def __str__(self):
        out = ""
        for i in self.s:
            out += (str(i) + "\n")
        return out

    def get_tensor_by_name(self, tname):
        return self.shape_pool[tname]


class workload:
    def __init__(self, stream):
        self.stream_pool = []
        self.stream_pool.append(stream)

    def get_stream(self, stream_id=0):
        return self.stream_pool[stream_id]


def string(a):
    if a is not None:
        return a
    else:
        return 'None'