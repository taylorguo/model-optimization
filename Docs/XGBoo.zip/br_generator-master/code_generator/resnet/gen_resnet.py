#!/usr/bin/env python3
import FBN

version = "resnet50"
ty = "classic"
N = 16
wl = FBN.resnet(version, ty, N)
import code_generator.kernel_gen.hardware
hw = code_generator.kernel_gen.hardware.hardware()
import code_generator.kernel_gen.infer_hw_shape_pass
pass_hw_shape = code_generator.kernel_gen.infer_hw_shape_pass.infer_hw_shape_pass(hw, wl)
pass_hw_shape.run_on_stream() 
import code_generator.kernel_gen.kernel_selector_pass
pass_ks = code_generator.kernel_gen.kernel_selector_pass.kernel_selector_pass(hw, wl)
pass_ks.run_on_stream()
import code_generator.kernel_gen.dump_stream_pass
Pds = code_generator.kernel_gen.dump_stream_pass.dump_stream_pass(hw, wl)
Pds.run_on_stream(dump_all=False) 
#import list2asm
#pass_bk = list2asm.list2asm(hw, wl)
#pass_bk.run_on_stream()

