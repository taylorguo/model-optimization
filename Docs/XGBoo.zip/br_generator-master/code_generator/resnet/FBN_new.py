#!/usr/bin/env python3
import sys
sys.path.append('../')

import json
global locked, backward, unable, all_inst

from FBN_operators import BRReLU, BRConv2, BRForwardConv2BatchNorm, BRForwardConv2Relu, BRBatchNorm, BRFullConnect, BRAveragePool, \
    BRForwardConv2BatchNormAdderRelu, BRMaxPool, BRBackConv2ReluBatchNorm, BRBackConv2AdderReluBatchNormBatchNorm, \
    BRForwardConv2BatchNormReluMaxPool, BRBackConv2AdderMaxpoolReluBatchNorm, BRBackConv2AdderReluBypassBatchNorm, \
    BRForwardConv2BatchNormRelu, BRSoftmax, Adder, ForwardNet, BackwardNet, nn_Module, backward, nn_Module, nn_Sequential

#from FBN_utils import stream, workload
#from FBN_inst import op_inst, alloca_inst, dealloca_inst
from code_generator.kernel_gen.stream_pass import *
import code_generator.kernel_gen.workload
import code_generator.kernel_gen.stream
from code_generator.kernel_gen.inst import *


global unable, locked, all_inst, ForwardNet, BackwardNet
locked = []
unable = []
all_inst = {}

global isDynamicBS
isDynamicBS = False
# Allocation
# to check if an item is already allocated
def alloc_in(input):
    global locked
    for i in locked:
        if i.name == input.name:
            return i
    return False


# allocate an inst
def alloc(inst_l, network, op=-1):
    global locked, all_inst
    if len(inst_l) > 0:
        for inst in inst_l:
            k = alloc_in(inst)
            if k == False:
                locked.append(inst)
                if op >= 0:
                    network.insert(op, inst)
                else:
                    network.append(inst)
            else:
                unable.append(inst.name)
                if op >= 0:
                    network.insert(op, {'type': 'alloc_fail', inst.name: inst.shape})
                else:
                    network.append({'type': 'alloc_fail', inst.name: inst.shape})


            if inst.name not in all_inst:
                all_inst[inst.name] = inst.shape
            else:
                print(inst.name)
                #quit()


# deallocate an inst
def dealloc(inst_l, network):
    global locked, unable
    if len(inst_l) > 0:
        for inst in inst_l:
            k = alloc_in(inst)
            if k != False:
                locked.remove(k)
                network.append(dealloca_inst(inst))
            else:
                unable.append(inst.name)
                network.append({'type': 'dealloc_fail', inst.name: inst.shape})


class ResNetBuilder(object):
    def __init__(self, version, config):
        self.config = config

        self.L = sum(version['layers'])
        self.M = version['block'].M

    def conv(self, kernel_size, in_planes, out_planes, stride=1):
        if kernel_size == 3:
            conv = self.config['conv'](
                in_planes, out_planes, kernel_size=3, stride=stride, padding=1,
                 bias=False)
        elif kernel_size == 1:
            conv = BRConv2(in_planes, out_planes, kernel_size=1, stride=stride,
                             bias=False)
        elif kernel_size == 5:
            conv = BRConv2(in_planes, out_planes, kernel_size=5, stride=stride, padding=2,
                             bias=False)
        elif kernel_size == 7:
            conv = BRConv2(in_planes, out_planes, kernel_size=7, stride=stride, padding=3,
                            bias=False)
        else:
            return None

        #if self.config['nonlinearity'] == 'relu':
            # nn.init.kaiming_normal_(conv.conv.weight, mode=self.config['conv_init'], nonlinearity=self.config['nonlinearity'])

        return conv

    def conv3x3(self, in_planes, out_planes, stride=1):
        """3x3 convolution with padding"""
        c = self.conv(3, in_planes, out_planes, stride=stride)

        return c

    def conv1x1(self, in_planes, out_planes, stride=1):
        """1x1 convolution with padding"""
        c = self.conv(1, in_planes, out_planes, stride=stride)

        return c

    def conv7x7(self, in_planes, out_planes, stride=1):
        """7x7 convolution with padding"""
        c = self.conv(7, in_planes, out_planes, stride=stride)

        return c

    def conv5x5(self, in_planes, out_planes, stride=1):
        """5x5 convolution with padding"""
        c = self.conv(5, in_planes, out_planes, stride=stride)

        return c

    def batchnorm(self, planes, last_bn=False):
        bn = BRBatchNorm(planes)

        gamma_init_val = 0 if last_bn and self.config['last_bn_0_init'] else 1
        bn.setGamma(gamma_init_val)
        bn.setBeta(0)

        return bn

    def activation(self, name):
        relu = self.config['activation']
        return relu


class Bottleneck(nn_Module):
    M = 3
    expansion = 4

    def __init__(self, num, round, builder, inplanes, planes, stride=1, downsample=None):
        global ForwardNet
        global isDynamicBS
        self.conv1 = builder.conv1x1(inplanes, planes)
        self.conv1.setName(num + '_' + round +'_conv1')
        self.bn1 = builder.batchnorm(planes)
        self.bn1.setName(num + '_' + round + '_bn1')
        self.conv2 = builder.conv3x3(planes, planes, stride=stride)
        self.conv2.setName(num + '_' + round + '_conv2')
        self.bn2 = builder.batchnorm(planes)
        self.bn2.setName(num + '_' + round + '_bn2')
        self.conv3 = builder.conv1x1(planes, planes * self.expansion)
        self.conv3.setName(num + '_' + round + '_conv3')
        self.bn3 = builder.batchnorm(planes * self.expansion, last_bn=True)
        self.bn3.setName(num + '_' + round + '_bn3')
        self.relu = builder.activation(num + '_' + round + '_relu')
        self.relu.setName(num + '_' + round + '_relu')
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        # residual handling
        if self.downsample is not None:
            if not isDynamicBS:
                alloc([self.downsample.conv.weight, self.downsample.bn.weight], ForwardNet)
                residual = self.downsample(x)
                alloc([residual], ForwardNet, len(ForwardNet)-1)
            else:
                residual = x[1]
        else:
            residual = x
        # *_1_1 handling, for isDynamicDS, should skip this step
        if self.downsample is not None and isDynamicBS:
            out_1 = x[0]
            # dealloc([x[0]], ForwardNet)
        else:
            alloc([self.conv1.weight, self.bn1.weight], ForwardNet)
            out_1 = BRForwardConv2BatchNormRelu(self.conv1, self.bn1, self.relu)(x)
            alloc([out_1, self.bn1.act_after_bn], ForwardNet, len(ForwardNet)-1)

        if self.downsample is not None:
            if not isDynamicBS:
                dealloc([x], ForwardNet)
            # else:
            #     dealloc([x[1]], ForwardNet)

        alloc([self.conv2.weight, self.bn2.weight], ForwardNet)
        out_2 = BRForwardConv2BatchNormRelu(self.conv2, self.bn2, self.relu)(out_1)
        alloc([out_2, self.bn2.act_after_bn], ForwardNet, len(ForwardNet)-1)
        dealloc([out_1], ForwardNet)


        adder = Adder(residual)
        alloc([self.conv3.weight, self.bn3.weight], ForwardNet)
        out_3 = BRForwardConv2BatchNormAdderRelu(self.conv3, self.bn3, adder, self.relu)(out_2)
        alloc([out_3, self.bn3.act_after_bn], ForwardNet, len(ForwardNet)-1)
        dealloc([out_2], ForwardNet)

        if self.downsample is None:
            dealloc([residual], ForwardNet)

        return out_3

class Bottleneck_1_1(nn_Module):
    M = 3
    expansion = 4

    def __init__(self, num, round, builder, inplanes, planes, stride=1, downsample=None):
        global ForwardNet
        self.conv1 = builder.conv1x1(inplanes, planes)
        self.conv1.setName(num + '_' + round +'_conv1')
        self.bn1 = builder.batchnorm(planes)
        self.bn1.setName(num + '_' + round + '_bn1')
        self.relu = builder.activation(num + '_' + round + '_relu')
        self.relu.setName(num + '_' + round + '_relu')
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):

        if self.downsample is not None:
            alloc([self.downsample.conv.weight, self.downsample.bn.weight], ForwardNet)
            residual = self.downsample(x)
            alloc([residual], ForwardNet, len(ForwardNet)-1)
        else:
            residual = x

        alloc([self.conv1.weight, self.bn1.weight], ForwardNet)
        out_1 = BRForwardConv2BatchNormRelu(self.conv1, self.bn1, self.relu)(x)
        alloc([out_1, self.bn1.act_after_bn], ForwardNet, len(ForwardNet)-1)
        if self.downsample is not None:
            dealloc([x], ForwardNet)

        return out_1,residual

class ResNet(nn_Module):
    def __init__(self, builder, block, layers, num_classes=1000):
        global ForwardNet, BackwardNet
        global isDynamicBS
        self.inplanes = 64
        self.conv1 = builder.conv7x7(3, 64, stride=2)
        self.conv1.setName('0_0_conv1')
        self.bn1 = builder.batchnorm(64)
        self.bn1.setName('0_0_bn1')
        self.relu = builder.activation('0_0_relu')
        self.builder = builder
        self.block = block
        self.layers = layers
        self.maxpool = BRMaxPool(kernel_size=3, stride=2, padding=1)
        self.maxpool.setName('0_0_BRMaxpool')

        self.layer1_1_1 = self._make_layer_1_1('1', builder, block, 64, layers[0])
        self.layer1 = self._make_layer('1', builder, block, 64, layers[0])

        self.layer2_1_1 = self._make_layer_1_1('2', builder, block, 128, layers[1], stride=2)
        self.layer2 = self._make_layer('2', builder, block, 128, layers[1], stride=2)

        self.layer3_1_1 = self._make_layer_1_1('3', builder, block, 256, layers[2], stride=2)
        self.layer3 = self._make_layer('3', builder, block, 256, layers[2], stride=2)

        self.layer4_1_1 = self._make_layer_1_1('4', builder, block, 512, layers[3], stride=2)
        self.layer4 = self._make_layer('4', builder, block, 512, layers[3], stride=2)

        self.avgpool = BRAveragePool(1)
        self.avgpool.setName('0_0_BRAveragePool')
        self.fc = BRFullConnect(512 * block.expansion, num_classes)
        self.fc.setName('0_0_BRFullConnect')

    def _make_layer_1_1(self, num, builder, block, planes, blocks, stride=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            dconv = builder.conv1x1(self.inplanes, planes * block.expansion,
                                    stride=stride)
            dconv.setName(num+'_D_downsample_conv')
            dbn = builder.batchnorm(planes * block.expansion)
            dbn.setName(num+'_D_downsample_BN')
            if dbn is not None:
                downsample = BRForwardConv2BatchNorm(dconv, dbn)
            else:
                downsample = dconv

        layers = []
        layers.append(Bottleneck_1_1(num, '1', builder, self.inplanes, planes, stride, downsample))
        return nn_Sequential(*layers)

    def _make_layer(self, num, builder, block, planes, blocks, stride=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            dconv = builder.conv1x1(self.inplanes, planes * block.expansion,
                                    stride=stride)
            dconv.setName(num+'_D_downsample_conv')
            dbn = builder.batchnorm(planes * block.expansion)
            dbn.setName(num+'_D_downsample_BN')
            if dbn is not None:
                downsample = BRForwardConv2BatchNorm(dconv, dbn)
            else:
                downsample = dconv

        layers = []
        layers.append(block(num, '1', builder, self.inplanes, planes, stride, downsample))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(num, str(i+1), builder, self.inplanes, planes))

        return nn_Sequential(*layers)

    def forward(self, x):
        x = alloca_inst(name='original_input', shape=x)
        alloc([x], ForwardNet)

        if self.bn1 is not None:
            alloc([self.conv1.weight, self.bn1.cache], ForwardNet)
            x_1 = BRForwardConv2BatchNormReluMaxPool(self.conv1, self.bn1, self.relu, self.maxpool)(x)
            alloc([x_1, self.bn1.act_after_bn], ForwardNet, len(ForwardNet)-1)
        else:
            x_2 = BRForwardConv2Relu(self.conv1, self.relu)(x)
            alloc([x_2, self.conv1.weight], ForwardNet)
            dealloc([x], ForwardNet)
            x_1 = self.maxpool(x_2, write=True)
            alloc([x_1], ForwardNet)
            dealloc([x_2], ForwardNet)

        if not isDynamicBS:
            x = self.layer1(x_1)
            x = self.layer2(x)
            x = self.layer3(x)
            x = self.layer4(x)
        else:
            x = self.layer1_1_1(x_1)
            x = self.layer1(x)
            x = self.layer2_1_1(x)
            x = self.layer2(x)
            x = self.layer3_1_1(x)
            x = self.layer3(x)
            x = self.layer4_1_1(x)
            x = self.layer4(x)


        x_1 = self.avgpool(x, write=True)
        alloc([x_1], ForwardNet, len(ForwardNet)-1)
        dealloc([x], ForwardNet)
        mul = 1
        for i in x_1.shape:
            mul *= i
        x_1.shape = [x_1.shape[0], int(mul/x_1.shape[0])]
        alloc([self.fc.weight, self.fc.bias], ForwardNet)
        x = self.fc(x_1, write=True)
        alloc([x], ForwardNet, len(ForwardNet)-1) # x_1 = fc input
        dealloc([x_1], ForwardNet)

        return x

    def backward(self, output_delta):
        output_delta = alloca_inst(name='output_delta', shape=output_delta)
        alloc([output_delta], BackwardNet)
        output_delta_1 = self.fc(output_delta, write=True)
        alloc([output_delta_1, self.fc.tensor[3], self.fc.tensor[4]], BackwardNet, len(BackwardNet)-1)
        dealloc([output_delta], BackwardNet)
        # reshape
        if len(output_delta_1.shape) == 2:
            output_delta_1.shape += [self.avgpool.output_size, self.avgpool.output_size]

        output_delta = self.avgpool(output_delta_1, write=True)
        alloc([output_delta], BackwardNet, len(BackwardNet)-1)
        dealloc([output_delta_1], BackwardNet)

        output_delta_1 = self.layer4[-1].relu(output_delta, write=True)
        residual = output_delta_1
        alloc([output_delta_1], BackwardNet, len(BackwardNet)-1)
        dealloc([output_delta], BackwardNet)

        layer = [self.layer1, self.layer2, self.layer3, self.layer4]

        output_delta, bn_weight_delta = layer[-1][-1].bn3(output_delta_1, write=True)
        alloc([output_delta], BackwardNet, len(BackwardNet)-1)
        dealloc([layer[-1][-1].bn3.act_after_bn], BackwardNet) # we don't dealloc output_delta here because output_delta == residual.

        l = 3
        while l >= 0:
            n = self.layers[l]
            for i in range(1, n+1):
                crb = BRBackConv2ReluBatchNorm(layer[l][n-i].conv3, layer[l][n-i].relu, layer[l][n-i].bn2)
                output_delta_1 = crb(output_delta)
                alloc([output_delta_1, crb.tensor[3], crb.tensor[4]], BackwardNet, len(BackwardNet)-1)
                dealloc([output_delta, layer[l][n-i].bn2.act_after_bn], BackwardNet)

                crb = BRBackConv2ReluBatchNorm(layer[l][n-i].conv2, layer[l][n-i].relu, layer[l][n-i].bn1)
                output_delta = crb(output_delta_1)
                alloc([output_delta, crb.tensor[3], crb.tensor[4]], BackwardNet, len(BackwardNet)-1)
                dealloc([output_delta_1, layer[l][n-i].bn1.act_after_bn], BackwardNet)

                residual_1 = residual

                if (n-i) == 1:# 1 to 0
                    carbb = BRBackConv2AdderReluBatchNormBatchNorm(layer[l][1].conv1,
                                                                    Adder(residual_1),
                                                                    layer[l][0].relu,
                                                                    layer[l][0].bn3,
                                                                    layer[l][0].downsample[-1])
                    output_delta_1, residual = carbb(output_delta)
                    alloc([residual, output_delta_1, carbb.tensor[5], carbb.tensor[6], carbb.tensor[7]], BackwardNet, len(BackwardNet)-1)
                    dealloc([output_delta, layer[l][0].bn3.act_after_bn, layer[l][0].downsample[-1].act_after_bn, residual_1], BackwardNet)
                    residual_1, down_weight_delta = layer[l][0].downsample[0](residual, write=True)

                    temp = residual
                    residual = residual_1
                    residual_1 = temp

                    alloc([residual], BackwardNet, len(BackwardNet)-1)
                    dealloc([residual_1], BackwardNet)

                elif (n - i) == 0 and l == 0:
                    continue

                elif (n-i) != 0:
                    carpb = BRBackConv2AdderReluBypassBatchNorm(layer[l][n-i].conv1,
                                                                 Adder(residual_1),
                                                                 layer[l][n-i-1].relu,
                                                                 layer[l][n-i-1].bn3)
                    output_delta_1, residual = carpb(output_delta)
                    alloc([output_delta_1,  carpb.tensor[4], carpb.tensor[5]], BackwardNet, len(BackwardNet)-1)
                    dealloc([output_delta, layer[l][n-i-1].bn3.act_after_bn], BackwardNet)

                elif (n-i) == 0:
                    carpb = BRBackConv2AdderReluBypassBatchNorm(layer[l][n - i].conv1,
                                                                 Adder(residual_1),
                                                                 layer[l-1][-1].relu,
                                                                 layer[l-1][-1].bn3)
                    output_delta_1, residual = carpb(output_delta)
                    alloc([output_delta_1, carpb.tensor[4], carpb.tensor[5]], BackwardNet, len(BackwardNet)-1)
                    dealloc([output_delta, layer[l-1][-1].bn3.act_after_bn], BackwardNet)

                if (n - i) == 0 and l == 0:
                    pass
                else:
                    temp = output_delta
                    output_delta = output_delta_1
                    output_delta_1 = temp
            l -= 1

        if self.bn1 is not None:
            output_delta_2 = BRBackConv2AdderMaxpoolReluBatchNorm(self.layer1[0].conv1, Adder(residual), self.maxpool, self.relu, self.bn1)(output_delta)
            alloc([output_delta_2], BackwardNet, len(BackwardNet)-1)
            dealloc([output_delta, residual, self.bn1.act_after_bn], BackwardNet)
        else:
            output_delta = Adder(residual)(output_delta, write=True)
            output_delta = self.maxpool(output_delta, write=True)
            output_delta_2 = self.relu(output_delta, write=True)

        output_delta, conv_weight = self.conv1(output_delta_2, write=True)
        alloc([output_delta], BackwardNet, len(BackwardNet)-1)
        dealloc([output_delta_2, self.conv1.input], BackwardNet) # the first conv, no prior bn, hence dealloc con1.input.
        return output_delta


class Demo_Forward(nn_Module):
    def __init__(self, builder, block, layers, num_classes, stride=1):
        inplanes = 64
        planes = 64
        self.conv1 = builder.conv1x1(inplanes, planes)
        self.conv1.setName('Demo_Forward_conv1')
        self.bn1 = builder.batchnorm(planes)
        self.bn1.setName('Demo_Forward_bn1')
        self.conv2 = builder.conv3x3(planes, planes, stride=stride)
        self.conv2.setName('Demo_Forward_conv2')
        self.bn2 = builder.batchnorm(planes)
        self.bn2.setName('Demo_Forward_bn2')
        self.relu = builder.activation('Demo_Forward_relu')
        self.relu.setName('Demo_Forward_relu')

    def forward(self, x):
        x = alloca_inst(name='activation', shape=x)
        alloc([self.conv1.weight, self.bn1.weight], ForwardNet)
        x_1 = BRForwardConv2BatchNormRelu(self.conv1, self.bn1, self.relu)(x)
        alloc([x_1, self.bn1.act_after_bn], ForwardNet, len(ForwardNet)-1)
        dealloc([x, self.conv1.weight, self.bn1.weight], ForwardNet)
        alloc([self.conv2.weight, self.bn2.weight], ForwardNet)
        x = BRForwardConv2BatchNormRelu(self.conv2, self.bn2, self.relu)(x_1)
        alloc([x,  self.bn2.act_after_bn], ForwardNet, len(ForwardNet)-1)
        dealloc([x_1, self.conv2.weight, self.bn2.weight], ForwardNet)
        return x


class Demo_Backward(nn_Module):
    def __init__(self, builder, block, layers, num_classes, stride=1):
        inplanes = 64
        planes = 64
        self.conv1 = builder.conv1x1(inplanes, planes)
        self.conv1.setName('Demo_Forward_conv1')
        self.bn1 = builder.batchnorm(planes)
        self.bn1.setName('Demo_Forward_bn1')
        self.conv2 = builder.conv3x3(planes, planes, stride=stride)
        self.conv2.setName('Demo_Forward_conv2')
        self.bn2 = builder.batchnorm(planes)
        self.bn2.setName('Demo_Forward_bn2')
        self.relu = builder.activation('Demo_Forward_relu')
        self.relu.setName('Demo_Forward_relu')

    def backward(self, x):
        x = alloca_inst(name='output_delta', shape=x)
        alloc([self.conv1.weight, self.bn1.weight], BackwardNet)
        x_1 = BRBackConv2ReluBatchNorm(self.conv1, self.relu, self.bn1)(x)
        alloc([x_1, self.bn1.act_after_bn], BackwardNet, len(BackwardNet)-1)
        dealloc([x, self.conv1.weight, self.bn1.weight], BackwardNet)
        alloc([self.conv2.weight, self.bn2.weight], BackwardNet)
        x = BRBackConv2ReluBatchNorm(self.conv2, self.relu, self.bn2)(x_1)
        alloc([x, self.bn2.act_after_bn], BackwardNet, len(BackwardNet)-1)
        dealloc([x_1, self.conv2.weight, self.bn2.weight], BackwardNet)
        return x


resnet_configs = {
    'classic': {
        'conv': BRConv2,
        'conv_init': 'fan_out',
        'nonlinearity': 'relu',
        'last_bn_0_init': False,
        'activation': BRReLU(inplace=True),
    },
    'fanin': {
        'conv_grad': BRConv2,
        'conv_init': 'fan_in',
        'nonlinearity': 'relu',
        'last_bn_0_init': False,
        'activation': BRReLU(inplace=True),
    },
}

resnet_versions = {
    'resnet50': {
        'net': ResNet,
        'block': Bottleneck,
        'layers': [3, 4, 6, 3],
        'num_classes': 1000,
    },
    'resnet101': {
        'net': ResNet,
        'block': Bottleneck,
        'layers': [3, 4, 23, 3],
        'num_classes': 1000,
    },
    'resnet152': {
        'net': ResNet,
        'block': Bottleneck,
        'layers': [3, 8, 36, 3],
        'num_classes': 1000,
    },
    'demo_forward': {
        'net': Demo_Forward,
        'block': Bottleneck,
        'layers': [1],
        'num_classes': 1000,
    },
    'demo_backward': {
        'net': Demo_Backward,
        'block': Bottleneck,
        'layers': [1],
        'num_classes': 1000,
    },
}


def build_resnet(version, config, model_state=None):
    version = resnet_versions[version]
    config = resnet_configs[config]

    builder = ResNetBuilder(version, config)
    #print("Version: {}".format(version))
    #print("Config: {}".format(config))
    model = version['net'](builder,
                           version['block'],
                           version['layers'],
                           version['num_classes'])
    return model


def resnet(version, ty, N):
    global locked, backward, ForwardNet, BackwardNet, unable
    model = build_resnet(version, ty)
    outputs = model([N, 3, 224, 224])
    softmax = BRSoftmax()
    results = softmax(outputs)
    alloc([results], ForwardNet, len(ForwardNet)-1)
    dealloc([outputs], ForwardNet)
    backward[0] = True # backward is a list storing a bolean which indicates whether we will be doing forward propagation or back propagation. The mutable itself is saved in FBN_operators.
    outputs = softmax(results)
    alloc([outputs], ForwardNet, len(ForwardNet)-1)
    dealloc([results], ForwardNet)
    outputs = model(outputs.shape)
    dealloc([outputs], BackwardNet)
    model_stream = kernel_gen.stream.stream()
    model_stream.set_stream(ForwardNet + BackwardNet)
    wl = kernel_gen.workload.workload()
    wl.set_stream(model_stream)
    #model_stream.stream() = ForwardNet + BackwardNet
    model_stream.shape_pool = all_inst
    return wl

if __name__ == "__main__":
    version = "resnet50"
    ty = "classic"
    N = 64
    wl = resnet(version, ty, N)
    print(ForwardNet)
    import hardware
    hw = hardware.hardware()
    import dump_stream_pass
    Pds = dump_stream_pass.dump_stream_pass(hw, wl)
    Pds.run_on_stream() 
    #debug_and_save(version, ty, N)


