import pickle

def debug_and_save(version, ty, N):
    global locked, backward, ForwardNet, BackwardNet, unable, all_inst

    resnet50 = resnet(version, ty, N)

    file = open("./" + version + "_" + ty + "_Forward.pkl", 'wb')
    for i in range(len(ForwardNet)):
        if str(type(ForwardNet[i]))[-6:-2] == 'dict':
            pass
        else:
            ForwardNet[i] = ForwardNet[i].json()

    file = open("./" + version + "_" + ty + "_Backward.pkl", 'wb')
    for i in range(len(BackwardNet)):
        if str(type(BackwardNet[i]))[-6:-2] == 'dict':
            pass
        else:
            BackwardNet[i] = BackwardNet[i].json()

    for i in ForwardNet:
        print(i)

    print(
        "====================================================================================================================================================================================")

    for i in BackwardNet:
        print(i)

    print(
        "====================================================================================================================================================================================")

    for i in locked:
        print(i.json())

    print(len(locked))
    j = 0
    for i in locked:
        if i.name[-6:] != 'weight':
            print(i.name)
            j += 1
    print(j)
    print(unable)
    print(len(unable))

    print(all_inst)
    print(len(all_inst))


def separateBatch(inst, batch):
    l = []
    total = 0
    N = inst.shape[0]
    while total < N:
        if total + batch <= N:
            l.append(alloca_inst(name=inst.name+"_"+str(total)+"-"+str(), shape=[batch]+inst.shape[1:]))
        else:
            l.append(alloca_inst(name=inst.name+"_"+str(total)+"-"+str(), shape=[N-batch]+inst.shape[1:]))
        total += batch
    return l


def merge(l):
    num = 0
    for i in l:
        num += i.shape[0]
    tensor = l[0].shape
    tensor.remove(tensor[0])
    tensor.append(0, num)
    return alloca_inst(name=l[0].name.split("_")[0:-1], tensor=tensor)


