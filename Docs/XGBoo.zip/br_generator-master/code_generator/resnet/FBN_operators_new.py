#from FBN_inst import op_inst, alloca_inst, dealloca_inst
#from FBN_utils import string
import sys
sys.path.append('../')
from code_generator.kernel_gen.inst import *
def string(a):
    if a is not None:
        return a
    else:
        return 'None'

global ForwardNet, BackwardNet, backward

#backward is a list storing a bolean which indicates whether we will be doing forward propagation or back propagation.
backward = [False]

ForwardNet = []
BackwardNet = []



# Forward
def ForwardConv2(input, weight, stride, padding):
    return [input[0], weight[0], int(input[2]/stride[0]), int(input[3]/stride[1])]


def ForwardBN(input, var, mean, bias):
    return input, mean, var


def ForwardReLU(activation):
    return activation


def ForwardMaxPool(activation, return_indices, stride):
    if return_indices:
        indices = activation
        indices[-2] = int(activation[2] / stride[0])
        indices[-1] = int(activation[3] / stride[1])
        return activation, indices
    else:
        return activation


def ForwardAveragePool(activation, output_size):
    return [activation[0], activation[1], output_size, output_size]


# Back
def BPA(input, weight, output_grad, dilation, padding):
    #print("BPA: "+"weight="+str(weight.shape)+", output_grad="+ alloca_inst(name=self.name+'_output_grad', tensor=output_grad.shape)ation: "+str(dilation)+", padding="+str(padding))
    _, x, _, _ = weight.shape
    a, _, y, _ = input.shape
    return alloca_inst(name=weight.name[0:-6]+'input_grad', shape=[a, x, y, y])


def BPW(input, output_grad, weight):
    #print("BPW: "+"input="+str(input.shape)+", output_grad="+ alloca_inst(name=self.name+'_output_grad', tensor=output_grad.shape)nel_size: "+str(kernel_size)+", stride="+str(stride)+", padding="+str(padding))
    return alloca_inst(name=input.name[0:-6]+'weight_grad', shape=weight.shape)


def BNGrad(output_grad, input, running_mean, running_var, weight, bias, act_after_bn):
    #print("BNGrad: "+"output_grad="+ alloca_inst(name=self.name+'_output_grad', tensor=output_grad.shape)ut="+str(input.shape) + ", weight=" + str(weight.shape) + ", bias: " + str(bias.shape))
    return alloca_inst(name=input.name.split("_")[0]+"_"+input.name.split("_")[1]+"_" + input.name.split("_")[2][4:] + '_input_grad', shape=output_grad.shape), alloca_inst(name=weight.name.split("_")[0]+"_"+weight.name.split("_")[1]+"_"+weight.name.split("_")[2]+"_"+'weight_grad', shape=weight.shape)


def ReLUGrad(input, output, output_grad):
    #print("ReLUGrad: " + "input=" + string(input.shape) + ", output=" + string(output.shape) + ", output_grad=" + string(output_grad.shape))
    return alloca_inst(name=input.name.split("_")[0]+"_"+input.name.split("_")[1]+"_"+input.name.split("_")[2][4:] + '_input_grad', shape=output_grad.shape)


def MaxPool2dGrad(output_grad, indices):
    a, b, c, d = output_grad.shape
    _, _, x, y = indices.shape
    #print("MaxPool2dGrad: " + "output_dealta=" +  alloca_inst(name=self.name+'_output_grad', tensor=output_grad.shape)ndices=" + str(indices))
    return alloca_inst(name=indices.name.split("_")[0]+"_"+indices.name.split("_")[1]+"_"+ 'input_grad', shape=[a, b, c+x, d+y])


def AdaptiveAvgPool2dGrad(input, output_size, output_grad):
    #print("AdaptiveAvgPool2dGrad: "+ "input=" + str(input.shape) + ", output_size=" + str(output_size) + ", output_grad=" + string(output_grad))
    return alloca_inst(name=input.name.split("_")[0]+"_"+input.name.split("_")[1]+"_"+'input_grad', shape=input.shape)


def FCGrad(input, weight, bias, output_grad):
    #print(output_grad.shape)
    a, b = output_grad.shape
    in_features = weight.shape[1]
    #print("FCGrad: " + "input=" + str(input.shape) + ", weight=" + str(weight.shape) + ", bias=" + str(bias.shape) + ", output_grad=" + list(output_grad.shaeturn torch.rand([a, in_features, 1, 1])
    return alloca_inst(name=weight.name.split("_")[0]+"_"+weight.name.split("_")[1]+"_"+'input_grad', shape=[a, in_features]), alloca_inst(name=weight.name.split("_")[0]+"_"+weight.name.split("_")[1]+'_weight_grad', shape=weight.shape), alloca_inst(name=weight.name.split("_")[0]+"_"+weight.name.split("_")[1]+'_bias_grad', shape=bias.shape)

class nn_Module:
    def __call__(self, *more, **kargs):
        global backward
        if not backward[0]:
            self.b = True
            return self.forward(*more, **kargs)
        else:
            self.b = False
            return self.backward(*more, **kargs)

    def forward(self, *more, **kargs):
        # will be overriden
        pass

    def backward(self, *more, **kargs):
        # will be overriden
        pass


class BRSoftmax(nn_Module):
    def __init__(self, dim=-1):
        global ForwardNet, BackwardNet
        self.dim = dim
        self.name = 'BRSoftmax'
        self.input = None
        self.output = None

    def forward(self, activation):
        self.input = activation
        self.output = alloca_inst(name=self.name + '_output', shape=activation.shape)
        ForwardNet.append(op_inst(infer_type=False, ty='BRForwardSoftmax', name=self.name, in_tensor=[activation],
                                  out_tensor=[self.output],
                                  params={'dim': self.dim}))
        return alloca_inst(name=self.name + '_output', shape=activation.shape)

    def backward(self, output_grad):
        input_grad = alloca_inst(name=self.name + '_input_grad', shape=output_grad.shape)
        ForwardNet.append(op_inst(infer_type=False, ty='BRForwardSoftmax', name=self.name, in_tensor=[alloca_inst(name=self.name + '_output_grad', shape=output_grad.shape)],
                                  out_tensor=[input_grad],
                                  params={'dim': self.dim}))
        return alloca_inst(name=self.name + '_input_grad', shape=output_grad.shape)


class ConvShapeInfer_type(nn_Module):
    def __init__(self, in_planes, output_planes, kernel_size=1, padding=None, stride=1, bias=True):
        self.in_channels = in_planes
        self.out_channels = output_planes
        self.kernel_size = kernel_size
        if type(padding) == type(int(1)):
            self.padding = [padding, padding]
        else:
            self.padding = padding

        if type(kernel_size) == type(int(1)):
            self.kernel_size = [kernel_size, kernel_size]
        else:
            self.kernel_size = kernel_size

        if type(stride) == type(int(1)):
            self.stride = [stride, stride]
        else:
            self.stride = stride

        self.bias = bias
        self.weight = [output_planes, in_planes, kernel_size, kernel_size]
        self.bias = [output_planes]

    def forward(self, activation):
        return ForwardConv2(activation, self.weight, self.stride, self.padding)

class BRConv2(nn_Module):
    def __init__(self, in_planes, output_planes, kernel_size=1, padding=0, stride=1, dilation=1, bias=True):
        global locked, BackwardNet, ForwardNet
        self.conv = ConvShapeInfer_type(in_planes=in_planes, output_planes=output_planes, kernel_size=kernel_size, padding=None, stride=stride, bias=bias)
        self.input = None
        self.output = None
        if type(kernel_size ) == type(int(1)):
            self.kernel_size = [kernel_size , kernel_size ]
        else:
            self.kernel_size  = kernel_size

        if type(stride) == type(int(1)):
            self.stride = [stride, stride]
        else:
            self.stride = stride

        self.dilation = dilation
        if type(padding) == type(int(1)):
            self.padding = [padding, padding]
        else:
            self.padding = padding
        self.weight_grad = None
        self.name = 'conv'
        self.weight = alloca_inst(name=self.name + '_weight', shape=self.conv.weight)
        self.tensor = []

    def setName(self, name):
        self.name = name
        self.weight = alloca_inst(name=self.name + '_weight', shape=self.conv.weight)

    def forward(self, activation, write=False):
        self.input = activation
        output = self.conv(activation.shape)
        self.output = alloca_inst(name=self.name + '_output', shape=output)
        self.weight = alloca_inst(name=self.name + '_weight', shape=self.conv.weight)
        self.forward_alloc_tensor = [self.input, self.weight, self.output]
        self.forward_dealloc_tensor = []
        if write:
            self.forward_alloc_tensor.append(self.output)
            self.forward_dealloc_tensor.append(activation)
            ForwardNet.append(op_inst(infer_type=False, ty='BRForwardConv2', name=self.name, in_tensor=[activation],
                out_tensor=[self.output], params={'ic': self.conv.in_channels, 'oc': self.conv.out_channels, 'k': self.conv.kernel_size, 'bias': string(self.conv.bias), 'padding':self.padding, 'strides':self.stride}))
        return alloca_inst(name=self.name + '_output', shape=output)

    def backward(self, output_grad, write=False):
        tensor = [self.input, alloca_inst(name=self.name + '_weight', shape=self.conv.weight)]
        input_grad = BPA(self.input, self.weight, output_grad, self.dilation, self.padding)
        self.weight_grad = BPW(self.input, output_grad, self.weight)
        tensor.append(self.weight_grad)
        self.tensor = tensor
        if write:
            BackwardNet.append(op_inst(infer_type=False, ty='BRBackConv2', name=self.name, in_tensor=[output_grad],
                out_tensor=[alloca_inst(name=self.name+"_input_grad", shape=input_grad.shape)], tensor=tensor, params={'ic': self.conv.in_channels, 'oc': self.conv.out_channels, 'k': self.conv.kernel_size, 'bias': string(self.conv.bias) , 'padding':self.padding, 'strides':self.stride}))
        return input_grad, self.weight_grad

    def __str__(self):
        return str({'name': self.name, 'ic': (self.conv.in_channels), 'oc': (self.conv.out_channels), 'k': (self.conv.kernel_size), 'bias': string(self.conv.bias)})

    def json(self):
        return {'name': self.name, 'ic': self.conv.in_channels, 'oc': self.conv.out_channels,
         'k': self.conv.kernel_size, 'bias': string(self.conv.bias), 'strides': self.stride, 'padding': self.padding}


class BatchNorm(nn_Module):
    def __init__(self, num_features):
        self.num_features = num_features
        self.running_mean = [num_features]
        self.running_var = [num_features]
        self.cache = alloca_inst(name='bn_weight', shape=[num_features*4])
        self.eps = 1e-05
        self.momentum = 0.1
        self.affine = True
        self.track_running_stats = True
        self.bias = [num_features]

    def forward(self, activation):
        self.running_mean = [self.cache.shape[0]]
        self.running_var = [self.cache.shape[0]]
        return ForwardBN(activation, self.running_var, self.running_mean, self.bias)


class BRBatchNorm(nn_Module):
    def __init__(self, num_features):
        global locked, BackwardNet, ForwardNet
        self.bn = BatchNorm(num_features)
        self.input = None
        self.name = 'BN'
        self.cache = alloca_inst(name=self.name + '_bn_cache', shape=self.bn.cache.shape)
        self.running_mean = [num_features]
        self.running_var = [num_features]
        self.bias = None
        self.act_after_bn = None
        self.input = None
        self.gamma = None
        self.beta = None

    def setName(self, name):
        self.name = name
        self.weight = alloca_inst(name=self.name + '_bn_cache', shape=self.cache.shape)

    def setGamma(self, gamma):
        # nn.init.constant_(self.bn.weight, gamma)
        self.gamma = gamma

    def setBeta(self, beta):
        # nn.init.constant_(self.bn.bias, beta)
        self.beta = beta

    def json(self):
        return {'name': self.name, 'num_features': self.bn.num_features, 'eps': self.bn.eps, 'momentum': self.bn.momentum, 'affine': self.bn.affine, 'track_running_stats':self.bn.track_running_stats, 'scale': self.gamma, 'offset': self.beta, 'act_after_bn': self.act_after_bn}

    def forward(self, activation, write=False):
        self.input = activation
        self.running_mean = alloca_inst(name=self.name + '_bn_running_mean', shape=self.bn.running_mean)
        self.running_var = alloca_inst(name=self.name + '_bn_running_var', shape=self.bn.running_var)
        self.weight = alloca_inst(name=self.name + '_bn_weight', shape=self.weight.shape)
        self.bias = alloca_inst(name=self.name + '_bias', shape=self.bn.bias)
        self.act_after_bn = self.bn(activation.shape)
        self.act_after_bn = alloca_inst(name=self.name + '_act_after_bn', shape=self.act_after_bn)
        self.act_after_bn, self.running_mean, self.running_var = ForwardBN(self.input, self.running_var, self.running_mean, self.bias)
        if write:
            ForwardNet.append(op_inst(infer_type=False, ty='BRForwardBatchNorm', name=self.name, in_tensor=[activation],
                                      out_tensor=[alloca_inst(name=self.name+'_act_after_bn', shape=self.act_after_bn.shape)], params={'num_features': self.bn.num_features, 'eps':self.bn.eps, 'momentum': self.bn.momentum, 'affine': self.bn.affine, 'track_running_stats':self.bn.track_running_stats, 'scale': self.gamma, 'offset': self.beta}))
        return self.act_after_bn

    def backward(self, output_grad, write=False):
        input_grad, weight_grad = BNGrad(output_grad, self.input, self.running_mean, self.running_var, self.weight, self.bias, self.act_after_bn)
        self.backward_dealloc_tensor = [self.running_mean, self.running_var, self.weight, self.bias, self.act_after_bn]
        if self.input.name[3] == 'D':
            self.backward_dealloc_tensor.append(self.input)
        self.backward_alloc_tensor = [output_grad]
        if write:
            BackwardNet.append(op_inst(infer_type=False, ty='BRBackBatchNorm', name=self.name, in_tensor=[output_grad],
                                       out_tensor=[alloca_inst(name=self.name+'_input_grad', shape=input_grad.shape)], params={'num_features': self.bn.num_features, 'eps':self.bn.eps, 'momentum': self.bn.momentum, 'affine': self.bn.affine, 'track_running_stats':self.bn.track_running_stats, 'scale': self.gamma, 'offset': self.beta}))
        return input_grad, weight_grad


class ReLU(nn_Module):
    def __init__(self, inplace):
        self.inplace = inplace

    def forward(self, activation):
        return ForwardReLU(activation)


class BRReLU(nn_Module):
    def __init__(self, inplace):
        global locked, BackwardNet, ForwardNet
        self.relu = ReLU(inplace)
        self.input = None
        self.output = None
        self.name = 'ReLU'

    def setName(self, name):
        self.name = name

    def __str__(self):
        return self.name + (self.relu.json())[4:]

    def json(self):
        return {'name': self.name, 'inplace': self.relu.inplace}

    def forward(self, activation, write=False):
        self.input = activation
        self.output = self.relu(activation.shape)
        self.output = alloca_inst(name=self.name + '_output', shape=self.output)
        self.forward_dealloc_tensor = []
        if write:
            ForwardNet.append(op_inst(infer_type=False, ty='BRForwardReLU', name=self.name, in_tensor=[activation],
                                      out_shape=[self.output], params={'inplace': self.relu.inplace}))
        return self.output

    def backward(self, output_grad, write=False):
        input_grad = ReLUGrad(self.input, self.output.shape, output_grad)
        self.backward_alloc_tensor = []
        if write:
            BackwardNet.append(op_inst(infer_type=False, ty='BRBackReLU', name=self.name, in_tensor=[output_grad],
                                       out_tensor=[input_grad], params={'inplace': self.relu.inplace}))
        return input_grad


class MaxPool2d(nn_Module):
    def __init__(self, kernel_size, stride, padding, return_indices=True):
        if type(kernel_size) == type(int(1)):
            self.kernel_size = [kernel_size, kernel_size]
        else:
            self.kernel_size = kernel_size

        if type(stride) == type(int(1)):
            self.stride = [stride, stride]
        else:
            self.stride = stride

        if type(padding) == type(int(1)):
            self.padding = [padding, padding]
        else:
            self.padding = padding

        self.return_indices = return_indices
        self.dilation = 1
        self.ceil_mode = False

    def forward(self, activation):
        return ForwardMaxPool(activation, self.return_indices, self.stride)


class BRMaxPool(nn_Module):
    def __init__(self, kernel_size, stride=None, padding=0):
        global locked, BackwardNet, ForwardNet
        self.maxpool = MaxPool2d(kernel_size, stride, padding, return_indices=True)
        self.indices = None
        self.input = None
        self.output = None
        self.name = None
        self.return_indices = True

        if type(kernel_size) == type(int(1)):
            self.kernel_size = [kernel_size, kernel_size]
        else:
            self.kernel_size = kernel_size

        if type(stride) == type(int(1)):
            self.stride = [stride, stride]
        else:
            self.stride = stride

        if type(padding) == type(int(1)):
            self.padding = [padding, padding]
        else:
            self.padding = padding

    def setName(self, name):
        self.name = name

    def forward(self, activation, write=False):
        self.input = activation
        if self.return_indices:
            self.output, self.indices = self.maxpool(activation.shape)
        else:
            self.output = self.maxpool(activation.shape)
        self.indices = alloca_inst(name=self.name + '_indices', shape=self.indices)
        self.output = alloca_inst(name= self.name + '_output', shape=self.output)
        if write:
            self.forward_alloc_tensor.append(self.output)
            self.forward_dealloc_tensor.append(activation)
            ForwardNet.append(op_inst(infer_type=False, ty='BRForwardMaxPool', in_tensor=[activation],
                                      out_shape=[self.output], params={'k': self.maxpool.kernel_size, 'strides': self.maxpool.stride, 'padding':self.maxpool.padding, 'dilation':self.maxpool.dilation, 'ceil_mode': self.maxpool.ceil_mode}))
        return self.output

    def backward(self, output_grad, write=False):
        input_grad = MaxPool2dGrad(output_grad, self.indices)
        if write:
            BackwardNet.append(op_inst(infer_type=False, ty='BRBackMaxPool', in_tensor=[output_grad],
                                       out_tensor=[input_grad], params={'k': self.maxpool.kernel_size, 'strides': self.maxpool.stride, 'padding':self.maxpool.padding, 'dilation':self.maxpool.dilation, 'ceil_mode': self.maxpool.ceil_mode}))
        return input_grad

    def __str__(self):
        return "name="+self.name +", "+ str(self.maxpool)[9:]

    def json(self):
        return {"name": self.name, 'k': self.kernel_size, 'strides':self.stride, 'padding':self.padding, 'dilation': self.maxpool.dilation, 'ceil_mode': self.maxpool.ceil_mode}


class AdaptiveAvgPool2d(nn_Module):
    def __init__(self, output_size):
        self.output_size = output_size

    def forward(self, activation):
        return ForwardAveragePool(activation, self.output_size)

class BRAveragePool(nn_Module):
    def __init__(self, output_size):
        global locked, BackwardNet, ForwardNet
        self.avgpool = AdaptiveAvgPool2d(output_size)
        self.output_size = output_size
        self.input = None
        self.output = None
        self.name = 'BRAveragePool'
        self.forward_alloc_tensor = []
        self.forward_dealloc_tensor = []
        self.backward_alloc_tensor = []
        self.backward_dealloc_tensor = []

    def setName(self, name):
        self.name = name

    def forward(self, activation, write=False):
        self.input = activation
        output = self.avgpool(activation.shape)
        # reshape in resnet50
        #mul = 1
        #for i in self.output:
        #    mul *= i
        #self.output = [self.output[0], int(mul / self.output[0])]
        self.output = alloca_inst(name=self.name + '_output', shape=output)
        self.forward_alloc_tensor = [self.input]
        self.forward_dealloc_tensor = []
        if write:
            self.forward_alloc_tensor.append(self.output)
            self.forward_dealloc_tensor.append(activation)
            #alloc(self.forward_dealloc_tensor, ForwardNet)
            ForwardNet.append(op_inst(infer_type=False, ty='BRForwardAveragePool', name=self.name, in_tensor=[activation],
                                      out_tensor=[alloca_inst(name=self.name + '_output', shape=output)],
                                      params={'output_size':self.avgpool.output_size}))
        return self.output

    def backward(self, output_grad, write=False):
        #if len(output_grad.shape) == 2:
        #    output_grad.shape += [self.output_size, self.output_size]

        input_grad = AdaptiveAvgPool2dGrad(self.input, self.avgpool.output_size, output_grad)
        self.backward_alloc_tensor = [output_grad]
        self.backward_dealloc_tensor = [self.input]
        if write:
            self.backward_dealloc_tensor.append(output_grad)
            self.backward_alloc_tensor.append(input_grad)
            BackwardNet.append(
                op_inst(infer_type=False, ty='BRBackAveragePool', name=self.name, in_tensor=[output_grad],
                        out_tensor=[input_grad],
                        params={'output_size':self.avgpool.output_size}))
        return input_grad

    def __str__(self):
        return "name=" + self.name + 'output_size=' + str(self.avgpool.output_size)

    def json(self):
        return {"name": self.name, 'output_size=': str(self.avgpool.output_size)}


class Linear(nn_Module):
    def __init__(self, in_features, out_features, bias):
        self.in_features = in_features
        self.out_features = out_features
        self.bias = [out_features]
        self.weight = [out_features, in_features]

    def forward(self, activation):
        result = [0, 0]
        result[0] = activation[0]
        result[1] = self.out_features
        return result


class BRFullConnect(nn_Module):
    def __init__(self, in_features, out_features, bias=True):
        global locked, BackwardNet, ForwardNet
        self.fc = Linear(in_features, out_features, bias)
        self.input = None
        self.output = None
        self.name = '0_0_BRFullConnect'
        self.weight = alloca_inst(name=self.name + '_weight', shape=self.fc.weight)
        self.bias = alloca_inst(name=self.name + '_bias', shape=self.fc.bias)
        self.forward_alloc_tensor = []
        self.forward_dealloc_tensor = []
        self.backward_alloc_tensor = []
        self.backward_dealloc_tensor = []
        self.tensor = []

    def setName(self, name):
        self.name = name
        self.weight = alloca_inst(name=self.name + '_weight', shape=self.fc.weight)

    def forward(self, activation, write=False):
        self.input = activation
        self.output = self.fc(activation.shape)
        self.output = alloca_inst(name=self.name + '_output', shape=self.output)
        self.forward_alloc_tensor = [self.input, self.weight, self.bias]
        self.forward_dealloc_tensor = []
        if write:
            self.forward_dealloc_tensor.append(activation)
            self.forward_alloc_tensor.append(self.output)
            ForwardNet.append(
                op_inst(infer_type=False, ty='BRForwardFullConnect', name=self.name, in_tensor=[activation],
                        out_tensor=[self.output], tensor=[self.weight, self.bias],
                        params={'in_features': self.fc.in_features, 'out_features':self.fc.out_features, 'bias': string(self.fc.bias)}))
        return self.output

    def backward(self, output_grad, write=False):
        input_grad, weight_grad, bias_grad = FCGrad(self.input, self.weight, self.bias, output_grad)
        self.backward_alloc_tensor = [output_grad]
        self.backward_dealloc_tensor = [self.input, self.weight, self.bias]
        if write:
            self.backward_dealloc_tensor.append(output_grad)
            self.backward_alloc_tensor.append(input_grad)
            self.tensor = [self.input, self.weight, self.bias, weight_grad, bias_grad]
            BackwardNet.append(
                op_inst(infer_type=False, ty='BRBackFullConnect', name=self.name, in_tensor=[output_grad],
                        out_tensor=[input_grad],
                        tensor=self.tensor, params={'in_features': self.fc.in_features, 'out_features':self.fc.out_features, 'bias':string(self.fc.bias)}))
        return input_grad

    def __str__(self):
        return 'in_tensor=activation, #'+str(self.fc.in_features)+', ' \
                                                     'out_tensor='+str(self.fc.out_features)+', bias='+str(self.fc.bias)

    def json(self):
        return {'in_tensor':self.fc.in_features, 'out_tensor': self.fc.out_features, 'bias': string(self.fc.bias)}


class Adder(nn_Module):
    def __init__(self, addend):
        global locked, BackwardNet, ForwardNet
        self.addend = addend
        self.name = 'adder'
        self.forward_alloc_tensor = []
        self.forward_dealloc_tensor = [self.addend]
        self.backward_alloc_tensor = []
        self.backward_dealloc_tensor = [self.addend]

    def forward(self, activation, write=False):
        if activation is not None:
            output = alloca_inst(name=self.name+'_output', shape=activation.shape)
            if write:
                self.forward_dealloc_tensor.append(activation)
                self.forward_alloc_tensor.append(output)
                ForwardNet.append(
                    op_inst(infer_type=False, ty='adder', name=self.name, in_tensor=[activation],
                            out_tensor=[output],
                            params={'addend': string(self.addend)}))
            return output
        else:
            pass

    def backward(self, output_grad, write=False):
        if output_grad is not None:
            input_grad = alloca_inst(name='add_output_grad', shape=output_grad.shape)
            if write:
                self.backward_dealloc_tensor.append(output_grad)
                self.backward_alloc_tensor.append(input_grad)
                BackwardNet.append(
                    op_inst(infer_type=False, ty='adder', name=self.name, in_tensor=[output_grad],
                            out_tensor=[alloca_inst(name=self.name+'_output_grad', shape=output_grad.shape)],
                            params={'addend': string(self.addend)}))
            return input_grad
        else:
            pass

    def __str__(self):
        return "adder: residual=" + str(self.addend.shape)

    def json(self):
        return {'name': self.name, 'residual': self.addend.shape}


class nn_Sequential(nn_Module):
    def __init__(self, *modules):
        self.modules = [*modules]
        self.input = None
        self.output = None

    def __getitem__(self, item):
        return self.modules[item]

    def forward(self, activation):
        self.input = activation

        self.output = self.input
        for op in self.modules:
            self.output = op(self.output)
        return self.output

    def backward(self, output_grad):
        r = list(self.modules)
        for op in r:
            output_grad = op(output_grad)
        return output_grad


class BRForwardConv2BatchNormRelu(nn_Module):
    def __init__(self, conv, bn, relu):
        global locked, BackwardNet, ForwardNet
        self.sequential = nn_Sequential(conv, bn, relu)
        self.conv = conv
        self.bn = bn
        self.relu = relu
        self.name = self.conv.name.split("_")[0]+"_"+self.conv.name.split("_")[1]+"_"+ self.conv.name.split("_")[2][4:] + '_' + 'BRForwardConv2BatchNormRelu'

    def forward(self, activation):
        tensor = []
        output = self.conv(activation)
        output = self.bn(output)
        self.bn.act_after_bn = alloca_inst(name=self.name + '_act_after_bn', shape=output.shape)
        tensor.append(self.bn.act_after_bn)
        tensor.append(alloca_inst(name=self.conv.name + '_weight', shape=self.conv.weight.shape))
        tensor.append(self.bn.cache)
        output = self.relu(output)
        output = alloca_inst(name=self.name + '_output', shape=output.shape)
        ForwardNet.append(
            op_inst(infer_type=False, ty='BRForwardConv2BatchNormRelu',name=self.name, in_tensor=[activation],
                    out_tensor=[output], tensor=tensor,
                    params={'conv': (self.conv.json()),
                            'bn': (self.bn.json()),
                            'relu': (self.relu.json())}))
        return output


class BRForwardConv2BatchNormReluMaxPool(nn_Module):
    def __init__(self, conv, bn, relu, maxpool):
        global locked, BackwardNet, ForwardNet
        self.sequential = nn_Sequential(conv, bn, relu, maxpool)
        self.conv = conv
        self.bn = bn
        self.relu = relu
        self.maxpool = maxpool
        self.name = self.conv.name.split("_")[0]+"_"+self.conv.name.split("_")[1]+"_"+ 'BRForwardConv2BatchNormReluMaxPool'

    def forward(self, activation):
        tensor = []
        output = self.conv(activation)
        output = self.bn(output)
        import copy
        act_af_bn_shape = copy.deepcopy(output.shape)
        self.bn.act_after_bn = alloca_inst(name=self.name + '_act_after_bn', shape=act_af_bn_shape)
        tensor.append(self.bn.act_after_bn)
        tensor.append(alloca_inst(name=self.conv.name + '_weight', shape=self.conv.weight.shape))
        tensor.append(self.bn.cache)
        output = self.relu(output)
        output = self.maxpool(output)
        ForwardNet.append(
            op_inst(infer_type=False, ty='BRForwardConv2BatchNormReluMaxPool', name=self.name, in_tensor=[activation],
                    out_tensor=[output], tensor=tensor,
                    params={'conv': (self.conv.json()),
                            'bn': (self.bn.json()),
                            'relu': (self.relu.json()),
                            'maxpool': (self.maxpool.json())}))
        return output


class BRForwardConv2Relu(nn_Module):
    def __init__(self, conv, relu):
        global locked, BackwardNet, ForwardNet
        self.sequential = nn_Sequential(conv, relu)
        self.conv = conv
        self.relu = relu
        self.name = self.conv.name.split("_")[0]+"_"+self.conv.name.split("_")[1]+"_" + 'BRForwardConv2RELU'

    def forward(self, activation):
        output = self.sequential(activation.shape)
        output = alloca_inst(name=self.name + '_output', tensor=output)
        ForwardNet.append(
                op_inst(infer_type=False, ty='BRForwardConv2Relu',name=self.name, in_tensor=[activation],
                        out_tensor=[output],
                        params={'conv': (self.conv.json()),
                                'relu': (self.relu.json())}))
        return output


class BRForwardConv2BatchNormAdderRelu(nn_Module):
    def __init__(self, conv, bn, adder, relu):
        global locked, BackwardNet, ForwardNet
        self.sequential = nn_Sequential(conv, bn, adder, relu)
        self.conv = conv
        self.bn = bn
        self.adder = adder
        self.adder.name = self.conv.name.split("_")[0]+"_"+self.conv.name.split("_")[1]+"_" + "adder"
        self.relu = relu
        self.name = self.conv.name.split("_")[0]+"_"+self.conv.name.split("_")[1]+"_" + 'BRForwardConv2BatchNormAdderRelu'

    def forward(self, activation):
        tensor = []
        output = self.conv(activation)
        output = self.bn(output)
        self.bn.act_after_bn = alloca_inst(name=self.name + '_act_After_bn', shape=output.shape)
        tensor.append(self.bn.act_after_bn)
        output = self.adder(output)
        tensor.append(alloca_inst(name=self.name + '_act_after_adder', shape=output.shape))
        tensor.append(alloca_inst(name=self.conv.name + '_weight', shape=self.conv.weight.shape))
        tensor.append(self.bn.cache)
        output = self.relu(output)
        output = alloca_inst(name=self.name + '_output', shape=output.shape)
        ForwardNet.append(
            op_inst(infer_type=False, ty='BRForwardConv2BatchNormAdderRelu', name=self.name, in_tensor=[activation, self.adder.addend],
                    out_tensor=[alloca_inst(name=self.name+'_output', shape=output.shape)], tensor=tensor,
                    params={'conv': (self.conv.json()),
                            'bn': (self.bn.json()),
                            'adder': (self.adder.json()),
                            'relu': (self.relu.json())}))
        return output


class BRForwardConv2BatchNorm(nn_Module):
    def __init__(self, conv, bn):
        global locked, BackwardNet, ForwardNet
        self.sequential = nn_Sequential(conv, bn)
        self.conv = conv
        self.bn = bn
        self.name = self.conv.name.split("_")[0]+"_"+self.conv.name.split("_")[1]+"_" + 'BRForwardConv2BatchNorm'

    def __getitem__(self, item):
        if item == 0:
            return self.conv
        elif item == -1:
            return self.bn
        else:
            return self.conv

    def forward(self, activation):
        tensor = []
        output = self.conv(activation)
        output = self.bn(output)
        self.bn.act_after_bn = alloca_inst(name=self.name + '_act_after_bn', shape=output.shape)
        tensor.append(self.bn.act_after_bn)
        tensor.append(alloca_inst(name=self.conv.name + '_weight', shape=self.conv.weight.shape))
        tensor.append(self.bn.cache)
        output = self.bn.act_after_bn
        ForwardNet.append(
            op_inst(infer_type=False, ty='BRForwardConv2BatchNorm', name=self.name, in_tensor=[activation],
                    out_tensor=[output], tensor=tensor,
                    params={'conv': (self.conv.json()),
                            'bn': (self.bn.json())}))
        return output


class BRBackConv2ReluBatchNorm(nn_Module):
    def __init__(self, conv, relu, bn):
        global locked, BackwardNet, ForwardNet
        self.sequential = nn_Sequential(conv, relu, bn)
        self.conv = conv
        self.relu = relu
        self.bn = bn
        self.name = conv.name.split("_")[0]+"_"+self.conv.name.split("_")[1]+"_"+ self.conv.name.split("_")[2][4:] + '_' + 'BRBackConv2ReluBatchNorm'
        self.tensor = []

    def backward(self, output_grad):
        tensor = []
        output, conv_weight_grad = self.conv(output_grad)
        output = self.relu(output)
        tensor.append(self.bn.act_after_bn)
        output, bn_weight_grad = self.bn(output)
        tensor.append(alloca_inst(name=self.conv.name+'_weight', shape=self.conv.weight.shape))
        tensor.append(self.bn.cache)
        tensor.append(conv_weight_grad)
        tensor.append(bn_weight_grad)
        output = alloca_inst(name=self.name + '_output', shape=output.shape)
        self.tensor = tensor
        BackwardNet.append(
            op_inst(infer_type=False, ty='BRBackConv2ReluBatchNorm', name=self.name, in_tensor=[output_grad],
                    out_tensor=[output], tensor=tensor,
                    params={'conv': (self.conv.json()),
                            'relu': (self.relu.json()),
                            'bn': (self.bn.json())}))
        return output


class BRBackConv2AdderMaxpoolReluBatchNorm(nn_Module):
    def __init__(self, conv, add, max, relu, bn):
        global locked, BackwardNet, ForwardNet
        self.sequential = nn_Sequential(conv, add, max, relu, bn)
        self.residual = add.addend
        self.conv = conv
        self.adder = add
        self.adder.name = self.conv.name.split("_")[0]+"_"+self.conv.name.split("_")[1]+"_" + "adder"
        self.maxpool = max
        self.relu = relu
        self.bn = bn
        self.name = conv.name.split("_")[0]+"_"+self.conv.name.split("_")[1]+"_" + 'BRBackConv2dAdderMaxpoolReluBatchNorm'
        self.backward_alloc_tensor = []
        self.backward_dealloc_tensor = []

    def backward(self, output_grad):
        tensor = []
        output, conv_weight_grad = self.conv(output_grad)
        output = self.adder(output)
        output = self.maxpool(output)
        output = self.relu(output)
        tensor.append(self.bn.act_after_bn)
        output, bn_weight_grad = self.bn(output)
        tensor.append(alloca_inst(name=self.conv.name+'_weight', shape=self.conv.weight.shape))
        tensor.append(self.bn.cache)
        tensor.append(conv_weight_grad)
        tensor.append(bn_weight_grad)
        BackwardNet.append(
            op_inst(infer_type=False, ty='BRBackConv2dAdderMaxpoolReluBatchNorm',name=self.name, in_tensor=[output_grad, self.adder.addend],
                    out_tensor=[alloca_inst(name=self.name+'_output', shape=output.shape)], tensor=tensor,
                    params={'conv': (self.conv.json()),
                            'adder': (self.adder.json()),
                            'maxpool': str(self.maxpool),
                            'relu': (self.relu.json()),
                            'bn': (self.bn.json())}))
        return output


class BRBackConv2AdderReluBatchNormBatchNorm(nn_Module):
    def __init__(self, conv, add, relu, bn1, bn2):
        global locked, BackwardNet, ForwardNet
        self.sequential = nn_Sequential(conv, add, relu, bn1)
        self.residual = add.addend
        self.conv = conv
        self.adder = add
        self.adder.name = self.conv.name.split("_")[0]+"_"+self.conv.name.split("_")[1]+"_" + "adder"
        self.relu = relu
        self.bn1 = bn1
        self.downsample_bn = bn2
        self.name = conv.name.split("_")[0]+"_"+self.conv.name.split("_")[1]+"_" + 'BRBackConv2AdderReluBatchNormBatchNorm'
        self.tensor = []

    def backward(self, output_grad):
        tensor = []
        output, conv_weight_grad = self.conv(output_grad)
        output = self.adder(output)
        output = self.relu(output)
        tensor.append(self.bn1.act_after_bn)
        output, bn1_weight_grad = self.bn1(output)
        tensor.append(self.downsample_bn.act_after_bn)
        tensor.append(alloca_inst(name=self.conv.name+'_weight', shape=self.conv.weight.shape))
        tensor.append(self.bn1.cache)
        tensor.append(self.downsample_bn.cache)
        tensor.append(conv_weight_grad)
        tensor.append(bn1_weight_grad) #bn weight grad
        self.residual, downsample_bn_weight_grad = self.downsample_bn(self.residual)
        tensor.append(downsample_bn_weight_grad)  # downsample bn weight grad
        self.tensor = tensor
        BackwardNet.append(
            op_inst(infer_type=False, ty='BRBackConv2AdderReluBatchNormBatchNorm',name=self.name, in_tensor=[output_grad, self.adder.addend],
                    out_tensor=[alloca_inst(name=self.name+'_output', shape=output.shape), self.residual], tensor=tensor,
                    params={'conv': (self.conv.json()),
                            'adder': (self.adder.json()),
                            'relu': (self.relu.json()),
                            'bn': (self.bn1.json()),
                            'downsample_bn': (self.downsample_bn.json())}))
        return output, self.residual


class BRBackConv2AdderReluBypassBatchNorm(nn_Module):
    def __init__(self, conv, add, relu, bn):
        global locked, BackwardNet, ForwardNet
        self.sequential = nn_Sequential(conv, add, relu, bn)
        self.residual = add.addend
        self.conv = conv
        self.adder = add
        self.adder.name = self.conv.name.split("_")[0]+"_"+self.conv.name.split("_")[1]+"_"+"adder"
        self.relu = relu
        self.bn = bn
        self.name = conv.name.split("_")[0]+"_"+self.conv.name.split("_")[1]+"_"+'BRBackConv2AdderReluBypassBatchNorm'
        self.tensor = []

    def backward(self, output_grad):
        tensor = []
        output, conv_weight_grad = self.conv(output_grad)
        output = self.adder(output)
        output = self.relu(output)
        tensor.append(self.bn.act_after_bn)
        output, bn_weight_grad = self.bn(output)
        tensor.append(self.residual)
        tensor.append(alloca_inst(name=self.conv.name+'_weight', shape=self.conv.weight.shape))
        tensor.append(self.bn.cache)
        tensor.append(conv_weight_grad)
        tensor.append(bn_weight_grad)
        self.tensor = tensor
        BackwardNet.append(
            op_inst(infer_type=False, ty='BRBackConv2AdderReluBypassBatchNorm',name=self.name, in_tensor=[output_grad, self.adder.addend],
                    out_tensor=[alloca_inst(name=self.name+'_output', shape=output.shape), self.residual], tensor=tensor,
                    params={'conv': (self.conv.json()),
                            'adder': (self.adder.json()),
                            'relu': (self.relu.json()),
                            'bn': (self.bn.json())}))
        return output, self.residual


class BRBackConv2ReLU(nn_Module):
    def __init__(self, conv, relu):
        global locked, BackwardNet, ForwardNet
        self.sequential = nn_Sequential(conv, relu)
        self.conv = conv
        self.relu = relu
        self.name = conv.name.split("_")[0]+"_"+self.conv.name.split("_")[1]+"_"+'BRBackConv2ReLU'

    def backward(self, output_grad):
        output = self.sequential(output_grad)
        BackwardNet.append(
            op_inst(infer_type=False, ty='BRBackConv2ReLU',name=self.name, in_tensor=[output_grad],
                    out_tensor=[alloca_inst(name=self.name+'_output', tensor=output.shape)],
                    params={'conv': (self.conv.json()),
                            'relu': (self.relu.json())}))
        return output



