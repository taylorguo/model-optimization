class op_inst():
    def __init__(self, ty,  in_tensor, out_tensor, name=None, tensor=None, params=None):
        self.ty = ty
        self.name = name
        self.in_tensor = in_tensor
        self.out_tensor = out_tensor

        if tensor == None:
            self.shape = None
        else:
            self.shape = self.list_json(tensor)

        self.params = params
        self.tensor = tensor

    def list_json(self, tensor):
        result = []
        for i in tensor:
            if type(i) == type([1]):
                result.append(self.list_json(i))
            elif str(type(i))[-6:-2] == 'dict':
                result.append(i)
            else:
                result.append(i.json())
        return result

    def json(self):
        #return {'type': self.ty, 'name': self.name, 'in_tensor': self.in_tensor, 'out_tensor': self.out_tensor}
        if self.name == None:
            data = {'type': self.ty, 'name': self.name, 'in_tensor': self.in_tensor.shape, 'out_tensor': self.out_tensor,
                    'tensor': self.shape, 'params': self.params}
        else:
            data = {'type': self.ty, 'in_tensor': self.in_tensor.shape, 'out_tensor': self.out_tensor,
                    'tensor': self.shape, 'params': self.params}
        return data

    def __str__(self):
        if self.ty=="BRConv2" or self.ty=="BRConv2BatchNormReLU" or self.ty=='BRConv2BatchNorm':
            N, IC, IH, IW = self.in_tensor.shape
            (N, OC, OH, OW) = self.out_tensor.shape
            return(self.ty+ "("+ self.name+ "): ic="+str(IC)+" ,oc="+str(OC)+", params="+ str(self.params))
            #return(self.ty+ ","+ self.name+ str(self.in_tensor[0].shape)+ \
                    #str(self.in_tensor[1].shape) + \
                    #"->" + str(self.out_tensor[0].shape))
        elif self.ty=='BRAveragePool' or self.ty=='BRMaxPool':
            return(self.ty+ ","+ self.name+ str(self.in_tensor.shape)+ \
                    "->" + str(self.out_tensor.shape))
        elif type(self.out_tensor) == type([1]):
            return (self.ty + "," + self.name + str(self.in_tensor.shape)) + "->" + \
                   "["+str(self.out_tensor[0].shape)+","+str(self.out_tensor[1].shape)+"]"
        else:
            return(self.ty+ ","+ self.name+ str(self.in_tensor.shape)) + "->" + \
                    str(self.out_tensor.shape)


class alloca_inst():
    def __init__(self, shape, tensor=None, dtype='bf16',\
            scope="hbm", uma_mode="uma", name="None", layout= None, overwrite=None, attr=[]):
        self.name= name
        self.dtype = dtype
        # Matrix, Matrix3D, MatrixWeight, ConvWeight, Activation
        self.layout = layout
        self.uma_mode = uma_mode
        self.scope = scope
        self.addr = None
        self.attr = attr
        self.slice_coord = []
        self.slice_length = []
        self.tensor = tensor
        self.shape = shape
        self.alloc = 'alloc'
        #if type(tensor) != type(torch.shape([0])) and str(type(tensor))[-11:-2]!='Parameter':
        #    print(type(tensor))
        #    print(self.json())

    def json(self):
        data = {'name': self.name, 'shape': self.shape, 'scope': self.scope,
                    'uma_mode': self.uma_mode, 'dtype': self.dtype, 'attr': self.attr, 'layout': self.layout}
        return {self.alloc: data}

    def __str__(self):
        return "alloca: " + self.name + ' shape=' + str(self.shape) + ' ' + self.scope + ' ' + self.uma_mode


class dealloca_inst:
    def __init__(self, alloca_inst):
        self.alloc = 'dealloc'
        self.t = alloca_inst
    def __str__(self):
        return "dealloca " + self.t.name
    def json(self):
        return {self.alloc: self.t.json()[self.t.alloc]}
