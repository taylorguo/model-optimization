#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import os
import code_generator.br_code_gen_interface as bgi
import code_generator.share.br_defined_print as bdp


def run_stm():
    vector_s2_stm_reduce = [
        ('outer_oc', 4, 1, 256, {'start': 0}),
        ('sample', 1, 1, 1, {'start': 0,'epilog': 4}),
        ('col', 3, 1, 8, {
            'start': 0, 'tlr_bar_csm': [6,7], 'tlr_bar_pass': [8,9], 'tlr_pingpong': [0, 64]}),
        ('row', 7, 1, 4, {'start': 0}),
        ('inner_oc', 4, 1, 32, {'start': 0})]

    operator0 = bgi.br_fwd_stm(
        warpid=0, usharpid=0,
        loopconfig=vector_s2_stm_reduce,
        layerid=0, layernum=1)
    operator0.generate()
    print("[===stm WSR====] ", operator0.get_required_wsr())
    operator0.generate()
    print("[===stm WSR====] ", operator0.get_required_wsr())
    operator0.generate()
    print("[===stm WSR====] ", operator0.get_required_wsr())
    operator0.generate()
    print("[===stm WSR====] ", operator0.get_required_wsr())
    operator0.generate()
    print("[===stm WSR====] ", operator0.get_required_wsr())
    operator0.generate()
    print("[===stm WSR====] ", operator0.get_required_wsr())
    operator0.generate()
    print("[===stm WSR====] ", operator0.get_required_wsr())
    operator0.generate()
    print("[===stm WSR====] ", operator0.get_required_wsr())
    operator0.generate()
    print("[===stm WSR====] ", operator0.get_required_wsr())
    operator0.generate()
    print("[===stm WSR====] ", operator0.get_required_wsr())
    operator0.flush()

def run_maxpooling():
    maxpooling0 = bgi.br_fwd_maxpooling(
        warpid=0, 
        vgpr_start=156, 
        vgpr_end=256,
        usharp_0=[0, (1, 32, 16, 32)],
        usharp_1=[1, (1, 32, 16, 32)],
        options=[1, 1, 0, 0, 0, 0, 0,
                1], # mate mode is max
        layerid=0, layernum=1,
        withrelu=False,
        force_ackgmb=True)

    maxpooling0.generate()
    maxpooling0.generate()
    maxpooling0.flush()

def run_reduce():
    loopconfig = [('outer_oc', 1, 1, 32, {'wset': [48], 'sset': [32]}), 
                    ('sample', 1, 1, 1, {'start': 0, 'bar_sync': [4], 'bar_set': [2], 'grb_pingpong': [0]}), 
                    ('col', 1, 1, 8, {'tlr_bar_csm': [6, 7], 'tlr_bar_pass': [8, 9]}), 
                    ('row', 1, 1, 8), ('inner_oc', 1, 1, 32), ('ich', 1, 1, 8)]
    operator = bgi.br_fwd_reduce(0, 0, channelnum=32, loopconfig=loopconfig, layerid=None, sync_layer=False,
        layernum=1, afterdwc=None, spcnum=20, force_ackgmb=False)
    operator.generate()
    operator.flush()

def run_bn():
    vector_bn = bgi.br_fwd_bn(
        warpid=3, vgpr_start=156, vgpr_end=256,
        usharp_0=[1, (16, 64, 56, 56)],
        usharp_1=[2, (1, 1, 1, 64)],
        usharp_2=[3, (16, 64, 56, 56)],
        usharp_3=[4, (16, 64, 56, 56)],
        options=[0], layerid=0, layernum=1, withrelu=True)

    vector_bn.generate()
    print("[===BN WSR====] ", vector_bn.get_required_wsr())
    vector_bn.generate()
    print("[===BN WSR====] ", vector_bn.get_required_wsr())
    vector_bn.generate()
    print("[===BN WSR====] ", vector_bn.get_required_wsr())
    vector_bn.generate()
    print("[===BN WSR====] ", vector_bn.get_required_wsr())
    vector_bn.generate()
    print("[===BN WSR====] ", vector_bn.get_required_wsr())
    vector_bn.generate()
    print("[===BN WSR====] ", vector_bn.get_required_wsr())
    vector_bn.generate()
    print("[===BN WSR====] ", vector_bn.get_required_wsr())
    vector_bn.flush()

if __name__=="__main__":
    new_file = "kernel_test.s"
    bdp.set_output_file(new_file)
    #run_maxpooling()
    # run_bn()
    run_reduce()
    #run_stm()
