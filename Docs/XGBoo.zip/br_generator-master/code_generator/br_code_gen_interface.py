#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import code_generator.share.br_const_defs as bcd
import code_generator.tcore.br_tcore_fwd_conv as btfc
import code_generator.tcore.br_tcore_bpw_mma as btbm
import code_generator.tcore.br_tcore_bpa_conv as btbc
import code_generator.tcore.br_tcore_mma as btm
import code_generator.vector.br_vector_bn as bvb
import code_generator.vector.br_vector_stm as bvs
import code_generator.vector.br_vector_reduce as bvr
import code_generator.vector.br_vector_maxpooling as bvm
import code_generator.vector.br_vector_dwc as bvd
import code_generator.vector.br_vector_add_relu as bvar
import code_generator.share.br_resource_manager as brm
import code_generator.share.br_state_manager as state_man


def br_get_boundary_coordinate_table(block_size_in_one_direction):
    return bcd.get_boundary_coordinate_table(
        block_size_in_one_direction)


def br_get_csr_table():
    return brm.get_csr_table()


def br_fwd_conv(
        tensor_b, tensor_a, dt, stride=1, dilation=1,
        padx=0, pady=0, usharps=None, loop_configs=[],
        pingpong_a=[0], pingpong_b=[0], red_mode="roff",
        write_through=None, csrs=None, hwshape=None,
        gmb_mapping=False, ic_partition=False, spc_num=bcd.BR_SPC_NUMBER,
        sync_layer=False, force_ackgmb=False, extension=False,
        unroll_disable=False, tlr_flip_interval=0, micro_batch_mode=False):

    return btfc.br_fwd_conv(
        tensor_b, tensor_a, dt, stride, dilation, padx, pady,
        usharps, pingpong_a=pingpong_a, pingpong_b=pingpong_b,
        loop_configs=loop_configs, csrs=csrs, hwshape=hwshape,
        red_mode=red_mode, write_through=write_through,
        gmb_mapping=gmb_mapping, ic_partition=ic_partition, spc_num=spc_num,
        sync_layer=False, force_ackgmb=force_ackgmb, extension=extension,
        unroll_disable=unroll_disable, micro_batch_mode=micro_batch_mode)

def br_fwd_bn(
        warpid, vgpr_start, vgpr_end,
        usharp_0, usharp_1, usharp_2, 
        usharp_3=None, options=None, 
        withrelu=False, layerid=None,
        withadder=False, layernum=None, 
        force_ackgmb=False, sync_layer=False, 
        loop_config=None, syncid_with_maxpool=None,
        micro_batch_mode=False):
    
    bn_op = bvb.bn(
        warpid=warpid, vgpr_start=vgpr_start, vgpr_end=vgpr_end,
        usharp_0=usharp_0, usharp_1=usharp_1, usharp_2=usharp_2,
        usharp_3=usharp_3, options=options, withrelu=withrelu, 
        layerid=layerid, layernum=layernum, force_ackgmb=force_ackgmb,
        sync_layer=sync_layer, loop_config=loop_config, 
        syncid_with_maxpool=syncid_with_maxpool, 
        micro_batch_mode=micro_batch_mode)

    # bn_op.generate(True)

    return bn_op


def br_fwd_stm(
        warpid, usharpid, loopconfig, layerid=None, layernum=None, 
        merge_reduce=False, with_icpartition=False, wred_usharpid=None, 
        wred_channelnum=None, force_ackgmb=False, sync_layer=False,
        with_extension=False, enable_8tlr_burst=False, micro_batch_mode=False):
    
    stm_op = bvs.stm(
        warpid=warpid, usharpid=usharpid, 
        loopconfig=loopconfig, layerid=layerid, 
        layernum=layernum, merge_reduce=merge_reduce, 
        wred_usharpid=wred_usharpid, wred_channelnum=wred_channelnum,
        force_ackgmb=force_ackgmb, sync_layer=sync_layer,
        with_icpartition=with_icpartition, with_extension=with_extension,
        enable_8tlr_burst=enable_8tlr_burst, micro_batch_mode=micro_batch_mode)

    # stm_op.generate(True)

    return stm_op


def br_fwd_reduce(
        warpid, usharpid, channelnum, loopconfig, layerid=None, sync_layer=False,
        layernum=None, afterdwc=None, spcnum=20, force_ackgmb=False, micro_batch_mode=False):

    reduce_op = bvr.reduce(
        warpid=warpid, usharpid=usharpid, channelnum=channelnum, 
        loopconfig=loopconfig, layerid=layerid, layernum=layernum, 
        afterdwc=afterdwc, spcnum=spcnum, force_ackgmb=force_ackgmb,
        sync_layer=sync_layer, micro_batch_mode=micro_batch_mode)

    # reduce_op.generate(True)

    return reduce_op


def br_fwd_maxpooling(
        warpid, vgpr_start, vgpr_end,
        usharp_0, usharp_1, options, usharp_2=None,
        usharp_3=None, layerid=None, layernum=None,
        withrelu=False, force_ackgmb=False, sync_layer=False,
        syncid_with_bn=None):

    maxpool_op = bvm.maxpooling(
        warpid=warpid, vgpr_start=vgpr_start, vgpr_end=vgpr_end,
        usharp_0=usharp_0, usharp_1=usharp_1, usharp_2=usharp_2, 
        usharp_3=usharp_3, options=options, layerid=layerid, 
        layernum=layernum, withrelu=withrelu, force_ackgmb=force_ackgmb,
        sync_layer=sync_layer, syncid_with_bn=syncid_with_bn)

    # maxpool_op.generate(True)

    return maxpool_op


def br_fwd_dwc(
        warpid, vgpr_start, vgpr_end,
        usharp_0, usharp_1, options, usharp_2=None,
        layerid=None, layernum=None,
        force_ackgmb=False, sync_layer=False,
        idtype="bf16", wdtype="bf16", odtype="bf16"):

    dwc_op = bvd.dwc(
        warpid=warpid, vgpr_start=vgpr_start, vgpr_end=vgpr_end,
        usharp_0=usharp_0, usharp_1=usharp_1, usharp_2=usharp_2, 
        options=options, layerid=layerid, layernum=layernum, 
        force_ackgmb=force_ackgmb, sync_layer=sync_layer,
        idtype=idtype, wdtype=wdtype, odtype=odtype)

    return dwc_op

def br_bpa_conv(
        tensor_b, tensor_a, dt, stride=1, dilation=1,
        padx=0, pady=0, usharps=None, loop_configs=[],
        pingpong_a=[0], red_mode="roff", write_through=False,
        csrs=None, hwshape=None):

    return btbc.br_bpa_conv(
        tensor_b, tensor_a, dt, stride, dilation, padx, pady,
        usharps, pingpong_a=pingpong_a, red_mode=red_mode,
        write_through=write_through, csrs=csrs, hwshape=hwshape,
        loop_configs=loop_configs)


def br_bpw_mma(
        tensor_b, tensor_w, tensor_a, dt, stride=1, dilation=1,
        padx=0, pady=0, usharps=None, loop_configs=[],
        pingpong_a=[0], pingpong_b=[0], red_mode="roff",
        write_through=None, csrs=None, hwshape=None,
        gmb_mapping=False, ic_partition=False, spc_num=bcd.BR_SPC_NUMBER,
        sync_layer=False, force_ackgmb=False, extension=False,
        unroll_disable=False, tlr_flip_interval=0, micro_batch_mode=False):

    return btbm.br_bpw_mma(
        tensor_b=tensor_b, tensor_w=tensor_w,
        tensor_a=tensor_a, dt=dt, stride=1, dilation=1,
        padx=padx, pady=pady, usharps=usharps, loop_configs=loop_configs,
        pingpong_a=pingpong_a, pingpong_b=pingpong_b, red_mode=red_mode,
        write_through=write_through, csrs=csrs, hwshape=hwshape,
        gmb_mapping=gmb_mapping, ic_partition=ic_partition, spc_num=spc_num,
        sync_layer=sync_layer, force_ackgmb=force_ackgmb, extension=extension,
        unroll_disable=unroll_disable, tlr_flip_interval=tlr_flip_interval,
        micro_batch_mode=micro_batch_mode)


def br_mma(
        tensor_a, tensor_b, dt,
        usharps=None, loop_configs=[], pingpong_a=[0], pingpong_b=[0],
        red_mode="roff", write_through=None, unroll_disable=False):

    return btm.br_mma(
        mata_shape=tensor_a, matb_shape=tensor_b, dt=dt,
        usharps=usharps, pingpong_a=pingpong_a, pingpong_b=pingpong_b,
        red_mode=red_mode, write_through=write_through,
        loop_configs=loop_configs, unroll_disable=unroll_disable)


def br_fwd_add_relu(warpid, vgpr_start, vgpr_end, usharp_0,
                 usharp_1, usharp_2, usharp_3=None, relu_on=True,
                 options=None, layer_id=None, layer_num=None,
                 force_ackgmb=False, sync_layer=False, loop_config=None):

    return bvar.add_relu(warpid=warpid, vgpr_start=vgpr_start, vgpr_end=vgpr_end, 
                        usharp_0=usharp_0, usharp_1=usharp_1, usharp_2=usharp_2, 
                        usharp_3=usharp_3, relu_on=relu_on,
                        options=options, layer_id=layer_id, layer_num=layer_num,
                        force_ackgmb=force_ackgmb, sync_layer=sync_layer,
                        loop_config=loop_config)


def reset_kernel():
    state_man.reset_kernel()