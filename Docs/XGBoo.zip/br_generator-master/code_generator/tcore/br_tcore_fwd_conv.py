#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import math

import code_generator.share.br_const_defs as tcd
import code_generator.tcore.br_tcore_conv as tcc
import code_generator.vector.br_vector_stm as bvs
import code_generator.tcore.br_tcore_utils as btu
import code_generator.share.br_loop_config as blc
import code_generator.vector.br_vector_reduce as bvr
import code_generator.share.br_defined_print as inst_buf
import code_generator.backend.PassManager as passmang

def br_fwd_conv(
    tensor_b,
    tensor_a,
    dt,
    stride=1,
    dilation=1,
    padx=0,
    pady=0,
    usharps=None,
    loop_configs=[],
    pingpong_a=[0],
    pingpong_b=[0],
    red_mode="roff",
    write_through=None,
    csrs={},
    hwshape=None,
    reduction=0,
    gmb_mapping=False,
    ic_partition=False,
    spc_num=tcd.BR_SPC_NUMBER,
    sync_layer=False,
    force_ackgmb=False,
    extension=False,
    unroll_disable=False,
    micro_batch_mode=False
):

    operator = tcore_fwd_conv(
        tensor_b,
        tensor_a,
        dt,
        stride,
        dilation,
        padx,
        pady,
        usharps,
        pingpong_a=pingpong_a,
        pingpong_b=pingpong_b,
        red_mode=red_mode,
        write_through=write_through,
        csrs=csrs,
        hwshape=hwshape,
        reduction=reduction,
        gmb_mapping=gmb_mapping,
        ic_partition=ic_partition,
        spc_num=spc_num,
        sync_layer=False,
        force_ackgmb=force_ackgmb,
        extension=extension,
        loop_configs=loop_configs,
        unroll_disable=unroll_disable
    )
    # operator.generate(loop_configs, dry_run=True)

    return operator


class tcore_fwd_conv(tcc.tcore_conv):
    def __init__(
        self,
        tensor_b,
        tensor_a,
        dt,
        stride=1,
        dilation=1,
        padx=0,
        pady=0,
        usharps=None,
        pingpong_a=[0],
        pingpong_b=[0],
        red_mode="roff",
        write_through=None,
        csrs={},
        hwshape=None,
        reduction=0,
        gmb_mapping=False,
        ic_partition=False,
        spc_num=tcd.BR_SPC_NUMBER,
        sync_layer=False,
        force_ackgmb=False,
        extension=False,
        loop_configs=None,
        unroll_disable=False,
        micro_batch_mode=False
    ):
        super().__init__(
            "fwd_conv",
            tensor_b,
            tensor_a,
            tensor_a,
            dt,
            stride=stride,
            dilation=dilation,
            padx=padx,
            pady=pady,
            usharps=usharps,
            pingpong_a=pingpong_a,
            pingpong_b=pingpong_b,
            red_mode=red_mode,
            write_through=write_through,
            csrs=csrs,
            gmb_mapping=gmb_mapping,
            hwshape=hwshape,
            loop_configs=loop_configs,
            unroll_disable=unroll_disable
        )
        self.sample_w = 0
        self.sample_h = 0
        self.sample_full_unroll = 0
        self.enable_sample_merge = False
        if red_mode != "roff":
            self.reduction = True
        else:
            self.reduction = False
        self.extension = extension
        if hwshape is not None:
            self.enable_sample_merge = True
        # Currently, gmb mapping is only feature map
        self.gmb_mapping = gmb_mapping

        self.ic_partition = ic_partition
        self.spc_num = spc_num
        self.sync_layer = sync_layer
        self.force_ackgmb = force_ackgmb

        self.direction = "fwd"

        self.bwdtype = None
        self.halftlr = None
        self.Pass_Manager = passmang.PM()

        self.aliged_w_block_num = int(
            (
                (self.input_w + tcd.ACTIVATION_BLOCK_W_SIZE - 1)
                / tcd.ACTIVATION_BLOCK_W_SIZE
            )
        )
        self.aligned_input_w = self.aliged_w_block_num * tcd.ACTIVATION_BLOCK_W_SIZE
        self.aliged_h_block_num = int(
            (
                (self.input_h + tcd.ACTIVATION_BLOCK_H_SIZE - 1)
                / tcd.ACTIVATION_BLOCK_H_SIZE
            )
        )
        self.aligned_input_h = self.aliged_h_block_num * tcd.ACTIVATION_BLOCK_H_SIZE

        self.aligned_ich_block_num = int(
            ((self.ich_num + self.bst_ich_ld_num - 1) / self.bst_ich_ld_num)
        )
        self.aligned_ich_num = self.aligned_ich_block_num * self.bst_ich_ld_num
        self.aligned_och_block_num = int(
            ((tensor_b[0] + tcd.WEIGHT_OCH_LD_SIZE - 1) / tcd.WEIGHT_OCH_LD_SIZE)
        )
        self.aligned_och_num = self.aligned_och_block_num * tcd.WEIGHT_OCH_LD_SIZE

        self.required_buffer_a_entries_per_ld = int(
            self.bst_ich_ld_num / tcd.BUFFER_A_ENTRY_ICH_NUM
        )
        self.required_buffer_a_entries_per_ld *= self.filter_h
        self.required_buffer_a_entries_per_ld *= self.filter_w

        self.required_buffer_a_entries_per_ld *= int(
            tcd.WEIGHT_OCH_LD_SIZE/tcd.BUFFER_A_ENTRY_OCH_NUM)

        self.required_buffer_b_entries_per_ld = int(
            self.bst_ich_ld_num / tcd.BUFFER_B_ENTRY_ICH_NUM
        )
        self.required_buffer_b_entries_per_ld *= int(
            tcd.ACTIVATION_BLOCK_W_SIZE / tcd.BUFFER_B_ENTRY_PIXEL_WIDTH
        )
        self.required_buffer_b_entries_per_ld *= int(
            tcd.ACTIVATION_BLOCK_H_SIZE / tcd.BUFFER_B_ENTRY_PIXEL_HEIGHT
        )

        if self.required_buffer_b_entries_per_ld <= 16 and self.filter_h > 1:
            self.required_buffer_b_entries_per_ld *= 2

        self.amount_buffer_a_entries_required = int(
            self.aligned_ich_num / self.bst_ich_ld_num
        )
        self.amount_buffer_a_entries_required *= int(
            self.aligned_och_num / self.och_ld_ch_num
        )
        self.amount_buffer_a_entries_required *= self.required_buffer_a_entries_per_ld

        self.amount_buffer_b_entries_required = int(
            self.aligned_input_w / tcd.ACTIVATION_BLOCK_W_SIZE
        )
        self.amount_buffer_b_entries_required *= int(
            self.aligned_input_h / tcd.ACTIVATION_BLOCK_H_SIZE
        )
        self.amount_buffer_b_entries_required *= int(
            self.aligned_ich_num / self.bst_ich_ld_num
        )
        self.amount_buffer_b_entries_required *= self.sample_num
        self.amount_buffer_b_entries_required *= self.required_buffer_b_entries_per_ld

        self.buffer_a_oc_loop_times = math.ceil(self.aligned_och_num / self.och_ld_ch_num)
        self.buffer_ich_loop_times = math.ceil(self.aligned_ich_num / self.bst_ich_ld_num)

        self.blc = blc.br_loop_config()

        self._initialize_instructions()

        self.check_loop_configs()

        self.buf_a_total_iterations = (
            self.get_total_iteration_times(self.loop_configs[0]))
        self.buf_b_total_iterations = (
            self.get_total_iteration_times(self.loop_configs[1]))

        self.accumulation_times = self.get_accu_times_for_filter_w_above_one(
            self.bst_ich_ld_num)

    def _generate_buf_a_ld(self, loopconfig=None):
        if loopconfig is None:
            och_inc = self.och_ld_ch_num
            ich_iter = self.buffer_ich_loop_times
            ich_inc = self.bst_ich_ld_num

            och = self.aligned_och_num

            och_inner_grannular = min(
                math.ceil(och / och_inc), tcd.OCH_INNER_LOOP_GRANNULAR
            )
            och_outer_inc = och_inner_grannular * och_inc
            och_outer_iter = int(self.aligned_och_num / och_outer_inc)

            loopconfig = [
                # name,   iterations, unrolls, incremental unit
                (
                    "outer_oc",
                    och_outer_iter,
                    1,
                    och_outer_inc,
                    {"wset": [48], "sset": [32]},
                ),
                # ("outer_ic", och_iter, 1, och_inc),
                # ("bufa_conv_sync", 1, 1, 1, {"wset": [48], "sset": [32]}),
                ("oc", och_inner_grannular, 1, och_inc),
                ("ich", ich_iter, ich_iter, ich_inc),
            ]
        super()._generate_buf_a_ld(loopconfig)

    def _generate_buf_b_ld(self, loopconfig=None):
        h_iter = self.aliged_h_block_num
        w_iter = self.aliged_w_block_num

        ich_iter = self.buffer_ich_loop_times
        ich_inc = self.bst_ich_ld_num

        sample_iter = self.sample_num
        sample_inc = 1
        ich_inc = self.bst_ich_ld_num
        col_inc = tcd.ACTIVATION_BLOCK_W_SIZE
        row_inc = tcd.ACTIVATION_BLOCK_H_SIZE

        # print("in _generate_buf_b_ld loopconfig is ", loopconfig)
        if loopconfig is None:
            if self.filter_w == 1:
                loopconfig = [
                    #   name,   iterations, unrolls, incremental unit
                    # ("outer_oc", och_outer_iter, 1, och_outer_inc),
                    # ("outer_ic", och_outer_iter, 1, och_outer_inc),
                    # ("outer_oc", och_outer_iter, 1, och_outer_inc),
                    ("sample", sample_iter, 1, sample_inc),
                    ("col", w_iter, 1, col_inc),
                    ("row", h_iter, 1, row_inc),
                    # ("inner_oc", och_inner_grannular, 1, och_inc),
                    ("ich", ich_iter, ich_iter, ich_inc),
                ]  # unfold by default

            else:
                loopconfig = [
                    #   name,   iterations, unrolls, incremental unit
                    # ("outer_oc", och_outer_iter, 1, och_outer_inc),
                    # ("outer_ic", och_outer_iter, 1, och_outer_inc),
                    # ("outer_oc", och_outer_iter, 1, och_outer_inc),
                    ("sample", sample_iter, 1, sample_inc),
                    ("row", h_iter, 1, row_inc),
                    ("col", w_iter, 1, col_inc),
                    # ("inner_oc", och_inner_grannular, 1, och_inc),
                    ("ich", ich_iter, ich_iter, ich_inc),
                ]  # unfold by default

        if (
            self.tensor_b[3] % tcd.ACTIVATION_BLOCK_W_SIZE != 0
            and self.enable_sample_merge
        ):
            bound = "default"
            # hwshape will do sample merge
            if self.hwshape is None:
                loopconfig, w, h = btu.sample_merge(
                    loopconfig,
                    self.stride,
                    self.filter_w,
                    self.input_w,
                    self.input_h,
                    inst=bound,
                )

                if w != 0 and h != 0:
                    self.sample_w = w
                    self.sample_h = h
                    if bound == "fullunroll":
                        self.sample_full_unroll = 2
                    else:
                        self.sample_full_unroll = 1
            else:
                if bound == "fullunroll":
                    self.sample_full_unroll = 2
                else:
                    self.sample_full_unroll = 1

        if self.stride == 1 and self.sample_full_unroll != 2:
            if self.input_w > 8:
                loopconfig = btu.stride2_bufb_loopconfig(
                    loopconfig, self.filter_w, w_iter
                )
        super()._generate_buf_b_ld(loopconfig)

    def _genrate_conv(self, loopconfig=None):
        h_iter = self.aliged_h_block_num
        w_iter = self.aliged_w_block_num

        och_inc = self.och_ld_ch_num
        ich_iter = self.buffer_ich_loop_times
        ich_inc = self.bst_ich_ld_num

        sample_iter = self.sample_num
        sample_inc = 1
        och = self.aligned_och_num
        och_inc = self.och_ld_ch_num
        ich_inc = self.bst_ich_ld_num
        col_inc = tcd.ACTIVATION_BLOCK_W_SIZE
        row_inc = tcd.ACTIVATION_BLOCK_H_SIZE

        och_inner_grannular = min(math.ceil(och / och_inc), tcd.OCH_INNER_LOOP_GRANNULAR)
        och_outer_inc = och_inner_grannular * och_inc
        och_outer_iter = int(self.aligned_och_num / och_outer_inc)

        # print("in _genrate_conv loopconfig is ", loopconfig)

        if loopconfig is None:
            if self.filter_w == 1:
                if not self.reduction:
                    loopconfig = [
                        #   name,   iterations, unrolls, incremental unit
                        # ("outer_oc", och_outer_iter, 1, och_outer_inc,
                        # {"wset": [32], "sset": [48]}),
                        # ("outer_ic", och_outer_iter, 1, och_outer_inc),
                        # ("conv_bufa_sync", 1, 1, 1,
                        # {"wset": [32], "sset": [48]}),
                        (
                            "outer_oc",
                            och_outer_iter,
                            1,
                            och_outer_inc,
                            {
                                "wset": [32],
                                "sset": [48],
                                "grb_pingpong": [0],
                                "bar": "sync",
                            },
                        ),
                        ("sample", sample_iter, 1, sample_inc),
                        ("col", w_iter, 1, col_inc),
                        ("row", h_iter, 1, row_inc),
                        ("inner_oc", och_inner_grannular, 1, och_inc),
                        ("ich", ich_iter, ich_iter, ich_inc),
                    ]  # unfold by default
                else:
                    loopconfig = [
                        #   name,   iterations, unrolls, incremental unit
                        # ("outer_oc", och_outer_iter, 1, och_outer_inc,
                        # {"wset": [32], "sset": [48]}),
                        # ("outer_ic", och_outer_iter, 1, och_outer_inc),
                        # ("conv_bufa_sync", 1, 1, 1,
                        # {"wset": [32], "sset": [48]}),
                        (
                            "outer_oc",
                            och_outer_iter,
                            1,
                            och_outer_inc,
                            {
                                "wset": [32],
                                "sset": [48],
                                "grb_pingpong": [0, 8],
                                "bar_set": [
                                    tcd.GRB_PINGPONG_CONV_TO_VECTOR_BAR_ID_1,
                                    tcd.GRB_PINGPONG_CONV_TO_VECTOR_BAR_ID_2,
                                ],
                                "bar_sync": [
                                    tcd.GRB_PINGPONG_VECTOR_TO_CONV_BAR_ID_1,
                                    tcd.GRB_PINGPONG_VECTOR_TO_CONV_BAR_ID_2,
                                ],
                            },
                        ),
                        ("sample", sample_iter, 1, sample_inc),
                        ("col", w_iter, 1, col_inc),
                        ("row", h_iter, 1, row_inc),
                        ("inner_oc", och_inner_grannular, 1, och_inc),
                        ("ich", ich_iter, ich_iter, ich_inc),
                    ]  # unfold by default
            else:
                if not self.reduction:
                    loopconfig = [
                        #   name,   iterations, unrolls, incremental unit
                        # ("outer_oc", och_outer_iter, 1, och_outer_inc,
                        # {"wset": [32, 33], "sset": [48, 49]}),
                        # ("outer_ic", och_outer_iter, 1, och_outer_inc),
                        # ("conv_bufa_sync", 1, 1, 1,
                        #  {"wset": [32], "sset": [48]}),
                        (
                            "outer_oc",
                            och_outer_iter,
                            1,
                            och_outer_inc,
                            {
                                "wset": [32],
                                "sset": [48],
                                "grb_pingpong": [0, 8],
                                "bar": "sync",
                            },
                        ),
                        ("sample", sample_iter, 1, sample_inc),
                        ("row", h_iter, 1, row_inc),
                        ("col", w_iter, 1, col_inc),
                        ("inner_oc", och_inner_grannular, 1, och_inc),
                        ("ich", ich_iter, ich_iter, ich_inc),
                    ]  # unfold by default
                else:
                    loopconfig = [
                        #   name,   iterations, unrolls, incremental unit
                        # ("outer_oc", och_outer_iter, 1, och_outer_inc,
                        # {"wset": [32, 33], "sset": [48, 49]}),
                        # ("outer_ic", och_outer_iter, 1, och_outer_inc),
                        # ("conv_bufa_sync", 1, 1, 1,
                        #  {"wset": [32], "sset": [48]}),
                        (
                            "outer_oc",
                            och_outer_iter,
                            1,
                            och_outer_inc,
                            {
                                "wset": [32],
                                "sset": [48],
                                "grb_pingpong": [0, 8],
                                "bar_set": [
                                    tcd.GRB_PINGPONG_CONV_TO_VECTOR_BAR_ID_1,
                                    tcd.GRB_PINGPONG_CONV_TO_VECTOR_BAR_ID_2,
                                ],
                                "bar_sync": [
                                    tcd.GRB_PINGPONG_VECTOR_TO_CONV_BAR_ID_1,
                                    tcd.GRB_PINGPONG_VECTOR_TO_CONV_BAR_ID_2,
                                ],
                            },
                        ),
                        ("sample", sample_iter, 1, sample_inc),
                        ("row", h_iter, 1, row_inc),
                        ("col", w_iter, 1, col_inc),
                        ("inner_oc", och_inner_grannular, 1, och_inc),
                        ("ich", ich_iter, ich_iter, ich_inc),
                    ]  # unfold by default

        if (
            self.tensor_b[3] % tcd.ACTIVATION_BLOCK_W_SIZE != 0
            and self.enable_sample_merge
        ):
            bound = "default"
            # hwshape will do sample merge
            if self.hwshape is None:
                loopconfig, w, h = btu.sample_merge(
                    loopconfig,
                    self.stride,
                    self.filter_w,
                    self.input_w,
                    self.input_h,
                    inst=bound,
                )

                if w != 0 and h != 0:
                    self.sample_w = w
                    self.sample_h = h
                    if bound == "fullunroll":
                        self.sample_full_unroll = 2
                    else:
                        self.sample_full_unroll = 1
            else:
                if bound == "fullunroll":
                    self.sample_full_unroll = 2
                else:
                    self.sample_full_unroll = 1

        # process stride == 2 case
        if self.stride == 1 and self.sample_full_unroll != 2:
            if self.write_usharp:
                loopconfig = btu.gen_loopconfig(
                    loopconfig, self.stride, self.filter_w,
                    self.accumulation_times)
            if self.input_w > 8:
                loopconfig = btu.stride2_conv_loopconfig(
                    loopconfig, self.filter_w, w_iter
                )
        # loopconfig=btu.oc_unroll_all(loopconfig)
        super()._genrate_conv(loopconfig)

    def generate(self, loop_configs=[], dry_run=False):
        """:param och_unroll: Specify how to unroll the iteration. if it is 1
         or None, no unroll will be done. this value must the power of 2.
         for example: 1, 2, 4, 8, 16
        :param ich_unroll: Same as above
        No return value for this function call.
        """
        if len(loop_configs) == 0 and self.loop_configs is not None:
            loop_configs = self.loop_configs
        elif len(loop_configs) > 0:
            # print("loop_configs is before ", loop_configs)
            self._calculate_inner_loop_iterations_and_steps(loop_configs)
        super()._set_dry_run(dry_run)

        size_of_configs = len(loop_configs)
        # print("size of configs is ", size_of_configs)

        if size_of_configs > 0:
            self._generate_buf_a_ld(loopconfig=loop_configs[0])

        if size_of_configs > 1:
            self._generate_buf_b_ld(loop_configs[1])

        if size_of_configs > 2:
            self._genrate_conv(loop_configs[2])

        if size_of_configs > 3:
            loop_config = loop_configs[3]
        else:
            loop_config = None

        if self.stride == 1:
            w_iter = self.aliged_w_block_num
            bd = False
            if self.input_w % 8 != 0:
                bd = True
            if not tcd.ENABLE_ROW_ACCUMULATION:
                loop_config = btu.stride2_vector_loopconfig(
                    loop_config, self.filter_w, w_iter, boundary=bd
                )
            red_usharpid = self.usharp_reduce
            if not red_usharpid:
                red_usharpid = tcd.UT_WRED_USHARP_ID
            enable_8tlr_burst = False
            if tcd.ENABLE_ROW_ACCUMULATION:
                if self.filter_w > 1:
                    if self.accumulation_times > 1:
                        enable_8tlr_burst = True
            operator0 = bvs.stm(
                warpid=tcd.UT_CWARP_ID,
                usharpid=self.usharp_tensor_o,
                wred_channelnum=self.aligned_och_num,
                loopconfig=loop_config,
                layerid=self.layer_id,
                layernum=1,
                sync_layer=self.sync_layer,
                force_ackgmb=self.force_ackgmb,
                merge_reduce=True if self.reduction else False,
                wred_usharpid=red_usharpid,
                enable_8tlr_burst=enable_8tlr_burst,
                micro_batch_mode=self.micro_batch_mode
            )
            operator0.generate()
        elif self.stride == 0 and self.reduction:
            red_usharpid = self.usharp_reduce
            if not red_usharpid:
                red_usharpid = tcd.UT_WRED_USHARP_ID
            operator0 = bvr.reduce(
                warpid=tcd.UT_CWARP_ID,
                usharpid=red_usharpid,
                channelnum=self.aligned_och_num,
                loopconfig=loop_config,
                layerid=self.layer_id,
                layernum=1,
                spcnum=self.spc_num,
                force_ackgmb=self.force_ackgmb,
                sync_layer=self.sync_layer,
                micro_batch_mode=self.micro_batch_mode
            )
            operator0.generate()

        self.previous_operator_filter_width = self.cwm.get_previou_filter_width()
        if dry_run is False:
            self.cwm.set_filter_width(self.filter_w)

        super()._set_dry_run(False)
        enable_backend = False
        # use test_stride2_width1.py to test
        if enable_backend and not dry_run:
            self.Pass_Manager.set_pass_state("cwarp", 1)
            tcd.set_code_style(0)
            origin = inst_buf.br_printer().get_stream()
            self.Pass_Manager.apply_pass(stream=origin, file_path="./")
            #self.Pass_Manager.combine_on_off_pass(streamfile=origin)
            #passmang.PM().remove_dead_code_pass(streamfile=origin)
            #self.Pass_Manager.test_pass(streamfile=origin)

        self.reset()

    def reset(self):
        super()._reset()
        self.operator["conv"].reset()
        global layer_id
