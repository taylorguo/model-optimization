#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

from code_generator.tcore import br_tcore_loop_man_base
import code_generator.share.br_resource_manager as rm
import code_generator.share.br_const_defs as bcd
from code_generator.share.br_defined_print import br_print


class loop_man_mma(br_tcore_loop_man_base.loop_man_base):
    def __init__(
            self, indent, comment=None, instr=None,
            operator=None, loop_configs=None):
        super().__init__(
            indent, comment=comment, instr=instr,
            loop_config=loop_configs, operator=operator)

        self.loop_configs = loop_configs
        self.instr = instr
        self.comment = comment
        self.saved_buf_a_address_for_mma = None
        self.first_row_iteration = True
        self.last_row_iteration = False

        self.bpw_mma_buf_a_wsc = None
        self.bpw_mma_buf_a_ssc = None
        self.bpw_mma_buf_b_wsc = None
        self.bpw_mma_buf_b_ssc = None
        self.bpw_mma_buf_a_addr = None
        self.bpw_mma_buf_b_addr = None
        self.buf_b_entries_per_row = None

    def generate_innermost_instructions(
            self, unrolls=1,
            loop_configs=None,
            innermost_h=None,
            innermost_w=None,
            innermost_oc=None,
            innermost_sample=None,
            innermost_ic=None,
            innermost_kw=None,
            innermost_kh=None,
            innermore_kw=None,
            innermore_ic=None,
            innermore_oc=None,
            innermore_h=None,
            innermore_w=None):

        mod = ".on"
        values = {}
        x = None,
        y = None,
        z = None
        if self.operator.name != "bpw_mma":
            for i in range(unrolls):
                if i == 0 and i == unrolls-1:  # first and last instructions
                    if self.instr == "buf_a_ld":
                        mod += ".incx0.incy0.b0nil.wnil.snil.ro"
                        # values["wsc"] = self.operator.conv_to_bufa_sync_reg
                        # values["ssc"] = self.operator.bufa_to_conv_sync_reg
                        # values["gib0_addr"] = self.operator.gib0_addr.register
                        # values["gib0_step"] = (
                        #     self.operator.required_buffer_a_entries_per_ld)
                    elif self.instr == "buf_b_ld":
                        mod += ".incx0.incy0.b1inc.wset.sset.ro"
                        values["wsc"] = bcd.CONV_TO_LDCONV1_START_STATION
                        values["ssc"] = bcd.LDCONV1_TO_CONV_START_STATION
                        # values["gib1_addr"] = self.operator.gib1_addr.register
                        # values["gib1_step"] = (
                        #     self.operator.required_buffer_b_entries_per_ld)
                    elif self.instr == "mma":
                        mod += ".b0nil.b1inc.ini1.out1.wset.sset"
                        values["wsc"] = bcd.LDCONV1_TO_CONV_START_STATION
                        values["ssc"] = bcd.CONV_TO_LDCONV1_START_STATION
                elif i == 0:  # first instructions
                    if self.instr == "buf_a_ld":
                        mod += ".incx1.incy0.b0inc.wnil.snil.ro"
                    elif self.instr == "buf_b_ld":
                        mod += ".incx0.incy1.b1inc.wset.sset.ro"
                        values["wsc"] = bcd.CONV_TO_LDCONV1_START_STATION
                        values["ssc"] = bcd.LDCONV1_TO_CONV_START_STATION
                        # values["gib1_addr"] = self.operator.gib1_addr.register
                        # values["gib1_step"] = (
                        #     self.operator.required_buffer_b_entries_per_ld)
                    elif self.instr == "mma":
                        mod += ".b0inc.b1inc.ini1.out0.wset.snil"
                        values["wsc"] = bcd.LDCONV1_TO_CONV_START_STATION
                        # values["gib0_addr"] = self.operator.gib0_addr.register
                        # values["gib0_step"] = (
                        #     self.operator.required_buffer_a_entries_per_ld)
                elif i == unrolls-1:
                    if self.instr == "buf_a_ld":
                        mod += ".incx0.incy1.b0inc.wnil.snil.ro"
                    elif self.instr == "buf_b_ld":
                        mod += ".incx1.incy0.b1inc.winc.sinc.ro"
                    elif self.instr == "mma":
                        mod += ".b0nil.b1inc.ini0.out1.wnil.sset"
                        values["ssc"] = bcd.LDCONV1_TO_CONV_START_STATION
                else:
                    if self.instr == "buf_a_ld":
                        mod += ".incx1.incy0.b0inc.wnil.snil"
                    elif self.instr == "buf_b_ld":
                        mod += ".incx0.incy1.b1inc.winc.sinc"
                    elif self.instr == "mma":
                        mod += ".b0inc.b1inc.ini0.out0.winc.sinc"
                if self.instr == "mma":
                    if self.first_row_iteration and self.last_row_iteration:
                        mod += ".wset.sset"
                    elif self.first_row_iteration:
                        mod += ".wset.snil"
                    elif self.last_row_iteration:
                        mod += ".wnil.sset"
                    else:
                        mod += ".wnil.snil"
        else:
            sample_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_sample)

            oc_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_oc)
            ic_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_ic)
            ic_iterations = ic_loop_ordinal[0] - ic_loop_ordinal[1]
            oc_iterations = oc_loop_ordinal[0] - oc_loop_ordinal[1]

            h_loop_ordinal = self.get_unrolled_interation_ordinal(loop_configs[0])
            w_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_w)
            h_iterations = h_loop_ordinal[0] - h_loop_ordinal[1]
            w_iterations = w_loop_ordinal[0] - w_loop_ordinal[1]

            kh_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_kh)
            kw_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_kw)
            kh_iterations = h_loop_ordinal[0] - h_loop_ordinal[1]
            kw_iterations = w_loop_ordinal[0] - w_loop_ordinal[1]

            oc_loop_ordinal_2 = self.get_unrolled_interation_ordinal(innermost_oc)
            ic_loop_ordinal_2 = self.get_unrolled_interation_ordinal(innermore_ic)
            ic_iterations_2 = ic_loop_ordinal[0] - ic_loop_ordinal[1]
            oc_iterations_2 = oc_loop_ordinal[0] - oc_loop_ordinal[1]

            h_loop_ordinal_2 = self.get_unrolled_interation_ordinal(innermore_h)
            w_loop_ordinal_2 = self.get_unrolled_interation_ordinal(innermore_w)
            h_iterations_2 = h_loop_ordinal[0] - h_loop_ordinal[1]
            w_iterations_2 = w_loop_ordinal[0] - w_loop_ordinal[1]

            kw_loop_ordinal_2 = self.get_unrolled_interation_ordinal(innermore_kw)
            kw_iterations_2 = w_loop_ordinal[0] - w_loop_ordinal[1]

            if (ic_loop_ordinal_2[0] == 0 and kh_loop_ordinal[0] == 0 and
                oc_loop_ordinal[0] == 0 and ic_loop_ordinal[0] == 0):
                # w_loop_ordinal[0] == 0
                # if h_loop_ordinal[0] == 0:
                mod += ".b0inc.b1inc"
                buf_a_value = dict()
                if self.accu_iter_bufa % self.accu_times_bufa == 0:
                    buf_a_mod = ".off.incx0.incy0.incz0.wset.snil.b1nil"
                    buf_a_value["wsc"] = self.bpw_mma_buf_a_wsc
                    self.bpw_mma_buf_a_wsc += 1
                    self.bpw_mma_buf_a_wsc &= 0x2F
                    self.bpw_mma_buf_a_wsc |= 0x20
                    self.save_in_modifiers_to_stack((buf_a_mod, buf_a_value))
                    self.merge_in_off_modifiers(loop_configs, condition=True)
                if self.accu_iter % self.accu_times == 0:
                    mod += ".wset"
                    values["wsc"] = self.bpw_mma_buf_b_wsc
                    self.bpw_mma_buf_b_wsc += 1
                    self.bpw_mma_buf_b_wsc &= 0xF
                else:
                    mod += ".wnil"
                self.accu_iter_bufa += 1
                self.accu_iter += 1

            else:
                mod += ".wnil"
                self.accu_iter_bufa = 0
                self.accu_iter = 0
            if (ic_loop_ordinal_2[1] == -1 and kh_loop_ordinal[1] == -1 and
                    oc_loop_ordinal[1] == -1 and ic_loop_ordinal[1] == -1):
                if self.accu_iter_ssc % self.accu_times == self.accu_times-1:
                    mod += ".sset"
                    values["ssc"] = self.bpw_mma_buf_b_ssc
                    self.bpw_mma_buf_b_ssc += 1
                    self.bpw_mma_buf_b_ssc &= 0x1F
                    self.bpw_mma_buf_b_ssc |= 0x10
                else:
                    mod += ".snil"
                self.accu_iter_ssc += 1
            else:
                self.accu_iter_ssc = 0
                mod += ".snil"

            if h_loop_ordinal[0] == 0 and w_loop_ordinal[0] == 0:
                mod += ".ini1"
            else:
                mod += ".ini0"
            if h_loop_ordinal[1] == -1 and w_loop_ordinal[1] == -1:
                mod += ".out1"
            else:
                mod += ".out0"

        self.merge_in_off_modifiers(loop_configs, condition=True)

        if self.operator.name == "bpw_mma":
            values["gib0_addr"] = self.final_gib0_addr
            values["gib1_addr"] = self.final_gib1_addr
            values["x"] = x
            values["y"] = y
            # values["z"] = z

        self.operator.operator[self.instr].generate(
            indent=self.indent,
            modifier=mod, **values)

        self.final_gib0_addr = None
        self.final_gib1_addr = None

        if self.operator.name == "bpw_mma":
            if (ic_loop_ordinal_2[1] == -1 and kh_loop_ordinal[1] == -1 and
                oc_loop_ordinal[1] == -1 and ic_loop_ordinal[1] == -1):
                # w_loop_ordinal[1] == -1 and h_loop_ordinal[1] == -1
                buf_a_value = dict()
                if self.accu_iter_bufa_ssc % self.accu_times_bufa == self.accu_times_bufa-1:
                    buf_a_mod = ".off.incx0.incy0.incz0.wnil.sset.snil.b1nil"
                    buf_a_value["ssc"] = self.bpw_mma_buf_a_ssc
                    self.bpw_mma_buf_a_ssc += 1
                    self.bpw_mma_buf_a_ssc &= 0x3F
                    self.bpw_mma_buf_a_ssc |= 0x30

                    self.save_in_modifiers_to_stack((buf_a_mod, buf_a_value))
                    self.merge_in_off_modifiers(loop_configs, condition=True)
                self.accu_iter_bufa_ssc += 1
            else:
                self.accu_iter_bufa_ssc = 0



    def add_post_loop_instructions(self, loop_configs, label):
        e = loop_configs[0]
        mod = str(".off.")
        values = dict()
        # print("len(loop_configs) is ", len(loop_configs))
        if len(loop_configs) > 1:
            # if "col" in e[0]:
            #     mod += "resetx.incy0"
            # if "row" in e[0]:
            #     mod += "incx0.resety"
            pass
        if mod != ".off.":
            self.operator.operator[self.instr].generate(
                indent=self.indent, modifier=mod, transient=True, **values)

    def allocate_loop_label(self, prefix, loop_name):
        label = prefix + "_" + loop_name
        label += "_LOOP{}".format(self.operator.cwm.get_a_label())
        return label

    def set_buffer_b_address(self, loop_configs):
        e = loop_configs[0]
        if self.instr == "mma" and "row" in e[0]:
            if len(self.row_regs) == len(self.row_loop_configs):
                mod = ".off.b0nil.b1nil.wnil.snil"
                values = {}
                values["gib1_addr"] = self.gib1_addr.register
                values["gib1_step"] = (
                    self.operator.required_buffer_b_entries_per_ld)
                self.operator.operator[self.instr].generate(
                    indent=self.indent, modifier=mod, **values, transient=True)

    def increase_buffer_a_address(self, loop_configs):
        e = loop_configs[0]
        if self.instr == "mma" and "row" in e[0]:
            if len(self.row_regs) == len(self.row_loop_configs):
                self.sadd.generate(
                    self.indent,
                    dst=self.gib0_addr.register,
                    src1=self.gib0_addr.register,
                    src2=self.operator.required_buffer_a_entries_per_row,
                    comment="// Add buffer a address to next block row")

    def check_if_innermost_mma_row_loop(self, loop_configs):
        e = loop_configs[0]
        if self.instr == "mma" and "row" in e[0]:
            if len(self.row_regs) == len(self.row_loop_configs):
                return True
            if (e[1] < 2 and
                    len(self.row_regs) == len(self.row_loop_configs) - 1):
                return True
        return False

    def handle_loop_header(
            self, loop_configs, prefix, counter_reg, suffix=None,
            innermost_h=None,
            innermost_w=None,
            innermost_oc=None,
            innermost_sample=None,
            innermost_ic=None,
            innermost_kw=None,
            innermost_kh=None,
            innermore_kw=None,
            innermore_ic=None,
            innermore_oc=None,
            innermore_h=None,
            innermore_w=None):
        e = loop_configs[0]
        real_iter = e[1]

        if self.check_if_innermost_mma_row_loop(loop_configs):
            self.first_row_iteration = True
            if real_iter == 1:
                self.last_row_iteration = True
            self.generate_actual_loops_with_unrolls(
                loop_configs[1:],
                prefix,
                innermost_h=innermost_h,
                innermost_w=innermost_w,
                innermost_oc=innermost_oc,
                innermost_sample=innermost_sample,
                innermost_ic=innermost_ic,
                innermost_kw=innermost_kw,
                innermost_kh=innermost_kh,
                innermore_kw=innermore_kw,
                innermore_ic=innermore_ic,
                innermore_oc=innermore_oc,
                innermore_h=innermore_h,
                innermore_w=innermore_w)
            if real_iter == 1:
                self.last_row_iteration = False
            real_iter -= 1
            self.first_row_iteration = False
            if real_iter > 0:
                real_iter -= 1
            # Assume no unrolls for this loop

        real_label, loop_end_reg = self.generate_header(
            e[1], real_iter, real_iter, e[3] * e[2], prefix=prefix,
            counter_reg=counter_reg, suffix=e[0].upper())

        return real_label, loop_end_reg, real_iter

    def handle_loop_tail(
            self, loop_configs, real_iter, label, prefix, counter_reg,
            loop_end_reg, suffix=None,
            innermost_h=None,
            innermost_w=None,
            innermost_oc=None,
            innermost_sample=None,
            innermost_ic=None,
            innermost_kw=None,
            innermost_kh=None,
            innermore_kw=None,
            innermore_ic=None,
            innermore_oc=None,
            innermore_h=None,
            innermore_w=None):
        e = loop_configs[0]

        self.generate_tail(
            counter_reg, label, real_iter, e[3],
            loop_end_reg=loop_end_reg)

        if self.check_if_innermost_mma_row_loop(loop_configs):
            if real_iter > 0:
                self.last_row_iteration = True
                self.generate_actual_loops_with_unrolls(
                    loop_configs[1:],
                    prefix,
                    innermost_h=innermost_h,
                    innermost_w=innermost_w,
                    innermost_oc=innermost_oc,
                    innermost_sample=innermost_sample,
                    innermost_ic=innermost_ic,
                    innermost_kw=innermost_kw,
                    innermost_kh=innermost_kh,
                    innermore_kw=innermore_kw,
                    innermore_ic=innermore_ic,
                    innermore_oc=innermore_oc,
                    innermore_h=innermore_h,
                    innermore_w=innermore_w)
                self.last_row_iteration = False

    def generate_actual_loops(
            self,
            loop_configs,
            prefix,
            comment=None,
            sample=None,
            acculast=False,
            accufirst=False,
            innermost_h=None,
            innermost_w=None,
            innermost_oc=None,
            innermost_sample=None,
            innermost_ic=None,
            innermost_kw=None,
            innermost_kh=None,
            innermore_kw=None,
            innermore_ic=None,
            innermore_oc=None,
            innermore_h=None,
            innermore_w=None):

        e = loop_configs[0]
        self.print_loop_config(e)

        current_loop_iter, t = self.preprocess_loop_attributes(loop_configs)

        if len(loop_configs) == 1:
            self.generate_innermost_instructions(
                e[1],
                loop_configs,
                innermost_h=innermost_h,
                innermost_w=innermost_w,
                innermost_oc=innermost_oc,
                innermost_sample=innermost_sample,
                innermost_ic=innermost_ic,
                innermost_kw=innermost_kw,
                innermost_kh=innermost_kh,
                innermore_kw=innermore_kw,
                innermore_ic=innermore_ic,
                innermore_oc=innermore_oc,
                innermore_h=innermore_h,
                innermore_w=innermore_w)
        else:
            real_iter, unroll_times = self.get_real_iter_and_unroll_times(
                e[1], e[2])

            label = self.allocate_loop_label(prefix, e[0])
            if len(e) > 4:
                loop_attrib = e[4]
            else:
                loop_attrib = {}
            counter_reg = self.allocate_loop_counter_register(
                e[1], e[2], e[3], loop_attrib, prefix=label)

            self.keep_loop_counter_register(loop_configs, counter_reg)

            real_label, loop_end_reg, it = self.handle_loop_header(
                loop_configs, prefix, counter_reg)

            self.add_extra_handling_in_front(loop_configs)
            self.set_buffer_b_address(loop_configs)
            if self.instr == "mma":
                self.add_instruction_to_set_coordiante_modifier(loop_configs)

            if it > 0:
                self.generate_actual_loops_with_unrolls(
                    loop_config=loop_configs[1:],
                    prefix=prefix,
                    innermost_h=innermost_h,
                    innermost_w=innermost_w,
                    innermost_oc=innermost_oc,
                    innermost_sample=innermost_sample,
                    innermost_ic=innermost_ic,
                    innermost_kw=innermost_kw,
                    innermost_kh=innermost_kh,
                    innermore_kw=innermore_kw,
                    innermore_ic=innermore_ic,
                    innermore_oc=innermore_oc,
                    innermore_h=innermore_h,
                    innermore_w=innermore_w)

            self.add_extra_handling_in_back(loop_configs)
            self.merge_out_off_modifiers(loop_configs)

            self.increase_buffer_a_address(loop_configs)

            self.handle_loop_tail(
                loop_configs, it, real_label, prefix, counter_reg,
                loop_end_reg)

            self.add_post_loop_instructions(loop_configs, label)

            rm.wsr_free(counter_reg)
            rm.wsr_free(loop_end_reg)

        self.postprocess_loop_attributes(e, t)

    def generate_loops(self, prefix, comment=None):
        # print("self.loop_configs is ", self.loop_configs)
        super().generate_loops(self, prefix)
        self.unroll_innermost_loop()

        #self.bpw_mma_buf_a_wsc = (bcd.LDCONV0_TO_CONV_START_STATION +
        #                          int(self.operator.pingpong_a[0] /
        #                              bcd.LOAD_CONV_SYNC_STATION_NUM))
        #self.bpw_mma_buf_a_ssc = self.bpw_mma_buf_a_wsc + bcd.LOAD_CONV_SYNC_STATION_NUM
        #self.bpw_mma_buf_b_wsc = (bcd.LDCONV1_TO_CONV_START_STATION +
        #                          int(self.operator.pingpong_b[0] /
        #                              bcd.LOAD_CONV_SYNC_STATION_NUM))
        #self.bpw_mma_buf_b_ssc = self.bpw_mma_buf_b_wsc + bcd.LOAD_CONV_SYNC_STATION_NUM

        #self.bpw_mma_buf_a_addr = self.operator.pingpong_a[0]
        #self.bpw_mma_buf_b_addr = self.operator.pingpong_b[0]

        self.buf_b_entries_per_row = self.operator.required_buffer_b_entries_per_ld * self.loop_configs[-2][1]

        self.saved_buf_a_address_for_mma = rm.wsr_alloc("saved_buf_a_address")

        self.init_gib_buf()

        self.insert_unroll_loop_level()
        self.generate_actual_loops_with_unrolls(
            self.loop_config, prefix, comment=comment)

        rm.wsr_free(self.saved_buf_a_address_for_mma)
        self.free_resources()
