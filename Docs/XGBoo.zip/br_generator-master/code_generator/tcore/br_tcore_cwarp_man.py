#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

from code_generator.share.br_singleton_base import singleton
from code_generator.share import br_resource_manager as rm
from code_generator.share import br_const_defs as icd
from code_generator.share import br_utils
from code_generator.share.br_cwarp_man import cwarp_top
from code_generator.share import br_vector_instructions_def as vid
from code_generator.share import br_defined_print as bdp


class cwarp_man(singleton):
    __instance = None  # singlton class

    def __new__(cls, *args, **kwargs):
        if cls.__instance is None:
            cls.__instance = super(cwarp_man, cls).__new__(cls)
            cls.__instance.__initialized = False
        return cls.__instance

    def __init__(self):
        if(self.__initialized):
            return
        self.__initialized = True

        self.cwarp_top = cwarp_top()
        self.smov = vid.smov()
        self.buffer_a_addr = br_utils.Br_Register()
        self.buffer_b_addr = br_utils.Br_Register()
        self.slot_reg = br_utils.Br_Register()
        self.slot_reg.inc_unit = 1

        self.previous_filter_width = None
        self.bar = vid.bar()
        self.bufa_to_conv_sync = None
        self.conv_to_bufa_sync = None
        self.bar_id_from_vector = None
        self.bar_id_to_vector = None
        self.tlr_bar_id_to_vector = None
        self.tlr_bar_id_from_vector = None
        self.layer_id = 0

    def get_a_label(self):
        return self.cwarp_top.get_a_label()

    def start_buffer_a_ld_warp(self, operator):
        current_warp, warp_entry = self.cwarp_top.start_warp(0)

        if self.cwarp_top.is_new_cwarp():
            self.cwarp_top.gen_warp_header(current_warp)
            self.cwarp_top.loop_man.operator = operator

            self.buffer_a_addr.register = rm.wsr_alloc("gib0")
            self.bufa_to_conv_sync = rm.wsr_alloc("bufa_conv_sync")
            self.conv_to_bufa_sync = rm.wsr_alloc("conv_bufa_sync")

            self.smov.generate(
                 self.cwarp_top.indent,
                 dst=self.bufa_to_conv_sync,
                 src1=icd.LDCONV0_TO_CONV_START_STATION,
                 comment="// Init buf_a to conv sync station register")
            self.smov.generate(
                 self.cwarp_top.indent,
                 dst=self.conv_to_bufa_sync,
                 src1=icd.CONV_TO_LDCONV0_START_STATION,
                 comment="// Init conv to buf_a sync station register\n")

            # self.smov.generate(
            #      self.cwarp_top.indent,
            #      dst=self.buffer_a_addr.register, src1=0,
            #      comment="// Init Buf A address register to 0\n")
            if operator.name != "bpw_mma":
                operator.operator["buf_a_ld"].generate(
                    indent=self.cwarp_top.indent,
                    ssc=icd.CONV_TO_LDCONV0_START_STATION,
                    modifier="off.incy0.incz0.wnil.sset",
                    transient=True)
                operator.operator["buf_a_ld"].generate(
                    indent=self.cwarp_top.indent,
                    ssc=icd.CONV_TO_LDCONV0_START_STATION+1,
                    modifier="off.incy0.incz0.wnil.sset",
                    transient=True)
            else:
                for i in range(icd.LOAD_CONV_SYNC_STATION_NUM):
                    operator.operator["buf_a_ld"].generate(
                        indent=self.cwarp_top.indent,
                        ssc=icd.CONV_TO_LDCONV0_START_STATION+i,
                        modifier="off.incx0.incy0.incz0.wnil.sset",
                        transient=True)

        return self.cwarp_top.get_warp_entry_head()

    def end_buffer_a_ld_warp(self):
        if self.cwarp_top.only_two_cwarps():
            return
        else:
            self.cwarp_top.end_warp()

    def start_buffer_b_ld_warp(self, operator):
        current_warp, warp_entry = self.cwarp_top.start_warp(1)
        if self.cwarp_top.is_new_cwarp():
            self.cwarp_top.gen_warp_header(current_warp)
            self.cwarp_top.loop_man.operator = operator

            self.buffer_b_addr.register = rm.wsr_alloc("gib1")

            # self.smov.generate(
            #      self.cwarp_top.indent,
            #      dst=self.buffer_b_addr.register, src1=0,
            #      comment="// Init Buf B address register to 0\n")

            for i in range(icd.LOAD_CONV_SYNC_STATION_NUM):
                operator.operator["buf_b_ld"].generate(
                    indent=self.cwarp_top.indent,
                    filter_width=1,
                    filter_height=1,
                    ssc=icd.CONV_TO_LDCONV1_START_STATION + i,
                    modifier="off.ich8.incx0.incy0.incz0.sset", transient=True)
            # counter_reg = (
            #     self.cwarp_top.loop_man.allocate_loop_counter_register(
            #         16, 1, 1, loop_name=warp_entry.split("_")[0],
            #         suffix="wait_sync_init".upper()))
            # label, loop_end_reg = self.cwarp_top.loop_man.generate_header(
            #     16, 16, 16, 1, prefix=warp_entry.split("_")[0],
            #     counter_reg=counter_reg,
            #     suffix="wait_sync_init".upper())
            # operator.operator["buf_b_ld"].generate(
            #     indent=self.cwarp_top.indent,
            #     filter_width=1,
            #     filter_height=1,
            #     modifier="sset",
            #     transient=True)
            # self.cwarp_top.loop_man.generate_tail(
            #     counter_reg, label, 15, 1, loop_end_reg=loop_end_reg)
            # rm.wsr_free(counter_reg)

        return self.cwarp_top.get_warp_entry_head()

    def end_buffer_b_ld_warp(self):
        if self.cwarp_top.only_one_cwarp():
            return
        else:
            bdp.br_print("")
            self.bar.generate(
                indent=self.cwarp_top.indent, scope="wtg", bartype="sync",
                src1=icd.INTER_LAYER_BARRIER_BTWEEN_BUFB_AND_VECTOR, src2=17,
                comment="// Waiting for previous layer to finish")
            bdp.br_print("")
            self.cwarp_top.end_warp()

    def start_conv_warp(self, operator=None):
        current_warp, warp_entry = self.cwarp_top.start_warp(2)

        if self.cwarp_top.is_new_cwarp():
            self.cwarp_top.gen_warp_header(current_warp)
            self.cwarp_top.loop_man.operator = operator

            self.buffer_a_addr.register = rm.wsr_alloc("gib0")
            self.buffer_b_addr.register = rm.wsr_alloc("gib1")
            self.bufa_to_conv_sync = rm.wsr_alloc("bufa_conv_sync")
            self.conv_to_bufa_sync = rm.wsr_alloc("conv_bufa_sync")

            self.slot_reg.register = rm.wsr_alloc("slot")
            self.bar_id_from_vector = rm.wsr_alloc("bar_id_from_vector")
            self.bar_id_to_vector = rm.wsr_alloc("bar_id_to_vector")
            self.tlr_bar_id_to_vector = rm.wsr_alloc("tlr_bar_id_to_vector")
            self.tlr_bar_id_from_vector = rm.wsr_alloc("tlr_bar_id_from_vector")
            # self.smov.generate(
            #      self.cwarp_top.indent,
            #      dst=self.buffer_a_addr.register, src1=0,
            #      comment="// Init Buf A address register to 0")

            # self.smov.generate(
            #      self.cwarp_top.indent,
            #      dst=self.buffer_b_addr.register, src1=0,
            #      comment="// Init Buf B address register to 0")

            '''
            self.smov.generate(
                 self.cwarp_top.indent,
                 dst=self.bar_id_from_vector, src1=icd.GRB_PINGPONG_VECTOR_TO_CONV_BAR_ID_1,
                 comment="// Init bar id from vector register to 0")
            self.smov.generate(
                 self.cwarp_top.indent,
                 dst=self.bar_id_to_vector, src1=icd.GRB_PINGPONG_CONV_TO_VECTOR_BAR_ID_1,
                 comment="// Init bar id to vector register to 0")

            self.smov.generate(
                 self.cwarp_top.indent,
                 dst=self.tlr_bar_id_from_vector, src1=icd.TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_1,
                 comment="// Init bar id from vector register to 0")
            self.smov.generate(
                 self.cwarp_top.indent,
                 dst=self.tlr_bar_id_to_vector, src1=icd.TLR_PINGPONG_CONV_TO_VECTOR_BAR_ID_1,
                 comment="// Init bar id to vector register to 0")

            self.smov.generate(
                 self.cwarp_top.indent,
                 dst=self.bufa_to_conv_sync,
                 src1=icd.LDCONV0_TO_CONV_START_STATION,
                 comment="// Init buf_a to conv sync station register")
            self.smov.generate(
                 self.cwarp_top.indent,
                 dst=self.conv_to_bufa_sync,
                 src1=icd.CONV_TO_LDCONV0_START_STATION,
                 comment="// Init conv to buf_a sync station register")
            '''

            bdp.br_print("")
            operator.operator["conv"].generate(
                indent=self.cwarp_top.indent,
                modifier="off.bs0.ini1.wnil.snil.ro",
                **{"warp_count": 16})

            bdp.br_print("")

        return self.cwarp_top.get_warp_entry_head()

    def start_buffer_a_ldmma_warp(self, operator):
        current_warp, warp_entry = self.cwarp_top.start_warp(0)

        if self.cwarp_top.is_new_cwarp():
            self.cwarp_top.gen_warp_header(current_warp)
            self.cwarp_top.loop_man.operator = operator

            self.buffer_a_addr.register = rm.wsr_alloc("gib0")
            self.bufa_to_conv_sync = rm.wsr_alloc("bufa_conv_sync")
            self.conv_to_bufa_sync = rm.wsr_alloc("conv_bufa_sync")

            self.smov.generate(
                 self.cwarp_top.indent,
                 dst=self.bufa_to_conv_sync,
                 src1=icd.LDCONV0_TO_CONV_START_STATION,
                 comment="// Init buf_a to conv sync station register")
            self.smov.generate(
                 self.cwarp_top.indent,
                 dst=self.conv_to_bufa_sync,
                 src1=icd.CONV_TO_LDCONV0_START_STATION,
                 comment="// Init conv to buf_a sync station register\n")

            operator.operator["buf_a_ld"].generate(
                indent=self.cwarp_top.indent,
                ssc=icd.CONV_TO_LDCONV0_START_STATION,
                modifier="off.incx0.incy0.wnil.sset",
                transient=True)
            operator.operator["buf_a_ld"].generate(
                indent=self.cwarp_top.indent,
                ssc=icd.CONV_TO_LDCONV0_START_STATION+1,
                modifier="off.incx0.incy0.wnil.sset",
                transient=True)

        return self.cwarp_top.get_warp_entry_head()

    def end_buffer_a_ldmma_warp(self):
        if self.cwarp_top.only_two_cwarps():
            return
        else:
            self.cwarp_top.end_warp()

    def start_buffer_b_ldmma_warp(self, operator):
        current_warp, warp_entry = self.cwarp_top.start_warp(1)
        if self.cwarp_top.is_new_cwarp():
            self.cwarp_top.gen_warp_header(current_warp)
            self.cwarp_top.loop_man.operator = operator

            self.buffer_b_addr.register = rm.wsr_alloc("gib1")
            for i in range(icd.LOAD_CONV_SYNC_STATION_NUM):
                operator.operator["buf_b_ld"].generate(
                    indent=self.cwarp_top.indent,
                    ssc=icd.CONV_TO_LDCONV1_START_STATION + i,
                    modifier="off.ich8.incx0.incy0.sset", transient=True)
            # counter_reg = (
            #     self.cwarp_top.loop_man.allocate_loop_counter_register(
            #         16, 1, 1, loop_name=warp_entry.split("_")[0],
            #         suffix="wait_sync_init".upper()))
            # label, loop_end_reg = self.cwarp_top.loop_man.generate_header(
            #     16, 16, 16, 1, prefix=warp_entry.split("_")[0],
            #     counter_reg=counter_reg,
            #     suffix="wait_sync_init".upper())
            # operator.operator["buf_b_ld"].generate(
            #     indent=self.cwarp_top.indent, modifier="sinc",
            #     transient=True)
            # self.cwarp_top.loop_man.generate_tail(
            #     counter_reg, label, 15, 1, loop_end_reg=loop_end_reg)
            # rm.wsr_free(counter_reg)

        return self.cwarp_top.get_warp_entry_head()

    def end_buffer_b_ldmma_warp(self):
        if self.cwarp_top.only_one_cwarp():
            return
        else:
            self.cwarp_top.end_warp()

    def start_mma_warp(self, operator=None):
        current_warp, warp_entry = self.cwarp_top.start_warp(2)

        if self.cwarp_top.is_new_cwarp():
            self.cwarp_top.gen_warp_header(current_warp)
            self.cwarp_top.loop_man.operator = operator

            self.buffer_a_addr.register = rm.wsr_alloc("gib0")
            self.buffer_b_addr.register = rm.wsr_alloc("gib1")
            self.bufa_to_conv_sync = rm.wsr_alloc("bufa_conv_sync")
            self.conv_to_bufa_sync = rm.wsr_alloc("conv_bufa_sync")

            self.slot_reg.register = rm.wsr_alloc("slot")
            self.bar_id_from_vector = rm.wsr_alloc("bar_id_from_vector")
            self.bar_id_to_vector = rm.wsr_alloc("bar_id_to_vector")
            self.tlr_bar_id_to_vector = rm.wsr_alloc("tlr_bar_id_to_vector")
            self.tlr_bar_id_from_vector = rm.wsr_alloc("tlr_bar_id_from_vector")

            self.smov.generate(
                 self.cwarp_top.indent,
                 dst=self.bufa_to_conv_sync,
                 src1=icd.LDCONV0_TO_CONV_START_STATION,
                 comment="// Init buf_a to conv sync station register")
            self.smov.generate(
                 self.cwarp_top.indent,
                 dst=self.conv_to_bufa_sync,
                 src1=icd.CONV_TO_LDCONV0_START_STATION,
                 comment="// Init conv to buf_a sync station register")

            operator.operator["mma"].generate(
                indent=self.cwarp_top.indent,
                modifier="off.b0nil.b1nil.ini0.wnil.snil.ro",
                **{"warp_count": 16})

        return self.cwarp_top.get_warp_entry_head()

    def end_mma_warp(self):

        self.cwarp_top.end_warp()

    def end_conv_warp(self):

        self.cwarp_top.end_warp()
        # This is a workaround for working around cmodel issue
        # bdp.br_print("nop")

    def get_buffer_a_reg(self):
        return self.buffer_a_addr

    def get_buffer_b_reg(self):
        return self.buffer_b_addr

    def get_slot_reg(self):
        return self.slot_reg

    def set_filter_width(self, filter_width):
        self.previous_filter_width = filter_width

    def get_previou_filter_width(self):
        return self.previous_filter_width

    def get_bufa_to_conv_start_sync_reg(self):
        return self.bufa_to_conv_sync

    def get_conv_to_bufa_start_sync_reg(self):
        return self.conv_to_bufa_sync

    def get_start_wbar_id_from_vector_reg(self):
        return self.bar_id_from_vector

    def get_start_wbar_id_to_vector_reg(self):
        return self.bar_id_to_vector

    def get_start_tlr_wbar_id_to_vector(self):
        return self.tlr_bar_id_to_vector

    def get_start_tlr_wbar_id_from_vector(self):
        return self.tlr_bar_id_from_vector

    def get_layer_id(self):
        new_id = self.layer_id
        self.layer_id += 1
        return new_id
