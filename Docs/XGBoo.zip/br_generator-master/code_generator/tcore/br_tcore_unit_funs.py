#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import code_generator.tcore.br_tcore_instructions_def as tid
import code_generator.tcore.br_warp_input_assembly as wia
from code_generator.share import br_top


class br_tcore_unit_conv(br_top.top):
    def __init__(
            self, gib0_addr, gib1_addr, x=0, y=0, z=0, w=0, warp_count=None,
            slot=None, wsc=None, ssc=None, wbar_id=None, gib0_step=None,
            gib1_step=None, indent=None, modifier=None, **kw):
        super().__init__()
        self.conv_staging = wia.mma_conv_warp_input_assemble(
            indent, gib0_addr=gib0_addr, gib1_addr=gib1_addr, x=x,
            y=y, z=z, w=w, warp_count=warp_count, slot=slot, wsc=wsc, ssc=ssc,
            wbar_id=wbar_id, gib0_step=gib0_step, gib1_step=gib1_step)
        self.conv = tid.conv(indent=indent, modifier=None, **kw)

        self.produced_count = 0

    def generate(
            self, gib0_addr, gib1_addr, x=None, y=None, z=None, w=None,
            wsc_op=None, ssc_op=None, wsc=None, ssc=None,
            warp_count=None, slot=None, indent=None, modifier=None,
            wbar_id=None, gib0_step=None, gib1_step=None, boundary_x=None,
            boundary_y=None, unroll=False, transient=False, **kw):

        self.conv.generate(
            indent=indent, modifier=modifier, transient=transient, **kw)

        validity, dem_map = self.conv.check_warp_assemble_input_set_necessity()

        self.conv_staging.generate(
           validity, dem_map, indent, gib0_addr=gib0_addr,
           gib1_addr=gib1_addr, x=x, y=y, z=z, w=w, warp_count=warp_count,
           slot=slot, wsc=wsc, ssc=ssc, wbar_id=wbar_id, gib0_step=gib0_step,
           gib1_step=gib1_step, boundary_x=boundary_x, boundary_y=boundary_y,
           unroll=unroll, transient=transient)

        self.produced_count += 1

    def reset(self):
        self.conv.reset()
        self.conv_staging.reset()


class br_tcore_unit_buffer_a_ldconv(br_top.top):
    def __init__(
            self, gib0_addr=None, gib1_addr=None, x=None, y=None, z=None,
            w=None, is_bpw=None, wsc=None, ssc=None, gib0_step=None,
            gib1_step=None, indent=None, modifier=None, **kw):
        super().__init__()
        self.ld_staging = wia.ld_warp_input_assemble(
            indent, gib0_addr, x=x, y=y, z=z, w=w,
            wsc=wsc, ssc=ssc)
        if is_bpw:
            self.ld = tid.ldconv1(indent=indent, **kw)
        else:
            self.ld = tid.ldconv0(indent=indent, **kw)
        self.is_bpw = is_bpw

        self.produced_count = 0

    def generate(
            self, gib0_addr, gib1_addr=None, x=None, y=None, z=None, w=None,
            wsc=None, ssc=None, gib0_step=None, gib1_step=None,
            boundary_x=None, boundary_y=None, indent=None, modifier=None,
            unroll=False, transient=False, **kw):

        self.ld.generate(
            indent=indent, modifier=modifier, transient=transient, **kw)

        necessity, dem_map = self.ld.check_warp_assemble_input_set_necessity()
        self.ld_staging.generate(
           necessity, dem_map, indent, gib0_addr=gib0_addr, gib1_addr=gib1_addr,
           x=x, y=y, z=z, w=w, wsc=wsc, ssc=ssc, gib0_step=gib0_step,
           gib1_step=gib1_step, boundary_x=boundary_x, boundary_y=boundary_y,
           unroll=unroll, transient=transient)

        self.produced_count += 1

    def reset(self):
        self.ld.reset()
        self.ld_staging.reset()


class br_tcore_unit_buffer_b_ldconv(br_top.top):
    def __init__(
            self, gib0_addr=None, gib1_addr=None, x=0, y=0, z=0, w=0,
            indent=None, wsc=None, ssc=None, gib0_step=None, gib1_step=None,
            modifier=None, **kw):
        super().__init__()
        self.type = ""
        self.ld_staging = wia.ld_warp_input_assemble(
            indent, gib0_addr=gib0_addr, gib1_addr=gib1_addr, x=x, y=y, z=z,
            w=w, wsc=wsc, ssc=ssc, gib0_step=gib0_step, gib1_step=gib1_step)
        self.ld = tid.ldconv1(indent=indent, **kw)

        self.produced_count = 0

    def generate(
            self, gib_addr=None, wsc=None, ssc=None, x=None, y=None, z=None,
            w=None, gib0_step=None, gib1_step=None, boundary_x=None,
            boundary_y=None, indent=None, modifier=None,
            unroll=False, transient=False, **kw):

        self.ld.generate(
            indent=indent, modifier=modifier, transient=transient, **kw)

        necessity, dem_map = self.ld.check_warp_assemble_input_set_necessity()

        self.ld_staging.generate(
           necessity, dem_map, indent, gib1_addr=gib_addr, x=x, y=y, z=z, w=w,
           wsc=wsc, ssc=ssc, gib1_step=gib1_step, boundary_x=boundary_x,
           boundary_y=boundary_y, unroll=unroll, transient=transient)

        self.produced_count += 1

    def reset(self):
        self.ld.reset()
        self.ld_staging.reset()

    def reset_wsrpos(self):
        self.ld_staging.reset_tempwsr_pos()


class br_tcore_unit_mma(br_top.top):
    def __init__(
            self, gib0_addr, gib1_addr, x=0, y=0, z=0, w=0, warp_count=None,
            slot=None, wsc=None, ssc=None,  gib0_step=None, gib1_step=None,
            indent=None, modifier=None, **kw):
        super().__init__()
        self.mma_staging = wia.mma_conv_warp_input_assemble(
            indent, gib0_addr=gib0_addr, gib1_addr=gib1_addr, x=x,
            y=y,  gib0_step=gib0_step, gib1_step=gib1_step,
            warp_count=warp_count, slot=slot, wsc=wsc, ssc=ssc)
        self.mma = tid.mma(indent=indent, modifier=None, **kw)

        self.produced_count = 0

    def generate(
            self, gib0_addr, gib1_addr, x=None, y=None,
            wsc_op=None, ssc_op=None, wsc=None, ssc=None,
            warp_count=None, slot=None, gib0_step=None, gib1_step=None,
            indent=None, modifier=None, transient=False, **kw):

        self.mma.generate(
            indent=indent, modifier=modifier, transient=transient, **kw)

        validity, dem_map = self.mma.check_warp_assemble_input_set_necessity()

        self.mma_staging.generate(
           validity, dem_map, indent, gib0_addr=gib0_addr,
           gib1_addr=gib1_addr, x=x, y=y, warp_count=warp_count,
           slot=slot, wsc=wsc, ssc=ssc,  gib0_step=gib0_step,
           gib1_step=gib1_step, transient=transient)

        self.produced_count += 1

    def reset(self):
        self.mma.reset()
        self.mma_staging.reset()


class br_tcore_unit_mma_buf_a_ld(br_top.top):
    def __init__(
            self, gib0_addr, gib1_addr, x=0, y=0, z=0, w=0, warp_count=None,
            slot=None, wsc=None, ssc=None, gib0_step=None, gib1_step=None,
            indent=None, modifier=None, **kw):
        super().__init__()
        self.ldmma0_staging = wia.mma_conv_warp_input_assemble(
            indent, gib0_addr=gib0_addr, gib1_addr=gib1_addr, x=x,
            y=y, warp_count=warp_count, gib0_step=gib0_step,
            gib1_step=gib1_step, slot=slot, wsc=wsc, ssc=ssc)
        self.ldmma0 = tid.ldmma0(indent=indent, modifier=None, **kw)

        self.produced_count = 0

    def generate(
            self, gib0_addr, gib1_addr, x=None, y=None, wsc_op=None,
            ssc_op=None, wsc=None, ssc=None, warp_count=None,
            gib0_step=None, gib1_step=None, slot=None, indent=None,
            modifier=None, unroll=False, transient=False, **kw):
        self.ldmma0.generate(
            indent=indent, modifier=modifier, transient=transient, **kw)

        validity, dem_map = (
            self.ldmma0.check_warp_assemble_input_set_necessity())

        self.ldmma0_staging.generate(
           validity, dem_map, indent, gib0_addr=gib0_addr,
           gib1_addr=gib1_addr, x=x, y=y, warp_count=warp_count, slot=slot,
           wsc=wsc, ssc=ssc, gib0_step=gib0_step, gib1_step=gib1_step,
           unroll=unroll, transient=transient)

        self.produced_count += 1

    def reset(self):
        self.ldmma0.reset()
        self.ldmma0_staging.reset()


class br_tcore_unit_mma_buf_b_ld(br_top.top):
    def __init__(
            self, gib0_addr, gib1_addr, x=0, y=0, z=0, w=0, warp_count=None,
            slot=None, wsc=None, ssc=None, gib0_step=None, gib1_step=None,
            indent=None, modifier=None, **kw):
        super().__init__()
        self.ldmma1_staging = wia.mma_conv_warp_input_assemble(
            indent, gib0_addr=gib0_addr, gib1_addr=gib1_addr, x=x,
            y=y, warp_count=warp_count, slot=slot, wsc=wsc, ssc=ssc,
            gib0_step=gib0_step, gib1_step=gib1_step)
        self.ldmma1 = tid.ldmma1(indent=indent, modifier=None, **kw)

        self.produced_count = 0

    def generate(
            self, gib0_addr, gib1_addr, x=None, y=None, z=None, w=None,
            wsc_op=None, ssc_op=None, wsc=None, ssc=None,
            warp_count=None, slot=None, gib0_step=None, gib1_step=None,
            indent=None, modifier=None, unroll=False, transient=False, **kw):

        self.ldmma1.generate(
            indent=indent, modifier=modifier, transient=transient, **kw)

        validity, dem_map = (
            self.ldmma1.check_warp_assemble_input_set_necessity())

        self.ldmma1_staging.generate(
           validity, dem_map, indent, gib0_addr=gib0_addr,
           gib1_addr=gib1_addr, x=x, y=y, warp_count=warp_count,
           slot=slot, wsc=wsc, ssc=ssc, gib0_step=gib0_step,
           gib1_step=gib1_step, unroll=unroll, transient=transient)

        self.produced_count += 1

    def reset(self):
        self.ldmma1.reset()
        self.ldmma1_staging.reset()
