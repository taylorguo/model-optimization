#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.


import code_generator.tcore.br_tcore_operator as tco
import code_generator.share.br_const_defs as tcd


class tcore_conv(tco.tcore_operator):
    def __init__(
            self, name, tensor_b, tensor_a, tensor_w, dt, stride=1,
            dilation=1, padx=0, pady=0, usharps=None, fwd=True,
            bpw=False, pingpong_a=[0], pingpong_b=[0], red_mode="roff",
            write_through=None, csrs={}, hwshape=None, gmb_mapping=False,
            loop_configs=None, unroll_disable=False, micro_batch_mode=False):
        super().__init__(
            name, pingpong_a=pingpong_a, pingpong_b=pingpong_b, dt=dt,
            red_mode=red_mode, write_through=write_through, csrs=csrs,
            fwd=fwd, bpw=bpw, gmb_mapping=gmb_mapping,
            loop_configs=loop_configs, unroll_disable=unroll_disable)
        self.tensor_b = tensor_b
        self.tensor_w = tensor_w
        self.tensor_a = tensor_a
        self.hwshape = hwshape
        self.filter_w = tensor_w[3]
        self.filter_h = tensor_w[2]
        self.ich_num = tensor_b[1]
        self.och_num = tensor_w[0]
        self.input_w = tensor_b[3]
        self.input_h = tensor_b[2]
        self.sample_num = tensor_b[0]

        if hwshape is not None:
            self.input_w = hwshape[3]
            self.input_h = hwshape[2]
            self.sample_num = hwshape[0]

        self.i_dt = self.dt[0]
        self.w_dt = self.dt[1]
        self.o_dt = self.dt[2]
        self.stride = stride-1
        self.dilation = dilation-1
        self.padx = padx
        self.pady = pady

        # default tlr is 0, flip 64
        self.tlr_out = 0
        self.tlr_flip = 64
        self.write_usharp = True
        self.usharp_tensor_b = None
        self.usharp_tensor_b_gmb = None
        self.usharp_tensor_o = None
        self.usharp_tensor_o_gmb = None
        self.usharp_reduce = None
        self.usharp_reduce_gmb = None
        if "usharp" in usharps["tensor_b"].keys():
            self.usharp_tensor_b = usharps["tensor_b"]["usharp"]
            if "gmb_size" in usharps["tensor_b"].keys():
                self.usharp_tensor_b_gmb = usharps["tensor_b"]["gmb_size"]
        if "usharp" in usharps["tensor_a"].keys():
            self.usharp_tensor_a = usharps["tensor_a"]["usharp"]
        if "usharp" in usharps["tensor_o"].keys():
            self.usharp_tensor_o = usharps["tensor_o"]["usharp"]
            if "gmb_size" in usharps["tensor_o"].keys():
                self.usharp_tensor_o_gmb = usharps["tensor_o"]["gmb_size"]
        # set a default value for tlr, as it not works
        if "tlr" in usharps["tensor_o"].keys():
            self.tlr_out = usharps["tensor_o"]['tlr'][0]
            self.tlr_flip = usharps["tensor_o"]['tlr'][1]
            self.write_usharp = False
        if "reduce" in usharps.keys():
            if "usharp" in usharps["reduce"].keys():
                self.usharp_reduce = usharps["reduce"]["usharp"]
                if "gmb_size" in usharps["reduce"].keys():
                    self.usharp_reduce_gmb = usharps["reduce"]["gmb_size"]

        self.bst_matched_ich_ld_channels = self._find_best_block_inch_number()
        self.och_ld_channels = tcd.WEIGHT_OCH_LD_CHANNELS
        self.och_ld_ch_num = int(self.och_ld_channels[2:])
        self.bst_ich_ld_num = int(self.bst_matched_ich_ld_channels[3:])
        self.micro_batch_mode = micro_batch_mode
