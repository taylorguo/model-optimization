Rules:
==========================================
# 1. g0, that is dem0 of warp assemble input state, must be set always.
# 2. w, slot of warp assemble input state must be set at the first time.
# 3. PSR and warp assemble input is per cwarp. that means, they needs to be set for each CWarp at the first time.
# 4. If totally unrolled input channels can be acumulated to 16KB per load, the each 16KB total loading will have a sync. or else, each load will have a sync.
# 5. Under case of filter width is 1, Buffer B is used as a whole, and it can be wrapped back automatically by HW.
# 6. In the case of filter width > 1, Buffer B is divided into two part from 0-127 and 128-256. both parts can wrap back automatically.
# 7. Assume the HW Tcore can support minus address, so minus address 