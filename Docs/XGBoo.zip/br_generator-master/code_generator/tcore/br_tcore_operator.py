#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

from collections import OrderedDict

import code_generator.tcore.br_tcore_funs as tcf
import code_generator.share.br_const_defs as tcd
from code_generator.share import br_top
import code_generator.share.br_loop_manager as lm
import code_generator.tcore.br_tcore_utils as tcore_utils
import code_generator.share.br_utils as br_utils
import code_generator.tcore.br_tcore_cwarp_man as tcm
import code_generator.tcore.br_tcore_loop_man_conv as tlm
import code_generator.tcore.br_tcore_loop_man_mma as tlmm
import code_generator.share.br_loop_config_generator as blcg


class tcore_operator(br_top.top):
    def __init__(
        self,
        name,
        pingpong_a=None,
        pingpong_b=None,
        red_mode="roff",
        dt=None,
        fwd=True,
        bpw=False,
        write_through=False,
        csrs=None,
        gmb_mapping=False,
        loop_configs=None,
        unroll_disable=False
    ):
        super().__init__()
        self.name = name
        self.operator = OrderedDict()
        self.pingpong_a = pingpong_a
        self.pingpong_b = pingpong_b
        self.red_mode = red_mode
        self.previous_operator_filter_width = None
        self.fwd = fwd
        self.bpw = bpw
        self.write_through = write_through

        self.indent = br_utils.Br_Indent()
        self.cwm = tcm.cwarp_man()
        self.loop_configs = loop_configs

        self.gib0_addr = self.cwm.get_buffer_a_reg()
        self.gib1_addr = self.cwm.get_buffer_b_reg()
        self.gib0_step = None
        self.gib1_step = None

        self.dt = dt

        self.required_buffer_a_entries_per_ld = None
        self.required_buffer_b_entries_per_ld = None

        self.csrs = csrs
        self.unroll_disable = unroll_disable
        # Currently, gmb mapping is only feature map
        self.gmb_mapping = gmb_mapping

        self.layer_id = self.cwm.get_layer_id()

    def _initialize_instructions(self):
        buf_a_addr = self.cwm.get_buffer_a_reg()
        buf_b_addr = self.cwm.get_buffer_b_reg()
        direction = "fwd"
        bwdtype = None
        if not self.fwd:
            direction = "bwd"
            bwdtype = "bpw" if self.bpw else "bpa"
        self.direction = direction
        self.bwdtype = bwdtype
        if self.direction == "bwd" and self.bwdtype == "bpa" and self.stride == 1:
            psr_stride = self.stride
            self.stride = 0
        else:
            psr_stride = self.stride
            self.stride = self.stride

        usharp_index_a = self.usharp_tensor_a
        usharp_index_b = self.usharp_tensor_b
        usharp_index_o = self.usharp_tensor_o

        transpose = "tp0"
        if self.bwdtype == "bpa":
            transpose = "tp1"
        padx = self.padx
        pady = self.pady
        OutputCh_Shape = self.och_ld_channels
        ich_num = self.bst_matched_ich_ld_channels
        if self.bpw:
            padx = 0
            pady = 0
            OutputCh_Shape = tcd.ACTIVATION_BLOCK_SHAPE
            ich_num = self.bst_matched_ich_ld_channels_bpw_bufa
        self.operator["buf_a_ld"] = tcf.tcore_buffer_a_ld(
            self.filter_w,
            self.filter_h,
            stride=self.stride,
            dilation=self.dilation,
            padx=padx,
            pady=pady,
            direction=direction,
            bwdtype=bwdtype,
            gib0_addr=buf_a_addr,
            y=0,
            z=0,
            gib0_step=self.required_buffer_a_entries_per_ld,
            GIB0Ctrl="b0nil",
            wsc=tcd.CONV_TO_LDCONV0_START_STATION,
            ssc=tcd.LDCONV0_TO_CONV_START_STATION,
            indent=self.indent,
            OpDisable="off",
            DataType0=self.w_dt,
            UsharpIdx=usharp_index_a,
            Transpose_Out=transpose,
            Mat0Col_InputCh=ich_num,
            Mat0Row_OutputCh_Shape=OutputCh_Shape,
            PostInc_y="sety",
            PostInc_z="setz",
            Waitgsc="wnil",
            Setgsc="snil",
        )

        transpose = "tp0"
        if self.bpw:
            transpose = "tp1"
            padx = self.bpw_padx
            pady = 0
        self.operator["buf_b_ld"] = tcf.tcore_buffer_b_ld(
            self.filter_w,
            self.filter_h,
            padx=padx,
            pady=pady,
            stride=self.stride,
            stride_psr=psr_stride,
            dilation=self.dilation,
            direction=direction,
            bwdtype=bwdtype,
            gib1_addr=buf_b_addr,
            x=0,
            y=0,
            gib1_step=self.required_buffer_b_entries_per_ld,
            GIB0Ctrl="b1nil",
            z=0,
            w=0,
            wsc=0,
            ssc=16,
            DataType0=self.i_dt,
            indent=self.indent,
            OpDisable="off",
            PostInc_x="setx",
            PostInc_y="sety",
            PostInc_z="setz",
            Waitgsc="wnil",
            Setgsc="snil",
            Transpose_Out=transpose,
            Mat0Row_OutputCh_Shape=tcd.ACTIVATION_BLOCK_SHAPE,
            UsharpIdx=usharp_index_b,
            Mat0Col_InputCh=self.bst_matched_ich_ld_channels,
        )

        if self.write_through:
            wt = "wt"
        else:
            wt = "nwt"
        # for bpa and forward
        if self.fwd or (not self.bpw):
            self.operator["conv"] = tcf.tcore_conv(
                buf_a_addr,
                buf_b_addr,
                self.filter_w,
                self.filter_h,
                stride=self.stride,
                dilation=self.dilation,
                padx=self.padx,
                pady=self.pady,
                halftlr="htlr0",
                x=0,
                y=0,
                z=0,
                w=0,
                warp_count=0,
                slot="sls0",
                wsc=tcd.LDCONV1_TO_CONV_START_STATION,
                ssc=tcd.CONV_TO_LDCONV1_START_STATION,
                indent=self.indent,
                GIB0Ctrl="b0nil",
                GIB1Ctrl="b1nil",
                gib0_step=self.required_buffer_a_entries_per_ld,
                gib1_step=self.required_buffer_b_entries_per_ld,
                OpDisable="off",
                Mat0Row_OutputCh_Shape=tcd.CONV_OCH_SIZE_SYM,
                Init="ini1",
                DataType0=self.w_dt,
                DataType1=self.i_dt,
                DstDataType=self.o_dt,
                Transpose_Out="out1",
                LMScope_RedMode=self.red_mode,
                GIBID_WriteThru=wt,
                Waitgsc="wset",
                Setgsc="snil",
                UsharpIdx=usharp_index_o,
                Destination="z0",
                Mat0Col_InputCh=self.bst_matched_ich_ld_channels,
            )
        else:  # for bpw
            matrix_a_rows = tcd.CONV_OCH_SIZE
            matrix_a_cols = (tcd.ACTIVATION_BLOCK_W_SIZE *
                             tcd.ACTIVATION_BLOCK_H_SIZE)
            matrix_b_cols = self.best_input_channel_num_per_ld_for_bufb
            self.operator["mma"] = tcf.tcore_mma(
                gib0_addr=self.gib0_addr,
                gib1_addr=self.gib1_addr,
                x=0,
                y=0,
                warp_count=0,
                slot="sls0",
                wsc=tcd.LDCONV1_TO_CONV_START_STATION,
                ssc=tcd.CONV_TO_LDCONV1_START_STATION,
                indent=self.indent,
                GIB0Ctrl="b0nil",
                GIB1Ctrl="b1nil",
                gib0_step=self.required_buffer_a_entries_per_ld,
                gib1_step=self.required_buffer_b_entries_per_ld,
                OpDisable="off",
                Mat0Row_OutputCh_Shape="{}x{}".format(
                    matrix_a_rows, matrix_b_cols),
                Init="ini1",
                DataType0=self.w_dt,
                DataType1=self.i_dt,
                DstDataType=self.o_dt,
                Transpose_Out="out1",
                LMScope_RedMode=self.red_mode,
                GIBID_WriteThru=wt,
                ReadOnly_Sparse="spar0",
                Waitgsc="wset", Setgsc="snil",
                UsharpIdx=usharp_index_o, Destination="z0",
                Mat0Col_InputCh=matrix_a_cols
            )

    def _calculate_inner_loop_iterations_and_steps(self, loop_configs):
        for config in loop_configs:
            # only for normal ich loopconfig
            if len(config) > 3:
                c = config[-1]
            else:
                return
            # only for ich
            if c[0] != tcd.INNER_IC_LOOP_NAME:
                return
            # print("c is ", c)
            # print("inner ich loop config is ", c)
            if c[1] != 1 and c[2] != 1:
                print("Error: inner ich channel config wrong!")
            new_c = []
            new_c.append(c[0])
            iterations = int(
                (c[3] + self.bst_ich_ld_num - 1)/self.bst_ich_ld_num)
            new_c.append(iterations)
            new_c.append(iterations)
            new_c.append(self.bst_ich_ld_num)
            if len(c) > 4:
                new_c.append(c[4])
            config.remove(c)
            new_c = tuple(new_c)
            config.append(new_c)

    def _find_best_block_inch_number(self):
        ich = tcore_utils.find_best_match_block_inch_num(
            self.tensor_w[1], self.dt[1])
        # print("Best matched ich loading number is ", ich)
        n = int(ich[3:])
        if n > 64 and self.filter_w > 1:
            ich = ich.replace(ich[3:], "64")
        # print("ich is after ", ich)
        return ich

    def _find_best_block_inch_number_bpw_bufa(self):
        ich = tcore_utils.find_best_match_block_inch_num(
            self.tensor_a[1], self.dt[0])
        # print("Best matched ich loading number is ", ich)
        n = int(ich[3:])
        if n > 128:
            ich = ich.replace(ich[3:], "128")
        # print("ich is after ", ich)
        return ich

    def _generate_buf_a_ld(self, loop_config=None):
        warp_prefix = self.cwm.start_buffer_a_ld_warp(self)

        lm.loop_code_generate(
            indent=self.indent,
            loop_config=loop_config,
            instr="buf_a_ld",
            operator=self,
            prefix=warp_prefix,
            loop_man=tlm.loop_man_conv,
        )

        self.cwm.end_buffer_a_ld_warp()

    def _generate_buf_b_ld(self, loop_config=None):
        prefix = self.cwm.start_buffer_b_ld_warp(self)
        lm.loop_code_generate(
            indent=self.indent,
            loop_config=loop_config,
            instr="buf_b_ld",
            operator=self,
            prefix=prefix,
            loop_man=tlm.loop_man_conv,
        )

        self.cwm.end_buffer_b_ld_warp()

    def _genrate_conv(self, loop_config=None):
        prefix = self.cwm.start_conv_warp(self)
        lm.loop_code_generate(
            indent=self.indent,
            loop_config=loop_config,
            instr="conv",
            operator=self,
            prefix=prefix,
            loop_man=tlm.loop_man_conv,
        )

        self.cwm.end_conv_warp()

    def _generate_bpw_mma(self, loop_config=None):
        # print("Info: loop_config is: ", loop_config)
        warp_prefix = self.cwm.start_mma_warp(self)

        lm.loop_code_generate(
            indent=self.indent,
            loop_config=loop_config,
            instr="mma",
            operator=self,
            prefix=warp_prefix,
            loop_man=tlmm.loop_man_mma,
        )

        self.cwm.end_mma_warp()

    def _generate_mma(self, loop_config=None):
        warp_prefix = self.cwm.start_mma_warp(self)

        # self.operators["mma"].generate(modifier=".off")
        lm.loop_code_generate(
            indent=self.indent,
            loop_config=loop_config,
            instr="mma",
            operator=self,
            prefix=warp_prefix,
            loop_man=tlmm.loop_man_mma,
        )

        self.cwm.end_mma_warp()

    def _reset(self):
        self.operator["buf_a_ld"].reset()
        self.operator["buf_b_ld"].reset()

    def get_total_iteration_times(self, loop_configs):
        iterations = 1
        for config in loop_configs:
            if isinstance(config, tuple):
                iterations *= config[1]
            else:
                sum = 0
                for c in config:
                    sum += c[1]
                iterations *= sum
        return iterations

    def check_loop_configs(self):
        if not self.loop_configs:
            if self.unroll_disable:
                optimize_policy = None
                print("optimize policy is NONE")
            else:
                optimize_policy = {
                    "unroll_policy": 'target_count',
                    "unroll_target_instruction_count": [
                        600,
                        600,
                        600,
                        0,
                        0,
                    ],  # ldconv0, ldconv1, conv, reduce, elemwise
                    "force_bufa_pingpong": False,
                    "force_grb_pingpong": False,
                    "remove_ic_epilog": False,
                    "remove_oc_epilog": False,
                }

            config_generator = blcg.br_loop_config_conv2d_forward(
                self.tensor_b,
                self.tensor_a,
                dt=list(self.dt),
                stride=[self.stride, self.stride],
                dilation=[self.dilation, self.dilation],
                padding=[self.padx, self.pady],
                optimization_policy=optimize_policy,
                reduce=True if self.reduction else False,
            )

            self.loop_configs = config_generator.generate_config()

    def get_accu_times_for_filter_w_above_one(self, ich):
        # for loop in loop_config:
        if tcd.ENABLE_ROW_ACCUMULATION:
            loop_innermost_ich = self.loop_configs[2][-1]
            if "ich" in loop_innermost_ich[0]:
                if self.filter_h > 1:
                    if loop_innermost_ich[3] < tcd.ACCU_ICH_NUM_WITH_DOWN_PADDING:
                        return tcd.ACCU_ICH_NUM_WITH_DOWN_PADDING // ich
                else:
                    if loop_innermost_ich[3] < tcd.ACCU_ICH_NUM:
                        return tcd.ACCU_ICH_NUM // ich
        return 1
