#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

from collections import OrderedDict
import copy

import code_generator.share.br_vector_instructions_def as vid
import code_generator.share.br_utils as br_utils
import code_generator.share.br_const_defs as icd
import code_generator.share.br_resource_manager as rm
from code_generator.share.br_defined_print import br_print
from code_generator.share.br_utils import Br_Indent


class loop_man_base(object):
    def __init__(
        self, indent, comment=None, instr=None, operator=None,
        loop_config=None, accu=0,
        accu_bufa=0
    ):
        self.enable_row_accumulate = False

        self.indent = indent
        self.smov = vid.smov()
        self.smovg = vid.smovg(indent)
        self.sxor = vid.sxor(self.indent)
        self.nop = vid.nop()
        self.instr = instr
        self.operator = operator
        self.loop_config = loop_config
        self.comment = comment
        self.sadd = vid.sadd()
        self.blts = vid.blts()
        self.mulu = vid.mulu()
        self.sadda = vid.sadda()
        self.mov = vid.mov()
        self.movw = vid.movw()
        self.smovs = vid.smovs()
        self.xor = vid.xor()
        self.bar = vid.bar()
        self.madu = vid.madu()
        self.fadd = vid.fadd()
        self.sshl = vid.sshl()
        self.sand = vid.sand()
        self.sshr = vid.sshr()
        self.sor = vid.sor()
        self.ackgmb = vid.ackgmb()
        self.true_loop_config = []
        self.pb_po_modifier = None
        self.first_inner_oc = False
        self.last_inner_oc = False
        self.first_tcore_instr = False
        self.new_col_start = True
        self.new_row_start = True
        # self.sample_reg = None
        self.gib0_addr = None
        self.gib1_addr = None
        self.slot_flip_reg = br_utils.Br_Register()
        self.coord_x_reg = br_utils.Br_Register()
        self.coord_y_reg = br_utils.Br_Register()
        self.coord_z_reg = br_utils.Br_Register()
        self.coord_w_reg = br_utils.Br_Register()
        self.slot_reg = None
        self.cwarp_first_instr = True
        self.previous_gib0_addr = None
        self.previous_gib1_addr = None
        self.bufa_to_conv_sync_reg = None
        self.conv_to_bufa_sync_reg = None
        self.wbar_id_from_vector_reg = None
        self.wbar_id_to_vector_reg = None
        self.tlr_wbar_id_from_vector_reg = None
        self.tlr_wbar_id_to_vector_reg = None

        self.final_gib0_addr = None
        self.final_gib1_addr = None
        self.final_gib0_step = None
        self.final_gib1_step = None

        self.oc_levels = 0
        self.ic_levels = 0
        self.col_levels = 0
        self.row_levels = 0
        self.sample_levels = 0
        self.kw_levels = 0
        self.kh_levels = 0
        self.oc_loop_configs = []
        self.ic_loop_configs = []
        self.col_loop_configs = []
        self.kw_loop_configs = []
        self.kh_loop_configs = []
        self.row_loop_configs = []
        self.sample_loop_configs = []
        self.oc_regs = []
        self.updated_oc_regs = []
        self.ic_regs = []
        self.col_regs = []
        self.row_regs = []
        self.sample_regs = []
        self.stride_regs = []
        self.kw_regs = []
        self.kh_regs = []
        self.loop_execution_stack = []
        self.first_innermost_loop = True
        self.base_reg = None
        self.inner_a1 = None
        self.stride_a1 = None
        self.half_tlr = None
        self.index_row = None
        self.accu_times = accu
        self.accu_times_bufa = accu_bufa
        if self.operator and self.operator.name == "bpw_mma":
            self.accu_times_bufa = int( 
                icd.ACCU_BUFFER_ENTRY_NUM/self.operator.required_buffer_a_entries_per_ld)
            if self.accu_times_bufa < 1:
                self.accu_times_bufa = 1
            self.accu_times = int(
                icd.ACCU_BUFFER_ENTRY_NUM/self.operator.required_buffer_b_entries_per_ld)
            if self.accu_times < 1:
                self.accu_times = 1
        self.accu_iter = 0
        self.accu_iter_bufa = 0
        self.accu_iter_ssc = 0
        self.accu_iter_bufa_ssc = 0
        self.accu_left_step_flip = 0
        self.conv_accu_left_block_mod = False
        self.accu_left_block = 0
        self.loop_end_map = dict()
        self.last_column = False
        self.itlr_first_innor_oc_step = 0
        self.itlr_body_step = 0
        self.itlr_last_innor_oc_step = 0
        self.column_stride_unroll = False
        # self.half_tlr = None
        self.tlr_switch_pos = 0
        self.accu_unroll_iter = 0
        # for accu set coord if row or col full unroll
        self.x_fullunroll_start = 0
        self.x_fullunroll_step = 8
        self.x_fullunroll_times = 0
        self.y_fullunroll_start = 0
        self.y_fullunroll_step = 8
        self.y_fullunroll_times = 0
        self.oc_fullunroll_start = 0
        self.oc_fullunroll_step = 32
        self.oc_fullunroll_times = 0

        self.enale_ir_iter = False
        self.itlr_column_iter = 0
        self.inner_oc_full_unroll = False
        self.inner_oc_iter = 0
        self.inner_oc_steps = 0
        self.oc_block_tlr = 0
        self.tlr_flip = None
        self.brst_num = 1 * (icd.CONV_OCH_SIZE // icd.OCH_PER_TLR)
        self.row_unroll_middle = False

        self.in_off_modifier_stack = []
        self.out_off_modifier_stack = []
        self.wsc_reg = None
        self.ssc_reg = None
        self.wsc_reg_row = None
        self.ssc_reg_row = None
        self.sample_merged = None
        self.sample_row_iter = 0
        self.sample_col_iter = 0
        self.row_stride = 7
        self.boundx = None
        self.boundy = None
        self.bound_index = None
        self.base_csr = None
        self.csr_table_start = 0
        self.csr_table_size = 0
        # ich split
        self.ich_split_iter = 0
        self.ich_split_num = 0
        self.ich_split = False

        self.wsc_flip_status = 0
        self.ssc_flip_status = 0
        if self.instr == "conv":
            self.wsc_flip_status = 8

        # if self.enable_row_accumulate:
        if icd.ENABLE_ROW_ACCUMULATION:
            self.wsc_flip_status = 8
            self.ssc_flip_status = 8
            if self.instr == "conv":
                self.ssc_flip_status = 0

        self.wsc_flip_status_last_col = self.wsc_flip_status
        self.ssc_flip_status_last_col = self.ssc_flip_status

        self.has_saved_buf_b_address_for_buf_b_ld = False

        self.need_set_gib0_addr = True
        self.need_set_gib1_addr = True
        self.need_flip_oc_slot = False

        self.buffer_b_blip_constant = None
        self.buffer_b_flip_status = 0
        self.buffer_b_need_flip_back = False

        self.is_full_unrolled = False

        self.inner_oc_a1_adder = None
        self.row_a1_adder = None
        self.row_a1_accumulation = 0

        self.final_padx = None

    def init_bound_reg(self, csr_start):
        self.boundx = rm.wsr_alloc("boundx")
        self.boundy = rm.wsr_alloc("boundy")
        self.stride_bound = rm.wsr_alloc("stride_bound")
        self.bound_index = rm.wsr_alloc("bound_index")
        self.base_csr = rm.alloc_addr_reg("iclr")

    def get_csr_table(self, shape):
        if self.operator.csrs is not None and len(self.operator.csrs) > 0:
            self.csr_table_start = self.operator.csrs[str(shape)][0]
            self.csr_table_size = self.operator.csrs[str(shape)][1]
        # self.smov.generate(
        #            self.indent, dst=self.bound_index,
        #            src1=csr_start,
        #            comment="// set csr start index")

    def gen_mod_inst(self, source, dst, modv):
        rcp = rm.tlr_alloc("rcp")
        self.fadd.generate(
            self.indent, dst=rcp, src1=modv, src2=0.0, mod=".rcp", comment=" do rcp"
        )
        self.fmul.generate(
            self.indent, dst=rcp, src1=rcp, src2=source, comment="// do rcp"
        )
        self.mov.generate(self.indent, dst=dst, src1=rcp, comment="// do rcp")
        self.mulu.generate(
            self.indent, dst=dst, src1=dst, src2=modv, commant="// do a % b"
        )
        self.sadd.generate(
            self.indent, dst=dst, src1=source, src2=dst, comment="// do a % b"
        )
        rm.tlr_free("rcp")

    def gen_bound_csr_uint8(self, boundx=True, stride2=False, csr_start=0):
        # shift bound index as csr save 4 coord
        # stride2 case take 2 coord as one, then shift inner
        if stride2:
            shift_const = 1
            inner_offset = 1
            csr_offset = 4
        else:
            shift_const = 2
            inner_offset = 3
            csr_offset = 3

        self.sshr.generate(
            self.indent,
            dst=self.boundx,
            src1=self.bound_index,
            src2=shift_const,
            comment="// shift counter to get step1 index",
        )
        # mov idx to a0 to get csr idx
        self.smovs.generate(
            self.indent,
            dst=self.base_csr,
            src1=self.boundx,
            comment="// set csr base to a0",
        )
        # get inner offset of idx
        self.sand.generate(
            self.indent,
            dst=self.bound_index,
            src1=self.bound_index,
            src2=inner_offset,
            comment="// save csr inner index",
        )
        # save csr:a0+ic0 into wsr
        csr = "ic" + str(csr_start) + ".u32"
        self.mov.generate(
            self.indent, dst="k0.u32", src1=csr, comment="// save csr value to k0"
        )
        self.smov.generate(
            self.indent,
            dst=self.stride_bound,
            src1="k0",
            comment="// save csr value to wsr",
        )
        self.sshl.generate(
            self.indent,
            dst=self.bound_index,
            src1=self.bound_index,
            src2=csr_offset,
            comment="// index = index * {}".format(csr_offset),
        )
        # shift boundx to get 8bit coord
        if boundx:
            self.sshr.generate(
                self.indent,
                dst=self.stride_bound,
                src1=self.stride_bound,
                src2=self.bound_index,
                comment="// shift boundx to get x coord in csr",
            )
            self.sand.generate(
                self.indent,
                dst=self.boundx,
                src1=self.stride_bound,
                src2=7,
                comment="// get boundx low 8 bit coord",
            )
        else:
            self.sshr.generate(
                self.indent,
                dst=self.stride_bound,
                src1=self.stride_bound,
                src2=self.bound_index,
                comment="// shift boundx to get y coord in csr",
            )
            self.sand.generate(
                self.indent,
                dst=self.boundy,
                src1=self.stride_bound,
                src2=7,
                comment="// get boundy low 8 bit coord",
            )

    def generate_boundx_coord(self):
        # get col index,
        self.sshr.generate(
            self.indent,
            dst=self.bound_index,
            src1=self.col_regs[0][0],
            src2=3,
            comment="// shift counter to get step1 index",
        )
        self.gen_bound_csr_uint8(csr_start=self.csr_table_start)

    def generate_boundy_coord(self):
        # get row index
        self.sshr.generate(
            self.indent,
            dst=self.bound_index,
            src1=self.row_regs[0][0],
            src2=3,
            comment="// shift counter to get step1 index",
        )
        self.gen_bound_csr_uint8(boundx=False, csr_start=self.csr_table_start)

    def calcuate_loop_levels_per_dim(self):
        for e in self.loop_config:
            if "oc" in e[0]:
                self.oc_levels += 1
            if "ic" in e[0]:
                self.ic_levels += 1
            if "col" in e[0]:
                self.col_levels += 1
            if "row" in e[0]:
                self.row_levels += 1
            if "sample" in e[0]:
                self.sample_levels += 1
            if "kw" in e[0]:
                self.kw_levels += 1
            if "kh" in e[0]:
                self.kh_levels += 1

    def get_loop_desc(self):
        return "\n// Info: Loop Configuration is " + str(self.loop_config)

    def generate_header(
        self,
        orig_iter,
        real_iter,
        loop_end,
        unit_inc,
        prefix,
        counter_reg,
        suffix=None,
        comment=None,
        loop_fun=None,
        loop_config=None,
        innermost=False,
        loop_name="other",
        acculast=False,
        accufirst=False,
        innermost_h=None,
        innermost_w=None,
        innermost_oc=None,
        innermost_sample=None,
        innermost_ic=None
    ):
        if isinstance(self.indent, Br_Indent):
            indent = self.indent.indent
        else:
            indent = self.indent
        q = counter_reg
        # alias = prefix
        # if suffix is not None:
        #     alias += "_" + suffix
        # alias += "_counter"
        # alias = alias.lower()
        # if real_iter >= 1:
        #     q = rm.wsr_alloc(alias)

        if loop_fun is not None:
            loop_fun(
                loop_config,
                prefix=prefix,
                comment=comment,
                acculast=acculast,
                accufirst=accufirst,
                innermost_h=innermost_h,
                innermost_w=innermost_w,
                innermost_oc=innermost_oc,
                innermost_sample=innermost_sample,
                innermost_ic=innermost_ic
            )

        label = None
        least_iteration = 1
        loop_end_reg = None
        if not self.enable_row_accumulate:
            if (
                self.accu_times > 0
                and (self.instr == "conv" or self.instr == "buf_b_ld")
                and self.accu_left_block == 1
                and loop_name == icd.COL_LOOP_NAME
            ):
                loop_end -= 1

        self.loop_end_map[loop_name] = (loop_end - 1) * unit_inc

        if self.instr == "conv" and "inner_oc" in loop_name:
            least_iteration = 2
        if real_iter > least_iteration:
            loopValue = (loop_end - 1) * unit_inc
            if loopValue >= 64:
                loop_end_reg = rm.csr_alloc([loopValue], "loop_end_constant")
                # loop_end_reg = rm.wsr_alloc("loop_end_register")
                # self.smov.generate(
                #     self.indent,
                #     dst=loop_end_reg,
                #     src1=loopValue,
                #     comment="// Save loop end value to wsr for case of imm >= 64",
                # )
            if br_utils.get_code_sytle():
                # if loop_config is not None:
                #    e = loop_config[0]
                # if w>1 and s2, unroll col and not update index
                # at the middle of loop, so need doubel inc
                # loop_name should be col or row as called
                # if e[0] == "inner_oc" and self.instr == "conv"\
                # and self.operator.stride == 1\
                # and e[1] >= 1\
                # and self.operator.filter_w > 1:
                #    unit_inc *= 2
                label = (
                    "for("
                    + "; "
                    + str(q)
                    + " < "
                    + str(loopValue)
                    + "; "
                    + str(q)
                    + " += "
                    + str(unit_inc)
                    + ")"
                )
                br_print(" " * indent * 4 + label)
                br_print(" " * indent * 4 + "{")
                # self.indent.indent += 1
                # # label = "for loop " + str(q)
                # self.sadd.generate(
                #     indent_level=(indent+1), dst=q, src1=unit_inc, src2=q)

            label = prefix + "_LOOP{}".format(self.operator.cwm.get_a_label())
            if suffix is not None:
                label += "_" + suffix
            comment = "// Initilize loop counter register {} to value {}".format(
                q, -unit_inc
            )
            # print("unit_inc is ", unit_inc)
            # self.smov.generate(
            #     indent_level=indent, dst=q, src1=-unit_inc, comment=comment)
            br_print(" " * indent * 4 + label + ":")
            # br_print(label + ":")
            self.indent.indent += 1
            indent = self.indent.indent
            comment = (
                "// Increase loop counter register {} to value {} to"
                " counterbalance the init value".format(q, unit_inc)
            )
            self.sadd.generate(
                indent_level=indent, dst=q, src1=q, src2=unit_inc, comment=comment
            )
        elif real_iter == 1 and counter_reg is not None and self.instr == "conv":
            if self.operator.stride != 1:
                self.sadd.generate(indent_level=indent, dst=q, src1=q, src2=unit_inc)
        return label, loop_end_reg

    def generate_tail(
        self, counter_reg, label, iter, inc_unit, loop_name=None, loop_end_reg=None
    ):

        # print("iter and unit_inc is ", iter, unit_inc)
        q = counter_reg
        if q is not None and label is not None:
            comment = "// End of " + label

            loop_end = int((iter - 1) * inc_unit)
            # if self.accu_times > 0 and loop_name in self.loop_end_map.keys():
            #     loop_end = self.loop_end_map[loop_name]
            if (
                self.operator.stride == 1
                and self.instr == "conv"
                and self.operator.filter_w > 1
                and "col" in loop_name
            ):
                inc_unit *= 2
            if loop_end_reg is None:
                self.blts.generate(
                    indent_level=self.indent,
                    rel="rel",
                    src1=q,
                    src2=loop_end,
                    target=label,
                    comment=comment,
                )
            else:
                self.mov.generate(
                    self.indent, dst="k0.u32",
                    src1="{}.u32".format(loop_end_reg),
                    comment="// Move loop end immediate number to k0")
                self.blts.generate(
                    indent_level=self.indent, rel="rel", src1=q, parallel=1,
                    src2="k0", target=label, comment=comment)
                # self.blts.generate(
                #     indent_level=self.indent,
                #     rel="rel",
                #     src1=q,
                #     src2=loop_end_reg,
                #     target=label,
                #     comment=comment,
                # )
                rm.wsr_free(loop_end_reg)
            self.indent.indent -= 1
            if br_utils.get_code_sytle():
                # br_print(" "*self.indent.indent*4 + "}", comment=comment)
                br_print(" " * self.indent.indent * 4 + "}", comment=comment)

            rm.wsr_free(q)

        # label_end = self.label + "_end:"
        # print(" "*self.indent+label_end)
        # print(" "*(self.indent + 1) * 4 + "end\n")

    def get_x_y_z_w_loop_oder(self):
        col_loop_num = 0
        row_loop_num = 0
        ich_loop_num = 0
        size = len(self.loop_config)
        for i in range(size):
            if "col" in self.loop_config[i][0]:
                col_loop_num = i
                break
        for i in range(size):
            if "row" in self.loop_config[i][0]:
                row_loop_num = i
                break
        for i in range(size):
            if self.loop_config[i][0] == "ich":
                ich_loop_num = i
                break
        return ich_loop_num, row_loop_num, col_loop_num

    def get_real_iter_and_unroll_times(self, orig_iter, orig_unroll):
        iter = orig_iter
        if iter <= 0:
            return 0, 0
        unroll_times = min(iter, orig_unroll)
        if unroll_times > int(iter / 2):
            unroll_times = iter
        unroll_times = max(unroll_times, 1)
        real_iter = int(iter / unroll_times)
        # if real_iter == 0:
        #     real_iter = 1
        return real_iter, unroll_times

    def append_loop_to_different_list(self, e):
        if "oc" in e[0]:
            self.oc_loop_configs.append(e)
        if "ic" in e[0]:
            self.ic_loop_configs.append(e)
        if "col" in e[0]:
            self.col_loop_configs.append(e)
        if "row" in e[0]:
            self.row_loop_configs.append(e)
        if "sample" in e[0]:
            self.sample_loop_configs.append(e)
        if "kw" in e[0]:
            self.kw_loop_configs.append(e)
        if "kh" in e[0]:
            self.kh_loop_configs.append(e)

    def remove_loop_from_corresponding_list(self, e):
        if "oc" in e[0]:
            self.oc_loop_configs.remove(e)
        if "ic" in e[0]:
            self.ic_loop_configs.remove(e)
        if "col" in e[0]:
            self.col_loop_configs.remove(e)
        if "row" in e[0]:
            self.row_loop_configs.remove(e)
        if "sample" in e[0]:
            self.sample_loop_configs.remove(e)
        if "kw" in e[0]:
            self.kw_loop_configs.remove(e)
        if "kh" in e[0]:
            self.kh_loop_configs.remove(e)

    def keep_loop_counter_register(self, loop_config, register):
        if register is None:
            return
        e = loop_config[0]
        if "oc" in e[0]:
            if e[3] not in self.oc_regs:
                self.oc_regs.append((register, e[3]))
        if "ic" in e[0]:
            if e[3] not in self.ic_regs:
                self.ic_regs.append((register, e[3]))
        if "col" in e[0]:
            if e[3] not in self.col_regs:
                self.col_regs.append((register, e[3]))
        if "row" in e[0]:
            if e[3] not in self.row_regs:
                self.row_regs.append((register, e[3]))
        if "sample" in e[0]:
            if e[3] not in self.sample_regs:
                self.sample_regs.append((register, e[3]))
        if "stride" in e[0]:
            if e[3] not in self.stride_regs:
                self.stride_regs.append((register, e[3]))
        if "kw" in e[0]:
            if e[3] not in self.stride_regs:
                self.kw_regs.append((register, e[3]))
        if "kh" in e[0]:
            if e[3] not in self.stride_regs:
                self.kh_regs.append((register, e[3]))

    def pop_loop_counter_register(self, loop_config, register):
        if register is None:
            return
        e = loop_config[0]
        if "oc" in e[0]:
            if e[3] in self.oc_regs:
                self.oc_regs.remove((register, e[3]))
        if "ic" in e[0]:
            if e[3] in self.ic_regs:
                self.ic_regs.remove((register, e[3]))
        if "col" in e[0] and self.instr == "conv":
            if e[3] in self.col_regs:
                self.col_regs.remove((register, e[3]))
        if "row" in e[0] and self.instr == "conv":
            if e[3] not in self.row_regs:
                self.row_regs.remove((register, e[3]))
        if "sample" in e[0]:
            if e[3] in self.sample_regs:
                self.sample_regs.remove((register, e[3]))
        if "kw" in e[0]:
            if e[3] in self.sample_regs:
                self.kw_regs.remove((register, e[3]))
        if "kh" in e[0]:
            if e[3] in self.sample_regs:
                self.kh_regs.remove((register, e[3]))

    def extract_and_init_sync_channel(self, loop_configs):
        for config in loop_configs:
            size = len(config)
            if size >= 5:
                items = config[4]  # Get the loop attributes
                if "sset" in items.keys() and self.instr == "buf_a_ld":
                    self.smov.generate(
                        self.indent,
                        dst=self.bufa_to_conv_sync_reg,
                        src1=items["sset"][0],
                        comment="// Init sset register with input first value",
                    )
                if "wset" in items.keys() and self.instr == "buf_a_ld":
                    self.smov.generate(
                        self.indent,
                        dst=self.conv_to_bufa_sync_reg,
                        src1=items["wset"][0],
                        comment="// Init wset register with input first value",
                    )
                if "sset" in items.keys() and self.instr == "conv":
                    self.smov.generate(
                        self.indent,
                        dst=self.conv_to_bufa_sync_reg,
                        src1=items["sset"][0],
                        comment="// Init sset register with input first value",
                    )
                if "wset" in items.keys() and self.instr == "conv":
                    self.smov.generate(
                        self.indent,
                        dst=self.bufa_to_conv_sync_reg,
                        src1=items["wset"][0],
                        comment="// Init wset register with input first value",
                    )
                if "bar_sync" in items.keys() and self.instr == "conv":
                    self.smov.generate(
                        self.indent,
                        dst=self.wbar_id_from_vector_reg,
                        src1=items["bar_sync"][0],
                        comment="// Init bar register with input first value",
                    )
                if "bar_set" in items.keys() and self.instr == "conv":
                    self.smov.generate(
                        self.indent,
                        dst=self.wbar_id_to_vector_reg,
                        src1=items["bar_set"][0],
                        comment="// Init bar register with input first value",
                    )
                if "tlr_bar_sync" in items.keys() and self.instr == "conv":
                    self.smov.generate(
                        self.indent,
                        dst=self.tlr_wbar_id_from_vector_reg,
                        src1=items["tlr_bar_sync"][0],
                        comment="// Init tlr sync bar register with input first value",
                    )

                if "tlr_bar_set" in items.keys() and self.instr == "conv":
                    self.smov.generate(
                        self.indent,
                        dst=self.tlr_wbar_id_to_vector_reg,
                        src1=items["tlr_bar_set"][0],
                        comment="// Init tlr pass bar register with input first value",
                    )

    def allocate_loop_counter_register(
        self, real_iter, unrolls, unit_inc, attrib={}, prefix="", loop_name="", suffix=""
    ):
        q = None
        alias = prefix
        if suffix != "":
            alias += "_" + suffix
        alias += "_counter"
        alias = alias.lower()
        if real_iter > 1 and unrolls <= int(real_iter / 2):
            if "start" in attrib.keys():
                start = attrib["start"]
            else:
                start = 0
            q = rm.wsr_alloc(alias)
            if self.instr == "conv" and loop_name == "inner_oc":
                self.smov.generate(
                    self.indent,
                    dst=q,
                    src1=start,
                    comment="// Init {} loop counter register".format(q),
                )
            else:
                self.smov.generate(
                    self.indent,
                    dst=q,
                    src1=start - unit_inc,
                    comment="// Init {} loop counter register".format(q),
                )
        else:
            if real_iter > 1:  # For unroll case:
                q = rm.allocate_immediate_variable(alias)

        # full unroll for accu
        if real_iter > 1 and unrolls == real_iter and self.accu_times > 0:
            if "col" in loop_name:
                self.x_fullunroll_step = unit_inc
                if "start" in attrib.keys():
                    start = attrib["start"]
                else:
                    start = 0
                self.x_fullunroll_start = start
                self.x_fullunroll_times = unrolls
            elif  "row" in loop_name:
                self.y_fullunroll_step = unit_inc
                if "start" in attrib.keys():
                    start = attrib["start"]
                else:
                    start = 0
                self.y_fullunroll_start = start
                self.y_fullunroll_times = unrolls
            elif "inner_oc" in loop_name:
                self.oc_fullunroll_step = unit_inc
                if "start" in attrib.keys():
                    start = attrib["start"]
                else:
                    start = 0
                self.oc_fullunroll_start = start
                self.oc_fullunroll_times = unrolls
        return q

    def init_gib_buf(self):
        values = dict()
        mod = ".off"
        if self.instr == "buf_b_ld":
            mod += ".off.b1nil.wnil.snil.incx0.incy0.incz0"
            if (
                (self.operator.name == "fwd_conv" or self.operator.name == "bpa_conv")
                and self.operator.filter_w == 1
            ) or self.operator.name == "mma":
                if len(self.operator.pingpong_b) > 0:
                    values["ssc"] = int(
                        self.operator.pingpong_b[0] / (icd.LOAD_CONV_SYNC_STATION_NUM * 2))
                    values["wsc"] = values["ssc"] + icd.LOAD_CONV_SYNC_STATION_NUM
                else:
                    values["wsc"] = icd.CONV_TO_LDCONV1_START_STATION
                    values["ssc"] = icd.LDCONV1_TO_CONV_START_STATION
                values["gib1_addr"] = self.operator.gib1_addr.register
            if self.operator.name == "bpw_mma":
                if self.accu_times > 1:
                    values["gib1_step"] = self.operator.required_buffer_b_entries_per_ld
                else:
                    values["gib1_step"] = icd.ACCU_BUFFER_ENTRY_NUM
            if mod is not None:
                self.operator.operator[self.instr].generate(
                    indent=self.indent, **values, modifier=mod
                )
                self.save_in_modifiers_to_stack((mod, values))
        if self.instr == "buf_a_ld":
            if self.operator.name == "bpw_mma":
                mod += ".off.b1nil.wnil.snil.incx0.incy0.incz0"
                # if len(self.operator.pingpong_a) > 0:
                #     values["ssc"] = (icd.LDCONV0_TO_CONV_START_STATION +
                #                      int(self.operator.pingpong_a[0] /
                #                          icd.LOAD_CONV_SYNC_STATION_NUM))
                #     values["wsc"]=values["ssc"] + icd.LOAD_CONV_SYNC_STATION_NUM
                # else:
                #     values["wsc"] = icd.CONV_TO_LDCONV0_START_STATION
                #     values["ssc"] = icd.LDCONV0_TO_CONV_START_STATION
                # values["gib0_addr"] = self.operator.gib0_addr.register
                if self.accu_times_bufa > 1:
                    values["gib0_step"] = self.operator.required_buffer_a_entries_per_ld
                else:
                    values["gib0_step"] = icd.ACCU_BUFFER_ENTRY_NUM
                if mod is not None:
                    self.operator.operator[self.instr].generate(
                        indent=self.indent, **values, modifier=mod
                    )
                    self.save_in_modifiers_to_stack((mod, values))
        if self.instr == "mma":
            if self.operator.name == "bpw_mma":
                mod += ".off.b1nil.wnil.snil.incx0.incy0.incz0"
                if self.accu_times_bufa > 1:
                    values["gib0_step"] = self.operator.required_buffer_a_entries_per_ld
                else:
                    values["gib0_step"] = icd.ACCU_BUFFER_ENTRY_NUM
                if self.accu_times > 1:
                    values["gib1_step"] = self.operator.required_buffer_b_entries_per_ld
                else:
                    values["gib1_step"] = icd.ACCU_BUFFER_ENTRY_NUM
                if mod is not None:
                    self.operator.operator[self.instr].generate(
                        indent=self.indent, **values, modifier=mod
                    )
                    self.save_in_modifiers_to_stack((mod, values))
        self.buffer_b_flip_constant = rm.csr_alloc(
            [icd.HALF_BUFFER_B_SIZE], "flip_constant")

    def print_global_configuration_info(self):
        global_info = "// Other Configurations for this layer:\n"
        if (
            self.operator.name == "fwd_conv"
            or self.operator.name == "bpw_mma"
            or self.operator.name == "bpa_conv"
        ):
            global_info += "//     Tensor shape in buffer a is: {}\n".format(
                self.operator.tensor_a
            )
            global_info += "//     Tensor shape in buffer b is: {}\n".format(
                self.operator.tensor_b
            )
            if self.operator.name == "bpw_mma":
                global_info += "//     Tensor weight is: {}\n".format(
                    self.operator.tensor_w
                )
            global_info += "//     Stride is: {}\n".format(self.operator.stride)
            global_info += "//     Dilation is: {}\n".format(self.operator.dilation)
            global_info += "//     Padx is: {}\n".format(self.operator.padx)
            global_info += "//     Pady is: {}\n".format(self.operator.pady)
        elif self.operator.name == "mma":
            global_info += "//     Tensor shape in buffer a is: {}\n".format(
                self.operator.mata_shape
            )
            global_info += "//     Tensor shape in buffer b is: {}\n".format(
                self.operator.matb_shape
            )

        global_info += "//     Data types are: {}\n".format(self.operator.dt)

        br_print(global_info)

    def generate_loops(self, prefix, comment):
        # For preload gmb checking.
        self.print_global_configuration_info()

        if self.operator.gmb_mapping:
            if self.instr == "buf_b_ld" and self.operator.usharp_in_gmb:
                br_print(
                    "pldgmb.sz{}.sc1 g0 u{}".format(
                        self.operator.usharp_in_gmb, self.operator.usharp_in
                    )
                )
                self.smovg.generate(
                    self.indent,
                    modifier="eog",
                    dst="g0",
                    src1=0,
                    comment="// Set preload offset of corresponding u# to 0",
                )
                self.nop.generate(self.indent, modifier="sc1")

        if self.instr == "buf_a_ld" or self.instr == "conv" or self.instr == "mma":
            self.gib0_addr = self.operator.cwm.get_buffer_a_reg()
            self.gib0_addr.inc_unit = self.operator.required_buffer_a_entries_per_ld
            self.gib0_addr.instr_type = self.instr
            self.bufa_to_conv_sync_reg = (
                self.operator.cwm.get_bufa_to_conv_start_sync_reg()
            )
            self.conv_to_bufa_sync_reg = (
                self.operator.cwm.get_conv_to_bufa_start_sync_reg()
            )
            self.smov.generate(
                self.indent,
                dst=self.gib0_addr.register,
                src1=self.operator.pingpong_a[0],
                comment="// Init buf a offset with input value",
            )
        if self.instr == "buf_b_ld" or self.instr == "conv" or self.instr == "mma":
            self.gib1_addr = self.operator.cwm.get_buffer_b_reg()
            self.gib1_addr.inc_unit = self.operator.required_buffer_b_entries_per_ld
            # self.gib1_addr.inc_unit *= self.loop_config[-1][1]
            self.gib1_addr.used_times = 0
            self.gib1_addr.instr_type = self.instr
            # self.smov.generate(
            #     self.indent,
            #     dst=self.gib1_addr.register,
            #     src1=self.operator.pingpong_b[0],
            #     comment="// Init buf b offset with input value",
            # )

        if self.instr == "conv":
            self.slot_reg = self.operator.cwm.get_slot_reg()
            self.slot_reg.inc_unit = 1
            self.smov.generate(
                self.indent,
                dst=self.slot_reg.register,
                src1=0,
                comment="// Init slot register to 0",
            )
            if self.need_flip_oc_slot:
                self.slot_flip_reg.register = rm.wsr_alloc("slot_flip")
                self.smov.generate(
                    self.indent,
                    dst=self.slot_flip_reg.register,
                    src1=0,
                    comment="// Init slot fipping register to 0",
                )
            self.wbar_id_from_vector_reg = (
                self.operator.cwm.get_start_wbar_id_from_vector_reg()
            )
            self.wbar_id_to_vector_reg = (
                self.operator.cwm.get_start_wbar_id_to_vector_reg()
            )

            self.tlr_wbar_id_from_vector_reg = (
                self.operator.cwm.get_start_tlr_wbar_id_from_vector()
            )
            self.tlr_wbar_id_to_vector_reg = (
                self.operator.cwm.get_start_tlr_wbar_id_to_vector()
            )

        # Not first operator, needs to save the old offset for restoring
        if self.instr == "buf_b_ld" or self.instr == "conv" or self.instr == "mma":
            self.previous_gib1_addr = self.gib1_addr

        if self.instr == "buf_a_ld" or self.instr == "conv" or self.instr == "mma":
            self.previous_gib0_addr = self.gib0_addr

        self.buffer_b_blip_constant = rm.csr_alloc(
            [256], "buffer_flip_constant")

        # if self.accu_times > 0:
        if icd.ENABLE_ROW_ACCUMULATION and self.operator.name != "mma":
            if self.operator.filter_w > 1:
                self.enable_row_accumulate = True
                icd.STRIDE_TLR_FLIP = icd.STRIDE_TLR_FLIP_64
                # self.inner_oc_a1_adder = rm.wsr_alloc("a1_inner_oc_adder")
                # self.row_a1_adder = rm.wsr_alloc("row_oc_adder")

        if self.instr != "buf_a_ld":
            if not self.wsc_reg:
                self.wsc_reg = rm.wsr_alloc("wsc")
            if not self.ssc_reg:
                self.ssc_reg = rm.wsr_alloc("ssc")
            if not icd.ENABLE_ROW_ACCUMULATION:
                if not self.wsc_reg_row:
                    self.wsc_reg_row = rm.wsr_alloc("wsc_row")
                if not self.ssc_reg_row:
                    self.ssc_reg_row = rm.wsr_alloc("ssc_row")

        self.is_full_unrolled = self.check_if_full_unrolled()
        self.calcuate_loop_levels_per_dim()
        self.extract_and_init_sync_channel(self.loop_config)

    def free_resources(self):
        if self.wsc_reg is not None:
            rm.wsr_free(self.wsc_reg)
            self.wsc_reg = None
        if self.ssc_reg is not None:
            rm.wsr_free(self.ssc_reg)
            self.ssc_reg = None
        if self.wsc_reg_row is not None:
            rm.wsr_free(self.wsc_reg_row)
            self.wsc_reg_row = None
        if self.ssc_reg_row is not None:
            rm.wsr_free(self.ssc_reg_row)
            self.ssc_reg_row = None

        if self.inner_a1 is not None:
            rm.wsr_free(self.inner_a1)
            self.inner_a1 = None
        if self.tlr_flip is not None:
            rm.wsr_free(self.tlr_flip)
            self.tlr_flip = None
        if self.slot_flip_reg.register is not None:
            rm.wsr_free(self.slot_flip_reg.register)
            self.slot_flip_reg.register = None
        if self.stride_a1 is not None:
            rm.wsr_free(self.stride_a1)
            self.stride_a1 = None
        if self.half_tlr is not None:
            rm.wsr_free(self.half_tlr)
            self.half_tlr = None
        # if self.inner_oc_a1_adder:
        #     rm.wsr_free(self.inner_oc_a1_adder)
        #     self.inner_oc_a1_adder = None
        # if self.row_a1_adder:
        #     rm.wsr_free(self.row_a1_adder)
        #     self.row_a1_adder = None

    def add_gib1_addr_restore_for_buf_b_ld(self, loop_config):
        if len(self.loop_execution_stack) > 1:
            previous_loop = self.loop_execution_stack[-2]
            if "sample" in previous_loop[0] and previous_loop[1] > 1:
                if self.instr == "buf_b_ld":
                    mod = ".off.b1nil.wnil.snil.incx0.incy0.incz0"
                else:
                    mod = ".off.b1nil.wnil.snil"
                values = {}
                if self.operator.name == "fwd_conv" or self.operator.name == "bpa_conv":
                    values["w"] = self.sample_regs
                    self.save_in_modifiers_to_stack((mod, values))

    def preprocess_loop_attributes(self, loop_config):
        self.prehandle_loop_attribute(loop_config)
        # print("After prehandle ", loop_config)
        # print("len(loop_config) is ", len(loop_config))

        e = loop_config[0]

        self.append_loop_to_different_list(e)

        current_loop_iterations = br_utils.Br_Iterations()
        t = [e[i] for i in range(len(e))]
        t.append(current_loop_iterations)
        t = tuple(t)
        self.loop_execution_stack.append(t)

        self.add_gib1_addr_restore_for_buf_b_ld(loop_config)

        n = len(loop_config)
        if n != 1 and self.instr != "conv" and self.instr != "mma":
            self.add_instruction_to_set_coordiante_modifier(loop_config)

        self.merge_in_off_modifiers(loop_config)

        return current_loop_iterations, t

    def postprocess_loop_attributes(self, e, t):
        self.loop_execution_stack.remove(t)
        self.remove_loop_from_corresponding_list(e)

    def add_extra_handling_in_front(self, loop_configs):
        keys = None
        e = loop_configs[0]

        self.merge_out_off_modifiers(loop_configs, True)

        if len(e) >= 5:
            attr = e[4]
            keys = attr.keys()
            if self.instr == "buf_a_ld" or self.instr == "conv" or self.instr == "mma":
                # print("previous_loop_config is ", previous_loop_config)
                if self.instr == "conv" or self.instr == "mma":
                    if "bar_sync" in keys:
                        self.bar.generate(
                            self.indent,
                            scope="wtg",
                            mode="sync",
                            src1=self.wbar_id_from_vector_reg,
                            src2=17,
                            comment="// Wait for signal from vector engine",
                        )
                        if len(attr["bar_sync"]) > 1:
                            self.sxor.generate(
                                self.indent,
                                dst=self.wbar_id_from_vector_reg,
                                src1=self.wbar_id_from_vector_reg,
                                src2=0x1,
                                comment="// Flip bar id",
                            )
                    if "tlr_bar_sync" in keys:
                        # flip tlr
                        if self.enable_row_accumulate:
                            ordinal = self.get_unrolled_interation_ordinal(e)
                            if (e[1] == 1 and ordinal[0] % 2 == 0) or e[1] > 1:
                                self.bar.generate(
                                    self.indent,
                                    scope="wtg",
                                    mode="sync",
                                    src1=self.tlr_wbar_id_from_vector_reg,
                                    src2=17,
                                    comment="// Wait for tlr write finish signal from vector engine",
                                )
                                self.sxor.generate(
                                    self.indent,
                                    dst=self.tlr_wbar_id_from_vector_reg,
                                    src1=self.tlr_wbar_id_from_vector_reg,
                                    src2=1,
                                    comment="// Flip tlr bar id from vector",
                                )
                        else:
                            self.bar.generate(
                                self.indent,
                                scope="wtg",
                                mode="sync",
                                src1=self.tlr_wbar_id_from_vector_reg,
                                src2=17,
                                comment="// Wait for tlr write finish signal from vector engine",
                            )
                            self.sxor.generate(
                                self.indent,
                                dst=self.tlr_flip,
                                src1=self.tlr_flip,
                                src2=icd.STRIDE_TLR_FLIP,
                                comment="// Flip tlr id",
                            )
                            self.sxor.generate(
                                self.indent,
                                dst=self.tlr_wbar_id_from_vector_reg,
                                src1=self.tlr_wbar_id_from_vector_reg,
                                src2=1,
                                comment="// Flip tlr bar id from vector",
                            )
            if self.operator.name == "bpw_mma":
                ordinal = self.get_unrolled_interation_ordinal(e)
                pre_values = dict()
                if "bufa_start" in keys:
                    start = e[4]["bufa_start"][0]
                    self.bpw_mma_buf_a_wsc = (icd.LDCONV0_TO_CONV_START_STATION +
                                              int(start /
                                                  icd.LOAD_CONV_SYNC_STATION_NUM))
                    self.bpw_mma_buf_a_ssc = self.bpw_mma_buf_a_wsc + icd.LOAD_CONV_SYNC_STATION_NUM


                    self.bpw_mma_buf_a_addr = start
                    # self.final_gib0_addr = self.bpw_mma_buf_a_addr
                    pre_values["gib0_addr"] = start
                if "bufb_start" in keys:
                    start = e[4]["bufb_start"][0]
                    self.bpw_mma_buf_b_wsc = (icd.LDCONV1_TO_CONV_START_STATION +
                                              int(start /
                                                  icd.LOAD_CONV_SYNC_STATION_NUM))
                    self.bpw_mma_buf_b_ssc = self.bpw_mma_buf_b_wsc + icd.LOAD_CONV_SYNC_STATION_NUM
                    self.bpw_mma_buf_b_addr = start
                    pre_values["gib1_addr"] = start
                    # self.final_gib1_addr = self.bpw_mma_buf_b_addr
                prod_mod = None
                if self.check_if_exist_later_operation_for_front(prod_mod, e):
                    self.save_in_modifiers_to_stack((prod_mod, pre_values))
                    self.merge_in_off_modifiers(loop_configs)
                else:
                    self.save_in_modifiers_to_stack((prod_mod, pre_values))

        mod, values = self.get_pre_loop_modifier(loop_configs)
        loop_name = e[0]
        if (
            (loop_name != "ich")
            or (loop_name == "ich" and self.first_inner_oc)
            or (self.instr == "buf_a_ld")
        ):
            if mod is not None:
                generate = False
                if self.instr == "conv" and self.operator.stride == 1:
                    for v in values:
                        if v == "wsc":
                            generate = True
                else:
                    generate = True
                if generate:
                    if self.check_if_exist_later_operation_for_front(mod, e):
                        self.save_in_modifiers_to_stack((mod, values))
                        self.merge_in_off_modifiers(loop_configs)
                    else:
                        self.save_in_modifiers_to_stack((mod, values))
        if mod:
            if self.instr == "buf_a_ld" and "wset" in mod:
                if len(self.operator.pingpong_a) > 1:
                    self.sxor.generate(
                        self.indent,
                        dst=self.conv_to_bufa_sync_reg,
                        src1=self.conv_to_bufa_sync_reg,
                        src2=0x1,
                        comment="// Flip conv to buf_a sync register",
                    )
            if (self.instr == "conv" or self.instr == "mma") and "wset" in mod:
                if len(self.operator.pingpong_a) > 1:
                    self.sxor.generate(
                        self.indent,
                        dst=self.bufa_to_conv_sync_reg,
                        src1=self.bufa_to_conv_sync_reg,
                        src2=0x1,
                        comment="// Flip buf_a to conv sync register",
                    )
                if (
                    keys
                    and "wset" in keys
                    and "bufb_wset" not in keys
                    and "wsc" in values.keys()
                    and (
                        self.operator.name == "fwd_conv"
                        or self.operator.name == "bpa_conv"
                    )
                    and self.operator.filter_w == 1
                ):
                    values2 = {}
                    if len(self.operator.pingpong_b) > 0:
                        values2["wsc"] = int(self.operator.pingpong_b[0] / 32)
                        values2["ssc"] = values2["wsc"] + 16
                    else:
                        values2["wsc"] = icd.LDCONV1_TO_CONV_START_STATION
                        values2["ssc"] = icd.CONV_TO_LDCONV1_START_STATION
                    values2["gib1_addr"] = self.operator.gib1_addr.register
                    mod2 = ".off.snil.b0nil.b1nil.wnil.snil"
                    if self.check_if_exist_later_operation_for_front(mod2, e):
                        self.save_in_modifiers_to_stack((mod2, values2))
                        self.merge_in_off_modifiers(loop_configs)
                    else:
                        self.save_in_modifiers_to_stack((mod2, values2))

        if self.instr == "conv" or self.instr == "buf_b_ld":
            if "sample" in loop_configs[0][0]:
                self.buffer_b_flip_status = 0
                self.wsc_flip_status = 0
                self.ssc_flip_status = 0
                if self.instr == "conv":
                    self.wsc_flip_status = 8

                # if self.enable_row_accumulate:
                if icd.ENABLE_ROW_ACCUMULATION:
                    self.wsc_flip_status = 8
                    self.ssc_flip_status = 8
                    if self.instr == "conv":
                        self.ssc_flip_status = 0

                self.smov.generate(
                    self.indent,
                    dst=self.gib1_addr.register,
                    src1=self.operator.pingpong_b[0],
                    comment="// Init buf b offset with input value")
                if (
                    self.operator.name == "fwd_conv" or self.operator.name == "bpa_conv"
                ) and self.operator.filter_w > 1:

                    self.gib1_addr.buf_address_flip = icd.HALF_BUFFER_B_SIZE

                    wsc_first_channel = icd.CONV_TO_LDCONV1_START_STATION
                    ssc_first_channel = icd.LDCONV1_TO_CONV_START_STATION
                    if self.instr == "buf_b_ld":
                        ssc_first_channel = int(
                            self.operator.pingpong_b[0] /
                            icd.BUFFER_ADDRESS_TO_SYNC_SHILT)
                        wsc_first_channel = (
                            ssc_first_channel + icd.SET_SYNC_TO_WAIT_DIFF)
                    elif self.instr == "conv":
                        wsc_first_channel = int(
                            self.operator.pingpong_b[0] /
                            icd.BUFFER_ADDRESS_TO_SYNC_SHILT)
                        ssc_first_channel = (
                            wsc_first_channel + icd.SET_SYNC_TO_WAIT_DIFF)

                    self.smov.generate(
                        self.indent,
                        dst=self.wsc_reg,
                        src1=wsc_first_channel,
                        comment="// Init WSC value with gib1 address")
                    self.smov.generate(
                        self.indent,
                        dst=self.ssc_reg,
                        src1=ssc_first_channel,
                        comment="// Init SSC value with gib1 address")
                    if not icd.ENABLE_ROW_ACCUMULATION:
                        self.smov.generate(
                            self.indent,
                            dst=self.wsc_reg_row,
                            src1=wsc_first_channel,
                            comment="// Init WSC value with gib1 address for row")
                        self.smov.generate(
                            self.indent,
                            dst=self.ssc_reg_row,
                            src1=ssc_first_channel,
                            comment="// Init SSC value with gib1 address for row")

    def check_if_exist_later_operation_for_front(self, mod, loop_config):
        if self.operator.name == "bpw_mma" and loop_config[1] > 1:
            return True
        return False

    def get_innermost_col_iterations(self):
        for config in self.loop_config:
            if len(self.col_loop_configs) == self.col_levels and config[0] == "col":
                return config[1]
        return 1

    def get_innermost_row_iterations(self):
        for config in self.loop_config:
            if len(self.row_loop_configs) == self.row_levels and config[0] == "row":
                return config[1]
        return 1

    def add_extra_handling_in_back(self, loop_config):
        e = loop_config[0]
        if self.instr == "conv":
            # if len(self.col_loop_configs) == self.col_levels and "col" in e[0]:
            #     self.flip_buf_b_address()

            if len(self.row_loop_configs) == self.row_levels and "row" in e[0]:
                if not self.enable_row_accumulate:
                    if self.get_innermost_col_iterations() == 1:
                        if self.operator.stride == 1 and self.operator.filter_w > 1:
                            self.sadda.generate(
                                indent_level=self.indent,
                                dst="a1",
                                src1=self.inner_a1,
                                src2=2,
                                comment="// Increase a1 for next loop")

            if self.operator.stride == 1 and self.operator.filter_w > 1:
                if self.enable_row_accumulate and "row" in e[0]:
                    if len(self.row_loop_configs) == self.row_levels:
                        e_next = loop_config[1]
                        if e_next[2] == e_next[1]:
                            acc = 0
                        else:
                            acc = e_next[1] * icd.OC64_TLR_SIZE
                        ordinal = self.get_unrolled_interation_ordinal(e)
                        if ordinal[1] != -1:
                            if ((self.row_a1_accumulation + 1) % icd.BURST_TLR_SIZE == 0 and
                                 self.row_a1_accumulation != 0):
                                if e_next[2] != e_next[1]:
                                    self.sadda.generate(
                                        indent_level=self.indent,
                                        dst="a1",
                                        src1=icd.BURST_TLR_SIZE - acc,
                                        src2="a1",
                                        comment="// Increase a1 for next row"
                                    )
                                else:
                                    # e_next_ordinal = self.get_unrolled_interation_ordinal(e_next)
                                    # iterations = e_next_ordinal[0] - e_next_ordinal[1]
                                    self.sadda.generate(
                                        indent_level=self.indent,
                                        dst="a1",
                                        src1=icd.BURST_TLR_SIZE + 1 + icd.OC64_TLR_SIZE * (e_next[2]-1),
                                        src2="a1",
                                        comment="// Increase a1 for next row"
                                    )
                            else:
                                self.sadda.generate(
                                    indent_level=self.indent,
                                    dst="a1",
                                    src1=1 - acc,
                                    src2="a1",
                                    comment="// Increase a1 for next row"
                                )
                            self.row_a1_accumulation += 1
                        else:
                            self.row_a1_accumulation = 0
                if self.enable_row_accumulate and "oc" in e[0]:
                    if len(self.oc_loop_configs) == self.oc_levels:
                        ordinal = self.get_unrolled_interation_ordinal(e)
                        iterations = ordinal[0] - ordinal[1]
                        # Only needed for unroll disable case
                        if e[1] > 1 and e[1] != e[2]:
                            self.sadda.generate(
                                indent_level=self.indent,
                                dst="a1",
                                src1=icd.OC64_TLR_SIZE,
                                src2="a1",
                                comment="// Increase a1 for next oc64")

        mod, values = self.handle_loop_attribute_in_back(e)
        bar_sync_mod = None
        bar_set = None
        if self.instr == "conv" or self.instr == "mma":
            if len(e) >= 5:
                attr = e[4]
                # print("current_loop_config is ", current_loop_config)
                keys = attr.keys()
                if "bar_set" in keys:
                    bar_sync_mod = ".off.wnil.snil.b0nil.b1nil"
                    values["wbar_id"] = self.wbar_id_to_vector_reg
                    # values["warp_count"] = 16
                    bar_set = attr["bar_set"]
                if "tlr_bar_set" in keys:
                    if self.enable_row_accumulate:
                        ordinal = self.get_unrolled_interation_ordinal(e)
                        if ordinal[0] % 2 == 1 or ordinal[1] == -1:
                            bar_sync_mod = ".off.wnil.snil.b0nil.b1nil"
                            values["wbar_id"] = self.tlr_wbar_id_to_vector_reg
                            # values["warp_count"] = 16
                            bar_set = attr["tlr_bar_set"]
                        self.smovs.generate(
                            self.indent,
                            dst="a1",
                            src1=self.tlr_flip,
                            comment="// Set a1 with original tlr base",
                        )
                        if ordinal[0] % 2 == 0:
                            self.sxor.generate(
                                self.indent,
                                dst=self.tlr_flip,
                                src1=self.tlr_flip,
                                src2=icd.STRIDE_TLR_FLIP,
                                comment="// Flip tlr id Next two columns")
                    else:
                        bar_sync_mod = ".off.wnil.snil.b0nil.b1nil"
                        values["wbar_id"] = self.tlr_wbar_id_to_vector_reg
                        # values["warp_count"] = 16
                        bar_set = attr["tlr_bar_set"]
                        self.smovs.generate(
                            self.indent,
                            dst="a1",
                            src1=self.tlr_flip,
                            comment="// set a1 with flipped tlr",
                        )
        if bar_sync_mod is not None:
            # print("bar_sync_mod is ", bar_sync_mod)
            if mod is not None:
                mod += bar_sync_mod
            else:
                mod = bar_sync_mod
        loop_name = e[0]
        if (
            (loop_name != "ich")
            or (loop_name == "ich" and self.last_inner_oc)
            or (self.instr == "buf_a_ld")
        ):
            if mod is not None or bool(values):
                if self.check_exist_later_operation_for_back(
                    mod, bar_set, e
                ):
                    self.save_out_modifiers_to_stack((mod, values))
                    self.merge_out_off_modifiers(loop_config)
                else:
                    self.save_out_modifiers_to_stack((mod, values))

        if (mod is not None or bool(values)) and e[1] >= 1:
            if self.instr == "buf_a_ld" and "sset" in mod:
                if len(self.operator.pingpong_a) > 1:
                    self.sxor.generate(
                        self.indent,
                        dst=self.bufa_to_conv_sync_reg,
                        src1=self.bufa_to_conv_sync_reg,
                        src2=0x1,
                        comment="// Flip buf_a to conv sync register",
                    )
            if (self.instr == "conv" or self.instr == "mma") and "sset" in mod:
                if len(self.operator.pingpong_a) > 1:
                    self.sxor.generate(
                        self.indent,
                        dst=self.conv_to_bufa_sync_reg,
                        src1=self.conv_to_bufa_sync_reg,
                        src2=0x1,
                        comment="// Flip conv to buf_a sync register",
                    )
            if self.instr == "conv" or self.instr == "mma" or self.instr == "buf_a_ld":
                if "wset" in mod or "sset" in mod:
                    if len(self.operator.pingpong_a) > 1:
                        self.sxor.generate(
                            self.indent,
                            dst=self.gib0_addr.register,
                            src1=self.gib0_addr.register,
                            src2=0x100,
                            comment="// Flip buffer a address",
                        )
        if ((self.operator.name == "fwd_conv" or self.operator.name == "bpa_conv") and
            (self.instr == "conv" or self.instr == "buf_b_ld")
                and self.operator.filter_w > 1 and
                ((e[1] > 1 and e[2] <= e[1]/2) or "row" in e[0] or
                 "col" in e[0] or "sample" in e[0])):
            if self.enable_row_accumulate:
                if self.instr == "conv" and "sample" in e[0]:
                    if len(self.sample_loop_configs) == self.sample_levels:
                        # ordinal = self.get_unrolled_interation_ordinal(e)
                        # iterations = ordinal[0] - ordinal[1]
                        # if ordinal[1] == -1:
                        # self.ssc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                        # This is for solving the issue that wset can't be winc with off
                        e_next = loop_config[1]
                        # iter_next = e_next[1]
                        if (e_next[1] == e_next[2] or
                                (e_next[1] != e_next[2] and e_next[2] % 2 == 0)):
                            self.sxor.generate(
                                self.indent,
                                dst=self.ssc_reg,
                                src1=self.ssc_reg,
                                src2=icd.SYNC_CHANNEL_FLIP,
                                comment="// Flip ssc sync channel to the appropriate side")

                        e_next_next = loop_config[2]
                        if self.operator.stride==1:
                            e_next_next = loop_config[3]
                        iter = e_next_next[1]
                        total_accumulate = int(
                                (iter + self.accu_times - 1)/self.accu_times)
                        # print("e_next_next is ", e_next_next)
                        # print("self.accu_times is ", self.accu_times)
                        # print("total_accumulate is ", total_accumulate)
                        for i in range(total_accumulate):
                            ssc = (self.ssc_reg + "__" +
                                   "{}".format(i))
                            self.operator.operator[self.instr].generate(
                                indent=self.indent,
                                ssc=ssc,
                                modifier="off.b0nil.b1nil.ini0.out0.wnil.sset",
                                transient=True)
                        # if self.operator.tensor_b[0] > 1:
                        #     self.sxor.generate(
                        #         self.indent,
                        #         dst=self.ssc_reg,
                        #         src1=self.ssc_reg,
                        #         src2=icd.SYNC_CHANNEL_FLIP,
                        #         comment="// Flip ssc sync channel back to original side")
                elif "col" in e[0]:
                    if len(self.col_loop_configs) == self.col_levels:
                        if e[1] > 1 and (self.instr != "conv" or self.operator.stride==0):  # conv alwasy unrolled two columns
                            self.sxor.generate(
                                self.indent,
                                dst=self.gib1_addr.register,
                                src1=self.gib1_addr.register,
                                src2=icd.HALF_BUFFER_B_SIZE,
                                comment="// Flip gib1_addr for next col")
                            self.sxor.generate(
                                self.indent,
                                dst=self.wsc_reg,
                                src1=self.wsc_reg,
                                src2=icd.SYNC_CHANNEL_FLIP,
                                comment="// Flip wsc sync channel for next col")
                            self.sxor.generate(
                                self.indent,
                                dst=self.ssc_reg,
                                src1=self.ssc_reg,
                                src2=icd.SYNC_CHANNEL_FLIP,
                                comment="// Flip ssc sync channel for next col")

            else:
                if self.instr == "conv" or self.instr == "buf_b_ld":
                    if len(self.col_loop_configs) == self.col_levels and "col" in e[0]:
                        # print("e in conv or buf_b_ld is ", e, e[2]%2)
                        self.wsc_flip_status_last_col = self.wsc_flip_status
                        self.ssc_flip_status_last_col = self.ssc_flip_status
                        if e[1] >= 2:
                            e_next = loop_config[1]
                            if (("col_unroll" not in e_next[0] and e[2] % 2 == 1) or
                                    ("col_unroll" in e_next[0] and e_next[1] % 2 == 1)):
                                # if self.self.wsc_flip_status == 8:
                                self.sxor.generate(
                                    self.indent,
                                    dst=self.gib1_addr.register,
                                    src1=self.gib1_addr.register,
                                    src2=icd.HALF_BUFFER_B_SIZE,
                                    comment="// Flip gib1_addr for next col")
                                self.sxor.generate(
                                    self.indent,
                                    dst=self.wsc_reg,
                                    src1=self.wsc_reg,
                                    src2=icd.SYNC_CHANNEL_FLIP,
                                    comment="// Flip wsc sync channel for next col")
                                self.sxor.generate(
                                    self.indent,
                                    dst=self.ssc_reg,
                                    src1=self.ssc_reg,
                                    src2=icd.SYNC_CHANNEL_FLIP,
                                    comment="// Flip ssc sync channel for next col")
                                need_flip = 0
                                if self.instr == "conv":
                                    need_flip = e[1]%2
                                else:
                                    need_flip = (e[1]-1)%2
                                if need_flip == 1: # For odd iterations, special operation
                                    self.wsc_flip_status_last_col = (
                                        self.wsc_flip_status ^ icd.SYNC_CHANNEL_FLIP)
                                    self.ssc_flip_status_last_col = (
                                        self.ssc_flip_status ^ icd.SYNC_CHANNEL_FLIP)
                                    self.buffer_b_need_flip_back = True
                if len(self.row_loop_configs) == self.row_levels and "row" in e[0]:
                    if self.buffer_b_need_flip_back:
                        self.sxor.generate(
                            self.indent,
                            dst=self.gib1_addr.register,
                            src1=self.gib1_addr.register,
                            src2=icd.HALF_BUFFER_B_SIZE,
                            comment="// Flip gib1_addr back for next row")
                        self.sxor.generate(
                            self.indent,
                            dst=self.wsc_reg,
                            src1=self.wsc_reg,
                            src2=icd.SYNC_CHANNEL_FLIP,
                            comment="// Flip wsc sync channel back for next row")
                        self.sxor.generate(
                            self.indent,
                            dst=self.ssc_reg,
                            src1=self.ssc_reg,
                            src2=icd.SYNC_CHANNEL_FLIP,
                            comment="// Flip ssc sync channel back for next row")
                    if self.instr == "conv":
                        ssc = (self.ssc_reg + "__" +
                               "{}".format(self.ssc_flip_status_last_col))
                        # self.ssc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                        self.operator.operator[self.instr].generate(
                            indent=self.indent,
                            ssc=ssc,
                            modifier="off.b0nil.b1nil.ini0.out0.wnil.sset",
                            transient=True)
                        innermost_loop_config = self.loop_config[-1]
                        iter = innermost_loop_config[1] - 1
                        for i in range(iter):
                            self.operator.operator[self.instr].generate(
                                indent=self.indent,
                                modifier="off.b0nil.b1nil.ini0.out0.wnil.sinc",
                                transient=True)
                    if (self.get_unrolled_interation_ordinal(e)[1] != -1 or
                        e[1] > 1):
                        temp_reg = rm.wsr_alloc("temp_buffer_flipping_bit")
                        temp_wsc_reg = rm.wsr_alloc("temp_for_keeping_wsc_flipping_bit")
                        temp_ssc_reg = rm.wsr_alloc("temp_for_keeping_ssc_flipping_bit")
                        self.sand.generate(
                            self.indent,
                            dst=temp_reg,
                            src1=self.gib1_addr.register,
                            src2=icd.HALF_BUFFER_B_SIZE,
                            comment="// Save buffer b flipping bit")
                        self.sadd.generate(
                            self.indent,
                            dst=self.gib1_addr.register,
                            src1=self.gib1_addr.register,
                            src2=icd.GIB1_BUFFER_INCREASE_ENTRIES_NUM,
                            comment="// Increase buffer b address for next row")
                        self.sand.generate(
                            self.indent,
                            dst=temp_wsc_reg,
                            src1=self.ssc_reg_row,
                            src2=0x18,
                            comment="// Save ssc row sync channel flipping bit")
                        self.sand.generate(
                            self.indent,
                            dst=temp_ssc_reg,
                            src1=self.wsc_reg_row,
                            src2=0x18,
                            comment="// Save wsc row sync channel flipping bit")
                        self.sadd.generate(
                            self.indent,
                            dst=self.ssc_reg_row,
                            src1=self.ssc_reg_row,
                            src2=0x01,
                            comment="// Increase ssc row sync channel to match buf b address")
                        self.sadd.generate(
                            self.indent,
                            dst=self.wsc_reg_row,
                            src1=self.wsc_reg_row,
                            src2=0x01,
                            comment="// Increase wsc row sync channel to match buffer b address")
                        self.sand.generate(
                            self.indent,
                            dst=self.gib1_addr.register,
                            src1=self.gib1_addr.register,
                            src2=~icd.HALF_BUFFER_B_SIZE,
                            comment="// Clean the buffer b flipping bit")
                        self.sand.generate(
                            self.indent,
                            dst=self.wsc_reg_row,
                            src1=self.wsc_reg_row,
                            src2=~0x08,
                            comment="// Clean flipping bit for wsc")
                        self.sand.generate(
                            self.indent,
                            dst=self.ssc_reg_row,
                            src1=self.ssc_reg_row,
                            src2=~0x08,
                            comment="// Clean flipping bit for ssc")
                        self.sor.generate(
                            self.indent,
                            dst=self.wsc_reg,
                            src1=self.wsc_reg_row,
                            src2=temp_wsc_reg,
                            comment="// Restore wsc sync flipping bits")
                        self.sor.generate(
                            self.indent,
                            dst=self.ssc_reg,
                            src1=self.ssc_reg_row,
                            src2=temp_ssc_reg,
                            comment="// Restore ssc sync flipping bits")
                        self.sor.generate(
                            self.indent,
                            dst=self.wsc_reg_row,
                            src1=self.wsc_reg_row,
                            src2=temp_wsc_reg,
                            comment="// Restore wsc sync flipping bits for backup register")
                        self.sor.generate(
                            self.indent,
                            dst=self.ssc_reg_row,
                            src1=self.ssc_reg_row,
                            src2=temp_ssc_reg,
                            comment="// Restore ssc sync flipping bits for backup register")
                        self.wsc_flip_status = 0
                        self.ssc_flip_status = 0
                        if self.instr == "conv":
                            self.wsc_flip_status = 8
                        self.sor.generate(
                            self.indent,
                            dst=self.gib1_addr.register,
                            src1=self.gib1_addr.register,
                            src2=temp_reg,
                            comment="// Restore buffer b flipping bit")
                        rm.wsr_free(temp_reg)
                        rm.wsr_free(temp_wsc_reg)
                        rm.wsr_free(temp_ssc_reg)

    def check_exist_later_operation_for_back(self, mod, bar_set, current_loop_config):
        e = current_loop_config
        if self.instr == "conv":
            if "oc" in e[0]:
                if len(self.oc_loop_configs) == self.oc_levels - 1:
                    return True
        if e[1] <= 1:
            return False
        elif mod is not None:
            if bar_set and len(bar_set) > 1:
                return True
            if self.instr == "buf_a_ld" and "sset" in mod:
                return True
            if self.instr == "conv" and "sset" in mod:
                if len(self.operator.pingpong_a) > 1:
                    return True
            if self.instr == "conv" or self.instr == "buf_a_ld":
                if "wset" in mod or "sset" in mod:
                    if len(self.operator.pingpong_a) > 1:
                        return True
        return False

    def save_out_modifiers_to_stack(self, mod_value):
        self.out_off_modifier_stack.append(mod_value)

    def save_in_modifiers_to_stack(self, mod_value):
        self.in_off_modifier_stack.append(mod_value)

    def merge_out_off_modifiers(self, loop_config=None, force=False):
        # print("Current operator type is ", self.instr)
        # print("self.out_off_modifier_stack is ", self.out_off_modifier_stack)
        if len(self.out_off_modifier_stack) < 1:
            return

        # Merge off instructions of back if loop iterations is greater than 1
        # or this is the last loop config
        if (force or (loop_config[0][1] > 1) or
                (len(loop_config) == len(self.loop_config))):
            # print("Current operator type is ", self.instr)
            mod = ""
            values = {}
            num = len(self.out_off_modifier_stack)
            for i in range(num):
                t = self.out_off_modifier_stack[-1]
                if self.check_if_two_dict_share_a_key(t[1], values):
                    break
                t = self.out_off_modifier_stack.pop()
                if t[0] is not None:
                    mod += "." + t[0]
                if t[1] is not None:
                    values.update(t[1])
                # print("t[0] and t[1] is ", t[0], t[1])
            if "wset" in mod:
                mod = mod.replace(".wnil", "")
            if "sset" in mod:
                mod = mod.replace(".snil", "")

            if mod != "" or bool(values):
                self.operator.operator[self.instr].generate(
                    indent=self.indent, **values, modifier=mod
                )

            ##################################################
            if "wbar_id" in values.keys():
                self.sxor.generate(
                    self.indent,
                    dst=values["wbar_id"],
                    src1=values["wbar_id"],
                    src2=0x1,
                    comment="// Flip bar id register",
                )
            if len(self.out_off_modifier_stack) > 0:
                self.merge_out_off_modifiers(loop_config, force)

    def prehandle_loop_attribute(self, loop_config):
        e = loop_config[0]
        # print("length of e is ", len(e))
        if len(e) < 5:
            return
        keys = e[4].keys()
        item = e[4]
        if (
            "wset" in keys
            and self.instr == "buf_a_ld"
            or "sset" in keys
            and self.instr == "buf_a_ld"
            or "wset" in keys
            and self.instr == "conv"
            or "sset" in keys
            and self.instr == "conv"
        ):
            # print("item[sset] is ", item["sset"])
            # print("item[wset] is ", item["wset"])
            if len(item["sset"]) != len(item["wset"]):
                print("Error: wset and sset is not consistent!")
            elif len(item["sset"]) == 2 and len(item["wset"]) == 2:
                if self.operator.pingpong_a is None:
                    print("Error: Buffer A should be configured as pingpong!")
                    return

    def check_if_two_dict_share_a_key(self, d1, d2):
        for k in d1.keys():
            if k in d2.keys():
                return True
        return False

    def merge_in_off_modifiers(self, loop_config, condition=False):
        if len(self.in_off_modifier_stack) < 1:
            return
        e = loop_config[0]
        n = len(loop_config)
        if not isinstance(loop_config, list):
            return
        if (
            (e[1] > 1 and (self.operator.name == "mma" or self.operator.name == "bpw_mma"))
            or (n > 2 and e[1] > 1 and self.operator.filter_w > 1)
            or (e[1] > 1 and self.operator.filter_w == 1)
            or condition
        ):
            mod = ""
            values = {}
            num = len(self.in_off_modifier_stack)
            jump_item = []
            for i in range(num):
                t = self.in_off_modifier_stack[0]
                if self.check_if_two_dict_share_a_key(t[1], values):
                    jump_item.append(t)
                    self.in_off_modifier_stack.remove(t)
                    continue

                self.in_off_modifier_stack.remove(t)
                if t[0] is not None:
                    mod += "." + t[0]
                if t[1] is not None:
                    values.update(t[1])
                # print("t[0] and t[1] is ", t[0], t[1])
            for item in jump_item:
                if item not in self.in_off_modifier_stack:
                    self.in_off_modifier_stack.append(item)

            if "wset" in mod or "winc" in mod:
                mod = mod.replace(".wnil", "")
            if "sset" in mod or "sinc" in mod:
                mod = mod.replace(".snil", "")
            if "setx" in mod:
                mod = mod.replace(".incx0", "")
            if "sety" in mod:
                mod = mod.replace(".incy0", "")
            if "setz" in mod:
                mod = mod.replace(".incz0", "")
            if mod != "" or bool(values):
                self.operator.operator[self.instr].generate(
                    indent=self.indent, **values, modifier=mod
                )
            if len(self.in_off_modifier_stack) > 0:
                self.merge_in_off_modifiers(loop_config, condition)

    def add_instruction_to_set_coordiante_modifier(self, loop_configs):
        e = loop_configs[0]
        mod = ""
        values = dict()

        start = 0
        if len(e) > 4:
            attrib = e[4]
            if "start" in attrib.keys():
                start = attrib["start"]
        if self.operator.name != "mma" and self.instr != "mma":
            ordinal = self.get_unrolled_interation_ordinal(e)
            if self.instr == "buf_a_ld":
                mod += ".off.incy0.incz0.b0nil.wnil.snil"
            elif self.instr == "buf_b_ld":
                mod += ".off.incx0.incy0.incz0.b1nil.po.snil.wnil"
            else:
                mod += ".off.b0nil.b1nil.wnil.snil"
            if "ic" in e[0]:
                if len(self.ic_loop_configs) == self.ic_levels:
                    if self.operator.name == "bpw_mma":
                        mod += ".setz"
                        if len(self.ic_regs) > 1:
                            values["z"] = self.ic_regs
                        else:
                            values["z"] = start
            if "oc" in e[0]:
                if len(self.oc_loop_configs) == self.oc_levels:
                    if ordinal[0] == 0:
                        if self.operator.name != "bpw_mma":
                            if self.instr == "buf_a_ld":
                                mod += ".setz"
                                if len(self.oc_regs) > 1:
                                    values["z"] = self.oc_regs
                                else:
                                    values["z"] = start
            if "col" in e[0]:
                if len(self.col_loop_configs) == self.col_levels:
                    if self.instr != "conv":
                        if ordinal[0] == 0:
                            mod += ".setx"
                            values["x"] = start
                    elif self.operator.stride == 0:
                        if len(self.col_regs) >= 1:
                            values["x"] = self.col_regs
                        else:
                            values["x"] = start
            if "kw" in e[0]:
                # must be unrolled for this loop
                if len(self.kw_loop_configs) == self.kw_levels:
                    if self.instr == "buf_b_ld" and self.operator.name == "bpw_mma":
                        ordinal = self.get_unrolled_interation_ordinal(e)
                        if ordinal[0] != 0:
                            self.sand.generate(
                                self.indent,
                                dst="q0",
                                src1="q0",
                                src2=~icd.PAD_X_MASK,
                                comment="// Clear padx bits")
                            padx = self.operator.bpw_padx - start
                            padx = padx << icd.PAD_X_START_BIT
                            self.sor.generate(
                                self.indent,
                                dst="q0",
                                src1="q0",
                                src2=padx,
                                comment="// Set padx accordingly")
            if "row" in e[0]:
                if len(self.row_loop_configs) == self.row_levels:
                    if not self.enable_row_accumulate:
                        self.buffer_b_flip_status = 0
                    if self.instr != "conv":
                        if ordinal[0] == 0:
                            mod += ".sety"
                            values["y"] = start
                    elif self.operator.stride == 0:
                        if len(self.row_regs) >= 1:
                            values["y"] = self.row_regs
                        else:
                            values["y"] = start
                    # if self.operator.filter_width == 1 and self.operator.stride == 0:
                    #     self.gib1_addr.
                    #     values["gib1_addr"] = self.gib1_addr
            if "sample" in e[0]:
                if len(self.sample_loop_configs) == self.sample_levels:
                    if ordinal[0] == 0:
                        if self.instr == "conv":
                            values[
                                "gib0_step"
                            ] = self.operator.required_buffer_a_entries_per_ld
                            values[
                                "gib1_step"
                            ] = self.operator.required_buffer_b_entries_per_ld
                        if self.instr == "buf_b_ld":
                            values[
                                "gib1_step"
                            ] = self.operator.required_buffer_b_entries_per_ld
                    if self.operator.stride != 1:
                        values["w"] = start
        else:  # for mma
            if len(loop_configs) > 1:
                mod += ".off.wnil.snil"
                if self.instr == "mma":
                    mod += ".ini0.out0.wnil.snil"
                    if "col" in e[0]:
                        values["x"] = self.col_regs
                    if "row" in e[0]:
                        values["y"] = self.row_regs
                    if len(loop_configs) == 2 and self.operator.name != "bpw_mma":
                        values["gib0_addr"] = self.operator.gib0_addr.register
                        values["gib1_addr"] = self.operator.gib1_addr.register
                        values[
                            "gib0_step"
                        ] = self.operator.required_buffer_a_entries_per_ld
                        values[
                            "gib1_step"
                        ] = self.operator.required_buffer_b_entries_per_ld
                    if self.operator.name == "bpw_mma":
                        if "kh" in e[0]:
                            ordinal = self.get_unrolled_interation_ordinal(e)
                            self.final_gib1_addr = (
                                self.bpw_mma_buf_b_addr + self.buf_b_entries_per_row*ordinal[0])
                        if "ich" in e[0]:
                            # ordinal = self.get_unrolled_interation_ordinal(e)
                            if len(self.ic_loop_configs) == self.ic_levels:
                                self.final_gib0_addr = self.bpw_mma_buf_a_addr
                else:  # for buf_a_ld and buf_b_ld
                    if len(loop_configs) == 2:
                        if "col" in e[0]:
                            mod += ".setx.sety"
                            values["x"] = self.col_regs
                            values["y"] = 0
                        if "row" in e[0]:
                            mod += ".setx.sety"
                            values["y"] = self.row_regs
                            values["x"] = 0
                        if self.instr == "buf_b_ld":
                            values["gib1_addr"] = self.operator.gib1_addr.register
                            values["gib1_step"] = (
                                self.operator.required_buffer_b_entries_per_ld)
                        else:
                            values["gib0_addr"] = self.operator.gib0_addr.register
                            values["gib0_step"] = (
                                self.operator.required_buffer_a_entries_per_ld)
                    else:
                        if "col" in e[0]:
                            mod += ".setx.incy0"
                            values["x"] = self.col_regs
                        if "row" in e[0]:
                            mod += ".incx0.sety"
                            values["y"] = self.row_regs

        if values:
            e = loop_configs[0]
            if self.instr != "conv" and (
                self.operator.name == "fwd_conv" or self.operator.name == "bpa_conv"
            ):
                self.save_in_modifiers_to_stack((mod, values))
            else:
                if self.check_if_exist_later_operation_for_front(mod, e):
                    self.save_in_modifiers_to_stack((mod, values))
                    self.merge_in_off_modifiers(loop_configs)
                else:
                    self.save_in_modifiers_to_stack((mod, values))

    def get_pre_loop_modifier(self, loop_configs):
        e = loop_configs[0]
        mod = None
        values = dict()

        if len(e) < 5:
            return mod, values
        if isinstance(e[4], br_utils.Br_Iterations):
            return mod, values
        keys = e[4].keys()
        # item = loop_config[4]
        if "wset" in keys:
            if mod is not None:
                mod += ".off.wset.snil.b0nil.b1nil"
            else:
                mod = ".off.wset.snil.b0nil.b1nil"
            if self.instr == "buf_a_ld":
                if self.operator.name == "fwd_conv" or self.operator.name == "bpa_conv":
                    mod += ".incy0.incz0"
                else:
                    mod += ".incx0.incy0"
                values["wsc"] = self.conv_to_bufa_sync_reg
                values["gib0_addr"] = self.gib0_addr.register
                values["gib0_step"] = self.operator.required_buffer_a_entries_per_ld
            if self.instr == "conv" or self.instr == "mma":
                if mod:
                    mod += ".ini0.out0"
                else:
                    mod = ".ini0.out0"
                values["wsc"] = self.bufa_to_conv_sync_reg

        if self.operator.stride == 1 and self.instr == "conv":
            values["x"] = None
            values["y"] = None
            values["z"] = None

        # print("mod, values are", mod, values)
        return mod, values

    def handle_loop_attribute_in_back(self, loop_config):
        mod = None
        values = OrderedDict()
        # print("length of e is ", len(e))
        if len(loop_config) < 5:
            return mod, values
        if isinstance(loop_config[4], br_utils.Br_Iterations):
            return mod, None
        # print("loop_config is ", loop_config)
        keys = loop_config[4].keys()
        if "sset" in keys:
            mod = "off.wnil.sset.b0nil.b1nil"
            if self.instr == "buf_a_ld":
                if self.operator.name == "fwd_conv" or self.operator.name == "bpa_conv":
                    mod += ".incy0.incz0.sset"
                elif self.operator.name == "mma":
                    mod += ".incx0.incy0.sset"
                values["ssc"] = self.bufa_to_conv_sync_reg
            if self.instr == "conv" or self.instr == "mma":
                mod += ".ini0.out0.sset"
                values["ssc"] = self.conv_to_bufa_sync_reg

        return mod, values

    def get_inner_oc_loop_iterations(self):
        for config in self.loop_config:
            if config[0] == "inner_oc" and config[1] > 1:
                return True
        return False

    def get_prolog_epilog_iterations(self, loop_configs):
        return 0, 0

    def get_iterations_and_unrolls_no_prolog_epilog(self, loop_configs, prolog, epilog):
        e = loop_configs[0]
        i = e[1]
        u = e[2]
        rest_iterations = i - prolog - epilog
        if rest_iterations <= 0:
            return 0, 0
        unroll_times = min(rest_iterations, u)
        if unroll_times > int(rest_iterations / 2):
            unroll_times = rest_iterations
        unroll_times = max(unroll_times, 1)
        last_iter = int(rest_iterations / unroll_times)
        return last_iter, unroll_times

    def get_unrolled_interation_ordinal(self, config):
        ordinal = (0, -1)
        if not config:
            return ordinal
        name = config[0]
        if "unroll" in name:
            s = name.split("_")
            ordinal = (int(s[-2]), int(s[-1]))
        # print("loop name and ordinal is ", name, ordinal)
        return ordinal

    def check_if_need_set_gib0_addr(self, loop_configs):
        if len(loop_configs) < 2:
            next_loop = loop_configs[1]
            if "inner_oc" in next_loop[0]:
                if self.operator.buf_a_total_iterations > 1:
                    self.need_set_gib0_addr = True

    def check_if_need_set_gib1_addr(self, loop_configs):
        pass

    def check_if_need_flip_oc_slot(self):
        for config in self.loop_config:
            if "oc" in config[0] and "inner_oc" not in config[0]:
                if config[1] > 1:
                    self.need_flip_oc_slot = True
                    return
        self.need_flip_oc_slot = False

    def check_if_full_unrolled(self):
        full_unrolled = True
        for config in self.loop_config:
            if config[2] <= int(config[1]/2):
                full_unrolled = False
                break
        return full_unrolled

    def print_loop_config(self, loop_config):
        if isinstance(self.indent, Br_Indent):
            indent = self.indent.indent
        else:
            indent = self.indent

        br_print(" " * indent * 4 + "// Begin loop: ", loop_config)

    def unroll_innermost_loop(self):
        innermost_loop = self.loop_config[-1]
        innermost_loop = list(innermost_loop)
        innermost_loop[2] = innermost_loop[1]
        innermost_loop = tuple(innermost_loop)
        self.loop_config[-1] = innermost_loop

    def insert_unroll_loop_level(self):
        new_loop_config = []
        # print("self.loop_config is in insert_unroll_loop_level", self.loop_config)
        for i in range(len(self.loop_config)):
            config = self.loop_config[i]
            unrolls = config[2]
            original_iterations = config[1]
            final_iterations = int(original_iterations / unrolls)
            remainder = original_iterations - final_iterations * unrolls

            if final_iterations < original_iterations:
                if final_iterations != 1:
                    new_config = copy.deepcopy(list(config))
                    new_config[0] = config[0]
                    new_config[1] = final_iterations
                    new_config[2] = 1
                    new_config[3] = unrolls * config[3]
                    # if "col" == config[0]:
                    new_config[4] = {"start": config[4]["start"]}
                    new_config = tuple(new_config)
                    if remainder:
                        remainder_config = copy.deepcopy(list(config))
                        remainder_config[0] = config[0] + "_remainder"
                        remainder_config[1] = remainder
                        remainder_config[2] = remainder
                        remainder_config[3] = unrolls * config[3]
                        remainder_config[4]["start"] = config[4]["start"] + new_config[3]
                        remainder_config = tuple(remainder_config)
                        new_config = [new_config, remainder_config]

                    new_loop_config.append(new_config)

                    new_config = copy.deepcopy(list(config))
                    new_config[0] = config[0] + "_unroll_inner"
                    new_config[1] = unrolls
                    new_config[2] = unrolls
                    new_config[4] = config[4]
                    new_config = tuple(new_config)
                    new_loop_config.append(new_config)
                else:
                    new_config = copy.deepcopy(config)
                    new_loop_config.append(new_config)
            else:
                new_config = copy.deepcopy(config)
                new_loop_config.append(new_config)
        self.loop_config = new_loop_config
        # print("After self.loop_config is in insert_unroll_loop_level", self.loop_config)

    def generate_actual_loops_with_unrolls(
            self, loop_config, prefix, comment=None, sample=None,
            acculast=False, accufirst=False, innermost_h=None,
            innermost_w=None, innermost_oc=None, innermost_sample=None,
            innermost_ic=None, innermost_kw=None, innermost_kh=None,
            innermore_kw=None, innermore_ic=None, innermore_oc=None,
            innermore_h=None, innermore_w=None):
        config = loop_config[0]
        if isinstance(config, tuple):
            unrolls = config[2]
            original_iterations = config[1]
            final_iterations = int(original_iterations / unrolls)
            if final_iterations < original_iterations:
                if final_iterations == 1:
                    start = config[4]["start"]
                    name = config[0]
                    for i in range(unrolls):
                        new_config = list(config)
                        if "_unroll" not in config[0]:
                            new_config[0] = (
                                name + "_unroll_{}".format(i))
                        else:
                            new_config[0] = name + "_{}".format(i)
                        reverse_ordinal = -(unrolls - i)
                        new_config[0] += "_{}".format(reverse_ordinal)
                        new_config[1] = 1
                        new_config[2] = 1
                        # new_config[4] = config[4]
                        new_config[4]["start"] = start + i * config[3]
                        new_config = tuple(new_config)
                        new_loop_config = copy.deepcopy(loop_config[1:])
                        new_loop_config.insert(0, new_config)
                        # prefix = "loop{}".format(i)
                        # if "row" in config[0]:
                        # print("new_loop_config is ", new_loop_config)
                        innermost_h, innermost_w, innermost_oc, innermost_sample, innermost_ic = (
                            self.get_innermost_h_w_oc_sample_loop_config(
                                new_loop_config, innermost_h, innermost_w,
                                innermost_oc, innermost_sample, innermost_ic))
                        innermost_kw, innermost_kh, innermore_kw, innermore_ic, innermore_oc, innermore_h, innermore_w = (
                            self.get_innermore_h_w_kh_hw_oc_sample_loop_config(
                                new_loop_config, innermost_kw, innermost_kh,
                                innermore_kw, innermore_ic, innermore_oc,
                                innermore_h, innermore_w))
                        self.generate_actual_loops(
                            new_loop_config, prefix, comment=comment,
                            sample=sample, acculast=acculast,
                            accufirst=accufirst, innermost_h=innermost_h,
                            innermost_w=innermost_w,
                            innermost_oc=innermost_oc,
                            innermost_sample=innermost_sample,
                            innermost_ic=innermost_ic,
                            innermost_kw=innermost_kw,
                            innermost_kh=innermost_kh,
                            innermore_kw=innermore_kw,
                            innermore_ic=innermore_ic,
                            innermore_oc=innermore_oc,
                            innermore_h=innermore_h,
                            innermore_w=innermore_w)
            else:
                innermost_h, innermost_w, innermost_oc, innermost_sample, innermost_ic = (
                    self.get_innermost_h_w_oc_sample_loop_config(
                        loop_config, innermost_h, innermost_w,
                        innermost_oc, innermost_sample, innermost_ic))
                innermost_kw, innermost_kh, innermore_kw, innermore_ic, innermore_oc, innermore_h, innermore_w = (
                    self.get_innermore_h_w_kh_hw_oc_sample_loop_config(
                        loop_config, innermost_kw, innermost_kh,
                        innermore_kw, innermore_ic, innermore_oc,
                        innermore_h, innermore_w))
                self.generate_actual_loops(
                    loop_config, prefix, comment=comment, sample=sample,
                    acculast=acculast, accufirst=accufirst,
                    innermost_h=innermost_h,
                    innermost_w=innermost_w,
                    innermost_oc=innermost_oc,
                    innermost_sample=innermost_sample,
                    innermost_ic=innermost_ic,
                    innermost_kw=innermost_kw,
                    innermost_kh=innermost_kh,
                    innermore_kw=innermore_kw,
                    innermore_ic=innermore_ic,
                    innermore_oc=innermore_oc,
                    innermore_h=innermore_h,
                    innermore_w=innermore_w)
        else:  # is a list
            for c in config:
                new_loop_config = copy.deepcopy(loop_config[1:])
                new_loop_config.insert(0, c)
                # print("loop_config is ", loop_config)
                innermost_h, innermost_w, innermost_oc, innermost_sample, innermost_ic = (
                    self.get_innermost_h_w_oc_sample_loop_config(
                        new_loop_config, innermost_h, innermost_w,
                        innermost_oc, innermost_sample,
                        innermost_ic, innermost_ic))
                innermost_kw, innermost_kh, innermore_kw, innermore_ic, innermore_oc, innermore_h, innermore_w = (
                    self.get_innermore_h_w_kh_hw_oc_sample_loop_config(
                        new_loop_config, innermost_kw, innermost_kh,
                        innermore_kw, innermore_ic, innermore_oc,
                        innermore_h, innermore_w))
                self.generate_actual_loops(
                    new_loop_config, prefix, comment=comment, sample=sample,
                    acculast=acculast, accufirst=accufirst,
                    innermost_h=innermost_h,
                    innermost_w=innermost_w,
                    innermost_oc=innermost_oc,
                    innermost_sample=innermost_sample,
                    innermost_ic=innermost_ic,
                    innermost_kw=innermost_kw,
                    innermost_kh=innermost_kh,
                    innermore_kw=innermore_kw,
                    innermore_ic=innermore_ic,
                    innermore_oc=innermore_oc,
                    innermore_h=innermore_h,
                    innermore_w=innermore_w)

    def get_innermost_h_w_oc_sample_loop_config(
            self, loop_config, innermost_h=None, innermost_w=None,
            innermost_oc=None, innermost_sample=None, innermost_ic=None):
        e = loop_config[0]
        if "row" in e[0]:
            if len(self.row_loop_configs) == self.row_levels-1:
                innermost_h = e
        if "col" in e[0]:
            if len(self.col_loop_configs) == self.col_levels-1:
                innermost_w = e
        if "oc" in e[0]:
            if len(self.oc_loop_configs) == self.oc_levels-1:
                innermost_oc = e
        if "sample" in e[0]:
            if len(self.sample_loop_configs) == self.sample_levels-1:
                innermost_sample = e
        if self.operator.name == "bpw_mma":
            if "ic" in e[0]:
                if len(self.ic_loop_configs) == self.ic_levels-1:
                    innermost_ic = e
        return innermost_h, innermost_w, innermost_oc, innermost_sample, innermost_ic

    def get_innermore_h_w_kh_hw_oc_sample_loop_config(
            self, loop_config, innermost_kw=None, innermost_kh=None,
            innermore_kw=None, innermore_ic=None, innermore_oc=None,
            innermore_h=None, innermore_w=None):
        if self.operator.name != "bpw_mma" and self.instr != "mma":
            return innermost_kw, innermost_kh, innermore_kw, innermore_ic, innermore_oc, innermore_h, innermore_w
        e = loop_config[0]
        if "kw" in e[0]:
            if len(self.kw_loop_configs) == self.kw_levels-1:
                innermost_kw = e
        if "kh" in e[0]:
            if len(self.kh_loop_configs) == self.kh_levels-1:
                innermost_kh = e

        if "row" in e[0]:
            if len(self.row_loop_configs) == self.row_levels-2:
                innermore_h = e
        if "col" in e[0]:
            if len(self.col_loop_configs) == self.col_levels-2:
                innermore_w = e
        if "oc" in e[0]:
            if len(self.oc_loop_configs) == self.oc_levels-2:
                innermore_oc = e
        if "ic" in e[0]:
            if len(self.ic_loop_configs) == self.ic_levels-2:
                innermore_ic = e
        if "kw" in e[0]:
            if len(self.kw_loop_configs) == self.kw_levels-2:
                innermore_kw = e
        return innermost_kw, innermost_kh, innermore_kw, innermore_ic, innermore_oc, innermore_h, innermore_w
