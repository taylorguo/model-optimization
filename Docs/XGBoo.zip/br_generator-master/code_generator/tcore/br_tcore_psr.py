#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import code_generator.share.br_vector_instructions_def as vid
from code_generator.share import br_top

Padx_Pady = {
    "0": 0,
    "1": 1,
    "2": 2,
    "3": 3,
    "-3": 5,
    "-2": 6,
    "-1": 7
}

Stride_Dilation = {
    "1": 0,
    "2": 1
}

Direction = {
    "fwd": 0,
    "bwd": 1
}

BwdType = {
    "bpa": 0,
    "bpw": 1
}

HalfTLR = {
    "htlr0": 0,
    "htlr1": 1
}


class psr(br_top.top):
    def __init__(
            self, filter_width, filter_height, padx, pady, stride=1,
            dilation=0, direction="fwd", bwdtype=None, halftlr=None,
            indent=None):
        super().__init__()
        self.filter_width = filter_width
        self.filter_height = filter_height
        self.padx = padx
        self.pady = pady
        self.stride = stride
        self.dilation = dilation
        self.direction = direction
        self.bwdtype = bwdtype
        self.halftlr = halftlr

        self.smov = vid.smov(indent)
        self.nop = vid.nop(indent)
        self.produced_count = 0
        self.psr = None
        self.indent = indent

        self.filter_width_back = self.filter_width
        self.filter_height_back = self.filter_height
        self.padx_back = self.padx
        self.pady_back = self.pady
        self.stride_back = self.stride
        self.dilation_back = self.dilation
        self.direction_back = self.direction
        self.bwdtype_back = self.bwdtype
        self.halftlr_back = self.halftlr

    def reset(self):
        self.filter_width = self.filter_width_back
        self.filter_height = self.filter_height_back
        self.padx = self.padx_back
        self.pady = self.pady_back
        self.stride = self.stride_back
        self.dilation = self.dilation_back
        self.direction = self.direction_back
        self.bwdtype = self.bwdtype_back
        self.halftlr = self.halftlr_back

    def generate(
            self, indent=None, filter_width=None, filter_height=None,
            padx=None, pady=None, stride=None, dilation=None,
            direction=None, bwdtype=None, halftlr=None, transient=False):
        if indent is not None:
            self.indent = indent
        if filter_width is not None and not transient:
            self.filter_width = filter_width
        if filter_height is not None and not transient:
            self.filter_height = filter_height
        if padx is not None:
            self.padx = padx
        if pady is not None:
            self.pady = pady
        if stride is not None:
            self.stride = stride
        if dilation is not None:
            self.dilation = dilation
        if direction is not None:
            self.direction = direction
        if bwdtype is not None:
            self.bwdtype = bwdtype
        if halftlr is not None:
            self.halftlr = halftlr

        # print("type of self.pady is ", type(self.pady))
        padx_str = "{}".format(self.padx)
        pady_str = "{}".format(self.pady)
        # print("padx_str is ", padx_str)
        # print("pady_str is ", pady_str)
        psr = 0
        if transient:
            if filter_width:
                psr += filter_width & 0xf
            else:
                psr += self.filter_width & 0xf
            if filter_height:
                psr += (filter_height & 0xf) << 4
            else:
                psr += (self.filter_height & 0xf) << 4
        else:
            psr += self.filter_width & 0xf
            psr += (self.filter_height & 0xf) << 4
        psr += (Padx_Pady[padx_str] & 0x7) << 8
        psr += (Padx_Pady[pady_str] & 0x7) << 12
        psr += self.stride << 16
        psr += self.dilation << 17
        if self.direction is not None:
            psr += Direction[self.direction] << 18
        if self.bwdtype is not None:
            psr += BwdType[self.bwdtype] << 19
        if self.halftlr is not None:
            psr += HalfTLR[self.halftlr] << 20

        if not self._get_dry_run():
            if self.psr != psr:
                q = "q0"
                # comment = ("// Set PSR state f_w:{}, f_h:{}, p_x:{}, p_x:{},"
                #            "stride:{}, dilation:{}, direction:{}, bwdtype:{},"
                #            "halftlr:{}".format(
                #                self.filter_width, self.filter_height,
                #                Padx_Pady[padx_str], Padx_Pady[pady_str],
                #                self.stride, self.dilation, self.direction,
                #                self.bwdtype, self.halftlr))
                comment = "// Set PSR state: {}".format(hex(psr))
                self.smov.generate(
                    self.indent, dst=q, src1=psr, comment=comment)
                # self.smov.generate(
                #    self.indent, q+", {}".format(psr))
                # self.nop.generate(self.indent, vcnt="v3")
                self.psr = psr
                self.produced_count += 1
                # rm.wsr_free(q)
