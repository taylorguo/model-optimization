#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import code_generator.share.br_const_defs as tcd


def get_ich_from_dt(w_dt):
    MAT_LSA_INPUT_CODING_LDCONV_CONV_4_L = ["s4", "s4xs8 conv", "s4xu8 conv"]
    MAT_LSA_INPUT_CODING_LDCONV_CONV_4 = {"ich32": 0, "ich64": 1, "ich128": 2}

    MAT_LSA_INPUT_CODING_LDCONV_CONV_8_L = [
        "u8",
        "s8",
        "s8xs8",
        "u8xs8",
        "s8xu8",
        "s4xs8 mma",
        "s4xu8 mma",
        "s8xs4 mma",
        "u8xs4 mma",
    ]
    MAT_LSA_INPUT_CODING_LDCONV_CONV_8 = {"ich16": 0, "ich32": 1, "ich64": 2, "ich128": 3}

    MAT_LSA_INPUT_CODING_LDCONV_CONV_16_1_L = ["u8xbf16", "s8xbf16", "bf16xu8", "bf16xs8"]
    MAT_LSA_INPUT_CODING_LDCONV_CONV_16_1 = {"ich16": 0, "ich32": 1, "ich64": 2}

    MAT_LSA_INPUT_CODING_LDCONV_CONV_16_2_L = [
        "bf16",
        "f8",
        "bf8",
        "bf16xbf16",
        "bf16xf8",
        "f8xbf16",
        "f8xbf16",
        "bf8xbf16",
        "f8xbf8",
        "bf8xf8",
        "f8xf8",
    ]
    MAT_LSA_INPUT_CODING_LDCONV_CONV_16_2 = {
        "ich8": 0,
        "ich16": 1,
        "ich32": 2,
        "ich64": 3,
        "ich128": 4,
    }

    MAT_LSA_INPUT_CODING_LDCONV_CONV_32_L = ["fp32", "fp32xfp32", "fp32xbf16", "bf16xfp32"]
    MAT_LSA_INPUT_CODING_LDCONV_CONV_32 = {
        "4": 0,
        "16": 1,
        "32": 2,
        "64": 3,
    }

    """
    MAT_LSA_INPUT_CODING_MMA_16_1_L = [
        "u8",
        "s8",
        "s8xs8",
        "u8xs8",
        "s8xu8",
        "s4xs8",
        "s4xu8",
        "s8xs4",
        "u8xs4",
    ]
    MAT_LSA_INPUT_CODING_MMA_16_1 = {"64": 0, "128": 1, "256": 2, "512": 3}

    MAT_LSA_INPUT_CODING_MMA_16_2_L = ["u8xbf16", "s8xbf16", "bf16xu8", "bf16xs8"]
    MAT_LSA_INPUT_CODING_MMA_16_2 = {"64": 0, "128": 1, "256": 2}

    MAT_LSA_INPUT_CODING_MMA_16_3_L = [
        "bf16",
        "f8",
        "bf8",
        "bf16xbf16",
        "bf16xbf8",
        "f8xbf16",
        "bf8xbf16",
        "f8xbf8",
        "bf8xbf16",
        "f8xbf8",
        "bf8xf8",
        "f8xf8",
    ]
    MAT_LSA_INPUT_CODING_MMA_16_3 = {"32": 0, "64": 1, "128": 2, "256": 3}
    """

    MAT_LSA_INPUT_CODING_MMA_16_4_L = ["fp32", "fp32xfp32", "fp32xbf16", "bf16xfp32"]
    MAT_LSA_INPUT_CODING_MMA_16_4 = {
        "4": 0,
        "8": 1,
        "16": 2,
        "32": 3,
        "64": 4,
        "128": 5,
        "256": 6,
    }

    if w_dt in MAT_LSA_INPUT_CODING_LDCONV_CONV_4_L:
        p = MAT_LSA_INPUT_CODING_LDCONV_CONV_4
    elif w_dt in MAT_LSA_INPUT_CODING_LDCONV_CONV_8_L:
        p = MAT_LSA_INPUT_CODING_LDCONV_CONV_8
    elif w_dt in MAT_LSA_INPUT_CODING_LDCONV_CONV_16_1_L:
        p = MAT_LSA_INPUT_CODING_LDCONV_CONV_16_1
    elif w_dt in MAT_LSA_INPUT_CODING_LDCONV_CONV_16_2_L:
        p = MAT_LSA_INPUT_CODING_LDCONV_CONV_16_2
    elif w_dt in MAT_LSA_INPUT_CODING_LDCONV_CONV_32_L:
        p = MAT_LSA_INPUT_CODING_LDCONV_CONV_32
    return p


def find_best_match_block_inch_num(ich, w_dt):
    p = get_ich_from_dt(w_dt)

    key_numbers = [e for e, _ in p.items()]
    # print("key_numbers are ", key_numbers)
    matched_ich_num = 0
    for e in key_numbers:
        if e.isdigit():
            input_ch_num = int(e)
        else:
            input_ch_num = int(e[3:])
        if input_ch_num >= ich:
            if matched_ich_num == 0:
                matched_ich_num = input_ch_num
            if input_ch_num < matched_ich_num:
                matched_ich_num = input_ch_num
    if matched_ich_num == 0:
        matched_ich_num = key_numbers[-1]
    else:
        matched_ich_num = "ich{}".format(matched_ich_num)

    # print("selected_ch_num is ", matched_ich_num)

    return matched_ich_num


def find_left_channels(ich, w_dt):
    p = get_ich_from_dt(w_dt)

    # print("key_numbers are ", key_numbers)
    backup_channels = [int(e[3:]) for e, _ in p.items()]
    backup_channels.reverse()
    bch = dict()

    # greedy search from the lagest one
    for i in backup_channels:
        if i < ich:
            bch[i] = ich // i
            ich = ich % i
        if ich != 0 and int(i) == int(backup_channels[len(backup_channels) - 1]):
            if i in bch.keys():
                bch[i] += 1  # append 1 for left channel
            else:
                bch[i] = 1  # append 1 for left channel
    return bch


def get_tlr(loop_config, stride):
    loop_num = []
    tlr_loop = []
    for loop in loop_config:
        if (
            loop[0] == "outer_oc"
            or loop[0] == "row"
            or loop[0] == "col"
            or loop[0] == "inner_oc"
            or loop[0] == "sample"
            or loop[0] == "outer_ic"
            or loop[0] == "stride"
        ):
            loop_num.append(loop[1])
            tlr_loop.append(loop)
    tlr = 1
    for i in loop_num:
        tlr *= i
    if stride == 0:
        return tlr
    else:
        return int((tlr + 1) / 2)


# compute y direction tlr usage
def get_row_tlr(loop_config, stride):
    loop_num = []
    tlr_loop = []
    for loop in loop_config:
        #    if loop[0] == "row":
        #        iloop = loop

        # index = loop_config.index(iloop)
        # y_loop = loop_config[index + 1, :]
        if loop[0] == "row" or loop[0] == "inner_oc":
            loop_num.append(loop[1])
            tlr_loop.append(loop)
    tlr = 1
    for i in loop_num:
        tlr *= i
    return tlr


def get_stride2_tlr_pingpang_pos(loop_config, width):
    iternum = 1
    m = 1
    for loop in loop_config:
        if loop[0] == "row" and width == 1:
            iternum = loop[1]
        elif loop[0] == "col" and width > 1:
            iternum = (loop[1] + 1) // 2
        if loop[0] == "inner_oc":
            m = loop[1]
    # each oc32 occupy 1 tlr
    return m * iternum


def stride2_conv_loopconfig(loopconfig, filter_w, w_iter):
    stride_loop = []
    need_stride = False
    if filter_w == 1:
        w_iter = (w_iter) // 2
        unroll = 1
        for loop in loopconfig:
            if loop[0] == "row":
                iloop = loop
            t = tuple()
            if loop[0] == "col":
                # print("col loop is ", loop)
                # increase uinc as each step do 2 blocks
                uinc = loop[3] * 2
                sinc = loop[3]
                unroll2 = loop[2]
                if loop[1] == loop[2]:
                    unroll = 2
                    unroll2 = loop[2] // 2
                t = t + (loop[0], w_iter, unroll2, uinc)
                if len(loop) > 4:
                    t += loop[4:]
            else:
                t = loop
            stride_loop.append(t)

        stride = ("stride", 2, unroll, sinc, {"start": 0})
        index = loopconfig.index(iloop)
        stride_loop.insert(index + 1, stride)

    elif filter_w > 1:
        # if w > 1, unroll col to 2 as one block
        # h_iter = h_iter // 2
        t = tuple()
        for loop in loopconfig:
            if loop[0] == "col" and loop[1] != loop[2]:
               # print("***col loop is ", loop)
                t = (loop[0], loop[1], 2, loop[3])
                if len(loop) > 4:
                    t += loop[4:]
            else:
                t = loop
            stride_loop.append(t)
            # stride = ("stride", 2, 1, 1)
            # index = loop_config.index(iloop)
            # stride_loop.insert(index + 1, stride)
    return stride_loop


def stride2_bufb_loopconfig(loopconfig, filter_w, w_iter):
    stride_loop = []
    if filter_w == 1:
        w_iter = (w_iter) // 2
        unroll = 1
        for loop in loopconfig:
            if loop[0] == "row":
                iloop = loop
            t = tuple()
            if loop[0] == "col":
                # increase uinc as each step do 2 blocks
                uinc = loop[3] * 2
                sinc = loop[3]
                unroll2 = loop[2]
                if loop[1] == loop[2]:
                    unroll = 2
                    unroll2 = loop[2] // 2
                t = t + (loop[0], w_iter, unroll2, uinc, {"start": 0})

            else:
                t = loop
            stride_loop.append(t)
        stride = ("stride", 2, unroll, sinc, {"start": 0})
        index = loopconfig.index(iloop)
        stride_loop.insert(index + 1, stride)
        return stride_loop
    return loopconfig


def stride2_vector_loopconfig(loopconfig, filter_w, w_iter, boundary=False):
    stride_loop = []
    if filter_w == 1:
        for loop in loopconfig:
            t = tuple()
            if loop[0] == "row":
                # decrease uinc as each step do 4x8 blocks
                uinc = loop[3] // 2
                t = t + (loop[0], w_iter, loop[2], uinc)
                if len(loop) > 4:
                    t += loop[4:]
                if boundary:
                    t += ({"start": 0},)
            elif loop[0] == "col":
                if len(loop) > 4:
                    if tcd.CONV_OCH_SIZE == 64:
                        tlr_pp = 1
                    else:
                        tlr_pp = 64
                    t = (
                        loop[0],
                        loop[1],
                        loop[2],
                        loop[3],
                        {
                            "tlr_pingpong": [0, tlr_pp],
                            "tlr_bar_csm": [
                                tcd.TLR_PINGPONG_CONV_TO_VECTOR_BAR_ID_1,
                                tcd.TLR_PINGPONG_CONV_TO_VECTOR_BAR_ID_2,
                            ],
                            "tlr_bar_pass": [
                                tcd.TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_1,
                                tcd.TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_2,
                            ],
                        },
                    )
                    if boundary:
                        t += ({"start": 0},)
                else:
                    t = loop
                    if boundary:
                        t += ({"start": 0},)
            else:
                t = loop
                if boundary:
                    t += ({"start": 0},)
            stride_loop.append(t)

    elif filter_w > 1:
        # if w > 1, unroll col to 2 as one block
        # h_iter = h_iter // 2
        t = tuple()
        for loop in loopconfig:
            if loop[0] == "col":
                t = (loop[0], loop[1], 2, loop[3])
                if len(loop) > 4:
                    t += loop[4:]
                if boundary:
                    t += ({"start": 0},)
            elif loop[0] == "row":
                if len(loop) > 4:
                    if tcd.CONV_OCH_SIZE == 64:
                        tlr_pp = 1
                    else:
                        tlr_pp = 64
                    t = (
                        loop[0],
                        loop[1],
                        loop[2],
                        loop[3],
                        {
                            "tlr_pingpong": [0, tlr_pp],
                            "tlr_bar_csm": [
                                tcd.TLR_PINGPONG_CONV_TO_VECTOR_BAR_ID_1,
                                tcd.TLR_PINGPONG_CONV_TO_VECTOR_BAR_ID_2,
                            ],
                            "tlr_bar_pass": [
                                tcd.TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_1,
                                tcd.TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_2,
                            ],
                        },
                    )
            else:
                t = loop
                if boundary:
                    t += ({"start": 0},)
            stride_loop.append(t)
            # stride = ("stride", 2, 1, 1)
            # index = loop_config.index(iloop)
            # stride_loop.insert(index + 1, stride)
    return stride_loop


def gen_loopconfig(
        loopconfig, stride, filter_w, accumulation_times):
    local_config = []
    t = tuple()
    for loop in loopconfig:
        if stride == 1:
            if filter_w > 1:
                # if accumulation_times > 1:
                if tcd.ENABLE_ROW_ACCUMULATION:
                    if "col" in loop[0]:   # temporarily change it from row to col
                        t = (
                            loop[0],
                            loop[1],
                            loop[2],
                            loop[3],
                            {
                                "start": 0,
                                "tlr_bar_sync": [
                                    tcd.TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_1,
                                    tcd.TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_2,
                                ],
                                "tlr_bar_set": [
                                    tcd.TLR_PINGPONG_CONV_TO_VECTOR_BAR_ID_1,
                                    tcd.TLR_PINGPONG_CONV_TO_VECTOR_BAR_ID_2,
                                ],
                            },
                        )
                    elif "row" in loop[0]:   # temporarily change it from row to col
                        t = (
                            loop[0],
                            loop[1],
                            loop[2],
                            loop[3],
                            {
                                "start": 0,
                            }
                        )
                    elif loop[0] == "outer_oc":
                        if len(loop) > 4:
                            if "grb_pingpong" in loop[4].keys():
                                newdict = dict()
                                for k, v in loop[4].items():
                                    if k != "grb_pingpong":
                                        newdict[k] = v
                                t = (loop[0], loop[1], loop[2], loop[3], newdict)
                        else:
                            t = loop

                    else:
                        t = loop
                else:
                    if "row" in loop[0]:   # temporarily change it from row to col
                        t = (
                            loop[0],
                            loop[1],
                            loop[2],
                            loop[3],
                            {
                                "start": 0,
                                "tlr_bar_sync": [
                                    tcd.TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_1,
                                    tcd.TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_2,
                                ],
                                "tlr_bar_set": [
                                    tcd.TLR_PINGPONG_CONV_TO_VECTOR_BAR_ID_1,
                                    tcd.TLR_PINGPONG_CONV_TO_VECTOR_BAR_ID_2,
                                ],
                            },
                        )
                    elif loop[0] == "outer_oc":
                        if len(loop) > 4:
                            if "grb_pingpong" in loop[4].keys():
                                newdict = dict()
                                for k, v in loop[4].items():
                                    if k != "grb_pingpong":
                                        newdict[k] = v
                                t = (loop[0], loop[1], loop[2], loop[3], newdict)
                        else:
                            t = loop
                    else:
                        t = loop
                local_config.append(t)
            elif filter_w == 1:
                if  "col" in loop[0]:
                    t = (
                        loop[0],
                        loop[1],
                        loop[2],
                        loop[3],
                        {
                            "start": 0,
                            "tlr_bar_sync": [
                                tcd.TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_1,
                                tcd.TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_2,
                            ],
                            "tlr_bar_set": [
                                tcd.TLR_PINGPONG_CONV_TO_VECTOR_BAR_ID_1,
                                tcd.TLR_PINGPONG_CONV_TO_VECTOR_BAR_ID_2,
                            ],
                        },
                    )
                elif loop[0] == "outer_oc":
                    if len(loop) > 4:
                        if "grb_pingpong" in loop[4].keys():
                            newdict = dict()
                            for k, v in loop[4].items():
                                if k != "grb_pingpong":
                                    newdict[k] = v
                            t = (loop[0], loop[1], loop[2], loop[3], newdict)
                        else:
                            t = loop

                else:
                    t = loop
                local_config.append(t)
    return local_config


def split_sample(num):
    sample_num = 1
    while num % 8 != 0:
        sample_num += 1
        num *= sample_num
    return sample_num


def get_row_col_param(ih, iw):
    h_iter = int((ih + tcd.ACTIVATION_BLOCK_H_SIZE - 1) / tcd.ACTIVATION_BLOCK_H_SIZE)
    w_iter = int(((iw + tcd.ACTIVATION_BLOCK_W_SIZE - 1) / tcd.ACTIVATION_BLOCK_W_SIZE))
    h_inc = tcd.ACTIVATION_BLOCK_W_SIZE
    w_inc = tcd.ACTIVATION_BLOCK_H_SIZE

    return h_iter, h_inc, w_iter, w_inc


def sample_merge(loopconfig, stride, filter_w, w, h, inst="default"):
    wnum = 0
    hnum = 0
    sample_loop = []
    if w % 8 != 0:
        wnum = split_sample(w)
    if h % 8 != 0:
        hnum = split_sample(h)
    if wnum == 0 and hnum == 0:
        return loopconfig, wnum, hnum

    ih = h * hnum
    iw = w * wnum
    if w == 14 and wnum > 2:
        wnum = 2
        iw = w * wnum
    hit, hinc, wit, winc = get_row_col_param(ih, iw)

    for loop in loopconfig:
        t = tuple()
        unroll = loop[2]
        if inst == "fullunroll":
            unroll = 7

        if loop[0] == "row":
            t = t + (loop[0], hit, unroll, hinc)
            if len(loop) > 4:
                t += loop[4:]
        elif loop[0] == "col":
            # increase uinc as each step do 2 blocks
            t = t + (loop[0], wit, unroll, winc)
            if len(loop) > 4:
                t += loop[4:]
        elif loop[0] == "sample" and loop[1] >= wnum * hnum:
            t = t + (loop[0], loop[1] // (wnum * hnum), loop[2], loop[3])
            if len(loop) > 4:
                t += loop[4:]
        else:
            t = loop
        sample_loop.append(t)
    return sample_loop, wnum, hnum


def oc_unroll_all(loopconfig):
    stride_loop = []
    t = tuple()
    for loop in loopconfig:
        if loop[0] == "inner_oc":
            t = (loop[0], loop[1], loop[1], loop[3])
            if len(loop) > 4:
                t += loop[4:]
        else:
            t = loop
        stride_loop.append(t)
    return stride_loop
