#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import code_generator.share.br_const_defs as tcd
import code_generator.tcore.br_tcore_conv as tcc
# import code_generator.vector.br_vector_stm as bvs
import code_generator.tcore.br_tcore_utils as btu
import code_generator.share.br_loop_config as blc
import code_generator.share.br_loop_manager as lm

# import tcore.br_tcore_operator as tco
import code_generator.tcore.br_tcore_loop_man_conv as tlm

import math


def br_bpa_conv(
    tensor_b,
    tensor_a,
    dt,
    stride=1,
    dilation=1,
    padx=0,
    pady=0,
    usharps=None,
    loop_configs=[],
    pingpong_a=[0],
    red_mode="roff",
    write_through=False,
    csrs={},
    hwshape=None
):

    
    print("PYN bpa ishape wshape",tensor_b, tensor_a) 
    print("PYN bpa stride dilation padx pady",stride, dilation, padx, pady)
    operator = tcore_bpa_conv(
        tensor_b,
        tensor_a,
        dt,
        stride,
        dilation,
        padx,
        pady,
        usharps,
        pingpong_a=pingpong_a,
        red_mode=red_mode,
        write_through=write_through,
        loop_configs=loop_configs
    )
    # operator.generate(loop_configs, dry_run=True)

    return operator


class tcore_bpa_conv(tcc.tcore_conv):
    def __init__(
        self,
        tensor_b,
        tensor_a,
        dt,
        stride=1,
        dilation=1,
        padx=0,
        pady=0,
        usharps=None,
        pingpong_a=[0],
        pingpong_b=[0],
        red_mode="roff",
        write_through=None,
        csrs={},
        hwshape=None,
        loop_configs=None
    ):
        super().__init__(
            "bpa_conv",
            tensor_b,
            tensor_a,
            tensor_a,
            dt,
            stride=stride,
            dilation=dilation,
            padx=padx,
            pady=pady,
            usharps=usharps,
            fwd=False,
            bpw=False,
            pingpong_a=pingpong_a,
            pingpong_b=pingpong_b,
            red_mode=red_mode,
            write_through=write_through,
            csrs=csrs,
            loop_configs=loop_configs
        )

        self.sample_w = 0
        self.sample_h = 0
        self.sample_full_unroll = 0

        self.enable_sample_merge = False
        if red_mode != "roff":
            self.reduction = True
        else:
            self.reduction = False
        # self.extension = extension
        if hwshape is not None:
            self.enable_sample_merge = True
        # Currently, gmb mapping is only feature map
        # self.gmb_mapping = gmb_mapping

        self.direction = "bwd"

        self.bwdtype = "bpa"
        self._generate_bpa_hw()

        self.halftlr = None

        self.aliged_w_block_num = int(
            (
                (self.input_w + tcd.ACTIVATION_BLOCK_W_SIZE - 1)
                / tcd.ACTIVATION_BLOCK_W_SIZE
            )
        )
        self.aligned_input_w = self.aliged_w_block_num * tcd.ACTIVATION_BLOCK_W_SIZE
        self.aliged_h_block_num = int(
            (
                (self.input_h + tcd.ACTIVATION_BLOCK_H_SIZE - 1)
                / tcd.ACTIVATION_BLOCK_H_SIZE
            )
        )
        self.aligned_input_h = self.aliged_h_block_num * tcd.ACTIVATION_BLOCK_H_SIZE

        self.aligned_ich_block_num = int((self.ich_num / self.bst_ich_ld_num))
        self.aligned_ich_num = self.aligned_ich_block_num * self.bst_ich_ld_num
        self.aligned_och_block_num = int(
            ((tensor_a[0] + tcd.WEIGHT_OCH_LD_SIZE - 1) / tcd.WEIGHT_OCH_LD_SIZE)
        )
        self.aligned_och_num = self.aligned_och_block_num * tcd.WEIGHT_OCH_LD_SIZE

        self.required_buffer_a_entries_per_ld = int(
            self.bst_ich_ld_num / tcd.BUFFER_A_ENTRY_ICH_NUM
        )
        self.required_buffer_a_entries_per_ld *= self.filter_h
        self.required_buffer_a_entries_per_ld *= self.filter_w

        self.required_buffer_b_entries_per_ld = int(
            self.bst_ich_ld_num / tcd.BUFFER_B_ENTRY_ICH_NUM
        )
        self.required_buffer_b_entries_per_ld *= int(
            tcd.ACTIVATION_BLOCK_W_SIZE / tcd.BUFFER_B_ENTRY_PIXEL_WIDTH
        )
        self.required_buffer_b_entries_per_ld *= int(
            tcd.ACTIVATION_BLOCK_H_SIZE / tcd.BUFFER_B_ENTRY_PIXEL_HEIGHT
        )

        self.amount_buffer_a_entries_required = int(
            self.aligned_ich_num / self.bst_ich_ld_num
        )
        self.amount_buffer_a_entries_required *= int(
            self.aligned_och_num / self.och_ld_ch_num
        )
        self.amount_buffer_a_entries_required *= self.required_buffer_a_entries_per_ld

        self.amount_buffer_b_entries_required = int(
            self.aligned_input_w / tcd.ACTIVATION_BLOCK_W_SIZE
        )
        self.amount_buffer_b_entries_required *= int(
            self.aligned_input_h / tcd.ACTIVATION_BLOCK_H_SIZE
        )
        self.amount_buffer_b_entries_required *= int(
            self.aligned_ich_num / self.bst_ich_ld_num
        )
        self.amount_buffer_b_entries_required *= self.sample_num
        self.amount_buffer_b_entries_required *= self.required_buffer_b_entries_per_ld

        self.buffer_a_oc_loop_times = math.ceil(self.aligned_och_num / self.och_ld_ch_num)
        self.buffer_ich_loop_times = math.ceil(self.aligned_ich_num / self.bst_ich_ld_num)

        self._initialize_instructions()
        self.check_loop_configs()

        self.buf_a_total_iterations = (
            self.get_total_iteration_times(self.loop_configs[0]))
        self.buf_b_total_iterations = (
            self.get_total_iteration_times(self.loop_configs[1]))

        self.accumulation_times = self.get_accu_times_for_filter_w_above_one(
            self.bst_ich_ld_num)

    def _generate_bpa_hw(self):
        if self.direction == "bwd" and self.bwdtype == "bpa":
            self.input_h = self.input_h * (self.stride + 1)
            self.input_w = self.input_w * (self.stride + 1)

    def _generate_buf_a_ld(self, loopconfig=None):
        super()._generate_buf_a_ld(loopconfig)

    def _generate_buf_b_ld(self, loopconfig=None):
        if self.input_w % 8 != 0:
            bound = "default"
            # hwshape will do sample merge
            if self.hwshape is None:
                loopconfig, w, h = btu.sample_merge(
                    loopconfig,
                    self.stride,
                    self.filter_w,
                    self.input_w,
                    self.input_h,
                    inst=bound,
                )
                if w != 0 and h != 0:
                    self.sample_w = w
                    self.sample_h = h
                    if bound == "fullunroll":
                        self.sample_full_unroll = 2
                    else:
                        self.sample_full_unroll = 1
            else:
                if bound == "fullunroll":
                    self.sample_full_unroll = 2
                else:
                    self.sample_full_unroll = 1

        super()._generate_buf_b_ld(loopconfig)

    def _generate_conv(self, loopconfig=None):
        h_iter = self.aliged_h_block_num
        w_iter = self.aliged_w_block_num

        och_inc = self.och_ld_ch_num
        ich_iter = self.buffer_ich_loop_times
        ich_inc = self.bst_ich_ld_num

        sample_iter = self.sample_num
        sample_inc = 1
        och = self.aligned_och_num
        och_inc = self.och_ld_ch_num
        ich_inc = self.bst_ich_ld_num
        col_inc = tcd.ACTIVATION_BLOCK_W_SIZE
        row_inc = tcd.ACTIVATION_BLOCK_H_SIZE

        och_inner_grannular = min(math.ceil(och / och_inc), tcd.OCH_INNER_LOOP_GRANNULAR)
        och_outer_inc = och_inner_grannular * och_inc
        och_outer_iter = int(self.aligned_och_num / och_outer_inc)

        if loopconfig is not None:
            loop_config = loopconfig
        else:
            if self.filter_w == 1:
                loop_config = [
                    #   name,   iterations, unrolls, incremental unit
                    (
                        "outer_oc",
                        och_outer_iter,
                        1,
                        och_outer_inc,
                        {"wset": [32], "sset": [48]},
                    ),
                    ("outer_ic", och_outer_iter, 1, och_outer_inc),
                    ("outer_oc", och_outer_iter, 1, och_outer_inc),
                    ("sample", sample_iter, 1, sample_inc),
                    ("col", w_iter, 1, col_inc),
                    ("row", h_iter, 1, row_inc),
                    ("inner_oc", och_inner_grannular, 1, och_inc),
                    ("ich", ich_iter, ich_iter, ich_inc),
                ]  # unfold by default
            else:
                loop_config = [
                    #   name,   iterations, unrolls, incremental unit
                    (
                        "outer_oc",
                        och_outer_iter,
                        1,
                        och_outer_inc,
                        {"wset": [32, 33], "sset": [48, 49]},
                    ),
                    ("outer_ic", och_outer_iter, 1, och_outer_inc),
                    (
                        "outer_oc",
                        och_outer_iter,
                        1,
                        och_outer_inc,
                        {"grb_pingpong": [1, 2], "bar": "sync"},
                    ),
                    ("sample", sample_iter, 1, sample_inc),
                    ("row", h_iter, 1, row_inc),
                    ("col", w_iter, 1, col_inc),
                    ("inner_oc", och_inner_grannular, 1, och_inc),
                    ("ich", ich_iter, ich_iter, ich_inc),
                ]  # unfold by default

        # process stride == 2 case
        stride_loop = []
        if self.stride == 1:
            if self.filter_w == 1:
                w_iter = w_iter // 2
                for loop in loop_config:
                    if loop[0] == "row":
                        iloop = loop
                    t = tuple()
                    if loop[0] == "col":
                        t = t + (loop[0], w_iter, loop[2], loop[3])
                    else:
                        t = loop
                    stride_loop.append(t)
                stride = ("stride", 2, 1, 1)
                index = loop_config.index(iloop)
                stride_loop.insert(index + 1, stride)
                loop_config = stride_loop

            elif self.filter_w > 1:
                # if w > 1, unroll col to 2 as one block
                # h_iter = h_iter // 2
                t = tuple()
                for loop in loop_config:
                    if loop[0] == "col":
                        t = (loop[0], loop[1], 2, loop[3])
                    else:
                        t = loop
                    stride_loop.append(t)
                # stride = ("stride", 2, 1, 1)
                # index = loop_config.index(iloop)
                # stride_loop.insert(index + 1, stride)
                loop_config = stride_loop

        prefix = self.cwm.start_conv_warp(self)
        lm.loop_code_generate(
            indent=self.indent,
            loop_config=loop_config,
            instr="conv",
            operator=self,
            prefix=prefix,
            loop_man=tlm.loop_man_conv,
        )

        self.cwm.end_conv_warp()

    def generate(self, loop_configs=[], dry_run=False):
        """:param och_unroll: Specify how to unroll the iteration. if it is 1
         or None, no unroll will be done. this value must the power of 2.
         for example: 1, 2, 4, 8, 16
        :param ich_unroll: Same as above
        No return value for this function call.
        """
        if len(loop_configs) == 0 and self.loop_configs is not None:
            loop_configs = self.loop_configs
        elif len(loop_configs) > 0:
            self._calculate_inner_loop_iterations_and_steps(loop_configs)
        super()._set_dry_run(dry_run)

        size_of_configs = len(loop_configs)

        if size_of_configs > 0:
            self._generate_buf_a_ld(loop_configs[0])
        else:
            self._generate_buf_a_ld(loopconfig=generated_loop_configs[0])
        if size_of_configs > 1:
            self._generate_buf_b_ld(loop_configs[1])
        else:
            self._generate_buf_b_ld(loopconfig=generated_loop_configs[1])

        if size_of_configs > 2:
            self._generate_conv(loop_configs[2])
        else:
            self._generate_conv(loopconfig=generated_loop_configs[2])
        self.previous_operator_filter_width = self.cwm.get_previou_filter_width()

        if dry_run is False:
            self.cwm.set_filter_width(self.filter_w)

        super()._set_dry_run(False)
        self.reset()

    def reset(self):
        super()._reset()
        self.operator["conv"].reset()
