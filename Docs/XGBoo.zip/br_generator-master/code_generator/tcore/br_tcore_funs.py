#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.


import copy

import code_generator.tcore.br_tcore_unit_funs as tuf
import code_generator.tcore.br_tcore_psr as tcore_psr
from code_generator.share import br_top
import code_generator.share.br_resource_manager as rm
import code_generator.share.br_vector_instructions_def as vid


class tcore_commom(br_top.top):
    def __init__(
        self,
        indent,
        filter_width,
        filter_height,
        padx=0,
        pady=0,
        stride=1,
        stride_psr=0,
        dilation=0,
        direction=None,
        bwdtype=None,
        halftlr=None,
    ):
        super().__init__()
        if direction == "bwd" and bwdtype == "bpa":
            psr_stride = stride_psr
            self.stride_psr = stride_psr
        else:
            psr_stride = stride
            self.stride_psr = stride
        self.direction = direction
        self.bwdtype = bwdtype
        self.psr = tcore_psr.psr(
            filter_width,
            filter_height,
            padx,
            pady,
            stride=psr_stride,
            dilation=dilation,
            direction=direction,
            bwdtype=bwdtype,
            halftlr=halftlr,
            indent=indent,
        )
        self.temp_q = []
        self.sadd = vid.sadd(indent)

    def reduce_warp_input_assemble_state_registers(self, indent, **kw):
        new_kw = copy.deepcopy(kw)
        # print("kw is ", kw)
        for k in kw.keys():
            if isinstance(kw[k], list):
                size = len(kw[k])
                regs = kw[k]
                new_regs = []
                if size > 2:
                    q = rm.wsr_alloc("temp_register")
                    self.temp_q.append(q)
                    new_regs.append((regs[-1]))
                    self.sadd.generate(indent, dst=q, src1=regs[0][0], src2=regs[1][0])
                    for i in range(size - 2 - 1):
                        self.sadd.generate(indent, dst=q, src1=q, src2=regs[i + 2][0])
                    new_regs.append((q, None, None))
                    new_kw[k] = new_regs
        # print("new_kw is ", new_kw)
        return new_kw

    def release_temp_wsr(self):
        for wsr in self.temp_q:
            rm.wsr_free(wsr)


class tcore_conv(tcore_commom):
    def __init__(
        self,
        gib0_addr,
        gib1_addr,
        filter_width,
        filter_height,
        padx=0,
        pady=0,
        stride=1,
        dilation=0,
        direction="fwd",
        bwdtype=None,
        halftlr=None,
        x=0,
        y=0,
        z=0,
        w=0,
        warp_count=None,
        slot=None,
        wsc=None,
        ssc=None,
        wbar_id=None,
        gib0_step=None,
        gib1_step=None,
        indent=None,
        modifier=None,
        **kw
    ):
        super().__init__(
            indent,
            filter_width,
            filter_height,
            padx,
            pady,
            stride=stride,
            dilation=dilation,
            direction=direction,
            bwdtype=bwdtype,
            halftlr=halftlr,
        )
        self.tuc = tuf.br_tcore_unit_conv(
            gib0_addr,
            gib1_addr,
            x,
            y,
            z,
            w,
            wsc=wsc,
            ssc=ssc,
            warp_count=warp_count,
            slot=slot,
            wbar_id=wbar_id,
            gib0_step=gib0_step,
            gib1_step=gib1_step,
            indent=indent,
            modifier=modifier,
            **kw
        )

        self.produced_count = 0

    def generate(
        self,
        gib0_addr=None,
        gib1_addr=None,
        filter_width=None,
        filter_height=None,
        padx=None,
        pady=None,
        stride=None,
        dilation=None,
        direction=None,
        bwdtype=None,
        halftlr=None,
        x=None,
        y=None,
        z=None,
        w=None,
        warp_count=None,
        slot=None,
        wsc=None,
        ssc=None,
        indent=None,
        wbar_id=None,
        gib0_step=None,
        gib1_step=None,
        boundary_x=None,
        boundary_y=None,
        modifier=None,
        unroll=False,
        transient=False,
        **kw
    ):

        warp_state = self.reduce_warp_input_assemble_state_registers(
            indent,
            x=x,
            y=y,
            z=z,
            w=w,
            warp_count=warp_count,
            slot=slot,
            wsc=wsc,
            ssc=ssc,
            gib0_step=gib0_step,
            gib1_step=gib1_step,
            boundary_x=boundary_x,
            boundary_y=boundary_y,
        )

        self.psr.generate(
            padx=padx,
            pady=pady,
            stride=stride,
            dilation=dilation,
            direction=direction,
            bwdtype=bwdtype,
            halftlr=halftlr,
            filter_height=filter_height,
            filter_width=filter_width,
            indent=indent,
            transient=transient
        )
        self.tuc.generate(
            gib0_addr,
            gib1_addr,
            **warp_state,
            indent=indent,
            modifier=modifier,
            unroll=unroll,
            transient=transient,
            wbar_id=wbar_id,
            **kw
        )

        self.release_temp_wsr()
        self.produced_count += 1

    def reset(self):
        self.tuc.reset()
        self.psr.reset()


class tcore_buffer_a_ld(tcore_commom):
    def __init__(
        self,
        filter_w,
        filter_h,
        stride=0,
        dilation=0,
        padx=0,
        pady=0,
        direction="fwd",
        bwdtype=None,
        halftlr=None,
        gib0_addr=0,
        gib1_addr=None,
        x=0,
        y=0,
        z=0,
        w=0,
        wsc=None,
        ssc=None,
        gib0_step=None,
        gib1_step=None,
        indent=None,
        modifier=None,
        **kw
    ):
        # print("modifier is ", modifier)
        self.bpw = False
        buf_switch = "bs0"
        if direction != "fwd" and bwdtype == "bpw":
            self.bpw = True
            buf_switch = "bs1"
        super().__init__(
            indent,
            filter_w,
            filter_h,
            padx,
            pady,
            stride=stride,
            dilation=dilation,
            direction=direction,
            bwdtype=bwdtype,
            halftlr=halftlr,
        )
        self.tubal = tuf.br_tcore_unit_buffer_a_ldconv(
            gib0_addr=gib0_addr,
            gib1_addr=gib1_addr,
            x=y,
            y=y,
            z=z,
            w=w,
            wsc=wsc,
            ssc=ssc,
            gib0_step=gib0_step,
            gib1_step=gib1_step,
            is_bpw=self.bpw,
            indent=indent,
            modifier=modifier,
            BufSwitch_DstRel=buf_switch,
            **kw
        )

        self.produced_count = 0

    def generate(
        self,
        gib0_addr=None,
        gib1_addr=None,
        padx=None,
        pady=None,
        filter_width=None,
        filter_height=None,
        stride=None,
        dilation=None,
        direction=None,
        bwdtype=None,
        halftlr=None,
        wsc=None,
        ssc=None,
        warp_count=None,
        slot=None,
        x=None,
        y=None,
        z=None,
        gib0_step=None,
        gib1_step=None,
        boundary_x=None,
        boundary_y=None,
        indent=None,
        modifier=None,
        unroll=False,
        transient=False,
        **kw
    ):

        warp_state = self.reduce_warp_input_assemble_state_registers(
            indent,
            x=x,
            y=y,
            z=z,
            wsc=wsc,
            ssc=ssc,
            gib0_step=gib0_step,
            gib1_step=gib1_step,
            boundary_x=boundary_x,
            boundary_y=boundary_y,
        )
        self.psr.generate(
            padx=padx,
            pady=pady,
            stride=stride,
            dilation=dilation,
            direction=direction,
            bwdtype=bwdtype,
            halftlr=halftlr,
            filter_height=filter_height,
            filter_width=filter_width,
            indent=indent,
            transient=transient
        )
        # print("warp_state is ", warp_state)
        buf_switch = "bs0"
        if self.bpw:
            buf_switch = "bs1"
        self.tubal.generate(
            gib0_addr,
            **warp_state,
            indent=indent,
            modifier=modifier,
            unroll=unroll,
            transient=transient,
            BufSwitch_DstRel=buf_switch,
            **kw
        )

        self.release_temp_wsr()
        self.produced_count += 1

    def reset(self):
        self.tubal.reset()
        self.psr.reset()


class tcore_buffer_b_ld(tcore_commom):
    def __init__(
        self,
        filter_width,
        filter_height,
        padx=0,
        pady=0,
        stride=0,
        stride_psr=0,
        dilation=0,
        direction="fwd",
        bwdtype=None,
        gib1_addr=None,
        halftlr=None,
        indent=None,
        wsc=None,
        ssc=None,
        x=0,
        y=0,
        z=0,
        w=0,
        gib1_step=None,
        modifier=None,
        **kw
    ):
        super().__init__(
            indent,
            filter_width,
            filter_height,
            padx,
            pady,
            stride=stride,
            stride_psr=stride_psr,
            dilation=dilation,
            direction=direction,
            bwdtype=bwdtype,
            halftlr=halftlr,
        )
        self.tubbl = tuf.br_tcore_unit_buffer_b_ldconv(
            gib1_addr=gib1_addr,
            x=x,
            y=y,
            z=z,
            w=w,
            wsc=wsc,
            ssc=ssc,
            indent=indent,
            modifier=modifier,
            **kw
        )

        self.produced_count = 0

    def generate(
        self,
        gib0_addr=None,
        gib1_addr=None,
        padx=None,
        pady=None,
        filter_width=None,
        filter_height=None,
        stride=None,
        dilation=None,
        direction=None,
        bwdtype=None,
        halftlr=None,
        x=None,
        y=None,
        z=None,
        w=None,
        warp_count=None,
        slot=None,
        wsc=None,
        ssc=None,
        gib0_step=None,
        gib1_step=None,
        boundary_x=None,
        boundary_y=None,
        indent=None,
        modifier=None,
        unroll=False,
        transient=False,
        **kw
    ):
        warp_state = self.reduce_warp_input_assemble_state_registers(
            indent,
            x=x,
            y=y,
            z=z,
            w=w,
            wsc=wsc,
            ssc=ssc,
            gib0_step=gib0_step,
            gib1_step=gib1_step,
            boundary_x=boundary_x,
            boundary_y=boundary_y,
        )
        if self.direction == "bwd" and self.bwdtype == "bpa":
            stride = self.stride_psr
        self.psr.generate(
            padx=padx,
            pady=pady,
            stride=stride,
            dilation=dilation,
            direction=direction,
            bwdtype=bwdtype,
            halftlr=halftlr,
            filter_height=filter_height,
            filter_width=filter_width,
            indent=indent,
            transient=transient
        )
        self.tubbl.generate(
            gib_addr=gib1_addr,
            **warp_state,
            indent=indent,
            modifier=modifier,
            unroll=unroll,
            transient=transient,
            **kw
        )

        self.release_temp_wsr()
        self.produced_count += 1

    def reset(self):
        self.tubbl.reset()
        self.psr.reset()

    def reset_wsrpos(self):
        self.tubbl.reset_wsrpos()


class tcore_mma(object):
    def __init__(
        self,
        gib0_addr,
        gib1_addr,
        x=None,
        y=None,
        warp_count=None,
        slot=None,
        wsc=None,
        ssc=None,
        wbar_id=None,
        gib0_step=None,
        gib1_step=None,
        indent=None,
        modifier=None,
        **kw
    ):

        self.tum = tuf.br_tcore_unit_mma(
            gib0_addr,
            gib1_addr,
            x,
            y,
            wsc=wsc,
            ssc=ssc,
            warp_count=warp_count,
            slot=slot,
            indent=indent,
            gib0_step=gib0_step,
            gib1_step=gib1_step,
            modifier=modifier,
            **kw
        )

        self.produced_count = 0

    def generate(
        self,
        gib0_addr=None,
        gib1_addr=None,
        x=None,
        y=None,
        warp_count=None,
        slot=None,
        wsc=None,
        ssc=None,
        wbar_id=None,
        gib0_step=None,
        gib1_step=None,
        indent=None,
        modifier=None,
        transient=False,
        **kw
    ):

        self.tum.generate(
            gib0_addr,
            gib1_addr,
            x=x,
            y=y,
            warp_count=warp_count,
            slot=slot,
            wsc=wsc,
            ssc=ssc,
            gib0_step=gib0_step,
            gib1_step=gib1_step,
            indent=indent,
            modifier=modifier,
            transient=transient,
            **kw
        )

        self.produced_count += 1

    def reset(self):
        self.tum.reset()

    def reset_wsrpos(self):
        self.tum.reset_wsrpos()


class tcore_mma_buf_a_ld(object):
    def __init__(
        self,
        gib0_addr,
        gib1_addr=None,
        x=None,
        y=None,
        warp_count=None,
        slot=None,
        wsc=None,
        ssc=None,
        gib0_step=None,
        gib1_step=None,
        indent=None,
        modifier=None,
        **kw
    ):
        self.tubal = tuf.br_tcore_unit_mma_buf_a_ld(
            gib0_addr,
            gib1_addr,
            x,
            y,
            wsc=wsc,
            ssc=ssc,
            gib0_step=gib0_step,
            gib1_step=gib1_step,
            warp_count=warp_count,
            slot=slot,
            indent=indent,
            modifier=modifier,
            **kw
        )

        self.produced_count = 0

    def generate(
        self,
        gib0_addr=None,
        gib1_addr=None,
        x=None,
        y=None,
        warp_count=None,
        slot=None,
        wsc=None,
        ssc=None,
        gib0_step=None,
        gib1_step=None,
        indent=None,
        modifier=None,
        unroll=False,
        transient=False,
        **kw
    ):
        self.tubal.generate(
            gib0_addr,
            gib1_addr,
            x=x,
            y=y,
            warp_count=warp_count,
            slot=slot,
            wsc=wsc,
            ssc=ssc,
            gib0_step=gib0_step,
            gib1_step=gib1_step,
            indent=indent,
            modifier=modifier,
            unroll=unroll,
            transient=transient,
            **kw
        )

        self.produced_count += 1

    def reset(self):
        self.tubal.reset()

    def reset_wsrpos(self):
        self.tubal.reset_wsrpos()


class tcore_mma_buf_b_ld(object):
    def __init__(
        self,
        gib0_addr=None,
        gib1_addr=None,
        x=None,
        y=None,
        wsc=None,
        ssc=None,
        warp_count=None,
        slot=None,
        gib0_step=None,
        gib1_step=None,
        indent=None,
        modifier=None,
        **kw
    ):
        self.tubbl = tuf.br_tcore_unit_mma_buf_b_ld(
            gib0_addr,
            gib1_addr,
            x,
            y,
            wsc=wsc,
            ssc=ssc,
            warp_count=warp_count,
            slot=slot,
            gib0_step=gib0_step,
            gib1_step=gib1_step,
            indent=indent,
            modifier=modifier,
            **kw
        )

        self.produced_count = 0

    def generate(
        self,
        gib0_addr=None,
        gib1_addr=None,
        x=None,
        y=None,
        warp_count=None,
        slot=None,
        wsc=None,
        ssc=None,
        gib0_step=None,
        gib1_step=None,
        indent=None,
        modifier=None,
        unroll=False,
        transient=False,
        **kw
    ):

        self.tubbl.generate(
            gib0_addr,
            gib1_addr,
            x=x,
            y=y,
            warp_count=warp_count,
            slot=slot,
            wsc=wsc,
            ssc=ssc,
            gib0_step=gib0_step,
            gib1_step=gib1_step,
            indent=indent,
            modifier=modifier,
            unroll=unroll,
            transient=transient,
            **kw
        )

        self.produced_count += 1

    def reset(self):
        self.tubbl.reset()

    def reset_wsrpos(self):
        self.tubbl.reset_wsrpos()
