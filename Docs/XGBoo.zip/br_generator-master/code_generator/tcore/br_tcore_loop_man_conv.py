#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import inspect
import copy

import code_generator.share.br_resource_manager as rm
from code_generator.share.br_defined_print import br_print
import code_generator.tcore.br_tcore_utils as br_tcore_utils
import code_generator.share.br_const_defs as icd
from code_generator.tcore.br_tcore_loop_man_base import loop_man_base
import code_generator.share.br_const_defs as bcd


flip_suffix = "__"


def check_loop_accumulate(loop_config, inst, ich):
    look = 2
    lookahead = []

    for i in range(look):
        if inst == "conv":
            assert len(loop_config) > 3
            lookahead.append(loop_config[-(i + 3)])
        elif inst == "buf_b_ld":
            assert len(loop_config) > 2
            lookahead.append(loop_config[-(i + 2)])
    total = 1
    for loop in loop_config:
        if "col" in loop[0] or "row" in loop[0]:
            total *= loop[1]

    for loop in loop_config:
        # if < 128 which means cannot achieve 16k
        if loop[0] == "ich" and loop[3] < icd.ACCU_ICH_NUM:
            split_lookahead = icd.ACCU_ICH_NUM // ich
            if split_lookahead > total:
                print("cannot accu to 16k!!!")
                return loop_config, 0
            origin_accu = split_lookahead
            for i in range(look):
                # split level 1
                if split_lookahead < lookahead[i][1]:
                    if isinstance(split_lookahead, (int, float)):
                        unroll = split_lookahead
                    else:
                        unroll = lookahead[i][1]
                    # if already unrolled, use default unroll times
                    if unroll < lookahead[i][2]:
                        unroll = lookahead[i][2]
                    oldloop = lookahead[i]
                    unrollloop = (
                        lookahead[i][0],
                        lookahead[i][1],
                        unroll,
                        lookahead[i][3],
                        lookahead[i][4],
                    )
                    index = loop_config.index(oldloop)
                    loop_config[index] = unrollloop
                    return loop_config, origin_accu
                else:
                    # print("increase look ahead level")
                    left = int(split_lookahead / lookahead[i][1])
                    oldloop = lookahead[i]
                    unrollloop = (
                        lookahead[i][0],
                        lookahead[i][1],
                        lookahead[i][1],
                        lookahead[i][3],
                        lookahead[i][4],
                    )
                    index = loop_config.index(oldloop)
                    loop_config[index] = unrollloop
                    split_lookahead = left

    return loop_config, 0


class loop_man_conv(loop_man_base):
    def __init__(
        self,
        indent,
        comment=None,
        instr=None,
        operator=None,
        loop_configs=None,
    ):

        accu_times = 0
        accu_times_bufa = 0
        if (instr == "buf_b_ld" or instr == "conv"):
            if operator.filter_w == 1 and operator.stride != 1:
                loop_config, accu_times = check_loop_accumulate(
                    loop_configs, instr, operator.bst_ich_ld_num
                )
            if operator.filter_w > 1:
                accu_times = operator.accumulation_times

        super().__init__(
            indent,
            comment=comment,
            instr=instr,
            operator=operator,
            loop_config=loop_configs,
            accu=accu_times,
        )

    def update_base(self, start):
        if self.operator.stride == 1:
            # allocate base tlr
            self.base_reg = rm.alloc_addr_reg("itlr")
            self.smovs.generate(
                indent_level=self.indent,
                dst=self.base_reg,
                src1=self.inner_a1,
            )
            self.smov.generate(
                indent_level=self.indent,
                dst=self.tlr_flip,
                src1=self.base_reg,
            )
            # self.inner_a1 = start

    def init_all(self, start):
        self.smov.generate(
            indent_level=self.indent,
            dst=self.inner_a1,
            src1=start,
            comment="// init with start tlr",
        )
        self.base_reg = rm.alloc_addr_reg("itlr")
        self.smovs.generate(
            indent_level=self.indent,
            dst=self.base_reg,
            src1=start,
            comment="// init with start tlr",
        )
        self.smov.generate(
            indent_level=self.indent,
            dst=self.tlr_flip,
            src1=start,
            comment="// init with start tlr",
        )

    def init_a1(self, start):
        self.smov.generate(indent_level=self.indent, dst=self.inner_a1, src1=start)
        # self.smov.generate(indent_level=self.indent,
        # dst=self.half_tlr, src1=icd.HALF_TLR)

    def reset_a1(self):
        # save a1 first when enter stride loop, use this a1 again when loop stride
        self.smov.generate(
            indent_level=self.indent,
            dst=self.stride_a1,
            src1=self.inner_a1,
            comment="// save a1 before stride loop",
        )
        # reset a1 to inner_oc a1
        self.smovs.generate(
            indent_level=self.indent,
            dst="a1",
            src1=self.inner_a1,
            comment="// reset a1 to write same tlr",
        )

    def reset_row_a1(self):
        # save a1 first when enter stride loop, use this a1 again when loop stride
        self.sadda.generate(
            indent_level=self.indent,
            dst="a1",
            src1=self.inner_a1,
            src2=2,
            comment="// save a1 for next loop",
        )

    def reset_col_a1(self):
        # reset a1 with origin tlr after first block finished, then switch half_tlr
        # self.smovs.generate(
        #     indent_level=self.indent,
        #     dst="a1",
        #     src1=self.inner_a1,
        #     comment="// Reset a1 with origin")
        self.sxor.generate(
            self.indent,
            dst="q0",
            src1="q0",
            src2=icd.HALF_TLR,
            comment="// switch half_tlr after reset a1",
        )

    def switch_half_tlr(self):
        self.sxor.generate(
            self.indent,
            dst="q0",
            src1="q0",
            src2=icd.HALF_TLR,
            comment="// switch half_tlr",
        )

    def get_dst_tlr(self):
        tlr = br_tcore_utils.get_tlr(self.loop_config, self.operator.stride)
        start = rm.tlr_alloc(tlr)
        return start

    def reset_itlr_iter(self):
        self.itlr_first_innor_oc_step = 0
        self.itlr_body_step = 0
        self.itlr_last_innor_oc_step = 0

    def save_tlr_state(self):
        self.smov.generate(
            self.indent,
            dst=self.inner_a1,
            src1="a1",
            comment="// Save itlr address",
        )
        self.smovs.generate(
            self.indent,
            dst="a1",
            src1=self.stride_a1,
            comment="// Restore itlr address",
        )
        self.sxor.generate(
            self.indent,
            dst="q0",
            src1="q0",
            src2=icd.HALF_TLR,
            comment="// switch half_tlr in save_tlr_state",
        )

    def save_column_tlr_state(self):
        self.smov.generate(
            self.indent,
            dst=self.inner_a1,
            src1="a1",
            comment="// Save column itlr address",
        )

    def generate_tlr_index(self, loop, base, step, comment=" // increase a1"):

        if loop[0] == "ich":  # and self.operator.filter_w == 1:
            #    self.sadd.generate(
            #            indent=self.indent, dst=base, src1=1, src2=base)
            # else:
            self.sadda.generate(
                indent_level=self.indent,
                dst=base,
                src1=step,
                src2=base,
                comment=comment,
            )
        elif "col_unroll" in loop[0] and self.operator.filter_w > 1:
            self.sadda.generate(
                indent_level=self.indent,
                dst=base,
                src1=step,
                src2=base,
                comment=comment,
            )
        """
        def loop_header(base, step, name):
            if name != "ich":
                base = base + step
            return base
        #def loop_end(ereg):
        #    base = ereg
        def tlr_sequence(sreg, stride):
            base = sreg
            ir = "ir0"
            for loop in tlr_loop:
                if stride == 1:
                    step = loop[1]
                    for i in range(step):
                        base += i
                    #reg = loop_header(base, step, loop[0])
                        print("conv base{1}{0}".format(ir, base))
        return tlr_sequence
        """

    def stride2_tlr_switch(self):
        self.tlr_switch_pos = br_tcore_utils.get_stride2_tlr_pingpang_pos(
            self.loop_config, self.operator.filter_w
        )

    def update_stride_boundary(self, isboundx):

        if isboundx:
            self.sshr.generate(
                self.indent,
                dst=self.boundx,
                src1=self.stride_bound,
                src2=8,
                comment="// get high 8 bits coordx in csr",
            )
        else:
            self.sshr.generate(
                self.indent,
                dst=self.boundy,
                src1=self.stride_bound,
                src2=8,
                comment="// get high 8 bits coordy in csr",
            )

    def check_loop_status(self):
        for loop in self.loop_config:
            if loop[0] == bcd.ICH_SPLIT_LOOP_NAME and loop[1] > 1:
                self.ich_split = True
                self.ich_split_iter = loop[1]
            if "inner_oc" in loop[0] and self.instr == "conv":
                if int(loop[2] / loop[1]) == 1 and loop[1] != 1:
                    self.inner_oc_full_unroll = True
                self.inner_oc_iter = loop[1]
                self.oc_block_tlr = int(loop[1] * loop[3] / bcd.CONV_OCH_SIZE)
            if "row" in loop[0] and self.instr == "conv":
                self.row_unroll = loop[2]

    def get_coodinate_value_and_modifiers(
            self, ic_loop_ordinal, oc_loop_ordinal, h_loop_ordinal,
            w_loop_ordinal, sample_loop_ordinal, ic_iterations,
            oc_iterations, w_iterations, h_iterations, innermost_oc,
            innermost_w, innermost_h):

        mod = None
        y = None
        z = None
        slot = None
        if self.instr == "buf_a_ld":
            mod = "on.bs0.po.wnil.snil.ro"
            if ic_loop_ordinal[0] == 0:
                if oc_loop_ordinal[0] == 0 or ic_iterations != 1:
                    mod += ".sety"
                    y = self.row_regs
                else:
                    mod += ".incy0"
            elif ic_loop_ordinal[1] == -1:
                mod += ".incy0"
            else:
                mod += ".incy1"
            if oc_loop_ordinal[0] != -1:
                mod += ".incz1"
            else:
                mod += ".incz0"
            if self.operator.buf_a_total_iterations > 1:
                mod += ".b0inc"
            else:
                mod += ".b0nil"
        elif self.instr == "buf_b_ld":
            mod = "on.bs0.8x8.winc.sinc.ro"
            if self.pb_po_modifier is None:
                self.pb_po_modifier = ".po"
            mod += self.pb_po_modifier
            z_order, y_order, x_order = self.get_x_y_z_w_loop_oder()

            # if self.first_tcore_instr and self.last_tcore_instr:
            if ic_loop_ordinal[0] == 0:
                if ((oc_loop_ordinal[0] == 0 and
                     h_loop_ordinal[0] == 0 and
                     w_loop_ordinal[0] == 0 and
                     sample_loop_ordinal[0] == 0) or (
                        ic_iterations != 1)):
                    mod += ".setz"
                    z = self.ic_regs
                else:
                    mod += ".incz0"

                if z_order > x_order > y_order:
                    if w_iterations != 1 or innermost_w[1] > 1:
                        mod += ".incx1"
                    else:
                        mod += ".incx0"
                    mod += ".incy0"
                if z_order > y_order > x_order:
                    if h_iterations != 1 or innermost_h[1] > 1:
                        mod += ".incy1"
                    else:
                        mod += ".incy0"
                    mod += ".incx0"
                if self.operator.stride == 1 and self.operator.filter_w == 1:
                    mod += ".incy0.incx1"
            elif ic_loop_ordinal[1] == -1:
                if z_order > x_order > y_order:
                    if w_iterations != 1 or innermost_w[1] > 1:
                        mod += ".incx1"
                    else:
                        mod += ".incx0"
                    mod += ".incy0.incz0"
                if z_order > y_order > x_order:
                    if h_iterations != 1 or innermost_h[1] > 1:
                        mod += ".incy1"
                    else:
                        mod += ".incy0"
                    mod += ".incx0.incz0"
                # stride 2 loop need incx as two block processed
                if self.operator.stride == 1 and self.operator.filter_w == 1:
                    if self.last_column:
                        mod += ".incx0.incy0.incz0"
                    else:
                        mod += ".incx1.incy0.incz1"
            else:
                mod += ".incy0.incx0.incz1"
            if self.operator.buf_b_total_iterations > 1:
                mod += ".b1inc"
            else:
                mod += ".b1nil"
            if ic_loop_ordinal[0] == 0:
                if self.operator.filter_w > 1:
                    if self.enable_row_accumulate:
                        if h_loop_ordinal[0] == 0:
                            if self.buffer_b_flip_status == 0:
                                self.final_gib1_addr = self.gib1_addr.register + "__0"
                            else:
                                self.final_gib1_addr = (
                                    self.gib1_addr.register + "__" +
                                    self.buffer_b_blip_constant)
                            self.buffer_b_flip_status ^= icd.HALF_BUFFER_B_SIZE
                    else:
                        if self.buffer_b_flip_status == 0:
                            self.final_gib1_addr = self.gib1_addr.register + "__0"
                        else:
                            self.final_gib1_addr = (
                                self.gib1_addr.register + "__" +
                                self.buffer_b_blip_constant)
                        self.buffer_b_flip_status ^= icd.HALF_BUFFER_B_SIZE
        elif self.instr == "conv":
            mod = "on"
            if ic_loop_ordinal[0] == 0:
                mod += ".ini1"
                if oc_loop_ordinal[0] == 0:
                    if (self.operator.buf_a_total_iterations > 1 or
                        (h_loop_ordinal[0] == 0 and w_loop_ordinal[0] == 0)):
                        self.final_gib0_addr = self.gib0_addr.register
                    slot = self.slot_reg
                if ((h_loop_ordinal[0] == 0 and
                     w_loop_ordinal[0] == 0 and
                        sample_loop_ordinal[0] == 0) or (oc_iterations > 1)):
                    if innermost_oc[1] > 1:
                        z = self.updated_oc_regs
                    else:
                        z = innermost_oc[4]["start"]
                if self.operator.filter_w > 1:
                    if self.enable_row_accumulate:
                        if (h_loop_ordinal[0] == 0 and
                            oc_loop_ordinal[0] == 0 and
                                ic_loop_ordinal[0] == 0):
                            if self.buffer_b_flip_status == 0:
                                self.final_gib1_addr = self.gib1_addr.register + "__0"
                            else:
                                self.final_gib1_addr = (
                                    self.gib1_addr.register + "__" +
                                    self.buffer_b_blip_constant)
                            self.buffer_b_flip_status ^= icd.HALF_BUFFER_B_SIZE
                        else:
                            if oc_loop_ordinal[0] == 0:
                                mod += ".b1inc"
                            else:
                                mod += ".b1nil"
                    else:
                        if self.buffer_b_flip_status == 0:
                            self.final_gib1_addr = self.gib1_addr.register + "__0"
                        else:
                            self.final_gib1_addr = (
                                self.gib1_addr.register + "__" +
                                self.buffer_b_blip_constant)
                        self.buffer_b_flip_status ^= icd.HALF_BUFFER_B_SIZE
            else:
                mod += ".ini0"
            if ic_loop_ordinal[1] == -1:
                mod += ".out1"
            else:
                mod += ".out0"

            if self.operator.buf_a_total_iterations > 1:
                mod += ".b0inc"
            else:
                mod += ".b0nil"
            if self.operator.buf_b_total_iterations > 1:
                if ic_iterations > 1:
                    mod += ".b1inc"
                else:
                    if (oc_iterations == 1 or
                        ("unroll" not in innermost_oc[0] and
                         innermost_oc[1] == 1)):
                        mod += ".b1inc"
                    else:
                        if oc_loop_ordinal[1] == -1 and oc_iterations > 1:
                            mod += ".b1inc"
                        else:
                            mod += ".b1nil"
            else:
                mod += ".b1nil"

        return mod, y, z, slot

    def get_coordinate_value_and_modifier_bpw(
            self, ic_loop_ordinal, oc_loop_ordinal, h_loop_ordinal,
            w_loop_ordinal, sample_loop_ordinal, ic_iterations,
            oc_iterations, w_iterations, h_iterations, innermost_oc,
            innermost_w, innermost_h):
        mod = "on.wnil.snil.ro"
        y = None
        if h_iterations > 1:
            if h_loop_ordinal[1] != -1:
                mod += ".incx0.incy1"
            else:
                mod += ".incx1.incy0"
            if h_loop_ordinal[0] == 0:
                y = innermost_h[4]["start"]
        else:
            if w_iterations > 1:
                mod += ".incx1.incy0"
            else:
                mod += ".incx0.incy0"
        mod += ".incz0"
        # if ic_iterations > 1:
        #     if ic_loop_ordinal[1] == -1:
        #         mod += ".incz1"
        #     else:
        #         mod += ".incz0"
        # else:
        #     mod += ".incz0"
        if self.instr == "buf_a_ld":
            mod += ".b0inc"
        else:
            mod += ".b1inc"

        if self.instr == "buf_a_ld":
            mod += ".pb"
        else:
            if h_loop_ordinal[1] == -1:
                mod += ".po"
            else:
                mod += ".pb"

        return mod, y

    def get_sync_value_and_modifiers(
            self, loop_config, mod, ic_loop_ordinal, oc_loop_ordinal,
            h_loop_ordinal, w_loop_ordinal, sample_loop_ordinal,
            ic_iterations, oc_iterations, w_iterations, h_iterations,
            innermost_oc, innermost_w, innermost_h):

        wsc = None
        ssc = None
        if self.operator.filter_w == 1:
            if self.accu_times > 1:
                if self.instr == "buf_b_ld":
                    if (h_loop_ordinal[0] == 0 and ic_loop_ordinal[0] == 0):
                        if innermost_w[1] > 1 or w_loop_ordinal[0] == 0:
                            self.accu_iter = 0
                    if self.accu_iter % self.accu_times == 0:
                        mod += ".winc"
                    else:
                        mod += ".wnil"
                    if self.accu_iter % self.accu_times == 1:
                        mod += ".sinc"
                    else:
                        if (w_loop_ordinal[1] == -1 and h_loop_ordinal[1] == -1):
                            mod += ".sinc"
                        else:
                            mod += ".snil"
                elif self.instr == "conv":
                    if (h_loop_ordinal[0] == 0 and ic_loop_ordinal[0] == 0):
                        if innermost_w[1] > 1 or w_loop_ordinal[0] == 0:
                            if oc_loop_ordinal[0] == 0:
                                self.accu_iter = 0
                    if self.accu_iter % self.accu_times == 0:
                        if oc_loop_ordinal[0] == 0:
                            mod += ".winc"
                        else:
                            mod += ".wnil"
                    else:
                        mod += ".wnil"
                    if self.accu_iter % self.accu_times == 1:
                        if oc_loop_ordinal[1] == -1:
                            mod += ".sinc"
                        else:
                            mod += ".snil"
                    elif (w_loop_ordinal[1] == -1 and h_loop_ordinal[1] == -1):
                        if oc_loop_ordinal[1] == -1:
                            mod += ".sinc"
                        else:
                            mod += ".snil"
                    else:
                        mod += ".snil"

                if self.instr == "buf_b_ld":
                    self.accu_iter += 1
                elif self.instr == "conv":
                    if oc_loop_ordinal[1] == -1:
                        self.accu_iter += 1
            else:
                if self.instr == "conv":
                    if oc_loop_ordinal[0] == 0:
                        mod += ".winc"
                    if oc_loop_ordinal[1] == -1:
                        mod += ".sinc"
                    if "winc" not in mod:
                        mod += ".wnil"
                    if "sinc" not in mod:
                        mod += ".snil"
        elif self.operator.filter_w > 1:
            if h_loop_ordinal[0] == 0:
                self.accu_iter = 0
            if self.instr == "conv":
                if self.enable_row_accumulate:
                    if self.accu_iter % self.accu_times == 0 or self.accu_times==1:
                        if oc_loop_ordinal[0] == 0:
                            mod += ".winc"
                            if h_loop_ordinal[0] == 0:
                                wsc = (self.wsc_reg + flip_suffix +
                                       "{}".format(self.wsc_flip_status))
                                self.wsc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                        else:
                            mod += ".wnil"
                    else:
                        mod += ".wnil"

                    if (self.accu_iter % self.accu_times == self.accu_times-1 or
                            h_loop_ordinal[1] == -1 or self.accu_times==1):
                        if oc_loop_ordinal[1] == -1:
                            mod += ".sinc"
                            if (h_loop_ordinal[0] == self.accu_times-1 or
                                (h_loop_ordinal[1] == -1 and h_iterations < self.accu_times)):
                                ssc = (self.ssc_reg + flip_suffix +
                                       "{}".format(self.ssc_flip_status))
                                self.ssc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                        else:
                            mod += ".snil"
                    else:
                        mod += ".snil"
                else:
                    if ic_loop_ordinal[0] == 0 and ic_loop_ordinal[1] == -1:
                        if oc_loop_ordinal[0] == 0 and oc_loop_ordinal[1] == -1:
                            mod += ".wset.sset"
                            wsc = (self.wsc_reg + flip_suffix +
                                   "{}".format(self.wsc_flip_status))
                            self.wsc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                            ssc = (self.ssc_reg + flip_suffix +
                                   "{}".format(self.ssc_flip_status))
                            self.ssc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                        elif oc_loop_ordinal[0] == 0:
                            mod += ".wset.snil"
                            wsc = (self.wsc_reg + flip_suffix +
                                   "{}".format(self.wsc_flip_status))
                            self.wsc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                            ssc = (self.ssc_reg + flip_suffix +
                                   "{}".format(self.ssc_flip_status))
                            self.ssc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                        elif oc_loop_ordinal[1] == -1:
                            mod += ".wnil.sinc"
                            wsc = None
                            ssc = None
                    elif ic_loop_ordinal[0] == 0 and oc_loop_ordinal[0] == 0:
                        mod += ".wset.snil"
                        wsc = (self.wsc_reg + flip_suffix +
                               "{}".format(self.wsc_flip_status))
                        self.wsc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                        ssc = (self.ssc_reg + flip_suffix +
                               "{}".format(self.ssc_flip_status))
                        self.ssc_flip_status ^= icd.SYNC_CHANNEL_FLIP
            elif self.instr == "buf_b_ld":
                if self.enable_row_accumulate:
                    if oc_loop_ordinal[0] == 0:
                        if mod and ".pb" in mod:
                            if h_loop_ordinal[0] == 0:
                                pre_mod = ".off.incx0.incy0.incz0.wnil.snil.b1nil"
                                total_accumulate = int(
                                    (h_iterations + self.accu_times - 1)/self.accu_times)
                                for i in range(total_accumulate):
                                    pre_mod += ".wset.snil"
                                    pre_values = dict()
                                    pre_values["wsc"] = (self.wsc_reg + flip_suffix +
                                                         "{}".format(i))
                                    self.save_in_modifiers_to_stack((pre_mod, pre_values))
                                    self.merge_in_off_modifiers(loop_config, condition=True)
                            mod += ".wnil.snil"
                            if self.accu_iter % self.accu_times == 0 or self.accu_times==1:
                                mod += ".winc"
                                if h_loop_ordinal[0] == 0:
                                    wsc = (self.wsc_reg + flip_suffix +
                                           "{}".format(self.wsc_flip_status))
                                    self.wsc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                                else:
                                    wsc = None
                            else:
                                mod += ".wnil"
                            if (self.accu_iter % self.accu_times == self.accu_times-1 or
                                    self.accu_times == 1 or h_loop_ordinal[1] == -1):
                                mod += ".sinc"
                                if (h_loop_ordinal[0] == self.accu_times-1 or
                                    (h_loop_ordinal[1] == -1 and h_iterations < self.accu_times)):
                                    ssc = (self.ssc_reg + flip_suffix +
                                           "{}".format(self.ssc_flip_status))
                                    self.ssc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                                else:
                                    ssc = None
                            else:
                                mod += ".snil"
                        else:  # po columns
                            if self.accu_iter % self.accu_times == 0 or self.accu_times==1:
                                mod += ".winc"
                                if h_loop_ordinal[0] == 0:
                                    wsc = (self.wsc_reg + flip_suffix +
                                           "{}".format(self.wsc_flip_status))
                                    self.wsc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                            else:
                                mod += ".wnil"

                            if (self.accu_iter % self.accu_times == self.accu_times-1 or
                                    h_loop_ordinal[1] == -1 or self.accu_times==1):
                                mod += ".sinc"
                                if (h_loop_ordinal[0] == self.accu_times-1 or
                                    (h_loop_ordinal[1] == -1 and h_iterations < self.accu_times)):
                                    ssc = (self.ssc_reg + flip_suffix +
                                           "{}".format(self.ssc_flip_status))
                                    self.ssc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                            else:
                                mod += ".snil"
                    else:
                        mod += "wnil.snil"
                else:  # no row accumulation
                    if mod and ".pb" in mod:
                        pre_mod = ".off.incx0.incy0.incz0.wset.snil.b1nil"
                        pre_values = dict()
                        pre_values["wsc"] = (self.wsc_reg + flip_suffix +
                                             "{}".format(self.wsc_flip_status))
                        self.wsc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                        self.ssc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                        # pre_values["ssc"] = self.ssc_reg
                        self.save_in_modifiers_to_stack((pre_mod, pre_values))
                        self.merge_in_off_modifiers(loop_config, condition=True)
                        if ic_loop_ordinal[0] != 0:
                            mod += ".wset.sset"
                            wsc = (self.wsc_reg + flip_suffix +
                                   "{}".format(self.wsc_flip_status))
                            self.wsc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                            ssc = (self.ssc_reg + flip_suffix +
                                   "{}".format(self.ssc_flip_status))
                            self.ssc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                    if ic_loop_ordinal[0] == 0:
                        mod += ".wset.sset"
                        wsc = (self.wsc_reg + flip_suffix +
                               "{}".format(self.wsc_flip_status))
                        self.wsc_flip_status ^= icd.SYNC_CHANNEL_FLIP
                        ssc = (self.ssc_reg + flip_suffix +
                               "{}".format(self.ssc_flip_status))
                        self.ssc_flip_status ^= icd.SYNC_CHANNEL_FLIP

            if self.instr == "conv":
                if oc_loop_ordinal[1] == -1:
                    self.accu_iter += 1
            else:
                self.accu_iter += 1

        return mod, wsc, ssc

    def get_sync_value_and_modifiers_bpw(
            self, loop_config, mod, ic_loop_ordinal, oc_loop_ordinal,
            h_loop_ordinal, w_loop_ordinal, sample_loop_ordinal,
            ic_iterations, oc_iterations, w_iterations, h_iterations,
            innermost_oc, innermost_w, innermost_h):

        if self.instr == "buf_b_ld":
            if self.accu_times > 1:
                if (h_loop_ordinal[0] == 0):
                    if innermost_w[1] > 1 or w_loop_ordinal[0] == 0:
                        self.accu_iter = 0
                if self.accu_iter % self.accu_times == 0:
                    mod += ".winc"
                else:
                    mod += ".wnil"
                if self.accu_iter % self.accu_times == self.accu_times-1:
                    mod += ".sinc"
                else:
                    if (w_loop_ordinal[1] == -1 and h_loop_ordinal[1] == -1):
                        mod += ".sinc"
                    else:
                        mod += ".snil"
            else:
                mod += ".winc.sinc"

            self.accu_iter += 1
        else:
            if self.accu_times_bufa > 1:
                if (h_loop_ordinal[0] == 0):
                    if innermost_w[1] > 1 or w_loop_ordinal[0] == 0:
                        self.accu_iter_bufa = 0
                if self.accu_iter_bufa % self.accu_times_bufa == 0:
                    mod += ".winc"
                else:
                    mod += ".wnil"
                if self.accu_iter_bufa % self.accu_times_bufa == self.accu_times_bufa-1:
                    mod += ".sinc"
                else:
                    if (w_loop_ordinal[1] == -1 and h_loop_ordinal[1] == -1):
                        mod += ".sinc"
                    else:
                        mod += ".snil"
            else:
                mod += ".winc.sinc"

            self.accu_iter_bufa += 1

        return mod

    def get_destination_type(self, oc_loop_ordinal, oc_iterations):
        Destination_type = None
        if self.ich_split:
            if self.instr == "conv":
                firstu = False
                for fcall in reversed(inspect.stack()):
                    if fcall[3] == "handle_loop_header":
                        loops = fcall.frame.f_locals["loop_config"]
                        loop = loops[0]
                        if loop[0] == bcd.ICH_SPLIT_LOOP_NAME and loop[1] == 1:
                            firstu = True
                if firstu:
                    Destination_type = "z0"
                else:
                    Destination_type = "ir0"

        if self.instr == "conv" and self.operator.stride == 1:
            if oc_iterations > 1:
                if self.enable_row_accumulate:
                    Destination_type = "ir" + str(oc_loop_ordinal[0] * icd.OC64_TLR_SIZE)
                else:
                    Destination_type = "ir" + str(self.itlr_column_iter)
                    # inner_oc should update brst num to keep vector seq
                    self.itlr_column_iter += self.brst_num
            else:
                Destination_type = "ir0"

        return Destination_type

    def get_bound_coordinate(self, x, y, z, ic_loop_ordinal, oc_loop_ordinal):
        bx = self.boundx
        by = self.boundy
        # compute bound xy if for full unroll
        if self.instr == "conv" and self.operator.stride == 1:
            if self.operator.sample_full_unroll == 2:
                mbx, mby = bcd.get_boundary_coordinates(
                    self.sample_col_iter,
                    self.sample_row_iter,
                    self.operator.input_w,
                    self.operator.input_h,
                )
                bx = int(mbx[1]) << 3 | int(mbx[0])
                by = int(mby[1]) << 3 | int(mby[1])
            elif (
                self.operator.sample_full_unroll == 1
                and oc_loop_ordinal[0] == 0
                and ic_loop_ordinal[0] == 0
            ):
                self.generate_boundx_coord()
                self.generate_boundy_coord()
                bx = self.boundx
                by = self.boundy
            # for stride 2 case, no need to set x, y, z, w coordinate
            x = None
            y = None
            z = None

        return bx, by, x, y, z

    def generate_middle_innermost_statement(
        self,
        loop_config,
        modifier=None,
        first=True,
        transient=False,
        acculast=False,
        innermost_h=None,
        innermost_w=None,
        innermost_oc=None,
        innermost_sample=None,
        innermost_ic=None
    ):
        x = None
        y = None
        z = None
        w = None
        slot = None
        ssc = None
        wsc = None
        mod = None
        bx = None
        by = None
        Destination_type = None

        self.merge_out_off_modifiers(force=True)

        # print("innermost_oc is ", innermost_oc)
        oc_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_oc)
        ic_loop_ordinal = self.get_unrolled_interation_ordinal(loop_config[0])
        ic_iterations = ic_loop_ordinal[0] - ic_loop_ordinal[1]
        oc_iterations = oc_loop_ordinal[0] - oc_loop_ordinal[1]

        h_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_h)
        w_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_w)
        sample_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_sample)
        h_iterations = h_loop_ordinal[0] - h_loop_ordinal[1]
        w_iterations = w_loop_ordinal[0] - w_loop_ordinal[1]
        # sample_iterations = sample_loop_ordinal[0] - sample_loop_ordinal[1]

        # print("innermost_oc is ", innermost_oc)

        if self.operator.name != "bpw_mma":
            mod, y, z, slot = self.get_coodinate_value_and_modifiers(
                ic_loop_ordinal, oc_loop_ordinal, h_loop_ordinal,
                w_loop_ordinal, sample_loop_ordinal, ic_iterations,
                oc_iterations, w_iterations, h_iterations, innermost_oc,
                innermost_w, innermost_h)
            mod, wsc, ssc = self.get_sync_value_and_modifiers(
                loop_config, mod, ic_loop_ordinal, oc_loop_ordinal,
                h_loop_ordinal, w_loop_ordinal, sample_loop_ordinal,
                ic_iterations, oc_iterations, w_iterations, h_iterations,
                innermost_oc, innermost_w, innermost_h)
        else:
            mod, y = self.get_coordinate_value_and_modifier_bpw(
                ic_loop_ordinal, oc_loop_ordinal, h_loop_ordinal,
                w_loop_ordinal, sample_loop_ordinal, ic_iterations,
                oc_iterations, w_iterations, h_iterations, innermost_oc,
                innermost_w, innermost_h)
            mod = self.get_sync_value_and_modifiers_bpw(
                loop_config, mod, ic_loop_ordinal, oc_loop_ordinal,
                h_loop_ordinal, w_loop_ordinal, sample_loop_ordinal,
                ic_iterations, oc_iterations, w_iterations, h_iterations,
                innermost_oc, innermost_w, innermost_h)

        self.merge_in_off_modifiers(loop_config, condition=True)

        tra = False
        if modifier is not None:
            if mod:
                mod += modifier
            else:
                mod = modifier

        Destination_type = self.get_destination_type(
            oc_loop_ordinal, oc_iterations)

        bx, by, x, y, z = self.get_bound_coordinate(
            x, y, z, ic_loop_ordinal, oc_loop_ordinal)

        if (self.operator.name == "fwd_conv" and
                self.instr != "buf_b_ld"):
            if "incz1" in mod:
                z = None
            if "incy1" in mod:
                y = None
            if "incx1" in mod:
                x = None

        self.operator.operator[self.instr].generate(
            gib0_addr=self.final_gib0_addr,
            gib1_addr=self.final_gib1_addr,
            x=x,
            y=y,
            z=z,
            w=w,
            slot=slot,
            wsc=wsc,
            ssc=ssc,
            padx=self.final_padx,
            gib0_step=self.final_gib0_step,
            gib1_step=self.final_gib1_step,
            indent=self.indent,
            transient=tra,
            modifier=mod,
            stride=self.operator.stride,
            boundary_x=bx,
            boundary_y=by,
            Destination=Destination_type
        )
        self.final_gib0_addr = None
        self.final_gib1_addr = None
        self.final_gib0_step = None
        self.final_gib1_step = None

        if self.operator.filter_w > 1 and ".pb" in mod and self.instr == "buf_b_ld":
            if self.operator.name == "fwd_conv" and self.instr == "buf_b_ld":
                if not self.last_tcore_instr:
                    self.sadd.generate(
                        self.indent,
                        dst=self.wsc_reg,
                        src1=self.wsc_reg,
                        src2=0x1,
                        comment="// Increase wsr reg with 0x01",
                    )
                    self.sadd.generate(
                        self.indent,
                        dst=self.ssc_reg,
                        src1=self.ssc_reg,
                        src2=0x1,
                        comment="// Increase ssr reg with 0x01",
                    )
        self.new_col_start = False
        self.new_row_start = False
        self.cwarp_first_instr = False

    def handle_bpw_pb_po_setting(self, loop_config):
        if self.operator.name == "bpw_mma":
            self.pb_po_modifier = ".po"

    def handle_innermost_loop(
        self,
        loop_config,
        real_iter,
        unroll_times,
        prefix,
        comment,
        accufirst=False,
        acculast=False,
        innermost_h=None,
        innermost_w=None,
        innermost_oc=None,
        innermost_sample=None,
        innermost_ic=None
    ):
        # check whether need to accumulate, maybe need more conditions
        mod = None
        # check bufb need accu and set modifier
        e = loop_config[0]
        if (
            self.instr == "buf_b_ld"
            and e[0] == "ich"
            and e[3] < icd.ACCU_ICH_NUM
            and self.accu_times > 1
        ):
            if self.operator.filter_w > 1:
                self.gib1_addr.inc_unit = icd.ACCU_BUFFER_NUM

        if self.instr == "conv" and self.accu_times > 1:
            if self.conv_accu_left_block_mod:
                self.accu_left_step_flip = icd.ACCU_BUFFER_NUM
                self.final_gib1_step = icd.ACCU_BUFFER_NUM * self.accu_times

        self.handle_bpw_pb_po_setting(loop_config)

        if self.instr == "buf_a_ld":
            self.gib0_addr.innermost_loop_unroll = True
        elif self.instr == "buf_b_ld":
            self.gib1_addr.innermost_loop_unroll = True
        else:
            self.gib1_addr.innermost_loop_unroll = True
            self.gib0_addr.innermost_loop_unroll = True

        # self.save_buf_b_address()
        # self.flip_buf_b_address()
        self.restore_buffer_a_address_for_new_inner_oc()
        self.restore_buf_b_address_for_next_32oc()

        if self.operator.name == "bpw_mma":
            unroll_times = real_iter

        if real_iter >= 1:
            for i in range(unroll_times):
                if i == 0:
                    self.first_tcore_instr = True
                else:
                    self.first_tcore_instr = False
                if i == unroll_times - 1:
                    if i == 0 or unroll_times * e[3] == self.operator.ich_num:
                        self.last_tcore_instr = True
                else:
                    self.last_tcore_instr = False
                if self.instr == "buf_a_ld" or self.instr == "conv":
                    self.gib0_addr.last_tcore_instr = self.last_tcore_instr
                    self.gib0_addr.first_tcore_instr = self.first_tcore_instr
                    self.gib0_addr.instr_type = self.instr
                if self.instr == "buf_b_ld" or self.instr == "conv":
                    self.gib1_addr.last_tcore_instr = self.last_tcore_instr
                    self.gib1_addr.instr_type = self.instr
                    self.gib1_addr.first_tcore_instr = self.first_tcore_instr

                self.generate_middle_innermost_statement(
                    loop_config=loop_config, modifier=mod, acculast=acculast,
                    innermost_h=innermost_h,
                    innermost_w=innermost_w,
                    innermost_oc=innermost_oc,
                    innermost_sample=innermost_sample,
                    innermost_ic=innermost_ic
                )
        # w==1 only 1 oc need update tlr at last of stride loop
        if (
            self.instr == "conv"
            and e[0] == "ich"
            and self.operator.stride == 1
            and (
                not self.inner_oc_full_unroll
                or (self.inner_oc_iter == 1 and self.operator.filter_w == 1)
            )
        ):
            if icd.CONV_OCH_SIZE == 64:
                tlr_step = 8
            else:
                tlr_step = self.brst_num
            # only iter number > 1 update dst tlr-->real_iter > 1
            if self.operator.filter_w == 1:
                self.generate_tlr_index(e, self.base_reg, tlr_step)
            # self.update_stride_boundary(True)
            # self.update_stride_boundary(False)
        # input channels not aligned to ich
        if self.operator.name != "bpw_mma":
            self.handle_innermost_loop_left_input_channels(unroll_times, e)

    def handle_innermost_loop_left_input_channels(self, unroll_times, loop_config):
        e = loop_config
        if unroll_times * e[3] < self.operator.ich_num and not self.ich_split:
            left_channels = self.operator.ich_num - unroll_times * e[3]
            lich = br_tcore_utils.find_left_channels(left_channels, self.operator.dt[0])
            old_inc = 0

            if self.instr == "buf_a_ld":
                old_inc = self.gib0_addr.inc_unit
            elif self.instr == "buf_b_ld":
                old_inc = self.gib1_addr.inc_unit
            elif self.instr == "conv":
                old_inc = self.gib1_addr.inc_unit

            lich_num = 0
            for ich, num in lich.items():
                lich_num += 1
                for unroll in range(num):
                    self.first_tcore_instr = False
                    if lich_num == len(lich) and unroll == num - 1:
                        self.last_tcore_instr = True
                    else:
                        self.last_tcore_instr = False

                    inc = int(
                        ich
                        / (
                            icd.BUFFER_A_ENTRY_ICH_NUM
                            * self.operator.filter_w
                            * self.operator.filter_h
                        )
                    )
                    if self.instr == "buf_a_ld":
                        self.gib0_addr.inc_unit = inc
                    elif self.instr == "buf_b_ld":
                        self.gib1_addr.inc_unit = inc
                    elif self.instr == "conv":
                        self.gib0_addr.inc_unit = inc
                        self.gib1_addr.inc_unit = inc
                    mod = ".ich" + str(ich)
                    self.generate_middle_innermost_statement(
                        loop_config=loop_config, modifier=mod, transient=True
                    )
            # restore old value
            # self.operator.operator[self.instr].setinput(old_ich)
            if self.instr == "buf_a_ld":
                self.gib0_addr.inc_unit = old_inc
            elif self.instr == "buf_b_ld":
                self.gib1_addr.inc_unit = old_inc
            elif self.instr == "conv":
                self.gib1_addr.inc_unit = old_inc
                self.gib0_addr.inc_unit = old_inc

    def add_flip_for_buf_b_ld(self):
        if len(self.loop_execution_stack) > 1:
            previous_loop = self.loop_execution_stack[-2]
            # if "col" in previous_loop[0]:
            #     if self.instr == "buf_b_ld":
            #         # print("Add flip here")
            #         self.flip_buf_b_address()
            if "col" in previous_loop[0] or "stride" in previous_loop[0]:
                if self.instr == "conv":
                    self.new_col_start = True
            if "row" in previous_loop[0] or "stride" in previous_loop[0]:
                if self.instr == "conv":
                    self.new_row_start = True

    def generate_actual_loops(
        self,
        loop_config,
        prefix,
        comment=None,
        sample=None,
        acculast=False,
        accufirst=False,
        innermost_h=None,
        innermost_w=None,
        innermost_oc=None,
        innermost_sample=None,
        innermost_ic=None,
        innermost_kw=None,
        innermost_kh=None,
        innermore_kw=None,
        innermore_ic=None,
        innermore_oc=None,
        innermore_h=None,
        innermore_w=None
    ):
        n = len(loop_config)
        e = loop_config[0]
        self.print_loop_config(e)
        iter = e[1]

        current_loop_iter, t = self.preprocess_loop_attributes(loop_config)

        real_iter, unroll_times = self.get_real_iter_and_unroll_times(e[1], e[2])

        counter_reg = None
        label = None

        if n == 1:  # Indicates this is the innermost loop
            self.handle_innermost_loop(
                loop_config,
                real_iter,
                unroll_times,
                prefix,
                comment,
                accufirst=accufirst,
                acculast=acculast,
                innermost_h=innermost_h,
                innermost_w=innermost_w,
                innermost_oc=innermost_oc,
                innermost_sample=innermost_sample,
                innermost_ic=innermost_ic
            )
        else:
            suffix = e[0].upper() + "_{}".format(len(self.loop_config) - n)
            if len(e) > 4:
                loop_attrib = e[4]
            else:
                loop_attrib = {}
            counter_reg = self.allocate_loop_counter_register(
                e[1],
                e[2],
                e[3],
                loop_attrib,
                prefix,
                e[0],
                suffix=suffix,
            )
            self.keep_loop_counter_register(loop_config, counter_reg)
            temp_oc_reg = self.reduce_oc_regs_to_two(loop_config)

            label, iter, loop_end_reg = self.handle_loop_header(
                loop_config,
                real_iter,
                prefix,
                current_loop_iter,
                counter_reg,
                acculast=acculast,
                accufirst=accufirst,
                innermost_h=innermost_h,
                innermost_w=innermost_w,
                innermost_oc=innermost_oc,
                innermost_sample=innermost_sample,
                innermost_ic=innermost_ic
            )
            if self.instr == "conv":
                self.add_instruction_to_set_coordiante_modifier(loop_config)
            # print("iter number after header is ", iter)

            self.handle_loop_body(
                loop_config,
                counter_reg,
                real_iter,
                unroll_times,
                prefix,
                current_loop_iter,
                innermost_h=innermost_h,
                innermost_w=innermost_w,
                innermost_oc=innermost_oc,
                innermost_sample=innermost_sample,
                innermost_ic=innermost_ic
            )

            self.true_loop_config.append(
                (
                    e[0],
                    iter,
                    e[2],
                    counter_reg,
                    label,
                    real_iter,
                    unroll_times,
                    e[3],
                )
            )

            # print("self.true_loop_config is ", self.true_loop_config)
            # Generate the tail part of corresponding loop.
            self.handle_loop_tail(
                loop_config,
                counter_reg,
                prefix,
                current_loop_iter,
                acculast=acculast,
                loop_end_reg=loop_end_reg,
                innermost_h=innermost_h,
                innermost_w=innermost_w,
                innermost_oc=innermost_oc,
                innermost_sample=innermost_sample,
                innermost_ic=innermost_ic
            )

            self.pop_loop_counter_register(loop_config, counter_reg)

            # Specail handle for release the counter register
            rm.wsr_free(temp_oc_reg)
            rm.wsr_free(counter_reg)

        self.add_flip_for_buf_b_ld()
        self.postprocess_loop_attributes(e, t)

    def reduce_oc_regs_to_two(self, loop_config):
        e = loop_config[0]
        new_regs = []
        q = None
        self.updated_oc_regs = self.oc_regs
        if len(self.oc_regs) > 2:
            if self.instr == "conv" and "inner_oc" in e[0]:
                size = len(self.oc_regs)
                q = rm.wsr_alloc("temp_register")
                new_regs.append((self.oc_regs[-1]))
                self.sadd.generate(
                    self.indent,
                    dst=q,
                    src1=self.oc_regs[0][0],
                    src2=self.oc_regs[1][0],
                )
                for i in range(size - 2 - 1):
                    self.sadd.generate(
                        self.indent,
                        dst=q,
                        src1=q,
                        src2=self.oc_regs[i + 2][0],
                    )
                new_regs.append((q, None, None))
                self.updated_oc_regs = new_regs
        return q

    def handle_loop_header(
        self,
        loop_config,
        real_iter,
        prefix,
        current_loop_iterations,
        counter_reg,
        acculast=False,
        accufirst=False,
        innermost_h=None,
        innermost_w=None,
        innermost_oc=None,
        innermost_sample=None,
        innermost_ic=None
    ):
        comment = "// Initialize index register of {}"
        if (
            self.instr == "conv"
            and "stride" in loop_config[0][0]
            and self.operator.stride == 1
            and self.operator.filter_w == 1
            and not self.last_column
        ):

            ordinal = self.get_unrolled_interation_ordinal(loop_config[0])
            if loop_config[0][1] > 1 or ordinal[0] == 0:
                self.reset_a1()

        if (
            self.instr == "conv"
            and "inner_oc" in loop_config[0][0]
            and self.operator.stride == 1
            and self.operator.filter_w > 1
            and not self.column_stride_unroll
            # and not self.last_column
        ):
            if not self.enable_row_accumulate:
                self.save_column_tlr_state()

        e = loop_config[0]
        uinc = e[3]

        fun = self.generate_actual_loops_with_unrolls
        iter = e[1]

        if "col" in e[0] and self.instr == "buf_b_ld":
            # The first column needs to be "pb", others to be "po".
            if self.operator.filter_w != 1 and self.operator.name != "bpw_mma":
                (
                    real_iter,
                    unroll_times,
                ) = self.get_real_iter_and_unroll_times(e[1] - 1, e[2])
                iter -= 1
                current_loop_iterations.iterations += 1
            else:
                fun = None
            if self.get_unrolled_interation_ordinal(e)[0] == 0:
                self.pb_po_modifier = ".pb"
                self.new_col_start = True

        elif e[0] == "inner_oc" and self.instr == "conv":
            self.first_inner_oc = True
            self.gib0_addr.first_iter_of_inner_oc_loop = True
            self.gib1_addr.first_iter_of_inner_oc_loop = True
            self.coord_x_reg.first_iter_of_inner_oc_loop = True
            self.coord_y_reg.first_iter_of_inner_oc_loop = True
            self.coord_w_reg.first_iter_of_inner_oc_loop = True
            self.coord_z_reg.first_iter_of_inner_oc_loop = True
            if e[1] == 1:
                fun = None
            else:
                iter -= 2
                current_loop_iterations.iterations += 1
        elif "ich" in e[0] and self.instr == "conv":
            pass
        elif "row" in e[0]:
            fun = None
            self.new_row_start = True
        elif e[0] == bcd.ICH_SPLIT_LOOP_NAME and self.instr == "conv":
            loops = []
            for loop in loop_config:
                if loop[0] == bcd.ICH_SPLIT_LOOP_NAME:
                    self.ich_split = True
                    t1 = (loop[0], 1, 1)

                    if len(loop) > 3:
                        t1 += loop[3:]
                    loops.append(t1)

                else:
                    loops.append(loop)

            loop_config = loops
            iter -= 1

        else:
            fun = None
        # use_unroll = 1
        # if self.instr != "conv":
        #    use_unroll = e[2]

        if fun:
            self.restore_slot_register_for_new_block(
                loop_config, innermost_h, innermost_w)

        # step not increase if unroll, as we did step add at the middle.
        label, loop_end_reg = self.generate_header(
            e[1],
            real_iter,
            iter,
            uinc,
            prefix=prefix,
            counter_reg=counter_reg,
            suffix=e[0].upper(),
            loop_fun=fun,
            comment=comment,
            loop_config=copy.deepcopy(loop_config[1:]),
            loop_name=e[0],
            acculast=acculast,
            accufirst=accufirst,
            innermost_h=innermost_h,
            innermost_w=innermost_w,
            innermost_oc=innermost_oc,
            innermost_sample=innermost_sample,
            innermost_ic=innermost_ic
        )

        self.restore_slot_register_for_new_block(
            loop_config, innermost_h, innermost_w)

        self.save_buffer_a_address_for_new_inner_oc_loop(loop_config)

        self.add_extra_handling_in_front(loop_config)

        return label, iter, loop_end_reg

    def flip_slot_register_between_high_low(self, current_loop_config):
        if self.instr != "conv":
            return
        e = current_loop_config
        if "oc" not in e[0]:
            return
        loop_ordinal = self.get_unrolled_interation_ordinal(e)
        loop_iterations = loop_ordinal[0] - loop_ordinal[1]
        if len(self.oc_loop_configs) == self.oc_levels - 1:
            if e[1] > 1 or loop_iterations > 1:
                self.sxor.generate(
                    self.indent,
                    dst=self.slot_flip_reg.register,
                    src1=self.slot_flip_reg.register,
                    src2=0x8,
                    comment="// Flip slot reg with 0x08",
                )

    def restore_slot_register_for_new_block(
            self, loop_config, innermost_h, innermost_w):
        if self.instr != "conv":
            return
        if len(loop_config) > 1:
            e = loop_config[0]
            if "inner_oc" not in e[0]:
                return
            h_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_h)
            w_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_w)
            oc_loop_ordinal = self.get_unrolled_interation_ordinal(e)
            if (len(self.oc_loop_configs) == self.oc_levels and
                    oc_loop_ordinal[0] == 0):
                if (w_loop_ordinal[0] == 0 and self.operator.filter_w > 1) or (
                    h_loop_ordinal[0] == 0 and self.operator.filter_w == 1):
                    if self.slot_flip_reg.register:
                        self.smov.generate(
                            self.indent,
                            dst=self.slot_reg.register,
                            src1=self.slot_flip_reg.register,
                            comment=(
                                "// Init slot register with corresponding "
                                "low/high base index"))

    def save_buffer_a_address_for_new_inner_oc_loop(self, loop_config):
        # e = loop_config[0]
        # if self.instr == "conv" and "oc" in e[0]:
        #     if len(self.oc_loop_configs) == self.oc_levels - 1:
        #         self.gib0_save_reg = rm.wsr_alloc("temp_save_register_gib0")
        #         self.smov.generate(
        #             self.indent,
        #             dst=self.gib0_save_reg,
        #             src1=self.gib0_addr.register,
        #             comment="// Save buffer a address",
        #         )
        pass

    def restore_buffer_a_address_for_new_inner_oc(self):
        # if self.instr == "conv":
        #     if self.first_innermost_loop:
        #         self.smov.generate(
        #             self.indent,
        #             dst=self.gib0_addr.register,
        #             src1=self.gib0_save_reg,
        #             comment="// Restore buffer a address",
        #         )
        pass

    def restore_buf_b_address_for_next_32oc(self):
        if self.instr != "conv":
            return

        self.first_innermost_loop = False

    def handle_loop_body(
        self,
        loop_config,
        counter_reg,
        real_iter,
        unroll_times,
        prefix,
        current_loop_iterations,
        innermost_h=None,
        innermost_w=None,
        innermost_oc=None,
        innermost_sample=None,
        innermost_ic=None,
    ):
        comment = "// Initialize index register of {}"
        e = loop_config[0]
        if "col" in e[0]:
            self.coord_x_reg.inc_unit = e[3]
            if counter_reg is None:
                self.coord_x_reg.register = 0
            else:
                self.coord_x_reg.register = counter_reg
        elif "row" in e[0]:
            self.coord_y_reg.inc_unit = e[3]
            if counter_reg is None:
                self.coord_y_reg.register = 0
            else:
                self.coord_y_reg.register = counter_reg
        elif "inner_oc" in e[0]:
            pass
        elif "outer_oc" in e[0]:
            self.coord_z_reg.outer_oc_loop_inc_unit = e[3]
            if counter_reg is None:
                self.coord_z_reg.outer_oc_loop_reg = 0
            else:
                self.coord_z_reg.outer_oc_loop_reg = counter_reg
        elif "sample" in e[0]:
            self.coord_w_reg.inc_unit = e[3]
            self.coord_w_reg.register = counter_reg

        if "oc" in e[0] and self.instr == "buf_a_ld":
            self.coord_z_reg.inc_unit = e[3]
            if counter_reg is None:
                self.coord_z_reg.register = 0
            else:
                self.coord_z_reg.register = counter_reg
        if "col" in e[0] and self.instr == "buf_b_ld":
            if self.operator.filter_w != 1:
                self.pb_po_modifier = ".po"
            self.new_col_start = True
            if e[1] == 1:
                unroll_times = 1
        elif "row" in e[0]:
            self.new_row_start = True
        elif "inner_oc" in e[0] and self.instr == "conv":
            (
                real_iter,
                unroll_times,
            ) = self.get_real_iter_and_unroll_times(e[1] - 2, e[2])
            if "unroll" in e[0] or e[1] == 1:
                real_iter = 1
            if e[1] == 2 or e[1] == 1:
                unroll_times = 1
            self.coord_z_reg.inc_unit = e[3]
            if counter_reg is None:
                self.coord_z_reg.register = 0
            else:
                self.coord_z_reg.register = counter_reg
            self.slot_reg.first_iter_of_inner_oc_loop = True
            self.first_inner_oc = False
            self.gib0_addr.first_iter_of_inner_oc_loop = True
            self.gib1_addr.first_iter_of_inner_oc_loop = True
            self.coord_z_reg.first_iter_of_inner_oc_loop = True
            self.slot_reg.first_iter_of_inner_oc_loop = True
        j = 0
        if unroll_times >= 1 and real_iter > 0:
            last = False
            # if full unroll need decrease header when width > 1
            if (
                self.instr == "buf_b_ld"
                and "col" in loop_config[0][0]
                and loop_config[0][1] // loop_config[0][2] == 1
                and self.operator.filter_w > 1
            ):
                if self.operator.name != "bpw_mma":
                    unroll_times -= 1
            for u in range(unroll_times):
                # only works for bufb accu_times != 0.
                # suppose for w==1
                if "row" in e[0]:
                    self.new_row_start = True
                elif "col" in e[0]:
                    self.new_col_start = True
                if (
                    (self.instr == "conv" or self.instr == "buf_b_ld")
                    and self.accu_times > 1
                    and "row" in loop_config[0][0]
                    and self.operator.filter_w == 1
                ):
                    if unroll_times < self.accu_times:
                        lu = self.accu_unroll_iter
                        self.accu_unroll_iter += 1
                    else:
                        lu = u
                    # if full unroll, add 1 for pb in header
                    if (unroll_times + 1) == loop_config[0][1]:
                        lu += 1
                    if (lu + 1) % self.accu_times == 0:
                        last = True
                    else:
                        last = False
                    if lu % self.accu_times == 0:
                        first = True
                    else:
                        first = False

                    if u == unroll_times - 1 and unroll_times == self.accu_times:
                        last = True
                    next_loop = copy.deepcopy(loop_config[1:])
                    self.generate_actual_loops_with_unrolls(
                        next_loop,
                        prefix=prefix,
                        comment=comment,
                        acculast=last,
                        accufirst=first,
                        innermost_h=innermost_h,
                        innermost_w=innermost_w,
                        innermost_oc=innermost_oc,
                        innermost_sample=innermost_sample,
                        innermost_ic=innermost_ic
                    )
                # if stride mode, need insert a reset a1 in the middle of column unroll
                elif (
                    self.instr == "conv"
                    and self.operator.stride == 1
                    and self.operator.filter_w > 1
                    # and unroll_times == 2
                    and "col_unroll" in loop_config[0][0]
                    and not self.last_column
                ):
                    loop_index = self.get_unrolled_interation_ordinal(loop_config[0])
                    if loop_index[0]%2 == 1:
                        self.reset_col_a1()
                        self.column_stride_unroll = True
                        self.reset_itlr_iter()
                        self.itlr_column_iter = 0
                    # Patch temporarily
                    next_loop = copy.deepcopy(loop_config[1:])
                    self.generate_actual_loops_with_unrolls(
                        next_loop,
                        prefix=prefix,
                        comment=comment,
                        innermost_h=innermost_h,
                        innermost_w=innermost_w,
                        innermost_oc=innermost_oc,
                        innermost_sample=innermost_sample,
                        innermost_ic=innermost_ic)
                    self.column_stride_unroll = True
                    # finally update a1 with ir increase number
                    # reset column ir iter
                    if loop_index[0]%2 == 1:
                        if icd.CONV_OCH_SIZE == 64:
                            tlr_step = 8
                        else:
                            tlr_step = self.oc_block_tlr * self.brst_num
                        if not self.enable_row_accumulate:
                            self.generate_tlr_index(
                                loop_config[0],
                                self.base_reg,
                                tlr_step,
                                comment="// increase middle column a1",
                            )
                        self.itlr_column_iter = 0
                        self.switch_half_tlr()
                elif (
                    self.instr == "conv"
                    and self.operator.stride == 1
                    and self.operator.filter_w > 1
                    and "row" in loop_config[0][0]
                ):
                    self.last_column = False
                    loop_index = self.get_unrolled_interation_ordinal(loop_config[0])
                    if loop_index[0]%2 == 1:
                        # self.reset_col_a1()
                        self.column_stride_unroll = True
                        self.reset_itlr_iter()
                        self.itlr_column_iter = 0
                        # self.sadd.generate(
                        #     indent_level=self.indent,
                        #     dst=self.inner_a1,
                        #     src1=self.inner_a1,
                        #     src2=1,
                        # )
                        # self.smovs.generate(
                        #     indent_level=self.indent,
                        #     dst="a1",
                        #     src1=self.inner_a1,
                        #     comment="// increase middle column a1 for row"
                        # )
                    next_loop = copy.deepcopy(loop_config[1:])
                    self.generate_actual_loops_with_unrolls(
                        next_loop, 
                        prefix=prefix, 
                        comment=comment,
                        innermost_h=innermost_h,
                        innermost_w=innermost_w,
                        innermost_oc=innermost_oc,
                        innermost_sample=innermost_sample,
                        innermost_ic=innermost_ic)
                elif (
                    self.instr == "conv"
                    and self.operator.stride == 1
                    and self.operator.sample_full_unroll == 2
                ):
                    if "col" in e[0]:
                        self.sample_col_iter += 1
                        self.sample_col_iter %= self.row_stride
                    elif "row" in e[0]:
                        self.sample_row_iter += 1
                    next_loop = copy.deepcopy(loop_config[1:])
                    self.generate_actual_loops_with_unrolls(
                        next_loop, prefix=prefix, comment=comment,
                        innermost_h=innermost_h,
                        innermost_w=innermost_w,
                        innermost_oc=innermost_oc,
                        innermost_sample=innermost_sample,
                        innermost_ic=innermost_ic)

                else:
                    next_loop = copy.deepcopy(loop_config[1:])
                    self.generate_actual_loops_with_unrolls(
                        next_loop, prefix=prefix, comment=comment,
                        innermost_h=innermost_h,
                        innermost_w=innermost_w,
                        innermost_oc=innermost_oc,
                        innermost_sample=innermost_sample,
                        innermost_ic=innermost_ic)

                current_loop_iterations.iterations += 1
                if j != unroll_times - 1:
                    # not update column index variable if s2 case,
                    # for unrolled loop at body
                    # if self.operator.stride == 0 and self.instr == "conv":
                    if counter_reg:
                        self.sadd.generate(
                            self.indent,
                            dst=counter_reg,
                            src1=counter_reg,
                            src2=e[3],
                            comment="// Increase loop counter register"
                            " by unit step for unrolled loops",
                        )
                    self.add_extra_handling_in_front(loop_config)
                j += 1

    def handle_loop_tail(
        self,
        loop_config,
        counter_reg,
        prefix,
        current_loop_iterations,
        acculast=False,
        loop_end_reg=None,
        innermost_h=None,
        innermost_w=None,
        innermost_oc=None,
        innermost_sample=None,
        innermost_ic=None
    ):
        comment = "// Initialize index register of {}"
        if len(self.true_loop_config) != 0:
            e = self.true_loop_config[-1]
            original_loop_count = loop_config[0][1]
            if original_loop_count > 0:
                self.add_extra_handling_in_back(loop_config)
                self.flip_slot_register_between_high_low(loop_config[0])
                self.merge_out_off_modifiers(loop_config)
                if "oc" in e[0] and self.instr == "conv":
                    if len(self.oc_loop_configs) == self.oc_levels - 1:
                        for i in range(1, len(self.loop_config) - 1):
                            config = self.loop_config[-i]
                            if self.instr == "conv" and "oc" in config[0]:
                                if e[1] > 1:
                                    temp_wsr = rm.wsr_alloc(
                                        "temp_register_for_increase_buf_a"
                                    )
                                    self.smov.generate(
                                        self.indent,
                                        dst=temp_wsr,
                                        src1=config[3],
                                        comment="// Move the step to a temp"
                                        " register for shifting",
                                    )
                                    self.sshl.generate(
                                        self.indent,
                                        dst=self.operator.gib0_addr.register,
                                        src1=temp_wsr,
                                        src2=config[1],
                                        comment="// Increase gib0 address with"
                                        " innermost oc loop number",
                                    )
                                    rm.wsr_free(temp_wsr)
                                    break
                self.generate_tail(
                    e[3],
                    e[4],
                    e[1],
                    e[7],
                    loop_name=e[0],
                    loop_end_reg=loop_end_reg,
                )

                left = original_loop_count - e[5] * e[6]

                if "col" in e[0] and self.instr == "buf_b_ld":
                    left -= 1

                if (
                    self.operator.stride == 1
                    and (self.operator.aliged_w_block_num % 2) != 0
                    and "col" in e[0]
                    and self.operator.aliged_w_block_num > 1
                ):  # only for more than one block

                    if (self.instr == "conv" and self.operator.filter_w > 1) or (
                        (self.instr == "buf_b_ld" or self.instr == "conv")
                        and self.operator.filter_w == 1
                    ):

                        self.last_column = True
                        self.itlr_body_step = 0
                        self.itlr_first_innor_oc_step = 0
                        self.itlr_last_innor_oc_step = 0
                        left = 1

                elif e[0] == "inner_oc" and self.instr == "conv":
                    left -= 2

                    self.gib0_addr.first_iter_of_inner_oc_loop = True
                    self.gib1_addr.first_iter_of_inner_oc_loop = True
                    self.coord_z_reg.first_iter_of_inner_oc_loop = True
                    self.slot_reg.first_iter_of_inner_oc_loop = True

                # print("Left is ", left)
                # print("loop_config is ", loop_config)
                # Below code is only for handling the remainders of unroll
                # after deducted the special handling iterations. like the
                # first inner_oc loops and last inner_oc loops
                if (
                    self.operator.stride == 1
                    and self.last_column
                    and (self.instr == "conv" or self.instr == "buf_b_ld")
                ):
                    true_con = []
                    for loop in loop_config[1:]:
                        if loop[0] == "stride":
                            nloop = (
                                loop[0],
                                loop[1] // 2,
                                loop[2],
                                loop[3],
                            )
                            true_con.append(nloop)
                        else:
                            true_con.append(loop)
                if len(loop_config) > 1 and self.operator.name == "fwd_conv":
                    for u in range(left):
                        # not update column index variable for s2 when do unroll left
                        if self.operator.stride == 0 and self.instr == "conv":
                            self.sadd.generate(
                                self.indent,
                                dst=counter_reg,
                                src1=e[7],
                                src2=counter_reg,
                            )
                        self.add_extra_handling_in_front(loop_config)
                        if (
                            self.operator.stride == 1
                            and self.last_column
                            and (self.instr == "conv" or self.instr == "buf_b_ld")
                        ):
                            self.switch_half_tlr()
                            self.generate_actual_loops_with_unrolls(
                                true_con,
                                prefix=prefix,
                                comment=comment,
                                innermost_h=innermost_h,
                                innermost_w=innermost_w,
                                innermost_oc=innermost_oc,
                                innermost_sample=innermost_sample,
                                innermost_ic=innermost_ic
                            )
                            # handle lefted one block
                            if self.inner_oc_full_unroll:
                                self.generate_tlr_index(
                                    loop_config[0],
                                    self.base_reg,
                                    self.oc_block_tlr * self.brst_num,
                                    " // increase lefted column a1",
                                )
                                self.itlr_column_iter = 0
                        else:
                            acclast = False
                            accfirst = False
                            if self.accu_times > 1:
                                if u == left - 1:
                                    acclast = True
                                if u == 0:
                                    accfirst = True
                            next_loop = copy.deepcopy(loop_config[1:])
                            if (
                                acclast
                                and accfirst
                                and self.instr == "conv"
                                and self.operator.filter_w == 1
                            ):
                                self.conv_accu_left_block_mod = True
                            self.generate_actual_loops_with_unrolls(
                                next_loop,
                                prefix=prefix,
                                accufirst=accfirst,
                                acculast=acclast,
                                comment=comment,
                                innermost_h=innermost_h,
                                innermost_w=innermost_w,
                                innermost_oc=innermost_oc,
                                innermost_sample=innermost_sample,
                                innermost_ic=innermost_ic
                            )
                        current_loop_iterations.iterations += 1
            z_order, y_order, x_order = self.get_x_y_z_w_loop_oder()
            if "inner_oc" in e[0] and self.instr == "conv" and e[1] > 2:
                # handling the last inner_oc iteration
                if original_loop_count == 1:
                    self.first_inner_oc = True
                if original_loop_count > 0:
                    self.last_inner_oc = True
                    self.gib0_addr.first_set = True
                    self.gib1_addr.first_set = True
                    self.gib0_addr.last_iter_of_inner_oc_loop = True
                    self.gib1_addr.last_iter_of_inner_oc_loop = True
                    if counter_reg:
                        # not update innor_oc index variable for s2
                        if self.operator.stride == 0 and self.instr == "conv":
                            self.sadd.generate(
                                self.indent,
                                dst=counter_reg,
                                src1=e[7],
                                src2=counter_reg,
                            )
                    next_loop = copy.deepcopy(loop_config[1:])
                    self.generate_actual_loops_with_unrolls(
                        next_loop,
                        prefix=prefix,
                        comment=comment,
                        acculast=acculast,
                        innermost_h=innermost_h,
                        innermost_w=innermost_w,
                        innermost_oc=innermost_oc,
                        innermost_sample=innermost_sample,
                        innermost_ic=innermost_ic,
                    )
                    self.last_inner_oc = False
                    self.gib0_addr.last_iter_of_inner_oc_loop = False
                    self.gib1_addr.last_iter_of_inner_oc_loop = False
                    current_loop_iterations.iterations += 1
                if original_loop_count == 1:
                    self.first_inner_oc = False

            mod = None
            values = dict()
            if self.operator.name != "bpw_mma":
                if "col" in e[0] and self.instr == "buf_b_ld" and not self.last_column:
                    ordinal = self.get_unrolled_interation_ordinal(e)
                    # print("#################e is ", e)
                    # print("#################ordinal is ", ordinal)
                    # e[5] is the original iterations
                    if e[5] > 1 or (ordinal[0] != 0 and ordinal[1] == -1):
                        if z_order > x_order > y_order  and "col_unroll_inner" not in e[0]:
                            h_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_h)
                            if h_loop_ordinal[1] != -1 or innermost_h[1] > 1:
                              mod = "off.incx0.incy1.incz0.wnil.snil.b0nil.b1nil"
            if "stride" in e[0] and self.instr == "buf_b_ld":
                ordinal = self.get_unrolled_interation_ordinal(e)
                # e[5] is the original iterations
                if e[5] > 1 or (ordinal[0] != 0 and ordinal[1] == -1):
                    if z_order > x_order > y_order:
                        mod = "off.incx0.incy1.incz0.wnil.snil.b0nil.b1nil"
                    # stride loop need incy for next row and set x to start
                    elif z_order > y_order > x_order:
                        mod = "off.setx.incy1.incz0.wnil.snil.b0nil.b1nil"
                        values["x"] = self.col_regs
            if "row" in e[0] and self.instr == "buf_b_ld" and not self.last_column:
                ordinal = self.get_unrolled_interation_ordinal(e)
                # e[5] is the original iterations
                if e[5] > 1 or (ordinal[0] != 0 and ordinal[1] == -1):
                    if z_order > y_order > x_order and "row_unroll_inner" not in e[0]:
                        w_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_w)
                        if w_loop_ordinal[1] != -1 or innermost_w[1] > 1:
                            mod = "off.incy0.incx1.incz0.wnil.snil.b0nil.b1nil"
            if self.operator.name == "bpw_mma":
                if "col" in e[0] and len(self.col_loop_configs) == self.col_levels:
                    ordinal = self.get_unrolled_interation_ordinal(e)
                    if e[5] > 1 or (ordinal[0] != 0 and ordinal[1] == -1):
                        if innermost_ic:
                            ic_loop_ordinal = self.get_unrolled_interation_ordinal(innermost_ic)
                            iterations_ic = ic_loop_ordinal[0] - ic_loop_ordinal[1]
                            if iterations_ic > 1 or innermost_ic[1] > 1:
                                mod = "off.incy0.incx0.incz1.wnil.snil.b0nil.b1nil"
            if mod:
                if (
                    self.accu_left_step_flip != 0
                    and self.accu_times > 1
                    and (self.instr == "buf_b_ld" or self.instr == "conv")
                    and self.operator.filter_w == 1
                ):
                    self.operator.operator[self.instr].generate(
                        indent=self.indent,
                        modifier=mod,
                        **values,
                        gib1_step=self.accu_left_step_flip
                    )
                    self.accu_left_step_flip = 0
                else:
                    self.operator.operator[self.instr].generate(
                        indent=self.indent, modifier=mod, **values
                    )

            self.true_loop_config.remove(e)
        if (
            self.instr == "conv"
            and "inner_oc" in loop_config[0][0]
            and self.operator.stride == 1
            and self.operator.filter_w == 1
            and not self.last_column
        ):
            self.save_tlr_state()

        # if self.instr == "conv" and loop_config[0][0] == "col" and
        # self.operator.stride == 1 and self.operator.filter_w > 1:
        #    # only iter number > 1 update dst tlr-->real_iter > 1
        #    self.generate_tlr_index(e, self.base_reg, loop_config[0][1])

    def generate_loops(self, prefix, comment):
        super().generate_loops(prefix, comment)

        self.check_loop_status()
        self.unroll_innermost_loop()
        if self.instr == "conv" and self.operator.stride == 1:
            self.stride2_tlr_switch()

        br_print("")
        # tlr = self.get_dst_tlr()
        if self.operator.stride == 1 and (
            (
                self.operator.filter_w == 1
                and (self.instr == "conv" or self.instr == "buf_b_ld")
                or (self.operator.filter_w > 1 and self.instr == "conv")
            )
        ):
            start = self.operator.tlr_out
            self.inner_a1 = rm.wsr_alloc("stride_finish_a1")
            self.stride_a1 = rm.wsr_alloc("stride_origin_a1")
            self.half_tlr = rm.wsr_alloc("half_tlr")
            self.tlr_flip = rm.wsr_alloc("tlr_flip")
            # self.init_a1(start)
            # self.update_base(start)
            self.init_all(start)
            self.index_row = br_tcore_utils.get_row_tlr(
                self.loop_config, self.operator.stride
            )
        elif self.ich_split and self.tlr_flip is None:
            # ic pat need tlr flip
            self.tlr_flip = rm.wsr_alloc("tlr_flip")

        if self.operator.stride == 1 and self.operator.sample_full_unroll == 1:
            self.init_bound_reg(0)
            self.get_csr_table(self.operator.ishape[2])

        self.init_gib_buf()

        aligned_w = (
            self.operator.tensor_b[3] + icd.BUFFER_B_ENTRY_PIXEL_WIDTH - 1
        ) / icd.BUFFER_B_ENTRY_PIXEL_WIDTH
        if self.accu_times > 1 and (aligned_w % self.accu_times) != 0:
            self.accu_left_block = 1

        # if self.operator.usharp_o and self.operator.stride == 0:
        #     if self.instr == "conv":
        #         self.ackgmb.generate(self.indent)
        self.check_if_need_flip_oc_slot()
        self.change_row_col_loop_order()
        self.insert_unroll_loop_level()
        self.generate_actual_loops_with_unrolls(
            self.loop_config, prefix, comment=comment)

        self.free_resources()

    def change_row_col_loop_order(self):
        if self.operator.filter_w <= 1:
            return
        if not self.enable_row_accumulate:
            return
        if self.instr == "conv" or self.instr == "buf_b_ld":
            row_unrolled = False
            new_loop_config = []
            for config in self.loop_config[::-1]:
                if "row" in config[0] and not row_unrolled:
                    new_config = list(config)
                    new_config[2] = new_config[1]  # unroll it for accumulation
                    new_config = tuple(new_config)
                    row_unrolled = True
                    new_loop_config.insert(0, new_config)
                else:
                    new_loop_config.insert(0, config)

            # print("old loop config is ", self.loop_config)
            self.loop_config = new_loop_config
            # print("new loop config is ", self.loop_config)
            br_print("// New loop config is ", self.loop_config)
