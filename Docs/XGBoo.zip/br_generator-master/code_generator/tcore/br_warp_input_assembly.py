#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

from collections import OrderedDict
import copy

import code_generator.share.br_vector_instructions_def as vid
import code_generator.share.br_utils as br_utils
from code_generator.share import br_top


def get_dem_id_name(dem_map, item_name=None):
    d = dem_map
    # print("dem_map is ", dem_map)
    dem_id_name = None
    dem_id = None
    if item_name in d.keys():
        dem_id = d[item_name]
    if dem_id is not None:
        dem_id_name = "g{}".format(dem_id)
    return dem_id_name


class warp_input_assemble(br_top.top):
    def __init__(
            self, indent, gib0_addr=None,
            gib1_addr=None, x=None, y=None, z=None, w=None,
            warp_count=None, slot=None, wsc=None, ssc=None,
            wbar_id=None, gib_step=None, gib0_step=None,
            gib1_step=None, boundary_x=None, boundary_y=None):
        self.stg_value = OrderedDict()
        self.stg_value_shadow = OrderedDict()
        self.stg_value["gib_addr"] = None
        self.stg_value["gib1_addr"] = None
        self.stg_value["gib0_addr"] = None
        self.stg_value["x"] = None
        self.stg_value["y"] = None
        self.stg_value["z"] = None
        self.stg_value["w"] = None
        self.stg_value["warp_count"] = None
        self.stg_value["slot"] = None
        self.stg_value["wsc"] = None
        self.stg_value["ssc"] = None
        self.stg_value["wbar_id"] = None
        self.stg_value["gib_step"] = None
        self.stg_value["gib0_step"] = None
        self.stg_value["gib1_step"] = None
        self.stg_value["boundary_x"] = None
        self.stg_value["boundary_y"] = None
        self.stg_value_shadow["gib1_addr"] = gib1_addr
        self.stg_value_shadow["gib0_addr"] = gib0_addr
        self.stg_value_shadow["x"] = x
        self.stg_value_shadow["y"] = y
        self.stg_value_shadow["z"] = z
        self.stg_value_shadow["w"] = w
        self.stg_value_shadow["warp_count"] = warp_count
        self.stg_value_shadow["slot"] = slot
        self.stg_value_shadow["wsc"] = wsc
        self.stg_value_shadow["ssc"] = ssc
        self.stg_value_shadow["wbar_id"] = wbar_id
        self.stg_value_shadow["gib_step"] = gib_step
        self.stg_value_shadow["gib0_step"] = gib0_step
        self.stg_value_shadow["gib1_step"] = gib1_step
        self.stg_value_shadow["boundary_x"] = boundary_x
        self.stg_value_shadow["boundary_y"] = boundary_y

        self.indent = indent
        self.smovg = vid.smovg(indent)
        self.movi = vid.movi(indent)
        self.sadd = vid.sadd(indent)
        self.addu = vid.addu(indent)
        self.saddg = vid.saddg(indent)
        self.sshl = vid.sshl(indent)
        self.sxor = vid.sxor(indent)
        self.xor = vid.xor(indent)
        self.mulu = vid.mulu(indent)
        self.nop = vid.nop(indent)
        self.mov = vid.mov(indent)
        # self.saddg = vid.saddg(indent)
        self.produced_count = 0
        self.temp_wsr = []
        self.dem0_accumulate = 0
        self.dem1_accumulate = 0

        self.stg_value_back = copy.deepcopy(self.stg_value)

    def reset(self):
        self.stg_value = copy.deepcopy(self.stg_value_back)

    def reset_tempwsr_pos(self):
        self.dem0_accumulate = 0

    def _print_sadd_statement(self):
        # print("self.temp_wsr is ", self.temp_wsr)
        for v in self.temp_wsr:
            self.sadd.generate(self.indent, dst=v[0], src1=v[1], src2=v[0],
                               comment=v[2])

        self.temp_wsr.clear()

    def _print_smovg_statement(
            self, k, dem_map, first, last, unroll, transient=False):
        # print("dem_map is ", dem_map)
        g = get_dem_id_name(dem_map, k)
        v = self.stg_value_shadow[k]
        t = self.stg_value_shadow[k]
        # print("Info: g is ", g)
        # print("Info: k is ", k)
        # print("Info: v is ", v)
        # print("Info: t is ", t)
        if isinstance(v, br_utils.Br_Register):
            # inc = v.inc_unit
            v = v.register
        #     comment = "// Increase {} register".format(k)
        #     if t.first_iter_of_inner_oc_loop:
        #         if (v is not None) and (k == "slot"):
        #             self.temp_wsr.append((v, inc, comment))
        # print("v is ", v)
        comment = "// Set warp assemble input state of " + k
        comment2 = "// Wrap back immediate number to 0"
        comment3 = "// Set offset to {} register for next iteration".format(k)
        # comment4 = "// Flip address to next half of the buffer"
        if g is not None:
            if first:
                if last:
                    modifier = "eog"
                else:
                    modifier = None
                if v is None:
                    v = 0
                if isinstance(v, str):
                    if "__" in v:
                        value = v.split("__")
                        flip = value[-1]
                        reg = value[0]
                        if modifier:
                            modifier = "b16." + modifier
                        else:
                            modifier = "b16"
                        self.xor.generate(
                            self.indent, parallel=1, modifier=modifier,
                            dst=g, src1=reg, src2=flip, comment=comment)
                    else:
                        self.mov.generate(
                            self.indent, parallel=1, modifier=modifier,
                            dst=g+".u32", src1=v+".u32", comment=comment)
                else:
                    self.movi.generate(
                        self.indent, parallel=1, modifier=modifier,
                        dst=g+".u32", src1=v, comment=comment)
            else:
                modifier = None
                if last:
                    modifier = "eog"
                if (isinstance(t, br_utils.Br_Register) and g == "g1" and
                        k == "gib0_addr"):
                    if t.first_iter_of_inner_oc_loop:
                        self.dem1_accumulate = 0
                        t.first_iter_of_inner_oc_loop = False
                    if g == "g1":
                        self.saddg.generate(
                            self.indent, dst=g, modifier=modifier,
                            src1=self.dem1_accumulate, src2=v,
                            comment=comment)
                        if not transient:
                            self.dem1_accumulate += t.inc_unit
                            if (t.instr_type == "conv" or
                                    t.instr_type == "buf_b_ld"):
                                if t.last_tcore_instr:
                                    if self.dem1_accumulate != 0:
                                        self.temp_wsr.append(
                                            (v, self.dem1_accumulate,
                                             comment3))
                else:
                    if isinstance(v, list):
                        if len(v) == 2:
                            v1 = v[0][0]
                            v2 = v[1][0]
                            self.saddg.generate(
                                self.indent, modifier=modifier, dst=g, src1=v1,
                                src2=v2, comment=comment)
                        else:
                            if len(v) == 0:
                                v = 0
                            else:
                                v = v[0][0]
                            self.smovg.generate(
                                self.indent, modifier=modifier, dst=g, src1=v,
                                comment=comment)
                    else:
                        if ((g == "g8" or g == "g9") and
                            isinstance(v, str) and ("__" in v)):
                            sp = v.split("__")
                            v = sp[0]
                            flip = sp[1]
                            if flip == "0" or flip == "8":
                                if modifier:
                                    modifier = "b16." + modifier
                                else:
                                    modifier = "b16"
                                self.xor.generate(
                                    self.indent, dst=g, src1=v, src2=flip,
                                    modifier=modifier,
                                    comment=comment)
                            else:
                                self.saddg.generate(
                                    self.indent, dst=g, src1=v, src2=flip,
                                    modifier=modifier,
                                    comment=comment)
                        else:
                            if v is not None:
                                self.smovg.generate(
                                    self.indent, modifier=modifier, dst=g, src1=v,
                                    comment=comment)
                            if v is None and (k == "warp_count" or k == "slot"):
                                self.smovg.generate(
                                    self.indent, modifier=modifier, dst=g, src1=0,
                                    comment=comment)

            self.produced_count += 1
            if not transient:
                self.stg_value[k] = v

    def generate(
            self, necessity, dem_map, indent=None,
            gib0_addr=None, gib1_addr=None, x=None, y=None, z=None,
            w=None, warp_count=None, slot=None, wsc=None, ssc=None,
            wbar_id=None, gib_step=None, gib0_step=None,
            gib1_step=None, boundary_x=None, boundary_y=None,
            unroll=False, transient=False):

        # print("necessity, dem_map is ", necessity, dem_map)
        if indent is not None:
            self.indent = indent

        self.stg_value_shadow["gib0_addr"] = gib0_addr
        self.stg_value_shadow["gib1_addr"] = gib1_addr
        # if x is not None:
        self.stg_value_shadow["x"] = x
        # if y is not None:
        self.stg_value_shadow["y"] = y
        # if z is not None:
        self.stg_value_shadow["z"] = z
        # if w is not None:
        self.stg_value_shadow["w"] = w
        # if warp_count is not None:
        self.stg_value_shadow["warp_count"] = warp_count
        # if slot is not None:
        self.stg_value_shadow["slot"] = slot
        self.stg_value_shadow["wsc"] = wsc
        self.stg_value_shadow["ssc"] = ssc
        self.stg_value_shadow["wbar_id"] = wbar_id
        self.stg_value_shadow["gib0_step"] = gib0_step
        self.stg_value_shadow["gib1_step"] = gib1_step
        self.stg_value_shadow["boundary_x"] = boundary_x
        self.stg_value_shadow["boundary_y"] = boundary_y

        # print("necessity is ", necessity)
        # print("stg stg_value_shadow is ", self.stg_value_shadow)
        # print("stg stg_value is ", self.stg_value)

        state_num = 0
        for k in necessity:
            if (isinstance(self.stg_value_shadow[k], br_utils.Br_Register) or
                isinstance(self.stg_value_shadow[k], str) or
                isinstance(self.stg_value_shadow[k], list) or
                (self.stg_value[k] != self.stg_value_shadow[k] and
                 self.stg_value_shadow[k] is not None) or
                (k == "y" and
                 self.stg_value_shadow[k] is not None) or
                (k == "x" and
                 self.stg_value_shadow[k] is not None)):
                state_num += 1
        # print("state_num is ", state_num)
        if state_num != 0:
            i = 0
            for k in necessity:
                if (isinstance(self.stg_value_shadow[k], br_utils.Br_Register)
                    or isinstance(self.stg_value_shadow[k], str)
                    or isinstance(self.stg_value_shadow[k], list)
                    or (self.stg_value[k] != self.stg_value_shadow[k] and
                        self.stg_value_shadow[k] is not None)
                    or (k == "y" and
                        self.stg_value_shadow[k] is not None)
                    or (k == "x" and
                        self.stg_value_shadow[k] is not None)):
                    first = True if i == 0 else False
                    last = True if i == state_num-1 else False
                    # print("last is ", last)
                    # if not transient:
                    #     self.stg_value[k] = self.stg_value_shadow[k]
                    if i == 0 and k != "gib1_addr":
                        self.mov.generate(
                            indent_level=self.indent, parallel=1,
                            dst="g0.u32",
                            src1="z0.u32",
                            comment="// Set null to dem0")
                        first = False
                    self._print_smovg_statement(
                        k, dem_map, first, last, unroll, transient=transient)
                    i += 1

                # Must update anyway even with the None value
                self.stg_value[k] = self.stg_value_shadow[k]

            self._print_sadd_statement()
        else:
            self.mov.generate(
                indent_level=self.indent, parallel=1,
                modifier="eog",
                dst="g0.u32",
                src1="z0.u32",
                comment="// No staging needs to be set")


class ld_warp_input_assemble(warp_input_assemble):
    def __init__(
            self, indent, gib0_addr=None, gib1_addr=None,
            x=None, y=None, z=None,
            w=None, wsc=None, ssc=None, gib0_step=None, gib1_step=None):
        super().__init__(
            indent, gib0_addr=gib0_addr, gib1_addr=gib1_addr,
            x=x, y=y, z=z, w=w, gib0_step=gib0_step,
            gib1_step=gib1_step, wsc=wsc, ssc=ssc)


class mma_conv_warp_input_assemble(warp_input_assemble):
    def __init__(
            self, indent, gib0_addr=None, gib1_addr=None, x=None,
            y=None, z=None, w=None, warp_count=None, slot=None,
            wsc=None, ssc=None, wbar_id=None, gib0_step=None,
            gib1_step=None):
        super().__init__(
            indent, gib0_addr=gib0_addr, gib1_addr=gib1_addr,
            x=x, y=y, z=z, w=w, warp_count=warp_count, slot=slot, wsc=wsc,
            ssc=ssc, wbar_id=wbar_id, gib0_step=gib0_step,
            gib1_step=gib1_step,)


class pldgmb_warm_input_assemble(object):
    def __int__(self, indent, x=None, y=None, z=None, w=None):
        super.__init__(indent, x=x, y=y, z=z, w=w)
