#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import code_generator.tcore.br_tcore_conv as tcc
import code_generator.share.br_const_defs as bcd


def br_bpw_mma(
        tensor_b, tensor_w, tensor_a, dt, stride=1, dilation=1,
        padx=0, pady=0, usharps=None, loop_configs=[],
        pingpong_a=[0], pingpong_b=[0], red_mode="roff",
        write_through=None, csrs=None, hwshape=None,
        gmb_mapping=False, ic_partition=False, spc_num=bcd.BR_SPC_NUMBER,
        sync_layer=False, force_ackgmb=False, extension=False,
        unroll_disable=False, tlr_flip_interval=0, micro_batch_mode=False):

    operator = tcore_bpw_mma(
        tensor_b=tensor_b, tensor_w=tensor_w,
        tensor_a=tensor_a, dt=dt, stride=1, dilation=1,
        padx=padx, pady=pady, usharps=usharps, loop_configs=loop_configs,
        pingpong_a=pingpong_a, pingpong_b=pingpong_b, red_mode=red_mode,
        write_through=write_through, csrs=csrs, hwshape=hwshape,
        gmb_mapping=gmb_mapping, ic_partition=ic_partition, spc_num=spc_num,
        sync_layer=sync_layer, force_ackgmb=force_ackgmb, extension=extension,
        unroll_disable=unroll_disable, tlr_flip_interval=tlr_flip_interval,
        micro_batch_mode=micro_batch_mode)
    # operator.generate(loop_configs, dry_run=True)

    return operator


class tcore_bpw_mma(tcc.tcore_conv):
    def __init__(
            self, tensor_b, tensor_w, tensor_a, dt, stride=1, dilation=1,
            padx=0, pady=0, usharps=None, loop_configs=[],
            pingpong_a=[0], pingpong_b=[0], red_mode="roff",
            write_through=None, csrs=None, hwshape=None,
            gmb_mapping=False, ic_partition=False, spc_num=bcd.BR_SPC_NUMBER,
            sync_layer=False, force_ackgmb=False, extension=False,
            unroll_disable=False, tlr_flip_interval=0, micro_batch_mode=False):
        super().__init__(
            name="bpw_mma", tensor_b=tensor_b, tensor_w=tensor_w,
            tensor_a=tensor_a, dt=dt, stride=1, dilation=1,
            padx=padx, pady=pady, usharps=usharps, loop_configs=loop_configs,
            pingpong_a=pingpong_a, pingpong_b=pingpong_b,
            fwd=False, bpw=True, red_mode=red_mode,
            write_through=write_through, csrs=csrs, hwshape=hwshape,
            gmb_mapping=gmb_mapping, unroll_disable=unroll_disable)

        self.best_input_channel_num_per_ld = (
            self.get_best_input_channel_number_per_ld())

        self.mata_shape = (
            tensor_a[1],
            tensor_a[2] * tensor_a[3])
        self.matb_shape = (
            tensor_b[2] * tensor_b[3],
            tensor_b[1])
        self.mata_w_unit = int(
            bcd.ACTIVATION_BLOCK_W_SIZE * bcd.ACTIVATION_BLOCK_H_SIZE)

        self.bst_matched_ich_ld_channels_bpw_bufa = (
            self._find_best_block_inch_number_bpw_bufa())

        # print(" self.bst_matched_ich_ld_channels_bpw_bufa is ",  self.bst_matched_ich_ld_channels_bpw_bufa)

        self.bst_matched_ich_ld_channels_num_bpw_bufa = int(self.bst_matched_ich_ld_channels_bpw_bufa[3:])
        self.required_buffer_a_entries_per_ld = int(
            self.bst_matched_ich_ld_channels_num_bpw_bufa / bcd.BUFFER_A_ENTRY_ICH_NUM
        )
        self.required_buffer_a_entries_per_ld *= int(
            bcd.ACTIVATION_BLOCK_W_SIZE / bcd.BUFFER_A_ENTRY_PIXEL_WIDTH
        )
        self.required_buffer_a_entries_per_ld *= int(
            bcd.ACTIVATION_BLOCK_H_SIZE / bcd.BUFFER_A_ENTRY_PIXEL_HEIGHT
        )

        self.required_buffer_a_entries_per_row = int(
            self.mata_shape[1]/self.mata_w_unit)
        self.required_buffer_a_entries_per_row *= (
            self.required_buffer_a_entries_per_ld)

        self.best_input_channel_num_per_ld_for_bufb = (
            self.get_best_input_channel_number_per_ld())

        self.buf_a_total_iterations = (
            self.get_total_iteration_times(self.loop_configs[0]))
        self.buf_b_total_iterations = (
            self.get_total_iteration_times(self.loop_configs[1]))

        self.required_buffer_b_entries_per_ld = int(
            self.bst_ich_ld_num / bcd.BUFFER_B_ENTRY_ICH_NUM
        )
        self.required_buffer_b_entries_per_ld *= int(
            bcd.ACTIVATION_BLOCK_W_SIZE / bcd.BUFFER_B_ENTRY_PIXEL_WIDTH
        )
        self.required_buffer_b_entries_per_ld *= int(
            bcd.ACTIVATION_BLOCK_H_SIZE / bcd.BUFFER_B_ENTRY_PIXEL_HEIGHT
        )

        self.bpw_padx = 0
        self.bpw_pady = 0
        if self.filter_w == 1:
            self.bpw_padx = 0
        elif self.filter_w <= 3:
            if self.tensor_a[3] < self.tensor_b[3]:
                self.bpw_padx = 0
            else:
                self.bpw_padx = 1
        elif self.filter_w <= 5:
            if self.tensor_a[3] < self.tensor_b[3]:
                self.bpw_padx = 0
            else:
                self.bpw_padx = 2
        elif self.filter_w <= 7:
            if self.tensor_a[3] < self.tensor_b[3]:
                self.bpw_padx = 0
            else:
                self.bpw_padx = 3

        self.buf_a_total_iterations = (
            self.get_total_iteration_times(self.loop_configs[0]))
        self.buf_b_total_iterations = (
            self.get_total_iteration_times(self.loop_configs[1]))

        self.accumulation_times = self.get_accu_times_for_filter_w_above_one(
            self.bst_ich_ld_num)

        super()._initialize_instructions()
        self.check_loop_configs()

    def get_best_input_channel_number_per_ld(self):
        if self.tensor_b[1] <= bcd.MATRIX1_COL[0]:
            return bcd.MATRIX1_COL[0]
        else:
            return bcd.MATRIX1_COL[1]

    def _generate_vector(self):
        pass

    def reset(self):
        super()._reset()
        self.operator["mma"].reset()

    def generate(self, loop_configs=[], dry_run=False):
        if len(loop_configs) > 0:
            self.loop_configs = loop_configs

        super()._set_dry_run(dry_run)

        if len(self.loop_configs) > 0:
            self._generate_buf_a_ld(self.loop_configs[0])

        if len(self.loop_configs) > 1:
            self._generate_buf_b_ld(self.loop_configs[1])

        if len(self.loop_configs) > 2:
            self._generate_bpw_mma(self.loop_configs[2])

        super()._set_dry_run(False)
        self.reset()

