#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import copy

from collections import OrderedDict
import code_generator.share.br_const_defs as tcd
from code_generator.share.br_defined_print import br_print
from code_generator.share.br_utils import Br_Indent
from code_generator.tcore.br_tcore_cwarp_man import cwarp_man
from code_generator.share.br_top import top


def get_variable_params_from_modifier(self, modifier, transient=False):
    modifier.strip("")
    modifier.strip(" ")
    params = modifier.split(".")
    # print(params)
    exacted_values = tcd.modifiers_of_tcore_fun
    # print("original length: ", len(exacted_values))
    for ele in params:
        find = False
        if ele == "" or ele == " ":
            continue
            # print("Error: value cannot be empty string!"
            #       .format(ele))
        for key in tcd.all_tcore_modifiers.keys():
            value = tcd.all_tcore_modifiers[key]
            # print("key and value is ", key, value)
            if ele in value.keys() and key in exacted_values.keys():
                if not transient:
                    self.fields[key] = ele
                else:
                    self.transient_fields[key] = ele
                find = True
                break
        if not find:
            # print("key is ", key)
            print("Error: value: {} cannot be found in the difinitions!".format(ele))


class MAT_LSA(top):
    def __init__(self, modifier=None, **kw):
        self.fields = OrderedDict()
        self.fields["Type"] = 1
        self.fields["OpDisable"] = None
        self.fields["Opcode"] = None
        self.fields["BufSwitch_DstRel"] = None
        self.fields["Mat0Row_OutputCh_Shape"] = None
        self.fields["Mat0Col_InputCh"] = None
        self.fields["Mat1Col"] = None
        self.fields["DataType0"] = None
        self.fields["DataType1"] = None
        self.fields["DstDataType"] = None
        self.fields["PostInc_x"] = None
        self.fields["PostInc_y"] = None
        self.fields["PostInc_z"] = None
        self.fields["L2Control_0"] = None
        self.fields["L2Control_1"] = None
        self.fields["L2Control_2"] = None
        self.fields["L2Control_3"] = None
        # self.fields["WbarCtrl"] = None
        self.fields["GIBID_WriteThru"] = None
        self.fields["ReadOnly_Sparse"] = None
        self.fields["DescIndex"] = None
        self.fields["GIB0Ctrl"] = None
        self.fields["GIB1Ctrl"] = None
        self.fields["LMScope_RedMode"] = None
        self.fields["Sync"] = None
        self.fields["Init"] = None
        self.fields["PadOnly_SlotSet"] = None
        self.fields["Transpose_Out"] = None
        self.fields["Waitgsc"] = None
        self.fields["Setgsc"] = None
        self.fields["DescSetID"] = None
        self.fields["StagingCnt"] = 1

        # self defined, not defined in ISA spec.
        self.fields["UsharpIdx"] = 0
        self.fields["Destination"] = None

        self.instr_name = "tcore_instr"
        self.indent_level = 1
        self.transient_fields = OrderedDict()
        self.type = "Tensor"

        # print("kw is ", kw)
        self._assign_kw_fields(**kw)
        self.warp_man = cwarp_man()

        self.fields_back = copy.deepcopy(self.fields)

    def reset(self):
        self.fields = copy.deepcopy(self.fields_back)

    def _assign_kw_fields(self, modifier=None, transient=False, **kw):
        for key in kw.keys():
            if key in self.fields.keys():
                if not transient:
                    if key != "Destination":
                        self.fields[key] = kw[key]
                    else:
                        if kw[key]:
                            self.fields[key] = kw[key]
                else:
                    self.transient_fields[key] = kw[key]
            else:
                print(
                    "Error: Input params is not right: key, value is {}, {}".format(
                        key, kw[key]
                    )
                )
        if modifier is not None:
            # print("modifer is ", modifier)
            get_variable_params_from_modifier(self, modifier, transient=transient)

        # some patch is put below
        if self.fields["OpDisable"] == "on":
            if (
                self.fields["Opcode"] == "LDCONV"
                and self.fields["GIBID_WriteThru"] == "gib0"
            ):
                self.fields["PostInc_x"] = None

        # Need to clear transient data.
        if not transient:
            self.transient_fields.clear()

    def _print(self, transient=False):
        if isinstance(self.indent_level, Br_Indent):
            assemble_code = " " * 4 * self.indent_level.indent
        else:
            assemble_code = " " * 4 * self.indent_level
        assemble_code += "{}".format(self.instr_name)
        # if self.instr_name == "mma":
        #     print("self.fields is ", self.fields)
        for key in self.fields.keys():
            if key != "Type" and key != "Opcode":
                if (
                    key == "GIBID_WriteThru"
                    and (self.fields[key] == "gib0" or self.fields[key] == "gib1")
                    or (key == "UsharpIdx")
                    or (key == "Destination")
                ):
                    continue
                if self.fields["GIBID_WriteThru"] == "gib0":
                    if key == "GIB1Ctrl":
                        continue
                if self.fields["GIBID_WriteThru"] == "gib1":
                    if key == "GIB0Ctrl" and self.fields["BufSwitch_DstRel"] != "bs1":
                        continue
                if self.fields["Opcode"] != "MMA" and self.fields["Opcode"] != "CONV":
                    if isinstance(self.fields[key], str) and "wb" in self.fields[key]:
                        continue
                if self.fields["Opcode"] == "MMA" or self.fields["Opcode"] == "CONV":
                    if isinstance(self.fields[key], str) and "ro" in self.fields[key]:
                        continue
                    if isinstance(self.fields[key], str) and "moff" in self.fields[key]:
                        continue
                    if isinstance(self.fields[key], str) and "bs0" in self.fields[key]:
                        continue
                # print("key and value is ", key, self.fields[key])
                if self.fields[key] is not None:
                    if key == "StagingCnt":
                        assemble_code += ".gc{}".format(self.fields[key])
                    else:
                        if not transient:
                            assemble_code += ".{}".format(self.fields[key])
                        else:
                            if key in self.transient_fields.keys():
                                assemble_code += ".{}".format(self.transient_fields[key])
                            else:
                                assemble_code += ".{}".format(self.fields[key])
        if self.fields["Opcode"] == "CONV" or self.fields["Opcode"] == "MMA":
            assemble_code += " {},".format(self.fields["Destination"])
        if self.fields["Opcode"] == "LDMMA" or self.fields["Opcode"] == "MMA":
            assemble_code = assemble_code.replace(".incz0", "")
            assemble_code = assemble_code.replace(".incz1", "")
            assemble_code = assemble_code.replace(".setz", "")
        assemble_code += " u{}".format(self.fields["UsharpIdx"])
        br_print(assemble_code)

    def generate(self, indent=None, modifier=None, transient=False, **kw):
        if indent is not None:
            self.indent_level = indent
        self._assign_kw_fields(modifier=modifier, transient=transient, **kw)
        self._print(transient)

    def check_warp_assemble_input_set_necessity(self):
        warp_input_assemble_type = "{}".format(self.fields["Opcode"])
        if "OpDisable" in self.transient_fields.keys():
            warp_input_assemble_type += "_{}".format(self.transient_fields["OpDisable"])
        else:
            warp_input_assemble_type += "_{}".format(self.fields["OpDisable"])
        warp_input_assemble_type = warp_input_assemble_type.lower()

        # print("warp_input_assemble_type is ", warp_input_assemble_type)
        warp_assembe_input_necessity = copy.deepcopy(
            tcd.warp_input_assemble[warp_input_assemble_type]
        )

        # print("warp_assembe_input_necessity is ",
        #       warp_assembe_input_necessity)

        warp_input_assemble_dem_map = None

        # print("warp_assembe_input_necessity ", warp_assembe_input_necessity)
        if self.fields["Opcode"] == "LDCONV" and self.fields["GIBID_WriteThru"] == "gib0":
            warp_assembe_input_necessity.remove("x")
        if "PostInc_x" in self.transient_fields.keys():
            if (
                self.transient_fields["PostInc_x"] is not None
                and self.transient_fields["PostInc_x"] == "incx0"
            ):
                if "x" in warp_assembe_input_necessity:
                    warp_assembe_input_necessity.remove("x")
        else:
            if (
                self.fields["PostInc_x"] is not None
                and self.fields["PostInc_x"] == "incx0"
            ):
                if "x" in warp_assembe_input_necessity:
                    warp_assembe_input_necessity.remove("x")
        if "PostInc_y" in self.transient_fields.keys():
            if (
                self.transient_fields["PostInc_y"] is not None
                and self.transient_fields["PostInc_y"] == "incy0"
            ):
                warp_assembe_input_necessity.remove("y")
        else:
            if (
                self.fields["PostInc_y"] is not None
                and self.fields["PostInc_y"] == "incy0"
            ):
                warp_assembe_input_necessity.remove("y")

        if self.fields["Opcode"] == "CONV" or self.fields["Opcode"] == "LDCONV":
            if "PostInc_z" in self.transient_fields.keys():
                if (
                    self.transient_fields["PostInc_z"] is not None
                    and self.transient_fields["PostInc_z"] == "incz0"
                ):
                    warp_assembe_input_necessity.remove("z")
            else:
                if (
                    self.fields["PostInc_z"] is not None
                    and self.fields["PostInc_z"] == "incz0"
                ):
                    warp_assembe_input_necessity.remove("z")

        if "OpDisable" in self.transient_fields.keys():
            if self.transient_fields["OpDisable"] == "off":
                warp_input_assemble_dem_map = tcd.warp_input_register_dem_map_off
            else:
                warp_input_assemble_dem_map = tcd.warp_input_register_dem_map_on
        else:
            if self.fields["OpDisable"] == "off":
                warp_input_assemble_dem_map = tcd.warp_input_register_dem_map_off
            else:
                warp_input_assemble_dem_map = tcd.warp_input_register_dem_map_on
        if self.fields["Opcode"] == "LDCONV" and (self.fields["GIBID_WriteThru"] == "gib0" or
            self.fields["BufSwitch_DstRel"] == "bs1"):
            warp_assembe_input_necessity.remove("gib1_addr")
            warp_assembe_input_necessity.remove("gib1_step")
        elif (
            self.fields["Opcode"] == "LDCONV" and self.fields["GIBID_WriteThru"] == "gib1"
        ):
            warp_assembe_input_necessity.remove("gib0_addr")
            warp_assembe_input_necessity.remove("gib0_step")

        # print("Necessity is ", warp_assembe_input_necessity)
        # print("warp_input_assemble_dem_map is ", warp_input_assemble_dem_map)
        return warp_assembe_input_necessity, warp_input_assemble_dem_map

    def fill_inst(self, indent=None, modifier=None, transient=False, **kw):
        if indent is not None:
            self.indent_level = indent
        self._assign_kw_fields(modifier=modifier, transient=transient, **kw)


class pldgmb(MAT_LSA):
    def __init__(self, modifier=None, **kw):
        super().__init__(modifier, Opcode="PLDGMB", **kw)
        self.type = "GMB"


class ldconv(MAT_LSA):
    def __init__(self, modifier=None, **kw):
        super().__init__(Opcode="LDCONV", **kw)
        self.type = "LDCONV"


class ldconv0(ldconv):
    def __init__(self, indent=None, modifier=None, **kw):
        super().__init__(modifier=modifier, GIBID_WriteThru="gib0", **kw)
        self.instr_name = "ldconv0"
        if indent is not None:
            self.indent_level = indent

    def generate(self, indent=None, modifier=None, transient=False, **kw):

        if indent is not None:
            self.indent_level = indent

        super()._assign_kw_fields(modifier=modifier, transient=transient, **kw)

        super()._print(transient)


class ldconv1(ldconv):
    def __init__(self, indent=None, modifier=None, **kw):
        super().__init__(modifier=modifier, GIBID_WriteThru="gib1", **kw)
        self.instr_name = "ldconv1"
        if indent is not None:
            self.indent_level = indent

    def generate(self, indent=None, modifier=None, transient=False, **kw):
        if indent is not None:
            self.indent_level = indent
        super()._assign_kw_fields(modifier=modifier, transient=transient, **kw)
        super()._print(transient)


class conv(MAT_LSA):
    def __init__(self, indent=None, modifier=None, **kw):
        super().__init__(Opcode="CONV", modifier=modifier, **kw)
        self.type = "CONV"

        self.instr_name = "conv"
        if indent is not None:
            self.indent_level = indent

    def generate(self, indent=None, modifier=None, transient=False, **kw):

        if indent is not None:
            self.indent_level = indent

        self._assign_kw_fields(modifier=modifier, transient=transient, **kw)

        # print(self.fields)
        super()._print(transient)


class ldmma(MAT_LSA):
    def __init__(self, modifier=None, **kw):
        super().__init__(Opcode="LDMMA", **kw)
        self.type = "LDMMA"


class ldmma0(ldmma):
    def __init__(self, indent=None, modifier=None, **kw):
        super().__init__(modifier=modifier, GIBID_WriteThru="gib0", **kw)
        self.instr_name = "ldmma0"


class ldmma1(ldmma):
    def __init__(self, indent=None, modifier=None, **kw):
        super().__init__(modifier=modifier, GIBID_WriteThru="gib1", **kw)
        self.instr_name = "ldmma1"


class mma(MAT_LSA):
    def __init__(self, indent=None, modifier=None, **kw):
        super().__init__(Opcode="MMA", modifier=modifier, **kw)
        self.type = "MMA"

        self.instr_name = "mma"
        if indent is not None:
            self.indent_level = indent
