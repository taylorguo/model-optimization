#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import math

import code_generator.tcore.br_tcore_funs as tcf
import code_generator.share.br_loop_manager as lm
import code_generator.share.br_utils as br_utils
import code_generator.tcore.br_tcore_cwarp_man as tcm
import code_generator.tcore.br_tcore_operator as to
import code_generator.tcore.br_tcore_loop_man_mma as tlmm
import code_generator.share.br_const_defs as bcd


def br_mma(
        mata_shape, matb_shape, dt,
        usharps=None, loop_configs=[], pingpong_a=[0], pingpong_b=[0],
        red_mode="roff", write_through=None, unroll_disable=False):
    operator = tcore_mma(
        mata_shape=mata_shape, matb_shape=matb_shape, dt=dt,
        usharps=usharps, pingpong_a=pingpong_a, pingpong_b=pingpong_b,
        red_mode=red_mode, write_through=write_through,
        loop_configs=loop_configs, unroll_disable=unroll_disable)
    # operator.generate(loop_configs, dry_run=True)

    return operator


class tcore_mma(to.tcore_operator):
    def __init__(
            self, mata_shape, matb_shape, dt=None, usharps=None,
            pingpong_a=None, pingpong_b=None, red_mode=None,
            write_through=None, loop_configs=None, unroll_disable=False):
        super().__init__(
            name="mma", pingpong_a=pingpong_a, pingpong_b=pingpong_b,
            dt=dt, red_mode=red_mode, write_through=write_through,
            loop_configs=loop_configs, unroll_disable=unroll_disable)
        self.mata_shape = mata_shape
        self.matb_shape = matb_shape
        self.mata_type = dt[0]
        self.matb_type = dt[1]
        self.out_type = dt[2]
        self.usharp_a = usharps["tensor_a"]["usharp"]
        self.usharp_b = usharps["tensor_b"]["usharp"]
        self.usharp_o = usharps["tensor_o"]["usharp"]

        self.indent = br_utils.Br_Indent()
        self.cwm = tcm.cwarp_man()
        self.operators = dict()
        self.stride = 0

        self.matb_h_unit, self.matb_w_unit = find_best_buffer_b_load_size(
            matb_shape)
        self.mata_h_unit = find_best_buffer_a_load_size(mata_shape)
        self.mata_w_unit = self.matb_h_unit

        self.required_buffer_a_entries_per_ld = int(
            self.mata_h_unit/bcd.BUFFER_A_ENTRY_PIXEL_NUM)
        self.required_buffer_a_entries_per_ld *= int(
            self.mata_w_unit/bcd.BUFFER_A_ENTRY_ICH_NUM)

        self.required_buffer_a_entries_per_row = int(
            self.mata_shape[1]/self.mata_w_unit)
        self.required_buffer_a_entries_per_row *= (
            self.required_buffer_a_entries_per_ld)

        self.required_buffer_b_entries_per_ld = int(
            self.matb_h_unit/bcd.BUFFER_B_ENTRY_ICH_NUM)
        self.required_buffer_b_entries_per_ld *= int(
            self.matb_w_unit/bcd.BUFFER_B_ENTRY_PIXEL_NUM)

        self.operator["buf_a_ld"] = tcf.tcore_mma_buf_a_ld(
            gib0_addr=self.gib0_addr, x=0, y=0,
            gib0_step=32,
            GIB0Ctrl="b0nil",
            wsc=48, ssc=32, indent=self.indent,
            OpDisable="off", DataType0=self.mata_type, UsharpIdx=self.usharp_a,
            # Mat0Col_InputCh="256",
            # Mat0Row_OutputCh_Shape="32",
            Mat0Row_OutputCh_Shape="{}x{}".format(
                self.mata_h_unit, self.mata_w_unit),
            PostInc_x="setx", PostInc_y="sety", Waitgsc="wnil", Setgsc="snil")

        self.operator["buf_b_ld"] = tcf.tcore_mma_buf_b_ld(
            gib1_addr=self.gib1_addr, x=0, y=0,
            gib1_step=32,
            GIB0Ctrl="b1nil",
            wsc=0, ssc=16, DataType0=self.matb_type,
            indent=self.indent, OpDisable="off", PostInc_x="setx",
            PostInc_y="sety", Waitgsc="wnil", Setgsc="snil",
            # Mat1Col=64, Mat0Col_InputCh=256,
            Mat0Row_OutputCh_Shape="{}x{}".format(
                self.matb_h_unit, self.matb_w_unit),
            UsharpIdx=self.usharp_b)

        self.operator["mma"] = tcf.tcore_mma(
            gib0_addr=self.gib0_addr, gib1_addr=self.gib1_addr,
            x=0, y=0,
            warp_count=0, slot="sls0", wsc=0, ssc=16, indent=self.indent,
            GIB0Ctrl="b0nil", GIB1Ctrl="b1nil",
            gib0_step=32,
            gib1_step=32,
            OpDisable="off",
            Mat0Row_OutputCh_Shape="{}x{}".format(
                self.mata_h_unit, self.matb_w_unit),
            Init="ini1", DataType0=self.mata_type, DataType1=self.matb_type,
            DstDataType=self.out_type, Transpose_Out="out1",
            LMScope_RedMode=self.red_mode, GIBID_WriteThru=self.write_through,
            ReadOnly_Sparse="spar0",
            Waitgsc="wset", Setgsc="snil",
            UsharpIdx=self.usharp_o, Destination="z0",
            Mat0Col_InputCh=self.mata_w_unit)

        self.check_loop_configs()

        self.cwm = tcm.cwarp_man()

        self.buf_a_total_iterations = (
            self.get_total_iteration_times(self.loop_configs[0]))
        self.buf_b_total_iterations = (
            self.get_total_iteration_times(self.loop_configs[1]))

    def _generate_buf_a_ld(self, loop_config):
        # print("Info: loop_config is: ", loop_config)
        warp_prefix = self.cwm.start_buffer_a_ldmma_warp(self)
        if not loop_config:
            loop_config = self.loop_configs[0]

        # self.operators["buf_a_ld"].generate(modifier=".off")
        lm.loop_code_generate(
            indent=self.indent, loop_config=loop_config,
            instr="buf_a_ld", operator=self, prefix=warp_prefix,
            loop_man=tlmm.loop_man_mma)

        self.cwm.end_buffer_a_ldmma_warp()

    def _generate_buf_b_ld(self, loop_config):
        # print("Info: loop_config is: ", loop_config)
        warp_prefix = self.cwm.start_buffer_b_ldmma_warp(self)
        if not loop_config:
            loop_config = self.loop_configs[1]

        # self.operators["buf_b_ld"].generate(modifier=".off")
        lm.loop_code_generate(
            indent=self.indent, loop_config=loop_config,
            instr="buf_b_ld", operator=self, prefix=warp_prefix,
            loop_man=tlmm.loop_man_mma)

        self.cwm.end_buffer_b_ldmma_warp()

    def _generate_mma(self, loop_config):
        # print("Info: loop_config is: ", loop_config)
        warp_prefix = self.cwm.start_mma_warp(self)

        # self.operators["mma"].generate(modifier=".off")
        lm.loop_code_generate(
            indent=self.indent, loop_config=loop_config,
            instr="mma", operator=self, prefix=warp_prefix,
            loop_man=tlmm.loop_man_mma)

        self.cwm.end_mma_warp()

    def generate(self, loop_configs=[], dry_run=False):
        if len(loop_configs) == 0 and self.loop_configs is not None:
            loop_configs = self.loop_configs

        self._set_dry_run(dry_run)
        size_of_configs = len(loop_configs)
        # print("size of configs is ", size_of_configs)
        if size_of_configs > 0:
            self._generate_buf_a_ld(loop_configs[0])
        else:
            self._generate_buf_a_ld()

        if size_of_configs > 1:
            self._generate_buf_b_ld(loop_configs[1])
        else:
            self._generate_buf_b_ld()

        if size_of_configs > 2:
            self._generate_mma(loop_configs[2])
        else:
            self._generate_mma()

        self.previous_operator_filter_width = (
            self.cwm.get_previou_filter_width())

        self._set_dry_run(False)
        self.reset()

    def reset(self):
        self.operator["buf_a_ld"].reset()
        self.operator["buf_b_ld"].reset()
        self.operator["mma"].reset()


def find_best_buffer_a_load_size(mat_shape):
    h = mat_shape[0]
    w = mat_shape[1]

    selected_h_size = 0
    selected_w_size = 0

    for v in bcd.MATRIX0_ROW:
        if v >= h:
            selected_h_size = v
            break
        else:
            selected_h_size = v

    return selected_h_size


def find_best_buffer_b_load_size(mat_shape):
    h = mat_shape[0]
    w = mat_shape[1]

    selected_h_size = 0
    selected_w_size = 0

    for v in bcd.MATRIX1_COL:
        if v >= w:
            selected_w_size = v
            break
        else:
            selected_w_size = v

    for v in bcd.MATRIX0_COL_MATRIX1_ROW:
        if v >= h:
            selected_h_size = v
            break
        else:
            selected_h_size = v
            if selected_w_size == bcd.MATRIX1_COL[0]:
                # keep the buffer b loading size to 16KB
                if (int(v / bcd.BUFFER_B_ENTRY_PIXEL_NUM) >=
                        bcd.BUFFER_B_ENTRY_MMA_LD_SIZE0):
                    break
            if selected_w_size == bcd.MATRIX1_COL[1]:
                # keep the buffer b loading size to 16KB
                if (int(v / bcd.BUFFER_B_ENTRY_PIXEL_NUM) >=
                        bcd.BUFFER_B_ENTRY_MMA_LD_SIZE1):
                    break

    return selected_h_size, selected_w_size


def calculate_load_iterations(mat_shape, h_unit, w_unit):
    h = mat_shape[0]
    w = mat_shape[1]

    h_iter = int(math.ceil(h/h_unit))
    w_iter = int(math.ceil(w/w_unit))

    return h_iter, w_iter

