# Interface definition of the basic operators.

## loop config
loop_config = [(name, iterations, unrolls, incremental_unit,
                {"wset": [32, 33], "sset": [48, 49], "bar": "sync", "grb_pingpong": [1]})]

Fields of "name", "iterations", "unrolls", "incremental_unit" are mandatory.
Any Fields of the dictionary is optional, if no field is in the dictionary, the dictionary can be ignored.


## br_fwd_conv
>'''
>>def br_fwd_conv(
>>        ishape, wshape, dt, stride=1, dilation=1,
>>        padx=0, pady=0, u_w="u0", u_i="u1", u_o="u2",
>>        loop_configs=[], pingpong_a=[0, 256], red_mode="roff"):
>'''
* ishape: the kernel input activation shape, a tuple with format (sample, ich, h, w), for example, (10, 512, 56, 56)
* wshape: the kernel weight shape, a tuple with format (och, ich, kh, kw), for example, (128, 512, 3, 3)
* dt： A tuple is used to specify the data types of activation, weight, and output. for example, ("bf16", "bf16", "bf16")
* stride: A number used to specify the stride configuration of the corresponding convolution, which can only be 1, and 2.
* dilation: A number used to specify the dilation configuration of the correspdonging convolution, which can only be 1, and 2.
* padx: A string used to specify the padx configuration of the corresponding convolution, which can be "0", "1", "2", "3", "-1", "-2", "-3".
* pady：A string used to specify the padx configuration of the corresponding convolution, which can be "0", "1", "2", "3", "-1", "-2", "-3".
* loop_configs: A list of list, which is used to specify how to generate loop code for buffer a loading, buffer b loading, conf. for example:
>'''
>    loop_configs = [
>>        [("outer_oc", och_iter, 1, och_inc, {"wset": [48, 49], "sset": [32, 33]}),
>>         ("outer_ic", och_iter, 1, och_inc),
>>         ("oc", och_iter, 1, och_inc),
>>         ("ich", ich_iter, ich_iter, ich_inc)],
>>        [("outer_oc", och_outer_iter, 1, och_outer_inc),
>>         ("outer_ic", och_outer_iter, 1, och_outer_inc),
>>         ("outer_oc", och_outer_iter, 1, och_outer_inc),
>>         ("sample", sample_iter, 1, sample_inc),
>>         ("row", h_iter, 1, row_inc),
>>         ("col", w_iter, 1, col_inc),
>>         # ("inner_oc", och_inner_grannular, 1, och_inc),
>>         ("ich", ich_iter, ich_iter, ich_inc)], 
>>        [("outer_oc", och_outer_iter, 1, och_outer_inc),
>>         ("outer_ic", och_outer_iter, 1, och_outer_inc, {"wset": [32, 33], "sset": [48, 49], "bar": "sync", "grb_pingpong": [1]}),
>>         ("outer_oc", och_outer_iter, 1, och_outer_inc),
>>         ("sample", sample_iter, 1, sample_inc, ),
>>         ("row", h_iter, 1, row_inc),
>>         ("col", w_iter, 1, col_inc),
>>         ("inner_oc", och_inner_grannular, 1, och_inc),
>>         ("ich", 7, 7, 8)]]
>'''
* pingpong_a: A list to specify which part of buffer a should be used as the first loading. for example, it can be [0, 256]
* red_mode: A string used to specify the reduction mode, it can be "roff", "sqs" etc.


