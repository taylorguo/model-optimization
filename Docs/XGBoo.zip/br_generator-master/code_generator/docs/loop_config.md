[ (loop_axis, iteration, unroll, big_step, dict) ]

loop_axis := oc|ic|sample| row | col| kh | kw | m |n | k| inner_oc |ich

iteration := NUMBER

unroll := NUMBER

big_step := NUMBER

dict = START , [ channel ]

channel =  {wait_key: channel_id_list, signal_key: channel_id_list, state_key: state}

channel

| Channel name    | producer wait | producer signal | consumer wait | consumer signal | state                    |
| --------------- | ------------- | --------------- | ------------- | --------------- | ------------------------ |
| ld_bufa_ch      | wset          | sset            | wset          | sset            | pingpong_a  (top_config) |
| ld_bufb_ch      | bufb_wset     | bufb_sset       | bufb_wset     | bufb_sset       | pingpong_b (top_config)  |
| tlr_ch          | tlr_bar_sync  | tar_bar_set     | tlr_bar_csm   | tlr_bar_pass    | tlr_pingpong             |
| grb_ch          | bar_sync      | bar_set         | bar_csm       | bar_pass        | grb_pingpong             |
| reduce_bn_ch    |               |                 |               |                 |                          |
| inter_kernel_ch |               |                 |               |                 |                          |



Dicts in tcore_top_config

| key     | values      | description        |
| ------- | ----------- | ------------------ |
| redmode | ssq \| roff | GRB reduction mode |

Example:

```
loop_config_tcore=
[   [   ('outer_oc', 1, 1, 64, {'sset': [32], 'start': 0, 'wset': [48]}),
        ('outer_ic', 1, 1, 8, {'start': 0}),
        ('oc', 2, 2, 32, {'start': 0}),
        ('ich', 1, 1, 8, {'start': 0})],
    [   ('outer_oc', 1, 1, 64, {'start': 0}),
        ('outer_ic', 1, 1, 8, {'start': 0}),
        ('outer_oc', 2, 1, 32, {'start': 0}),
        ('sample', 16, 1, 1, {'start': 0}),
        ('row', 28, 1, 8, {'start': 0}),
        ('col', 28, 1, 8, {'start': 0}),
        ('ich', 1, 1, 8, {'start': 0})],
    [   ('outer_oc', 1, 1, 64, {'sset': [48], 'start': 0, 'wset': [32]}),
        ('outer_ic', 1, 1, 8, {'start': 0}),
        (   'outer_oc',
            2,
            1,
            32,
            {   'bar_set': [2, 3],
                'bar_sync': [4, 5],
                'grb_pingpong': [0, 8],
                'start': 0}),
        ('sample', 16, 1, 1, {'start': 0}),
        ('sample_row', 1, 1, 1, {'start': 0}),
        (   'row',
            28,
            1,
            8,
            {   'start': 0,
                'tlr_bar_set': [6, 7],
                'tlr_bar_sync': [8, 9],
                'tlr_pingpong': [0, 64]}),
        ('sample_col', 1, 1, 1, {'start': 0}),
        ('col', 28, 1, 8, {'start': 0}),
        ('inner_oc', 1, 1, 32, {'start': 0}),
        ('ich', 1, 1, 8, {'start': 0})]]
top_config_tcore=
{   'pingpong_a': [0],
    'pingpong_b': [0, 256],
    'redmode': 'ssq',
    'tlr_pingpong': [0, 64]}
stm_reduce=
[   ('outer_oc', 1, 1, 64, {'start': 0}),
    (   'outer_oc',
        2,
        1,
        32,
        {   'bar_csm': [2, 3],
            'bar_pass': [4, 5],
            'grb_pingpong': [0, 8],
            'start': 0}),
    ('sample', 16, 1, 1, {'start': 0}),
    (   'row',
        28,
        1,
        8,
        {   'start': 0,
            'tlr_bar_csm': [6, 7],
            'tlr_bar_pass': [8, 9],
            'tlr_pingpong': [0, 64]}),
    ('col', 14, 1, 8, {'start': 0}),
    ('inner_oc', 1, 1, 32, {'start': 0})]
```

