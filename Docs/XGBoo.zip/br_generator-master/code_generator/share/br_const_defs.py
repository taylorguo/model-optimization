#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

BR_STM_G4_FEATURE_ENABLE = True

OC64_CONV_ROW64_MMA = True
# OC64_CONV_ROW64_MMA = False

ENABLE_ROW_ACCUMULATION = True


def set_code_style(style):
    global BR_CODE_GEN_STYLE
    BR_CODE_GEN_STYLE = style


def set_debug_mode(mode):
    global BR_CODE_DEBUG_STYLE
    BR_CODE_DEBUG_STYLE = mode

BR_CODE_GEN_STYLE = 0  # 0-ASM style; 1-Pseudo code style
BR_CODE_DEBUG_STYLE = 0  # 0-Release mode; 1-Debug mode print in order

BR_CODE_DEBUG_FLAG = 0
BR_SPC_NUMBER = 16

BUFFER_ADDRESS_TO_SYNC_SHILT = 32
SET_SYNC_TO_WAIT_DIFF = 16

GIB1_BUFFER_INCREASE_ENTRIES_NUM = 32

INTER_LAYER_BARRIER_BTWEEN_BUFB_AND_VECTOR = 1

MAX_CWARP_NUM = 8

MATRIX0_ROW = [32]
if OC64_CONV_ROW64_MMA:
    MATRIX0_ROW = [64]

MATRIX1_COL = [32, 64]
MATRIX0_COL_MATRIX1_ROW = [16, 32, 64, 128, 256]

WEIGHT_BLOCK_ICH_SIZE = 32
WEIGHT_BLOCK_OCH_SIZE = 8

ACTIVATION_BLOCK_W_SIZE = 8
ACTIVATION_BLOCK_H_SIZE = 8
ACTIVATION_BLOCK_I_SIZE = 32
ACTIVATION_BLOCK_SHAPE = "8x8"

WEIGHT_OCH_LD_SIZE = 32
WEIGHT_OCH_LD_CHANNELS = "oc32"
if OC64_CONV_ROW64_MMA:
    WEIGHT_OCH_LD_SIZE = 64
    WEIGHT_OCH_LD_CHANNELS = "oc64"

BUFFER_A_ENTRY_OCH_NUM = 32
BUFFER_A_ENTRY_ICH_NUM = 8

BUFFER_A_ENTRY_PIXEL_NUM = 32
BUFFER_A_ENTRY_ICH_NUM = 8
BUFFER_A_ENTRY_PIXEL_WIDTH = 8
BUFFER_A_ENTRY_PIXEL_HEIGHT = 4

BUFFER_B_ENTRY_PIXEL_NUM = 32
BUFFER_B_ENTRY_ICH_NUM = 8
BUFFER_B_ENTRY_PIXEL_WIDTH = 8
BUFFER_B_ENTRY_PIXEL_HEIGHT = 4
BUFFER_B_ENTRY_MMA_LD_SIZE0 = 8
BUFFER_B_ENTRY_MMA_LD_SIZE1 = 4


LOAD_CONV_SYNC_BUFFER_B_ENTRY_NUM = 16
SYNC_CHANNEL_FLIP = int(LOAD_CONV_SYNC_BUFFER_B_ENTRY_NUM/2)
LOAD_CONV_SYNC_BUFFER_B_SIZE = LOAD_CONV_SYNC_BUFFER_B_ENTRY_NUM * 1024

LOAD_CONV_SYNC_STATION_NUM = 16

BUFFER_A_ENTRY_NUM = 512
BUFFER_A_SIZE_PER_ENTRY = 32 * 128 >> 3
HALF_BUFFER_A_SIZE = int(BUFFER_A_ENTRY_NUM / 2)

BUFFER_B_ENTRY_NUM = 512
BUFFER_B_SIZE_PER_ENTRY = 64 * 128 >> 3
HALF_BUFFER_B_SIZE = int(BUFFER_B_ENTRY_NUM / 2)
BUFFER_B_ENTRY_SYNC_BIT_WIDTH = 5

CONV_OCH_SIZE = 32
CONV_OCH_SIZE_SYM = "oc32"
if OC64_CONV_ROW64_MMA:
    CONV_OCH_SIZE = 64
    CONV_OCH_SIZE_SYM = "oc64"

OCH_INNER_LOOP_GRANNULAR = 8

LDCONV1_TO_CONV_START_STATION = 0
CONV_TO_LDCONV1_START_STATION = 16
LDCONV0_TO_CONV_START_STATION = 32
CONV_TO_LDCONV0_START_STATION = 48

INTER_LAYER_BARRIER_BTWEEN_BUFB_AND_VECTOR = 1

GRB_PINGPONG_CONV_TO_VECTOR_BAR_ID_1 = 2
GRB_PINGPONG_CONV_TO_VECTOR_BAR_ID_2 = 3

GRB_PINGPONG_VECTOR_TO_CONV_BAR_ID_1 = 4
GRB_PINGPONG_VECTOR_TO_CONV_BAR_ID_2 = 5

TLR_PINGPONG_CONV_TO_VECTOR_BAR_ID_1 = 6
TLR_PINGPONG_CONV_TO_VECTOR_BAR_ID_2 = 7

TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_1 = 8
TLR_PINGPONG_VECTOR_TO_CONV_BAR_ID_2 = 9

VECTOR_PINGPONG_REDUCE_TO_BN_BAR_ID_1 = 6
VECTOR_PINGPONG_REDUCE_TO_BN_BAR_ID_2 = 7

VECTOR_PINGPONG_BN_TO_REDUCE_BAR_ID_1 = 8
VECTOR_PINGPONG_BN_TO_REDUCE_BAR_ID_2 = 9

BAR_CHANNELS_DWC_LDDW_BAR_ID = 14

BAR_CHANNELS_BETWEEN_BN_AND_MAXPOOL = 15

BAR_CHANNELS_BTWEEN_TCORE_AND_VECTOR = 17
BAR_CHANNELS_WITHIN_VECTOR = 8

EU_NUMBER_IN_A_SPC = 16

WSR_NUM = 32
TLR_NUM = 256
CSR_NUM_HALF = 512
CSR_NUM = 1024

CWARP_NUM = 6
USHARP_START_ID = 2
#############################
# accu constexpr define
ACCU_ICH_NUM = 128
ACCU_BUFFER_NUM = 16
############################
# accu constexpr define for filter height > 1
ACCU_ICH_NUM_WITH_DOWN_PADDING = 64
ACCU_BUFFER_NUM = 16
ACCU_BUFFER_ENTRY_NUM = 32
###############################
# stride 2 define
OCH_PER_TLR = 32
HALF_TLR = "0x100000"
STRIDE_TLR_FLIP_64 = 64
if CONV_OCH_SIZE == 64:
    STRIDE_TLR_FLIP = 1
BURST_TLR_SIZE = 4
OC64_TLR_SIZE = 8
###############################

OC_ROOT_LOOP_NAME = "oc"
IC_ROOT_LOOP_NAME = "ich_root"
ICH_SPLIT_LOOP_NAME = "ich_root"
TOC_LOOP_NAME = "oc"

OC_ROOT_VECTOR_LOOP_NAME = "outer_oc"
IC_ROOT_VECTOR_LOOP_NAME = "outer_ic"
TOC_VECTOR_LOOP_NAME = "outer_oc"

SAMPLE_LOOP_NAME = "sample"
ROW_LOOP_NAME = "row"
COL_LOOP_NAME = "col"
OUTER_ROW_LOOP_NAME = "outer_row"
OUTER_COL_LOOP_NAME = "outer_col"
INNER_OC_LOOP_NAME = "inner_oc"
INNER_IC_LOOP_NAME = "ich"


UT_WRED_USHARP_ID = 3
UT_CWARP_ID = 3

OpDisable = {"on": 0, "off": 1}

Opcode = {
    "MATE": 0,
    "LDMMA": 64,
    "LDCONV": 65,
    "PLDGMB": 66,
    "GLGMB": 67,
    "MMA": 72,
    "CONV": 73,
}

DataType = {"s4": 0, "s8": 1, "u8": 2, "f8": 3, "bf8": 4, "bf16": 5, "f32": 6}

INIT = {"ini0": 0, "ini1": 1}

SYNC = {"sc1": 1, "sc2": 2, "sc3": 3}

GIB0_CRTL = {"b0nil": 0, "b0inc": 1}

GIB1_CRTL = {"b1nil": 0, "b1inc": 1}

MAT1COL = {"32": 0, "64": 1}

LMSCOPE_REDMODE = {
    "moff": 0,
    "vtg": 1,
    "dtg": 2,
    "peer": 3,
    "roff": 0,
    "sum": 1,
    "ssq": 2,
    "add": 3,
}

DST_DATATYPE = {"bf16": 0, "f32": 1}

WBAR_CTRL = {
    "wbnil": 0,
    "wbset": 1,
}

L2CONTROL = {
    "npri": 0,
    "pri": 1,
    "nlast": 0,
    "last": 1,
    "nfuw": 0,
    "fuw": 1,
    "ntrs": 0,
    "trs": 1,
    "nbyp": 0,
    "byp": 1,
}

GIBID_WRITETHRU = {"gib0": 0, "gib1": 1, "nwt": 0, "wt": 1}

READONLY_SPARSE = {"rw": 0, "ro": 1, "spar0": 0, "spar1": 1}

DESC_INDEX = {
    "u0": 0x500,
    "u1": 0x501,
    "u2": 0x502,
    "u3": 0x503,
    "u4": 0x504,
    "u5": 0x505,
    "u6": 0x506,
    "u7": 0x507,
    "u8": 0x508,
    "u9": 0x509,
    "u10": 0x50A,
    "u11": 0x50B,
    "u12": 0x50C,
    "u14": 0x50D,
    "u15": 0x50E,
    "c0": 0x000,
    "c1": 0x001,
    "c2": 0x002,
    "c3": 0x503,
    "c4": 0x504,
    "c5": 0x505,
    "c6": 0x506,
    "c7": 0x507,
    "c8": 0x508,
    "c9": 0x509,
    "c10": 0x50A,
    "c11": 0x50B,
    "c12": 0x50C,
    "c14": 0x50D,
    "c15": 0x50E,
}

PAD_ONLY_SLOTSET = {
    "pb": 0,
    "po": 1
    # "sls0": 0,
    # "sls1": 1
}

BUF_SWITCH_DSTREL = {"bs0": 0, "bs1": 1}

BUF_TRANSPOSE_OUT = {"tp0": 0, "tp1": 1, "out0": 0, "out1": 1}

LDCONV0_POSTINC = {
    "incy0": 0,
    "incy1": 1,
    "resety": 14,
    "sety": 15,
    "incz0": 0,
    "incz1": 1,
    "resetz": 14,
    "setz": 15,
}

LDCONV1_POSTINC = {
    "incx0": 0,
    "incx1": 1,
    "resetx": 2,
    "setx": 3,
    "incy0": 0,
    "incy1": 1,
    "resety": 2,
    "sety": 3,
    "incz0": 0,
    "incz1": 1,
    "resetz": 14,
    "setz": 15,
}

Mat0Col_InputCh = {
    "16": 0,
    "32": 1,
    "64": 2,
    "128": 3,
    "256": 4,
    "512": 5,
    "ich8": 0,
    "ich16": 1,
    "ich32": 2,
    "ich64": 3,
    "ich128": 4,
}

MAT0ROW_OUTPUT_CH_SHAPE = {
    "32": 0,
    "oc32": 0,
    "8x8": 0,
}

PAD_X_START_BIT = 8
PAD_X_BIT_NUM = 3
PAD_X_MASK = 0x700

WAITGSC = {"wnil": 0, "wset": 1, "winc": 2}

SETGSC = {"snil": 0, "sset": 1, "sinc": 2}

FilWidth_Height = {"1": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9}

Padx_Pady = {"0": 0, "1": 1, "2": 2, "3": 3, "-3": 5, "-2": 6, "-1": 7}

Stride_Dilation = {"1": 0, "2": 1}

Direction = {"fwd": 0, "bwd": 1}

BwdType = {"bpa": 0, "bpw": 1}

HalfTLR = {"htlr0": 0, "htlr1": 1}

# self define, not in ISA spec
UsharpIdx = {
    "u0": 0,
    "u1": 1,
    "u2": 2,
    "u3": 3,
    "u4": 4,
    "u5": 5,
    "u6": 6,
    "u7": 7,
    "u8": 8,
    "u9": 9,
    "u10": 10,
    "u11": 11,
    "u12": 12,
    "u13": 13,
    "u14": 14,
    "u15": 15,
}

Destination = {"z0": 0, "r0": 1}

PostInc_x = {"incx0": 0, "incx1": 1, "resetx": 2, "setx": 3}
PostInc_y = {"incy0": 0, "incy1": 1, "resety": 2, "sety": 3}
PostInc_z = {"incz0": 0, "incz1": 1, "resetz": 2, "setz": 3}

all_tcore_modifiers = {
    "OpDisable": OpDisable,
    "DataType0": DataType,
    "DataType1": DataType,
    "Mat0Col_InputCh": Mat0Col_InputCh,
    "Init": INIT,
    "DstDataType": DST_DATATYPE,
    # "WbarCtrl": WBAR_CTRL,
    "PostInc_x": PostInc_x,
    "PostInc_y": PostInc_y,
    "PostInc_z": PostInc_z,
    "L2Control_0": L2CONTROL,
    "L2Control_1": L2CONTROL,
    "L2Control_2": L2CONTROL,
    "L2Control_3": L2CONTROL,
    "GIBID_WriteThru": GIBID_WRITETHRU,
    "ReadOnly_Sparse": READONLY_SPARSE,
    "DescIndex": DESC_INDEX,
    "GIB0Ctrl": GIB0_CRTL,
    "GIB1Ctrl": GIB1_CRTL,
    "Mat1Col": MAT1COL,
    "LMScope_RedMode": LMSCOPE_REDMODE,
    "Sync": SYNC,
    "PadOnly_SlotSet": PAD_ONLY_SLOTSET,
    "Transpose_Out": BUF_TRANSPOSE_OUT,
    "BufSwitch_DstRel": BUF_SWITCH_DSTREL,
    "Mat0Row_OutputCh_Shape": MAT0ROW_OUTPUT_CH_SHAPE,
    "Waitgsc": WAITGSC,
    "Setgsc": SETGSC,
    "UsharpIdx": UsharpIdx,
    "Destination": Destination,
}

modifiers_of_tcore_fun = {
    "OpDisable": None,
    "DataType0": None,
    "DataType1": None,
    "Mat0Col_InputCh": None,
    "Init": None,
    "DstDataType": None,
    "WbarCtrl": None,
    "PostInc_x": None,
    "PostInc_y": None,
    "PostInc_z": None,
    "L2Control_0": None,
    "L2Control_1": None,
    "L2Control_2": None,
    "L2Control_3": None,
    "GIBID_WriteThru": None,
    "ReadOnly_Sparse": None,
    "DescIndex": None,
    "GIB0Ctrl": None,
    "GIB1Ctrl": None,
    "Mat1Col": None,
    "LMScope_RedMode": None,
    "Sync": None,
    "PadOnly_SlotSet": None,
    "Transpose_Out": None,
    "BufSwitch_DstRel": None,
    "Mat0Row_OutputCh_Shape": None,
    "Waitgsc": None,
    "Setgsc": None,
    "UsharpIdx": None,
    "Destination": None,
}

ldmma_on = [
    "gib0_addr",
    "gib1_addr",
    "x",
    "y",
    "w",
    "wsc",
    "ssc",
    "gib0_step",
    "gib1_step",
    "boundary_x",
    "boundary_y",
]
ldmma_off = [
    "gib0_addr",
    "gib1_addr",
    "x",
    "y",
    "w",
    "wsc",
    "ssc",
    "gib0_step",
    "gib1_step",
    "boundary_x",
    "boundary_y",
]

ldconv_on = [
    "gib0_addr",
    "gib1_addr",
    "x",
    "y",
    "z",
    "w",
    "wsc",
    "ssc",
    "gib0_step",
    "gib1_step",
    "boundary_x",
    "boundary_y",
]
ldconv_off = [
    "gib0_addr",
    "gib1_addr",
    "x",
    "y",
    "z",
    "w",
    "wsc",
    "ssc",
    "gib0_step",
    "gib1_step",
    "boundary_x",
    "boundary_y",
]

mma_on = [
    "gib1_addr",
    "gib0_addr",
    "x",
    "y",
    "z",
    "w",
    "warp_count",
    "slot",
    "wsc",
    "ssc",
    "wbar_id",
    "gib0_step",
    "gib1_step",
    "boundary_x",
    "boundary_y",
]
mma_off = [
    "gib1_addr",
    "gib0_addr",
    "x",
    "y",
    "z",
    "w",
    "warp_count",
    "slot",
    "wsc",
    "ssc",
    "wbar_id",
    "gib0_step",
    "gib1_step",
    "boundary_x",
    "boundary_y",
]

conv_on = [
    "gib1_addr",
    "gib0_addr",
    "x",
    "y",
    "z",
    "w",
    "warp_count",
    "slot",
    "wsc",
    "ssc",
    "wbar_id",
    "gib0_step",
    "gib1_step",
    "boundary_x",
    "boundary_y",
]
conv_off = [
    "gib1_addr",
    "gib0_addr",
    "x",
    "y",
    "z",
    "w",
    "warp_count",
    "slot",
    "wsc",
    "ssc",
    "wbar_id",
    "gib0_step",
    "gib1_step",
    "boundary_x",
    "boundary_y",
]
# conv_off = ["x", "wsc", "ssc"]

pldgmb = ["x", "y", "z", "w"]

warp_input_assemble = {
    "ldmma_on": ldmma_on,
    "ldmma_off": ldmma_off,
    "ldconv_on": ldconv_on,
    "ldconv_off": ldconv_off,
    "mma_on": mma_on,
    "mma_off": mma_off,
    "conv_on": conv_on,
    "conv_off": conv_off,
    "pldgmb": pldgmb,
}

warp_input_register_dem_map_on = {
    "gib1_addr": 0,
    "gib0_addr": 1,
    "x": 2,
    "y": 3,
    "z": 4,
    "w": 5,
    "warp_count": 6,
    "slot": 7,
    "wsc": 8,
    "ssc": 9,
    "wbar_id": 10,
    "gib0_step": 11,
    "gib1_step": 12,
    "boundary_x": 13,
    "boundary_y": 14,
}

warp_input_register_dem_map_off = {
    "gib1_addr": 0,
    "gib0_addr": 1,
    "x": 2,
    "y": 3,
    "z": 4,
    "w": 5,
    "warp_count": 6,
    "wsc": 8,
    "ssc": 9,
    "wbar_id": 10,
    "gib0_step": 11,
    "gib1_step": 12,
    "boundary_x": 13,
    "boundary_y": 14,
}

boundry_5 = [(0, 5), (2, 7), (0, 4), (1, 6), (0, 3)]
boundry_6 = [(0, 6), (0, 4), (0, 2)]
boundry_7 = [(0, 7), (0, 6), (0, 5), (0, 4), (0, 3), (0, 2), (0, 1)]
boundry_10 = [(0, 0), (0, 2), (0, 4), (0, 6), (0, 0)]
boundry_12 = [(0, 0), (0, 4), (0, 0)]
boundry_13 = [(0, 0), (0, 5), (0, 0), (0, 2), (0, 6), (0, 0), (0, 3), (0, 0)]
boundry_14 = [(0, 0), (0, 6), (0, 0), (0, 4), (0, 0), (0, 2), (0, 0)]
boundry_15 = [
    (0, 0),
    (0, 7),
    (0, 0),
    (0, 6),
    (0, 0),
    (0, 6),
    (0, 0),
    (0, 5),
    (0, 0),
    (0, 4),
    (0, 0),
    (0, 3),
    (0, 0),
    (0, 2),
    (0, 0),
    (0, 1),
    (0, 0),
]
boundry_21 = [
    (0, 0),
    (0, 0),
    (0, 5),
    (0, 0),
    (0, 0),
    (0, 2),
    (0, 0),
    (0, 7),
    (0, 0),
    (0, 0),
    (0, 4),
    (0, 0),
    (0, 0),
    (0, 1),
    (0, 0),
    (0, 6),
    (0, 0),
    (0, 0),
    (0, 3),
    (0, 0),
    (0, 0),
]
boundry_22 = [
    (0, 0),
    (0, 0),
    (0, 6),
    (0, 0),
    (0, 0),
    (0, 4),
    (0, 0),
    (0, 0),
    (0, 2),
    (0, 0),
    (0, 0),
]
boundry_23 = [
    (0, 0),
    (0, 0),
    (0, 7),
    (0, 0),
    (0, 0),
    (0, 6),
    (0, 0),
    (0, 0),
    (0, 5),
    (0, 0),
    (0, 0),
    (0, 5),
    (0, 0),
    (0, 0),
    (0, 4),
    (0, 0),
    (0, 0),
    (0, 3),
    (0, 0),
    (0, 0),
    (0, 2),
    (0, 0),
    (0, 0),
]
boundry_28 = [(0, 0), (0, 0), (0, 0), (0, 4), (0, 0), (0, 0), (0, 0)]
boundry_29 = [(0, 0), (0, 0), (0, 0), (0, 4), (0, 0), (0, 0), (0, 0)]


boundary_table = {
    "boundry_5": boundry_5,
    "boundry_6": boundry_6,
    "boundry_7": boundry_7,
    "boundry_10": boundry_10,
    "boundry_12": boundry_12,
    "boundry_13": boundry_13,
    "boundry_14": boundry_14,
    "boundry_15": boundry_15,
    "boundry_21": boundry_21,
    "boundry_22": boundry_22,
    "boundry_23": boundry_23,
    "boundry_28": boundry_28,
}


def get_boundary_coordinates(block_x, block_y, block_x_size, block_y_size):
    table_name = "boundry_{}".format(block_x_size)
    table = boundary_table[table_name]
    x = table[block_x % len(table)]

    table_name = "boundry_{}".format(block_y_size)
    table = boundary_table[table_name]
    y = table[block_y % len(table)]

    return x, y


def get_boundary_coordinate_table(block_size_in_one_direction):
    table_name = "boundry_{}".format(block_size_in_one_direction)
    table = None
    if table_name in boundary_table.keys():
        table = boundary_table[table_name]
    else:
        print("Error: The input block size is not supported currently!")

    return table
