#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import math
from copy import deepcopy
from abc import abstractmethod
import code_generator.share.br_const_defs as const_defs
import code_generator.kernel_gen.math_utils as utils
import code_generator.kernel_gen.hardware
from code_generator.kernel_gen.channel import channel


class br_loop_config_generator:
    def __init__(
        self, ishape, wshape, dt, stride, dilation, padding, vmc_mode, reduce):
        
        self.ishape = ishape
        self.wshape = wshape
        self.dt = dt
        self.stride = [stride + 1, stride + 1] if isinstance(stride, int) else \
                      [stride[0] + 1, stride[1] + 1]
        self.dilation = [dilation + 1, dilation + 1] if isinstance(dilation, int) else \
                        [dilation[0] + 1, dilation[1] + 1]
        self.padding = [padding, padding] if isinstance(padding, int) else padding
        self.vmc_mode = vmc_mode
        self.reduce = reduce

    @abstractmethod
    def get_configuration(self):
        pass

class br_loop_config_conv2d_forward(br_loop_config_generator):
    def __init__(
        self, 
        ishape, 
        wshape,
        dt=["bf16", "bf16", "bf16"], # weight_dt, input_dt, output_dt
        stride=[0, 0], 
        dilation=[1, 1], 
        padding=[0, 0], 
        vmc_mode="auto",  # spc|vmc|auto
        reduce=False, 
        optimization_policy=None):
        super().__init__(
            ishape=ishape, wshape=wshape, dt=dt, stride=stride,
            dilation=dilation, padding=padding, vmc_mode=vmc_mode, 
            reduce=reduce)
        
        self.optimization_policy = optimization_policy

        if self.optimization_policy is None:
            self.optimization_policy = {
                    "unroll_policy": "only_ic",  # 'only_ic', 'target_count', 'legacy', 'unroll2', 'all'
                    "unroll_target_instruction_count": [
                        120,
                        120,
                        120,
                        0,
                        0,
                    ],  # ldconv0, ldconv1, conv, reduce, elemwise
                    "force_bufa_pingpong": False,
                    "force_grb_pingpong": False,
                    "remove_ic_epilog": False,
                    "remove_oc_epilog": False,
                }
    
    def generate_config(self):

        # Hardware parameters
        hardware = code_generator.kernel_gen.hardware.hardware()
        hw_buf_a_size = hardware.bufa_sz
        hw_output_channel = 32
        hw_input_channel = 8
        hw_input_height = 4
        hw_input_width = 8
        hw_accu_output_channel = 2 if const_defs.OC64_CONV_ROW64_MMA else 1

        (input_number, input_channel, input_height, input_width) = self.ishape
        (output_channel, _, kernel_height, kernel_width) = self.wshape
        
        weight_dt, input_dt, _ = self.dt
        weight_dem_size = self._get_dem_size(weight_dt)

        input_channel = utils.ceil_block(input_channel, hw_input_channel)
        output_channel = utils.ceil_block(output_channel, hw_output_channel)

        padding_height, padding_width = self.padding
        stride_height, stride_width = self.stride
        dilation_height, dilation_width = self.dilation
        output_height = (input_height + 2 * padding_height - dilation_height *(kernel_height - 1) - 1) // stride_height + 1
        output_width = (input_width + 2 * padding_width - dilation_width * (kernel_width - 1) - 1) // stride_width + 1

        N_H = 1
        N_W = 1

        def is_satisfied(tiled_output_channel, tiled_input_channel):
            occupied_buf_a_size = (
                tiled_output_channel * 
                tiled_input_channel * 
                (hw_input_channel * hw_accu_output_channel * hw_output_channel * kernel_height * kernel_width) * 
                weight_dem_size
            )

            return occupied_buf_a_size <= hw_buf_a_size

        # Meet reuse requirement
        m_min = math.ceil(2 * hw_accu_output_channel / (kernel_height * kernel_width))

        if m_min * hw_output_channel * hw_accu_output_channel > output_channel:
            m_min = 1
        tiled_output_channel = m_min
        tiled_input_channel = 1
        output_channel_root = output_channel / (tiled_output_channel * hw_output_channel * hw_accu_output_channel)
        input_channel_root = input_channel / (tiled_input_channel * hw_input_channel)

        while True:
            if tiled_input_channel * hw_input_channel < input_channel:
                if is_satisfied(tiled_output_channel, tiled_input_channel + 1):
                    tiled_input_channel += 1
                    continue
            elif tiled_output_channel * hw_output_channel * hw_accu_output_channel < output_channel:
                if is_satisfied(tiled_output_channel + 1, tiled_input_channel):
                    tiled_output_channel += 1
                    continue           
            break # Stop looping

        output_channel_root = output_channel / (tiled_output_channel * hw_output_channel * hw_accu_output_channel)
        input_channel_root = input_channel / (tiled_input_channel * hw_input_channel)

        # Remove input_channel epilog
        if self.optimization_policy["remove_ic_epilog"]:
            if not input_channel_root.is_integer():
                # Move total epilog to tiled_input_channel
                input_channel_root = utils.ceil_block(input_channel_root, 2)
                tiled_input_channel = input_channel / ((input_channel_root) * hw_input_channel)
                tiled_output_channel = hw_buf_a_size / (
                    tiled_input_channel * 
                    kernel_height * 
                    kernel_width * 
                    (hw_input_channel * hw_accu_output_channel * hw_output_channel) * 
                    weight_dem_size
                )
                output_channel_root = output_channel / (tiled_output_channel * hw_output_channel * hw_accu_output_channel)
        else:
            input_channel_root = math.ceil(input_channel_root)

        if self.optimization_policy["remove_oc_epilog"]:
            # Remove epilog
            if not output_channel_root.is_integer():
                output_channel_root = math.ceil(output_channel_root)
                # Move total epilog to tiled_output_channel
                tiled_output_channel = output_channel / (output_channel_root * hw_output_channel * hw_accu_output_channel)
            # Remove tiled_output_channel epilog
            if isinstance(tiled_output_channel, int) or not tiled_output_channel.is_integer():
                tiled_output_channel = math.floor(tiled_output_channel)
                output_channel_root = output_channel / (tiled_output_channel * hw_output_channel * hw_accu_output_channel)
        else:
            output_channel_root = math.ceil(output_channel_root)

        if input_channel_root == 1:
            # Split tiled_output_channel to tiled_output_channel and m
            # Exchange tiled_output_channel and m. Tradeoffs: more weight reuse, or more grb pingpong.
            m = tiled_output_channel
            m_max = 8
            tiled_output_channel = 1
            while m >= 2:
                if m > m_max:
                    m /= 2
                    tiled_output_channel *= 2
                else:
                    break
        else:
            m = tiled_output_channel
            tiled_output_channel = 1


        tiled_output_channel = utils.to_int(tiled_output_channel)
        tiled_input_channel = utils.to_int(tiled_input_channel)
        m = utils.to_int(m)

        if const_defs.ENABLE_ROW_ACCUMULATION:
            hburst = True
            tlr_h_step = 2  # 8 tlr for 64c16h8w
        else:
            hburst = False
            tlr_h_step = 1

        ldconv0_oc_root_dict = {"start": 0}
        ldconv0_ic_root_dict = {"start": 0}
        ldconv0_oc_dict = {"start": 0}
        ldconv0_ic_dict = {"start": 0}

        ldconv1_oc_root_dict = {"start": 0}
        ldconv1_ic_root_dict = {"start": 0}
        ldconv1_toc_dict = {"start": 0}
        ldconv1_n_dict = {"start": 0}
        ldconv1_h_dict = {"start": 0}
        ldconv1_w_dict = {"start": 0}
        ldconv1_ic_dict = {"start": 0}

        conv_oc_root_dict = {"start": 0}
        conv_ic_root_dict = {"start": 0}
        conv_toc_dict = {"start": 0}
        conv_n_dict = {"start": 0}
        conv_h_dict = {"start": 0}
        conv_w_dict = {"start": 0}
        conv_oc_dict = {"start": 0}
        conv_ic_dict = {"start": 0}

        vector_oc_root_dict = {"start": 0}
        vector_ic_root_dict = {"start": 0}
        vector_toc_dict = {"start": 0}
        vector_n_dict = {"start": 0}
        vector_h_dict = {"start": 0}
        vector_w_dict = {"start": 0}
        vector_oc_dict = {"start": 0}


        ld_bufa_ch = channel(
            name="ld_bufa_ch",
            scope="gib",
            sync_ty="gsc",
            sz=2,
            token_sz=256,
            forward_start=32,
            backward_start=48,
        )

        ld_bufb_ch = channel(
            name="ld_bufb_ch",
            scope="gib",
            sync_ty="gsc",
            sz=16,
            token_sz=32,
            forward_start=0,
            backward_start=16,
        )

        tlr_ch = channel(
            name="tlr_ch",
            scope="tlr",
            sync_ty="bar.wtg",
            sz=2,
            token_sz=64,
            forward_start=6,
            backward_start=8,
        )

        grb_ch = channel(
            name="grb_ch",
            scope="grb_ch",
            sync_ty="bar.wtg",
            sz=2,
            token_sz=8,
            forward_start=2,
            backward_start=4,
        )

        kernel_type = set()
        vmc_mode = "spc"
        kernel_type.add(vmc_mode)
        if input_channel_root > 1:
            kernel_type.add("ic_partition")

        # BufferA Channel
        ld_bufa_ch_counts = output_channel_root
        if (hw_accu_output_channel * hw_output_channel * m * tiled_output_channel) * \
            (hw_input_channel * tiled_input_channel) * (kernel_width * kernel_width) * \
            self._get_dem_size(input_dt) <= ( hardware.bufb_sz // 2 ):
            # Pingpong
            ld_bufa_ch.set_prolog_state(True)
            ldconv0_oc_root_dict.update(
                ld_bufa_ch.get_loop_config_dict("producer", ld_bufa_ch_counts)
            )
            conv_oc_root_dict.update(
                ld_bufa_ch.get_loop_config_dict("consumer", ld_bufa_ch_counts)
            )

            ld_bufa_ch.forward_to_epilog_state(1, ld_bufa_ch_counts)
        else:
            # single buffer
            ld_bufa_ch.set_prolog_state(False)
            ldconv0_oc_root_dict.update(
                ld_bufa_ch.get_loop_config_dict("producer", 1)
            )
            conv_oc_root_dict.update(
                ld_bufa_ch.get_loop_config_dict("consumer", 1)
            )
            ld_bufa_ch.forward_to_epilog_state(1, ld_bufa_ch_counts)

        # BufferB Channel
        if kernel_width > 1:
            # TODO: Incorrect. Policy unclear. 
            # First iteration of W
            ld_bufb_outer_counts = (
                output_channel_root * input_channel_root * tiled_output_channel * input_number * math.ceil(input_height * N_H / hw_input_height)
            )
            ld_bufb_inner_counts = (
                output_channel_root
                * input_channel_root
                * tiled_output_channel
                * input_number
                * math.ceil(input_height * N_H / hw_input_height)
                * math.ceil(input_channel / 128)
            )
            ld_bufb_ch.set_prolog_state(True)
            ld_bufb_ch.forward_to_epilog_state(
                ld_bufb_outer_counts, ld_bufb_inner_counts
            )
        else:
            # TODO: Incorrect. Policy unclear. 
            # kernel_width==1
            ld_bufb_counts = (
                output_channel_root
                * input_channel_root
                * tiled_output_channel
                * input_number
                * math.ceil(input_width * N_W / hw_input_width)
                * math.ceil(input_height * N_H / hw_input_height)
                * math.ceil(input_channel / 128)
            )
            ld_bufb_ch.set_prolog_state(False)
            ld_bufb_ch.forward_to_epilog_state(1, ld_bufb_counts)

        if input_channel_root == 1 and self.reduce: # BRForwardConv2BatchNorm
            # GRB pingpong
            grb_ch.set_prolog_state(True)

            grb_ch_counts = tiled_output_channel * output_channel_root
            conv_toc_dict.update(
                grb_ch.get_loop_config_dict("producer", grb_ch_counts)
            )
            vector_toc_dict.update(
                grb_ch.get_loop_config_dict("consumer", grb_ch_counts)
            )
            conv_toc_dict["grb_pingpong"] = grb_ch.get_token_addr(
                grb_ch_counts
            )
            vector_toc_dict["grb_pingpong"] = grb_ch.get_token_addr(
                grb_ch_counts
            )
            grb_ch.forward_to_epilog_state(1, grb_ch_counts)

        # TLR Pingpong Channel
        if stride_width > 1 or input_channel_root > 1:
            kernel_type.add("tlr_pingpong")
            if (stride_width > 1 and input_channel_root > 1) or (stride_width > 1):
                ic_root_body = input_channel_root
                # Output of prolog input_channel_root is written to GMB, instead of TLR.
            else:
                # input_channel_root >1:
                ic_root_body = input_channel_root - 1
            if kernel_width > 1 and not hburst:
                tlr_ch_counts = (
                    output_channel_root
                    * ic_root_body
                    * tiled_output_channel
                    * input_number
                    * math.ceil(input_height * N_H // stride_height / hw_input_height)
                )
                tlr_ch.set_prolog_state(True)
                conv_h_dict.update(
                    tlr_ch.get_loop_config_dict("producer", tlr_ch_counts)
                )
                vector_h_dict.update(
                    tlr_ch.get_loop_config_dict("consumer", tlr_ch_counts)
                )
                conv_h_dict["tlr_pingpong"] = tlr_ch.get_token_addr(
                    tlr_ch_counts
                )
                vector_h_dict["tlr_pingpong"] = tlr_ch.get_token_addr(
                    tlr_ch_counts
                )
                tlr_ch.forward_to_epilog_state(1, tlr_ch_counts)
            else:
                # kernel_width==1
                tlr_ch_counts = (
                    output_channel_root
                    * ic_root_body
                    * tiled_output_channel
                    * input_number
                    * math.ceil(input_width * N_W // stride_width / hw_input_width)
                )
                tlr_ch.set_prolog_state(True)
                conv_w_dict.update(
                    tlr_ch.get_loop_config_dict("producer", tlr_ch_counts)
                )
                vector_w_dict.update(
                    tlr_ch.get_loop_config_dict("consumer", tlr_ch_counts)
                )
                conv_w_dict["tlr_pingpong"] = tlr_ch.get_token_addr(
                    tlr_ch_counts
                )
                vector_w_dict["tlr_pingpong"] = tlr_ch.get_token_addr(
                    tlr_ch_counts
                )
                tlr_ch.forward_to_epilog_state(1, tlr_ch_counts)

        loop_config_ldconv0 = [
            [
                const_defs.OC_ROOT_LOOP_NAME,
                output_channel_root,
                1,
                hw_output_channel * hw_accu_output_channel * m * tiled_output_channel,
                ldconv0_oc_root_dict,
            ],
            [const_defs.IC_ROOT_LOOP_NAME, input_channel_root, 1, tiled_input_channel * hw_input_channel, ldconv0_ic_root_dict],
            ["oc", tiled_output_channel * m, 1, hw_output_channel * hw_accu_output_channel, ldconv0_oc_dict],
            ["ich", 1, 1, tiled_input_channel * hw_input_channel, ldconv0_ic_dict],
        ]

        if kernel_width > 1 and not hburst:
            loop_config_ldconv1 = [
                [
                    const_defs.OC_ROOT_LOOP_NAME,
                    output_channel_root,
                    1,
                    hw_output_channel * hw_accu_output_channel * m * tiled_output_channel,
                    ldconv1_oc_root_dict,
                ],
                [
                    const_defs.IC_ROOT_LOOP_NAME,
                    input_channel_root,
                    1,
                    tiled_input_channel * hw_input_channel,
                    ldconv1_ic_root_dict,
                ],
                ["oc", tiled_output_channel, 1, hw_output_channel * hw_accu_output_channel * m, ldconv1_toc_dict],
                ["sample", input_number, 1, 1, ldconv1_n_dict],
                [
                    "row",
                    math.ceil(input_height * N_H / (hw_input_height * 2)),
                    1,
                    hw_input_height * 2,
                    ldconv1_h_dict,
                ],
                ["col", math.ceil(input_width * N_W / hw_input_width), 1, hw_input_width, ldconv1_w_dict],
                ["ich", 1, 1, tiled_input_channel * hw_input_channel, ldconv1_ic_dict],
            ]
        else:
            loop_config_ldconv1 = [
                [
                    const_defs.OC_ROOT_LOOP_NAME,
                    output_channel_root,
                    1,
                    hw_output_channel * hw_accu_output_channel * m * tiled_output_channel,
                    ldconv1_oc_root_dict,
                ],
                [
                    const_defs.IC_ROOT_LOOP_NAME,
                    input_channel_root,
                    1,
                    tiled_input_channel * hw_input_channel,
                    ldconv1_ic_root_dict,
                ],
                ["oc", tiled_output_channel, 1, hw_output_channel * hw_accu_output_channel * m, ldconv1_toc_dict],
                ["sample", input_number, 1, 1, ldconv1_n_dict],
                ["col", math.ceil(input_width * N_W / hw_input_width), 1, hw_input_width, ldconv1_w_dict],
                [
                    "row",
                    math.ceil(input_height * N_H / (hardware.tcore_h)),
                    1,
                    hardware.tcore_h,
                    ldconv1_h_dict,
                ],
                ["ich", 1, 1, tiled_input_channel * hw_input_channel, ldconv1_ic_dict],
            ]

        if kernel_width > 1 and not hburst:
            if input_channel_root == 1:
                # not ic partition
                loop_config_conv = [
                    [
                        const_defs.OC_ROOT_LOOP_NAME,
                        output_channel_root,
                        1,
                        hw_output_channel * hw_accu_output_channel * tiled_output_channel * m,
                        conv_oc_root_dict,
                    ],
                    ["oc", tiled_output_channel, 1, hw_output_channel * hw_accu_output_channel * m, conv_toc_dict],
                    ["sample", input_number, 1, 1, conv_n_dict],
                    [
                        "row",
                        math.ceil(input_height * N_H / (hw_input_height * 2)),
                        1,
                        hw_input_height * 2,
                        conv_h_dict,
                    ],
                    ["col", math.ceil(input_width * N_W / hw_input_width), 1, hw_input_width, conv_w_dict],
                    ["inner_oc", m, 1, hw_output_channel * hw_accu_output_channel, conv_oc_dict],  # 8*32
                    ["ich", 1, 1, tiled_input_channel * hw_input_channel, conv_ic_dict],
                ]
            else:
                # ic partition
                loop_config_conv = [
                    [
                        const_defs.OC_ROOT_LOOP_NAME, # oc
                        output_channel_root,
                        1,
                        tiled_output_channel * hw_output_channel * hw_accu_output_channel * m,
                        conv_oc_root_dict,
                    ],
                    [
                        const_defs.IC_ROOT_LOOP_NAME, # ich_root
                        input_channel_root,
                        1,
                        tiled_input_channel * hw_input_channel,
                        conv_ic_root_dict,
                    ],
                    ["sample", input_number, 1, 1, conv_n_dict],
                    [
                        "row",
                        math.ceil(input_height * N_H / (hw_input_height * 2)),
                        1,
                        hw_input_height * 2,
                        conv_h_dict,
                    ],
                    ["col", math.ceil(input_width * N_W / hw_input_width), 1, hw_input_width, conv_w_dict],
                    [
                        "inner_oc",
                        m * tiled_output_channel,
                        1,
                        hw_output_channel * hw_accu_output_channel,
                        conv_oc_dict,
                    ],  # 8*32
                    ["ich", 1, 1, tiled_input_channel * hw_input_channel, conv_ic_dict],
                ]
        else:
            # conv
            if input_channel_root == 1:
                loop_config_conv = [
                    [
                        const_defs.OC_ROOT_LOOP_NAME,
                        output_channel_root,
                        1,
                        hw_output_channel * hw_accu_output_channel * tiled_output_channel * m,
                        conv_oc_root_dict,
                    ],
                    ["oc", tiled_output_channel, 1, hw_accu_output_channel * hw_output_channel * m, conv_toc_dict],
                    ["sample", input_number, 1, 1, conv_n_dict],
                    [
                        "col",
                        math.ceil(input_width * N_W / (hardware.tcore_w)),
                        1,
                        hardware.tcore_w,
                        conv_w_dict,
                    ],
                    [
                        "row",
                        math.ceil(input_height * N_H / (hardware.tcore_h)),
                        1,
                        hardware.tcore_h,
                        conv_h_dict,
                    ],
                    ["inner_oc", m, 1, hw_output_channel * hw_accu_output_channel, conv_oc_dict],  # 8*32
                    ["ich", 1, 1, tiled_input_channel * hw_input_channel, conv_ic_dict],
                ]
            else:
                # ic partition
                loop_config_conv = [
                    [
                        const_defs.OC_ROOT_LOOP_NAME,
                        output_channel_root,
                        1,
                        tiled_output_channel * hw_output_channel * hw_accu_output_channel * m,
                        conv_oc_root_dict,
                    ],
                    [
                        const_defs.IC_ROOT_LOOP_NAME,
                        input_channel_root,
                        1,
                        tiled_input_channel * hw_input_channel,
                        conv_ic_root_dict,
                    ],
                    ["sample", input_number, 1, 1, conv_n_dict],
                    ["col", math.ceil(input_width * N_W / hw_input_width), 1, hw_input_width, conv_w_dict],
                    [
                        "row",
                        math.ceil(input_height * N_H / (hw_input_height * 2)),
                        1,
                        hw_input_height * 2,
                        conv_h_dict,
                    ],
                    [
                        "inner_oc",
                        m * tiled_output_channel,
                        1,
                        hw_output_channel * hw_accu_output_channel,
                        conv_oc_dict,
                    ],  # 8*32
                    ["ich", 1, 1, tiled_input_channel * hw_input_channel, conv_ic_dict],
                ]

        if stride_width > 1 and input_channel_root > 1:
            # strides ==2 and input_channel partition
            if kernel_width > 1 and not hburst:
                # stm and reduce
                loop_config_vector_reduce = [
                    [
                        const_defs.OC_ROOT_VECTOR_LOOP_NAME,
                        output_channel_root,
                        1,
                        tiled_output_channel * hw_output_channel * hw_accu_output_channel * m,
                        vector_oc_root_dict,
                    ],
                    [
                        const_defs.IC_ROOT_VECTOR_LOOP_NAME,
                        input_channel_root - 1,
                        1,
                        tiled_input_channel * hw_input_channel,
                        vector_ic_root_dict,
                    ],
                    ["sample", input_number, 1, 1, vector_n_dict],
                    [
                        "row",
                        math.ceil(input_height * N_H / 8),
                        1,
                        4,
                        vector_h_dict,
                    ],  # Use 1 TLR
                    [
                        "col",
                        math.ceil(input_width * N_W / (8 * stride_width)),
                        1,
                        8,
                        vector_w_dict,
                    ],
                    ["inner_oc", tiled_output_channel * m, 1, hw_output_channel * hw_accu_output_channel, vector_oc_dict],
                ]
            else:
                # kernel_width==1 or hburst
                # stm and reduce
                loop_config_vector_reduce = [
                    [
                        const_defs.OC_ROOT_VECTOR_LOOP_NAME,
                        output_channel_root,
                        1,
                        tiled_output_channel * hw_output_channel * hw_accu_output_channel * m,
                        vector_oc_root_dict,
                    ],
                    [
                        const_defs.IC_ROOT_VECTOR_LOOP_NAME,
                        input_channel_root - 1,
                        1,
                        tiled_input_channel * hw_input_channel,
                        vector_ic_root_dict,
                    ],
                    ["sample", input_number, 1, 1, vector_n_dict],
                    [
                        "col",
                        math.ceil(input_width * N_W / (8 * stride_width)),
                        1,
                        8,
                        vector_w_dict,
                    ],
                    ["row", math.ceil(input_height * N_H / (8*stride_height*tlr_h_step)), 1, 8*tlr_h_step, vector_h_dict],
                    ["inner_oc", tiled_output_channel * m, 1, hw_output_channel * hw_accu_output_channel, vector_oc_dict],
                ]
        elif stride_width > 1:
            # strides ==2
            if kernel_width > 1 and not hburst:
                # stm and reduce
                loop_config_vector_reduce = [
                    [
                        const_defs.OC_ROOT_VECTOR_LOOP_NAME,
                        output_channel_root,
                        1,
                        tiled_output_channel * hw_output_channel * hw_accu_output_channel * m,
                        vector_oc_root_dict,
                    ],
                    [
                        const_defs.TOC_VECTOR_LOOP_NAME,
                        tiled_output_channel,
                        1,
                        hw_output_channel * hw_accu_output_channel * m,
                        vector_toc_dict,
                    ],
                    ["sample", input_number, 1, 1, vector_n_dict],
                    [
                        "row",
                        math.ceil(input_height * N_H / 8),
                        1,
                        4,
                        vector_h_dict,
                    ],  # Use 1 TLR
                    [
                        "col",
                        math.ceil(input_width * N_W / (8 * stride_width)),
                        1,
                        8,
                        vector_w_dict,
                    ],
                    ["inner_oc", m, 1, hw_output_channel * hw_accu_output_channel, vector_oc_dict],
                ]
            else:
                # kernel_width==1 or hburst
                # stm and reduce
                loop_config_vector_reduce = [
                    [
                        const_defs.OC_ROOT_VECTOR_LOOP_NAME,
                        output_channel_root,
                        1,
                        tiled_output_channel * hw_output_channel * hw_accu_output_channel * m,
                        vector_oc_root_dict,
                    ],
                    [
                        const_defs.TOC_VECTOR_LOOP_NAME,
                        tiled_output_channel,
                        1,
                        hw_output_channel * hw_accu_output_channel * m,
                        vector_toc_dict,
                    ],
                    ["sample", input_number, 1, 1, vector_n_dict],
                    [
                        "col",
                        math.ceil(input_width * N_W / (8 * stride_width)),
                        1,
                        8,
                        vector_w_dict,
                    ],
                    ["row", math.ceil(input_height * N_H / (8*stride_height*tlr_h_step)), 1, 8*tlr_h_step, vector_h_dict],
                    ["inner_oc", m, 1, hw_output_channel * hw_accu_output_channel, vector_oc_dict],
                ]
        elif input_channel_root > 1:
            # input_channel partition
            if kernel_width > 1 and not hburst:
                loop_config_vector_reduce = [
                    [
                        const_defs.OC_ROOT_VECTOR_LOOP_NAME,
                        output_channel_root,
                        1,
                        tiled_output_channel * hw_output_channel * hw_accu_output_channel * m,
                        vector_oc_root_dict,
                    ],
                    [
                        const_defs.IC_ROOT_VECTOR_LOOP_NAME,
                        input_channel_root - 1,
                        1,
                        tiled_input_channel * hw_input_channel,
                        vector_ic_root_dict,
                    ],
                    ["sample", input_number, 1, 1, vector_n_dict],
                    [
                        "row",
                        math.ceil((N_H * output_height) / (hw_input_height * 2)),
                        1,
                        hw_input_height * 2,
                        vector_h_dict,
                    ],
                    [
                        "col",
                        math.ceil((N_W * output_width) / hw_input_width),
                        1,
                        hw_input_width,
                        vector_w_dict,
                    ],
                    ["inner_oc", tiled_output_channel * m, 1, hw_output_channel * hw_accu_output_channel, vector_oc_dict],
                ]
            else:
                # kernel_width==1
                loop_config_vector_reduce = [
                    [
                        const_defs.OC_ROOT_VECTOR_LOOP_NAME,
                        output_channel_root,
                        1,
                        tiled_output_channel * hw_output_channel * hw_accu_output_channel * m,
                        vector_oc_root_dict,
                    ],
                    [
                        const_defs.IC_ROOT_VECTOR_LOOP_NAME,
                        input_channel_root - 1,
                        1,
                        tiled_input_channel * hw_input_channel,
                        vector_ic_root_dict,
                    ],
                    ["sample", input_number, 1, 1, vector_n_dict],
                    [
                        "col",
                        math.ceil((N_W * output_width) / hw_input_width),
                        1,
                        hw_input_width,
                        vector_w_dict,
                    ],
                    [
                        "row",
                        math.ceil((N_H * output_height) / (hw_input_height * 2 * tlr_h_step)),
                        1,
                        hw_input_height * 2 * tlr_h_step,
                        vector_h_dict,
                    ],
                    ["inner_oc", tiled_output_channel * m, 1, hw_output_channel * hw_accu_output_channel, vector_oc_dict],
                ]
        else:
            loop_config_vector_reduce = [
                [
                    const_defs.OC_ROOT_VECTOR_LOOP_NAME,
                    output_channel_root,
                    1,
                    tiled_output_channel * hw_output_channel * hw_accu_output_channel * m,
                    vector_oc_root_dict,
                ],
                [
                    const_defs.TOC_VECTOR_LOOP_NAME,
                    tiled_output_channel,
                    1,
                    hw_output_channel * hw_accu_output_channel * m,
                    vector_toc_dict,
                ],
                ["inner_oc", m, 1, hw_output_channel * hw_accu_output_channel, vector_oc_dict],
            ]

        #########################################################################################
        # Unroll ic and oc loops. IC loops are automatically unrolled.
        if self.optimization_policy['unroll_policy']=='legacy':
            for loop_config in [
                    loop_config_ldconv0,
                    loop_config_conv]: 
                for loop_level in loop_config[-2::]:
                    loop_var = loop_level[0]
                    loop_iter = loop_level[1]
                    loop_step = loop_level[3]

                    if loop_var != const_defs.INNER_IC_LOOP_NAME:
                        loop_level[2] = loop_iter

        # Unroll innermost 2 loops
        elif self.optimization_policy['unroll_policy'] == 'unroll2':
            for loop_config in [
                    loop_config_ldconv0,
                    loop_config_ldconv1,  
                    loop_config_conv]: 
                for loop_level in loop_config[-2::]:
                    loop_var = loop_level[0]
                    loop_iter = loop_level[1]
                    loop_step = loop_level[3]
        
                    if loop_var != const_defs.INNER_IC_LOOP_NAME:
                        loop_level[2] = loop_iter

        elif self.optimization_policy['unroll_policy'] == 'all':            
            for loop_config in [loop_config_ldconv0,
                    loop_config_ldconv1,  
                    loop_config_conv, 
                    loop_config_vector_reduce]:
                for loop_level in loop_config:
                    loop_var = loop_level[0]
                    if loop_var != const_defs.INNER_IC_LOOP_NAME:
                        loop_level[2] = loop_iter

        elif self.optimization_policy['unroll_policy'] == 'threshold' or \
                self.optimization_policy['unroll_policy'] == 'target_count':
            loop_config_index = 0
            for loop_config in [loop_config_ldconv0,
                    loop_config_ldconv1,  
                    loop_config_conv, 
                    loop_config_vector_reduce]:
                threshold = self.optimization_policy['unroll_target_instruction_count'][loop_config_index]
                loop_config_index +=1
                counts = 1
                for loop_level in loop_config[::-1]:
                    loop_var = loop_level[0]
                    loop_iter = loop_level[1]
                    loop_step = loop_level[3]
                    if loop_var == const_defs.INNER_IC_LOOP_NAME: 
                        counts = math.ceil(loop_step / 128)
                    counts *= loop_iter
                    if counts < threshold:
                        # Unroll
                        loop_level[2] = loop_iter
                    else:
                        # We have unrolled enough loop levels
                        break
        elif self.optimization_policy['unroll_policy'] == 'only_ic':
            # Unroll IC loop level and do not touch others
            pass
        else:
            assert False, 'Unrecognized unroll_policy.'
        
        # Finalize: Update to tuple
        loop_config_ldconv0 = [ tuple(i) for i in loop_config_ldconv0]
        loop_config_ldconv1 = [tuple(i) for i in loop_config_ldconv1]
        loop_config_conv = [tuple(i) for i in loop_config_conv]
        loop_config_vector_reduce= [tuple(i) for i in loop_config_vector_reduce]

        return [
            loop_config_ldconv0,
            loop_config_ldconv1,
            loop_config_conv,
            loop_config_vector_reduce,
            kernel_type,
            self.ishape
        ]

    @staticmethod
    def _get_dem_size(dem_type):
        # Consider to move to something relates to data model, and then can be shared by others
        if dem_type == 's8' or dem_type == 'u8' or dem_type == 's4' or \
            dem_type == 'f8_2' or dem_type == 'f8_3':
            dem_size = 1
        elif dem_type == "bf16" or dem_type == "fp16":
            dem_size = 2
        elif dem_type == 'fp32':
            dem_size = 4
        else:
            assert 0, "unsupported dem type"
        return dem_size

class br_loop_config_bpw(br_loop_config_generator):
    def __init__(
        self, 
        ishape, 
        wshape, 
        dt=["bf16", "bf16", "bf16"], 
        stride=[0, 0], 
        dilation=[1, 1], 
        padding=[0, 0], 
        vmc_mode="auto", 
        reduce=False):
        super().__init__(
            ishape=ishape, wshape=wshape, dt=dt, stride=stride,
            dilation=dilation, padding=padding, vmc_mode=vmc_mode, 
            reduce=reduce)

class br_loop_config_bpa(br_loop_config_generator):
    def __init__(
        self, 
        ishape, 
        wshape, 
        dt=["bf16", "bf16", "bf16"], 
        stride=[0, 0], 
        dilation=[1, 1], 
        padding=[0, 0], 
        vmc_mode="auto", 
        reduce=False):
        super().__init__(
            ishape=ishape, wshape=wshape, dt=dt, stride=stride,
            dilation=dilation, padding=padding, vmc_mode=vmc_mode, 
            reduce=reduce)



if __name__ == "__main__":
    lc = br_loop_config_conv2d_forward(            
        ishape=(16, 1024, 14, 14),
        wshape=(256, 1024, 1, 1),
        dt=["bf16", "bf16", "bf16"],
        stride=[0, 0],
        dilation=[0, 0],
        padding=[0, 0],
        vmc_mode="spc")
    import pprint

    pp = pprint.PrettyPrinter(indent=4)
    pp.pprint(
        lc.generate_config()
    )
