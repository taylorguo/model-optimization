#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
from code_generator.share.br_singleton_base import singleton
import code_generator.share.br_const_defs as icd
import code_generator.share.br_utils as utils

# keep one for dummy dry run for each warp
WSR_CLIENT_NUM = 2 * icd.MAX_CWARP_NUM


def wsr_alloc(alias=None, warp_man=None):
    re_man = resource_man.get_instance(warp_man)
    return re_man.alloc_wsr(alias)


def wsr_free(q):
    re_man = resource_man.get_instance()
    return re_man.free_wsr(q)


def get_req_wsr():
    re_man = resource_man.get_instance()
    return re_man.get_req_wsr()


def set_req_wsr(max_used):
    re_man = resource_man.get_instance()
    re_man.set_peek_wsr(max_used)


def get_avail_wsr():
    re_man = resource_man.get_instance()
    re_man.get_avail_wsr()


def tlr_alloc(alias=None, number=1):
    re_man = resource_man.get_instance()
    return re_man.alloc_tlr(alias, number)


def tlr_free(t):
    re_man = resource_man.get_instance()
    return re_man.free_tlr(t)


def get_req_tlr():
    re_man = resource_man.get_instance()
    return re_man.get_req_tlr()


def set_req_tlr(max_used):
    re_man = resource_man.get_instance()
    re_man.set_peek_tlr(max_used)


def reset_for_dry_mode():
    re_man = resource_man.get_instance()
    re_man.reset_peek_state()


def alloc_addr_reg(type):
    re_man = resource_man.get_instance()
    return re_man.alloc_addr(type)


def csr_alloc(values=[], alias=None, warp_man=None):
    re_man = resource_man.get_instance(warp_man)
    return re_man.alloc_csr(values, alias)


def get_csr_table(warp_man=None):
    re_man = resource_man.get_instance(warp_man)
    return re_man.csrs


def allocate_immediate_variable(alias, value=0):
    re_man = resource_man.get_instance()
    return re_man.allocate_immediate_variable(alias, 0)


def assign_immediate_variable(name, value):
    re_man = resource_man.get_instance()
    re_man.assign_immediate_variable(name, value)


def get_immediate_variable_value(name):
    re_man = resource_man.get_instance()
    return re_man.get_immediate_variable_value(name)


class rsbase(object):

    def __init__(self, num, type="q"):
        self.rs_avail = [type+"{}".format(i) for i in range(1, num)]
        self.rs_in_use = []
        self.rs_peek_num = 0
        self.rs_local_max = 0
        self.rs_in_use_with_alias = []

    def alloc_addr(self, type, alias=None):
        target = ""
        if alias is not None and utils.get_code_sytle():
            target = str(alias) + "_"
        if type == "itlr":
            return str(target) + "a1"
        if type == "iclr":
            return str(target) + "a0"
        if type == "islr":
            return str(target) + "a2"

    def alloc(self, alias=None, transient=None):
        ele = None
        if len(self.rs_avail) != 0:
            ele = self.rs_avail[0]
            self.rs_in_use.append(ele)
            self.rs_avail.remove(ele)
            self.rs_local_max += 1
            self.rs_peek_num = max(self.rs_local_max, self.rs_peek_num)
        else:
            print("Error: WSR registers are used up!")
            print("self.rs_in_use is ", self.rs_in_use)
            return "usedup"

        if (alias is not None) and utils.get_code_sytle():
            ele = str(alias) + "_" + ele
            self.rs_in_use_with_alias.append(ele)

        return ele

    def free(self, ele):
        if ele is not None:
            if ele in self.rs_in_use_with_alias:
                self.rs_in_use_with_alias.remove(ele)
                ele = ele.split("_")[-1]

            if ele in self.rs_in_use:
                self.rs_in_use.remove(ele)
                if ele not in self.rs_avail:
                    self.rs_avail.insert(0, ele)
                self.rs_local_max -= 1

    def get_peek_usage(self):
        return self.rs_peek_num

    def set_req_wsr(self, req_num):
        self.rs_peek_num = req_num

    def reset_peek_state(self):
        self.rs_local_max = 0
        self.rs_peek_num = 0

    def get_avail(self):
        return self.rs_avail


class vgpr(object):
    def __init__(self, capcity):
        super().__init__()
        self.avail_number = capcity
        self.capcity = capcity
        self.alloc_table = []
        self.usage_local_max = 0
        self.usage_peak_num = 0

    def get_available_number(self):
        return self.avail_number

    def reserve(self, start, length):
        assert self.avail_number >= length, "Not enough vgprs to reserve!"
        index = 0
        for alist in self.alloc_table:
            if not ((alist[0]+alist[1] <= start) or
                    (start + length) <= alist[0]):
                assert False, " reserve vgpr fail, address [" \
                    + str(start) + ", " + str(start + length) + ") not free"
                return -1

            if (alist[0] < start):
                index += 1

        self.alloc_table.insert(index, [start, length])
        self.avail_number -= length

        return start

    def allocate(self, number=1):
        assert self.avail_number >= number, "Not enough vgprs to allocate!"

        bestAddr = 0
        bestIndex = -1
        bestSpace = self.capcity + 1

        lastAddr = 0
        index = 0

        for alist in self.alloc_table:
            thisSpace = alist[0] - lastAddr
            if (thisSpace >= number and thisSpace < bestSpace):
                bestIndex = index
                bestSpace = thisSpace
                bestAddr = lastAddr

            lastAddr = alist[0] + alist[1]
            index += 1

        if lastAddr != self.capcity:
            thisSpace = self.capcity - lastAddr
            if (thisSpace >= number and thisSpace < bestSpace):
                bestIndex = index
                bestSpace = thisSpace
                bestAddr = lastAddr

        assert bestIndex >= 0, "no continous vgprs to allocate"

        self.alloc_table.insert(bestIndex, [bestAddr, number])
        self.avail_number -= number
        self.usage_local_max += number
        self.usage_peak_num += max(self.usage_peak_num, self.usage_local_max)
        return bestAddr

    def release(self, addr):
        index = 0
        found_index = -1
        for alist in self.alloc_table:
            if (alist[0] == addr):
                self.avail_number += alist[1]
                self.usage_local_max -= alist[1]
                found_index = index
                break
        assert found_index >= 0, "vgpr not found in allocation list"
        del self.alloc_table[found_index]

    def get_req_vgpr(self):
        return self.usage_peak_num

    def set_req_vgpr(self, req_num):
        self.usage_peak_num = req_num

    def reset_peek_state(self):
        self.usage_local_max = 0
        self.usage_peak_num = 0


class resource_man(singleton):
    __instance = None  # singlton class

    def __new__(cls, *args, **kwargs):
        if cls.__instance is None:
            cls.__instance = super(resource_man, cls).__new__(cls)
            cls.__instance.__initialized = False
        return cls.__instance

    def __init__(self, cwarp_manager=None):
        if(self.__initialized):
            return

        self.__initialized = True
        self.__init_resource()
        self.cwarp_top = cwarp_manager

    def __init_resource(self):
        self.wsr = []
        for i in range(WSR_CLIENT_NUM):
            self.wsr.append(rsbase(icd.WSR_NUM))
        self.tlr = vgpr(icd.TLR_NUM)  # rsbase(icd.TLR_NUM)
        self.addr = rsbase(3, "a")
        self.csr_used = 0
        self.csrs = []
        self.csr_names = []
        self.immediate_variables = {}

    def alloc_wsr(self, alias=None, transient=None):
        cwarp_id = self.cwarp_top.get_current_cwarp()
        #print("warp_id is in alloc_wsr", cwarp_id)
        if cwarp_id == -1:
            for i in range(icd.MAX_CWARP_NUM):
                wsr = self.wsr[i].alloc(alias, transient)
            return wsr
        else:
            wsr = self.wsr[cwarp_id].alloc(alias, transient)
            # if cwarp_id == 2:
            #     if wsr == "q19":
            #         print("cwarp_id is 2")
            if wsr == "Usedup":
                print("WSR of CWarp {} used up".format(cwarp_id))
            return wsr

    def alloc_wsr_more(self, num=1):
        # suppose the allocation is continuas
        # and the wsr is freed at end of cwarp
        # this is not a good practice and may
        # be enhanced later [TODO] 
        base_addr = None
        for idx in range(num):
            if base_addr is None:
                base_addr = self.alloc_wsr()
            else:
                self.alloc_wsr()
        return int(base_addr.split("q")[-1])
        
    def free_wsr(self, q):
        cwarp_id = self.cwarp_top.get_current_cwarp()
        #print("warp_id is in free_wsr", cwarp_id)
        if cwarp_id == -1:
            for i in range(icd.MAX_CWARP_NUM):
                self.wsr[i].free(q)
        else:
            self.wsr[cwarp_id].free(q)

    def free_wsr_more(self, base_index, num=1):
        for idx in range(num):
            self.free_wsr("q"+str(base_index+idx))

    def get_req_wsr(self):
        wsrs = [self.wsr[i].get_peek_usage() for i in range(WSR_CLIENT_NUM)]
        return wsrs

    def get_avail_wsr(self):
        cwarp_id = self.cwarp_top.get_current_cwarp()
        self.wsr[cwarp_id].get_avail()

    def set_peek_wsr(self, max_used):
        cwarp_id = self.cwarp_top.get_current_cwarp()
        self.wsr[cwarp_id].set_req_wsr(max_used)

    def alloc_tlr(self, alias=None, number=1):
        return self.tlr.allocate(number)

    def free_tlr(self, t):
        return self.tlr.release(t)

    def get_req_tlr(self):
        return self.tlr.get_req_vgpr()

    def set_peek_tlr(self, max_used):
        self.tlr.set_req_vgpr(max_used)

    def reset_peek_state(self):
        cwarp_id = self.cwarp_top.get_current_cwarp()
        self.wsr[cwarp_id].reset_peek_state()
        for i in range(icd.MAX_CWARP_NUM, 8):
            self.wsr[i] = rsbase(icd.WSR_NUM)
        self.tlr.reset_peek_state()

    def alloc_addr(self, type, alias=None):
        return self.addr.alloc_addr(type, alias)

    def alloc_csr(self, values=[], alias=None):
        size = len(values)
        if size == 0:
            print("Error：No values specified, default to 0!")
            size = 1
        if len(values) == 1:
            if values[0] in self.csrs:
                index = self.csrs.index(values[0])
                if (alias is not None) and utils.get_code_sytle():
                    return self.csr_names[index]
                else:
                    csr = "c{}".format(index)
                    return csr
        if self.csr_used + size >= icd.CSR_NUM_HALF:
            print("Warning: Used CSR has gone beyond"
                  " the half of the CSR size!")
        elif self.csr_used + size >= icd.CSR_NUM:
            print("Error: CSR has used up!")

        if (alias is not None) and utils.get_code_sytle():
            csr_return = None
            for i in range(0, len(values)):
                csr = str(alias) + "_c{}_{}".format(self.csr_used, i)
                if i == 0:
                    csr_return = csr
                self.csr_names.append(csr)
            csr = csr_return
        else:
            csr = "c{}".format(self.csr_used)

        self.csr_used += size
        for v in values:
            self.csrs.append(v)
        return csr

    def allocate_immediate_variable(self, alias, value):
        name = "imm_" + alias
        if name in self.immediate_variables.keys():
            assert "The immediate variable already existes!"
        self.immediate_variables[name] = value
        return name

    def assign_immediate_variable(self, name, value):
        if name not in self.immediate_variables.keys():
            assert "The immediate variable does not existe1!"
        self.immediate_variables[name] = value

    def get_immediate_variable_value(self, name):
        if name not in self.immediate_variables.keys():
            assert "The immediate variable does not existe1!"
        return self.immediate_variables[name]

    @staticmethod
    def get_instance(warp_man=None):
        return resource_man(warp_man)

