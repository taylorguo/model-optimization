import code_generator.kernel_gen.hardware
import code_generator.kernel_gen.infer_hw_shape_pass
import code_generator.kernel_gen.kernel_selector_pass
from code_generator.kernel_gen import workload
from code_generator.kernel_gen.inst import *


class br_loop_config:
    def get_loop_config_conv2d_forward(
        self,
        ishape,
        wshape,
        dt=["bf16", "bf16", "bf16"],
        stride=[0, 0],
        dilation=[1, 1],
        padding=[0, 0],
        vmc_mode="auto",
        optimization_policy = None,
        reduce=False,
    ):
        # input arguments
        #   vmc_mode = spc|vmc|auto
        # return value:
        #   kernel_ty: spc|vmc, ic_partition, tlr_pingpong
        #   top_config_tcore: pingpong_a, pingpong_b, red_mode
        #   hw_shape: hw_shape of input activation
        if isinstance(stride, int):
            stride = [stride + 1, stride + 1]
        else:
            stride = [stride[0] + 1, stride[1] + 1]
        if isinstance(dilation, int):
            dilation = [dilation + 1, dilation + 1]
        else:
            dilation = [dilation[0] + 1, dilation[1] + 1]
        if isinstance(padding, int):
            padding = [padding, padding]

        wl = workload.workload("loop_config_workload", ty="ut")
        s = wl.get_stream()
        if optimization_policy == None: 
            wl.set_optimization_policy(
                {
                    "unroll_policy": "only_ic",  # 'only_ic', 'target_count', 'legacy', 'unroll2', 'all'
                    "unroll_target_instruction_count": [
                        120,
                        120,
                        120,
                        0,
                        0,
                    ],  # ldconv0, ldconv1, conv, reduce, elemwise
                    "force_bufa_pingpong": False,
                    "force_grb_pingpong": False,
                    "remove_ic_epilog": False,
                    "remove_oc_epilog": False,
                }
            )
        else: 
            wl.set_optimization_policy(optimization_policy)
        top = s.append(
            alloca_inst(
                shape=ishape, scope="gmb", dtype=dt[0], uma_mode="numa", layout="4DA"
            )
        )
        weight = s.append(
            alloca_inst(
                shape=wshape, scope="hbm", layout="4DW", uma_mode="uma", dtype=dt[1]
            )
        )
        bn_bottom = s.append(alloca_inst(scope="hbm", layout="4DW", uma_mode="numa"))
        bn_cache = s.append(alloca_inst(scope="hbm", layout="linear", dtype="fp32"))
        bottom = s.append(alloca_inst(scope="gmb", dtype=dt[2], layout="4DA"))
        (N, IC, IH, IW) = ishape
        (OC, _, KH, KW) = wshape

        op = s.append(
            op_inst(
                ty="BRForwardConv2BatchNorm" if reduce else "BRForwardConv2",
                name="",
                in_tensor=[top],
                out_tensor=[bottom],
                tensor=[bn_bottom, weight, bn_cache],
                params={
                    "conv": {
                        "oc": int(OC),
                        "k": (KH, KW),
                        "strides": stride,
                        "padding": padding,
                        "dilations": dilation,
                    }
                },
            )
        )

        hw = code_generator.kernel_gen.hardware.hardware()
        pass_hw_shape = code_generator.kernel_gen.infer_hw_shape_pass.infer_hw_shape_pass(
            hw, wl
        )
        pass_hw_shape.run_on_stream()
        pass_ks = code_generator.kernel_gen.kernel_selector_pass.kernel_selector_pass(
            hw, wl
        )
        pass_ks.run_on_stream()
        return [
            op.loop_config_ldconv0,
            op.loop_config_ldconv1,
            op.loop_config_conv,
            op.loop_config_vector_reduce,
            op.kernel_ty,
            top.hw_shape,
        ]

    def get_loop_config_bpw():
        pass

    def get_loop_config_bpa(
        self,
        ishape,
        wshape,
        dt=["bf16", "bf16", "bf16"],
        stride=[0, 0],
        dilation=[1, 1],
        padding=[0, 0],
        vmc_mode="auto",
        reduce=False,
    ):
        return
        if isinstance(stride, int):
            stride = [stride + 1, stride + 1]
        else:
            stride = [stride[0] + 1, stride[1] + 1]
        if isinstance(dilation, int):
            dilation = [dilation + 1, dilation + 1]
        else:
            dilation = [dilation[0] + 1, dilation[1] + 1]
        if isinstance(padding, int):
            padding = [padding, padding]

        wl = workload.workload("ut_workload", ty="ut")
        s = wl.get_stream()
        wl.set_optimization_policy(
            {
                "unroll_policy": "legacy",  # 'target_count', 'legacy', 'unroll2', 'all'
                "unroll_target_instruction_count": [
                    120,
                    120,
                    120,
                    0,
                    0,
                ],  # ldconv0, ldconv1, conv, reduce, elemwise
                "force_bufa_pingpong": False,
                "force_grb_pingpong": False,
                "remove_ic_epilog": False,
                "remove_oc_epilog": False,
            }
        )
        top = s.append(
            alloca_inst(
                shape=ishape, scope="gmb", dtype=dt[0], uma_mode="numa", layout="4DA"
            )
        )
        weight = s.append(
            alloca_inst(
                shape=wshape, scope="hbm", layout="4DW", uma_mode="uma", dtype=dt[1]
            )
        )
        bn_bottom = s.append(alloca_inst(scope="hbm", layout="4DW", uma_mode="numa"))
        bn_cache = s.append(alloca_inst(scope="hbm", layout="linear", dtype="fp32"))
        bottom = s.append(alloca_inst(scope="gmb", dtype=dt[2], layout="4DA"))
        (N, IC, IH, IW) = ishape
        (OC, _, KH, KW) = wshape

        op = s.append(
            op_inst(
                ty="BRForwardConv2BatchNorm" if reduce else "BRForwardConv2",
                name="",
                in_tensor=[top],
                out_tensor=[bottom],
                tensor=[bn_bottom, weight, bn_cache],
                params={
                    "conv": {
                        "oc": int(OC),
                        "k": (KH, KW),
                        "strides": stride,
                        "padding": padding,
                        "dilations": dilation,
                    }
                },
            )
        )

        hw = code_generator.kernel_gen.hardware.hardware()
        pass_hw_shape = code_generator.kernel_gen.infer_hw_shape_pass.infer_hw_shape_pass(
            hw, wl
        )
        pass_hw_shape.run_on_stream()
        pass_ks_bpa = (
            code_generator.kernel_gen.kernel_selector_pass.kernel_selector_bpa_pass(
                hw, wl
            )
        )
        pass_ks_bpa.run_on_kernel(op)
        return [
            op.loop_config_bpa_ldconv0,
            op.loop_config_bpa_ldconv1,
            op.loop_config_bpa_conv,
            op.loop_config_bpa_vector_reduce,
            op.kernel_ty,
            top.hw_shape,
        ]
        pass


if __name__ == "__main__":
    LC = br_loop_config()
    import pprint

    pp = pprint.PrettyPrinter(indent=4)
    pp.pprint(
        LC.get_loop_config_conv2d_forward(
            ishape=(16, 1024, 14, 14),
            wshape=(256, 1024, 1, 1),
            dt=["bf16", "bf16", "bf16"],
            stride=[0, 0],
            dilation=[0, 0],
            padding=[0, 0],
            vmc_mode="spc",
        )
    )
