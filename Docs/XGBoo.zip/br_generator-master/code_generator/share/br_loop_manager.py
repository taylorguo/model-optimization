#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.


from code_generator.share.br_defined_print import br_print
# import code_generator.share.br_utils as br_utils


def reset_label_space():
    global label_avail
    label_avail = [i for i in range(10000)]

def split_loops(loopconfig):
    loops = [[], []]

    t1 = tuple()
    t2 = tuple()
    split = False
    for loop in loopconfig:
        if loop[0] == "ich_split":
            t1 = (loop[0], 1, 1)
            t2 = (loop[0], loop[1] - 1, loop[2])
            if len(loop) > 3:
                t1 += loop[3:]
                t2 += loop[3:]
            loops[0].append(t1)
            loops[1].append(t2)
            split = True
        else:
            loops[0].append(loop)
            loops[1].append(loop)
    return loops, split

def loop_code_generate(
        indent, comment=None, instr=None, operator=None, loop_config=None,
        prefix=None, loop_man=None):

    #loops, split = split_loops(loop_config)
    loop = loop_man(
            indent, comment=comment, instr=instr,
            operator=operator, loop_configs=loop_config)

        # print("prfex is ", prefix)
        # print("// Info: Loop Configuration is ", loop_config)
        # if br_utils.get_code_sytle():
    br_print(" ", comment_header=loop.get_loop_desc())

    loop.generate_loops(prefix=prefix, comment=comment)
        # return loop
