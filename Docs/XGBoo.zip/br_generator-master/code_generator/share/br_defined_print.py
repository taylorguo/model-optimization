#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
from command_generator import io_handler as ioh
from code_generator.share.br_singleton_base import singleton
import code_generator.share.br_utils as utils
import os

import traceback
import sys
#from code_generator.backend.wrap_decorator import wrap_decorator


'''
def _insert_pass_(func):
    def __impl__(*args, **kwargs):
        return func(*args, **kwargs)

    return __impl__

insert_pass = wrap_decorator(_insert_pass_)
'''

BR_PRINT_LEVEL_CWARP_BODY = -1  # default cwarp body
BR_PRINT_LEVEL_TOP_HEADER = 0  # top headers
BR_PRINT_LEVEL_TOP_SHARE = 1  # before switch
BR_PRINT_LEVEL_TOP_SWITCH = 2  # first switch closure
BR_PRINT_LEVEL_CWARP_START = 3  # start cwarp
BR_PRINT_LEVEL_COMMENT_ONLY = 4  # comment only lines
BR_PRINT_LEVEL_SUBFUNC_DECLARE = 5 # declare of subfunction
BR_PRINT_LEVEL_SUBFUNC_START = 6  # start subfunc in cwarp
BR_PRINT_LEVEL_SUBFUNC_END = 7  # end subfunc in cwarp
BR_PRINT_LEVEL_MACRO_START = 8  # start macro in cwarp
BR_PRINT_LEVEL_MACRO_END = 9  # end macro in cwarp

file_path = None
dry_run = False

def set_dry_run(flag):
    global dry_run
    dry_run = flag


def get_dry_run():
    global dry_run
    return dry_run


def set_print_subfunc_stage(start=True):
    if start:
        br_print(print_level=BR_PRINT_LEVEL_SUBFUNC_START)
    else:
        br_print(print_level=BR_PRINT_LEVEL_SUBFUNC_END)

def set_print_macro_stage(start=True):
    if start:
        br_print(print_level=BR_PRINT_LEVEL_MACRO_START)
    else:
        br_print(print_level=BR_PRINT_LEVEL_MACRO_END)

def br_print(*args, **options):
    global file_path
    if not get_dry_run():
        if utils.get_debug_flag():
            if file_path is not None:
                with open(file_path, "a+") as fhandler:
                    print(*args, file=fhandler)
            else:
                print(*args)
        else:
            printer = br_printer(file_path)
            string = ""
            for arg in args:
                if isinstance(arg, str):
                    string += arg
                else:
                    string += "{}".format(arg)

            print_level = None
            if "print_level" in options.keys():
                print_level = options["print_level"]

            if "indent" in options.keys():
                indent = options["indent"]
                string = indent.indent * 4 * " " + string

            if "comment" in options.keys():
                comment = options["comment"]
                if (comment is not None):
                    if len(string) < 90:
                        string += " "*(90 - len(string) + 4) + comment
                    else:
                        string += " "*4 + comment

            if "comment_header" in options.keys():
                comment = options["comment_header"]
                if (comment is not None):
                    string += comment

            printer.stream(string + "\n", print_level=print_level)


def set_output_file(name, path=None):
    global file_path
    if path is not None:
        if not os.path.exists(path):
            ioh.biren_mkdir(path)
        file_path = os.path.join(path, name)
    else:
        file_path = name

    if os.path.exists(file_path):
        os.remove(file_path)

    br_printer().set_file(file_path)

g_is_new_warp = False
g_cur_cwarp_end_flag = ""


def set_new_cwarp_flag(flag):
    global g_is_new_warp
    g_is_new_warp = flag


def is_new_cwarp():
    global g_is_new_warp
    return g_is_new_warp


def set_warp_end_flag(flag):
    global g_cur_cwarp_end_flag
    g_cur_cwarp_end_flag = flag


def get_warp_end_flag():
    global g_cur_cwarp_end_flag
    return g_cur_cwarp_end_flag

from code_generator.backend.ApplyPass import *

@enable_kernel_replace
def set_enable_kernel_replace():
    if os.path.exists(br_printer().file_path):
        os.remove(file_path)
    name, bak = file_path.split('.')
    opt_name = "".join(name)
    opt_name += "_" + "origin" + "." + bak
    br_printer().set_file(opt_name)

g_enable_backend = False

def enable_backend(enable):
    global g_enable_backend
    g_enable_backend = enable

class br_printer(singleton):
    __instance = None  # singlton class

    def __new__(cls, *args, **kwargs):
        if cls.__instance is None:
            cls.__instance = super(br_printer, cls).__new__(cls)
            cls.__instance.__initialized = False
        return cls.__instance
    def __init__(self, file_path=None):
        if(self.__initialized):
            return
        self.__initialized = True

        self.file_path = file_path
        self.head_stream = []
        self.content_stream = []
        self.tail_stream = []
        self.content_last_ptr = 0
        self.head_last_ptr = 1
        self.subfunc_insert_ptr = 1  # by default insert after header comment
        self.subfunc_insert_header_flag = False
        self.macro_insert_header_flag = False
        self.macro_append_header_flag = False
        self.subfunc_append_tail_flag = False
        self.file_handler = None
        #self.pm = passmang.PM()
        if self.file_path is not None:
            self.file_handler = open(self.file_path, "a+")

    def __del__(self):
        global g_enable_backend
        self._flush_(stream=self.get_stream(), enable = g_enable_backend, file_path = self.file_path)

    def __exit__(self, *exc_info):
        pass

    @apply_pass
    def _flush_(self):
        string = "".join(self.head_stream)
        string += "".join(self.content_stream)
        if len(self.tail_stream) > 1:
            string += "".join(self.tail_stream)

        if self.file_path is not None:
            print(string, file=self.file_handler)
        else:
            print(string)

        self.head_stream = []
        self.content_stream = []
        self.tail_stream = []
        if self.file_handler is not None:
            self.file_handler.close()
            self.file_handler = None

    def set_file(self, file_path):
        if (file_path is not None) and \
              (file_path != self.file_path):
            self.file_path = file_path
            self.file_handler = open(self.file_path, "a+")

    def get_stream(self):
        string = "".join(self.head_stream)
        string += "".join(self.content_stream)
        if len(self.tail_stream) > 1:
            string += "".join(self.tail_stream)
        return string

    def print_stream(self, file, stream):
        if os.path.exists(file):
            os.remove(file)
        fd = open(file, "a+") 
        print(stream, file=fd)
        fd.close()

    def stream(self, string, print_level=None):
        if print_level is None:
            # if self.subfunc_insert_header_flag:
            #     self.head_stream.insert(self.head_last_ptr, string)
            #     self.head_last_ptr += 1
            # else:
            if self.subfunc_append_tail_flag:
                self.tail_stream.append(string)
            elif self.macro_insert_header_flag:
                # self.head_stream.append(string)
                self.head_stream.insert(self.head_last_ptr, string)
                self.head_last_ptr += 1
            else:
                self.content_stream.insert(self.content_last_ptr, string)
                self.content_last_ptr += 1
        elif (print_level == BR_PRINT_LEVEL_TOP_HEADER):
            self.head_stream.append(string)
        elif (print_level == BR_PRINT_LEVEL_SUBFUNC_DECLARE):
            self.head_stream.insert(self.subfunc_insert_ptr, string)
        elif (print_level == BR_PRINT_LEVEL_TOP_SWITCH):
            if string not in self.head_stream:
                end_mark = "end\n\n\n"
                if end_mark in self.head_stream:
                    end_pos = self.head_stream.index(end_mark)
                    self.head_stream.insert(end_pos, string)
        elif (print_level == BR_PRINT_LEVEL_CWARP_START):
            if is_new_cwarp():
                self.content_stream.append(string)
                self.content_stream.append(get_warp_end_flag() + "\n")
                self.content_stream.append("end\n\n\n")
                self.content_last_ptr = len(self.content_stream) - 2
                # insert into new cwarp
                # self.subfunc_insert_ptr = self.content_last_ptr
            else:
                exist_warp_end = get_warp_end_flag() + "\n"
                if exist_warp_end in self.content_stream:
                    position = self.content_stream.index(exist_warp_end)
                    self.content_stream.insert(position, "\n")
                    self.content_last_ptr = self.content_stream.index(
                        exist_warp_end)
        elif (print_level == BR_PRINT_LEVEL_SUBFUNC_START):
            self.subfunc_append_tail_flag = True
        elif (print_level == BR_PRINT_LEVEL_SUBFUNC_END):
            self.subfunc_append_tail_flag = False
        elif (print_level == BR_PRINT_LEVEL_MACRO_START):
            self.macro_insert_header_flag = True
        elif (print_level == BR_PRINT_LEVEL_MACRO_END):
            self.macro_insert_header_flag = False


        else:
            assert False, "Not supported print level!"
