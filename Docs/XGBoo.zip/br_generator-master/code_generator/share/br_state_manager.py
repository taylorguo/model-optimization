#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
from code_generator.share.br_singleton_base import singleton


def reset_kernel():
    singleton.reset()
