#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import difflib
import sys
import code_generator.share.br_const_defs as csts


def get_code_sytle():
    style_from_cmdline = False
    i = 0
    for ele in sys.argv:
        if '--style' in ele.lower():
            # print("ele is ", sys.argv[i+1])
            if '=' in ele.lower():
                get_code_sytle.style = int(ele.split('=')[-1].strip())
            else:
                get_code_sytle.style = int(sys.argv[i+1])
            style_from_cmdline = True
            break
        i += 1
    if not style_from_cmdline:
        #if not hasattr(get_code_sytle, 'style'):
        get_code_sytle.style = csts.BR_CODE_GEN_STYLE

    return get_code_sytle.style


def get_debug_flag():
    debug_from_cmdline = False
    i = 0
    for ele in sys.argv:
        if '--debug' in ele.lower():
            if '=' in ele.lower():
                get_debug_flag.debug = int(ele.split('=')[-1].strip())
            else:
                get_code_sytle.style = int(sys.argv[i+1])
            debug_from_cmdline = True
            break
        i += 1
    if not debug_from_cmdline:
        #if not hasattr(get_debug_flag, 'debug'):
        get_debug_flag.debug = csts.BR_CODE_DEBUG_STYLE

    return get_debug_flag.debug


def read_file(file_name):
    try:
        file_desc = open(file_name, 'r')
        text = file_desc.read().splitlines()
        file_desc.close()
        return text
    except IOError as error:
        print ("Read input file Error: {0}".format(error))
        sys.exit()


def compare_file(file1, file2):
    if file1 == "" or file2 == "":
        print ("Please input two files.".format(file1, file2))
        sys.exit()

    text1_lines = read_file(file1)
    text2_lines = read_file(file2)
    diff = difflib.HtmlDiff()
    result = diff.make_file(text1_lines, text2_lines)
    try:
        with open("compare_report.html", 'w') as result_file:
            result_file.write(result)
            print ("Test compare Successfully Finished\n")
            print ("Please see the compare_report.html for details!\n")
    except IOError as error:
        print ("ERROR: Fail to generate html file!\n".format(error))

class Br_Slot(object):
    def __init__(self, operator):
        self.operator = operator
        self.ordinal = 0

    def __add__(self, other):
        if isinstance(other, int):
            self.ordinal += other
            return self.ordinal
        elif isinstance(other, Br_Slot):
            self.ordinal += other.ordinal
            return self.ordinal
        else:
            return NotImplemented

    def __radd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):
        if isinstance(other, int):
            self.ordinal -= other
            return self.ordinal
        elif isinstance(other, Br_Slot):
            self.ordinal -= other.ordinal
            return self.ordinal
        else:
            return NotImplemented

    def __rsub__(self, other):
        return self.__sub__(other)


class Br_Indent(object):
    def __init__(self):
        self.indent = 0
        self.print_level = None #to control where to be printed

    def _set_print_level(self, level):
        self.print_level = level

    def __add__(self, other):
        if isinstance(other, int):
            self.indent += other
            return self.indent
        elif isinstance(other, Br_Indent):
            self.indent += other.indent
            return self.indent
        else:
            return NotImplemented

    def __radd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):
        if isinstance(other, int):
            self.indent -= other
            return self.indent
        elif isinstance(other, Br_Indent):
            self.indent -= other.indent
            return self.indent
        else:
            return NotImplemented

    def __rsub__(self, other):
        return self.__sub__(other)


class Br_Register(object):
    def __init__(self):
        self.register = None
        self.inc_unit = 1
        self.first_iter_of_inner_oc_loop = True
        self.last_tcore_instr = False
        self.instr_type = None
        self.innermost_loop_unroll = False
        self.outer_oc_loop_reg = None
        self.outer_oc_loop_inc_unit = None
        self.buf_address_flip = 0
        self.used_times = 0
        self.last_iter_of_inner_oc_loop = False


class Br_loops(object):
    def __init__(self):
        self.code_style = get_code_sytle()
        self.label = None

    def get_for_loop_start(self):
        pass

    def get_for_loop_end(self):
        pass

    def get_if_loop_start(self):
        pass

    def get_if_loop_end(self):
        pass


class Br_Iterations(object):
    def __init__(self):
        self.iterations = 0
