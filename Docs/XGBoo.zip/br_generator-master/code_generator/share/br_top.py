#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.


from code_generator.share.br_cwarp_man import cwarp_top
from code_generator.share import br_resource_manager as rm
from code_generator.share import br_state_manager as sm


class top(object):
    def __init__(self):
        self.cwarp_top = cwarp_top()

    def _set_dry_run(self, flag):
        self.cwarp_top.set_dry_run(flag)

    def _get_dry_run(self):
        return self.cwarp_top.get_dry_run()

    def get_required_wsr(self):
        return rm.get_req_wsr()

    def get_required_tlr(self):
        return rm.get_req_tlr()

    def flush(self):
        sm.reset_kernel()
