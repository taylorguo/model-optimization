#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

from collections import OrderedDict
from code_generator.share.br_defined_print import br_print
from code_generator.share.br_utils import Br_Indent
import code_generator.share.br_resource_manager as rm


SIMT_EXCLUDE_FIELDS = [
    "Type", "Opcode", "Src1", "Src2", "Parallel", "SIMT", "Mask", "SrcCnt"]

SIMT_STAT_EXCLUDE = [
    "Parallel", "eog"]

class INSTR(object):
    def __init__(self):
        self.fields = OrderedDict()
        self.instr_name = None
        self.original_instr_name = None
        self.indent_level = 0
        self.operator_modifier = None
        self.operands = None
        self.comment = None

        self.dst = None
        self.src1 = None
        self.src2 = None
        self.src3 = None
        self.desc = None
        self.target = None
        self.type = None


    def _reset_stat(self):
        if self.operator_modifier is not None:
            params = self.operator_modifier.split('.')
            filters = []
            for ele in params:
                if ele not in SIMT_STAT_EXCLUDE:
                    filters.append(ele)
            if len(filters) > 0:
                self.operator_modifier = ", ".join([str(i) for i in filters])

        for key in self.fields.keys():
            if key in SIMT_STAT_EXCLUDE:
                self.fields[key] = None

        #TODO: move out of this scope if too many replaced instructions
        replaced_instructions = ["saddg", "sadd", "smov", "adds"]
        if self.original_instr_name in replaced_instructions:
            self.instr_name = self.original_instr_name

    def dump_stream(self):
        if isinstance(self.indent_level, Br_Indent):
            assemble_code = " "*4*self.indent_level.indent
        else:
            assemble_code = " "*4*self.indent_level
        for key in self.fields.keys():
            if key == "Parallel" and self.fields[key] == 1:
                assemble_code += "&"
            if key == "Mask" and self.fields[key] == 1:
                assemble_code += "m0."
                break

        assemble_code += "{}".format(self.instr_name)

        for key in self.fields.keys():
            if key not in SIMT_EXCLUDE_FIELDS:
                if self.fields[key] is not None:
                    if (key == "GIBID_WriteThru" and
                    (self.fields[key] == "gib0" or
                     self.fields[key] == "gib1")):
                        continue
                # print("key and value is ", key, self.fields[key])
                if self.fields[key] is not None:
                    if key == "StagingCnt":
                        assemble_code += ".gc{}".format(self.fields[key])
                    else:
                        assemble_code += ".{}".format(self.fields[key])

        if self.operator_modifier:
            assemble_code += ".{}".format(self.operator_modifier)

        operands = []
        if self.dst is not None:
            operands.append(self.dst)
        if self.src1 is not None:
            operands.append(self.src1)
        if self.src2 is not None:
            operands.append(self.src2)
        if self.src3 is not None:
            operands.append(self.src3)
        if self.desc is not None:
            operands.append(self.desc)
        if self.target is not None:
            operands.append(self.target)
        if len(operands) > 0:
            self.operands = ", ".join([str(i) for i in operands])

        if self.operands is not None:
            assemble_code += " {}".format(self.operands)

        br_print(assemble_code, comment=self.comment)

        self._reset_stat()

    # generate format
    # the operands priority is less than dst/src1/src2/desc/target
    def generate(
            self, indent_level=None, modifier=None, dst=None,
            src1=None, src2=None, src3=None, desc=None, target=None,
            operands=None, comment=None):
        if indent_level is not None:
            self.indent_level = indent_level

        self.check_and_replace_false_imm_num(src1, src2, src3, dst)
        self.operator_modifier = modifier
        if dst is not None:
            self.dst = dst
            if isinstance(dst, str) and dst.startswith("imm_"):
                # print("Info: replace this instruction with cpu instruction")
                self.replace_or_remove_operators(dst)
                return
            elif self.get_immediate_number(dst) >= 2:
                self.replace_or_remove_operators(dst)

        if desc is not None:
            self.desc = desc
        if target is not None:
            self.target = target

        if operands is not None:
            self.operands = operands


        self.comment = comment
        self.dump_stream()

    def check_and_replace_false_imm_num(self, src1, src2, src3, dst):
        if src1 is not None:
            if isinstance(src1, str) and src1.startswith("imm_"):
                src1 = "{}".format(rm.get_immediate_variable_value(src1))
            self.src1 = src1
        if isinstance(src2, str) and src2.startswith("imm_"):
            src2 = "{}".format(rm.get_immediate_variable_value(src2))
        self.src2 = src2
        if isinstance(src3, str) and src3.startswith("imm_"):
            src3 = "{}".format(rm.get_immediate_variable_value(src3))
        self.src3 = src3

    def get_immediate_number(self, dst):
        num = 0
        if (self.src1 and
            (isinstance(self.src1, int) or
             isinstance(self.src1, float) or
             self.src1.isnumeric())):
            num += 1
        if (self.src2 and
            (isinstance(self.src2, int) or
             isinstance(self.src1, float) or
             self.src2.isnumeric())):
            num += 1
        if (self.src3 and
            (isinstance(self.src3, int) or
             isinstance(self.src1, float) or
             self.src3.isnumeric())):
            num += 1

        return num

    def replace_or_remove_operators(self, dst):
        if self.instr_name == "sadd":
            new_imm = None
            src2_replaced = False
            src1_replaced = False
            if self.src2:
                if (isinstance(self.src2, int) or
                        isinstance(self.src2, float)):
                    new_imm = self.src2
                    src2_replaced = True
                elif self.src2.isnumeric():
                    new_imm = int(self.src2)
                    src2_replaced = True
                if new_imm and self.src1:
                    if (isinstance(self.src1, int) or
                            isinstance(self.src1, float)):
                        self.src2 = None
                        new_imm += self.src1
                        src1_replaced = True
                    elif self.src1.isnumeric():
                        self.src2 = None
                        new_imm += int(self.src1)
                        src1_replaced = True

                    if src1_replaced and src2_replaced:
                        if dst.startswith("imm_"):
                            rm.assign_immediate_variable(dst, new_imm)
                        else:
                            self.src1 = new_imm
                            self.instr_name = "smov"
        
        if self.instr_name == "saddg":
            new_imm = None
            src2_replaced = False
            src1_replaced = False
            if self.src2:
                if (isinstance(self.src2, int) or
                        isinstance(self.src2, float)):
                    new_imm = self.src2
                    src2_replaced = True
                elif self.src2.isnumeric():
                    new_imm = int(self.src2)
                    src2_replaced = True
                if (new_imm is not None) and self.src1:
                    if (isinstance(self.src1, int) or
                            isinstance(self.src1, float)):
                        self.src2 = None
                        new_imm += self.src1
                        src1_replaced = True
                    elif self.src1.isnumeric():
                        self.src2 = None
                        new_imm += int(self.src1)
                        src1_replaced = True

                    if src1_replaced and src2_replaced:
                        if isinstance(self.src1, str) and self.src1.startswith("imm_"):
                            rm.assign_immediate_variable(self.src1, new_imm)
                        else:
                            self.src1 = new_imm
                            self.instr_name = "smovg"

        if self.instr_name == "smov":
            new_imm = None
            if isinstance(self.src1, int) or isinstance(self.src1, float):
                new_imm = self.src1
                if isinstance(dst, str) and dst.startswith("imm_"):
                    rm.assign_immediate_variable(dst, new_imm)
            elif isinstance(self.src1, str) and self.src1.isnumeric():
                new_imm = int(self.src1) #float?
                if isinstance(dst, str) and dst.startswith("imm_"):
                    rm.assign_immediate_variable(dst, new_imm)
        
        if self.instr_name == "adds":
            new_imm = None
            src2_replaced = False
            src1_replaced = False
            if self.src2:
                if (isinstance(self.src2, int) or
                        isinstance(self.src2, float)):
                    new_imm = self.src2
                    src2_replaced = True
                elif self.src2.isnumeric():
                    new_imm = int(self.src2)
                    src2_replaced = True
                if (new_imm is not None) and self.src1:
                    if (isinstance(self.src1, int) or
                            isinstance(self.src1, float)):
                        self.src2 = None
                        new_imm += self.src1
                        src1_replaced = True
                    elif self.src1.isnumeric():
                        self.src2 = None
                        new_imm += int(self.src1)
                        src1_replaced = True

                    if src1_replaced and src2_replaced:
                        if isinstance(self.src1, str) and self.src1.startswith("imm_"):
                            rm.assign_immediate_variable(self.src1, new_imm)
                        else:
                            self.src1 = new_imm
                            #TODO: may need one table for different arch
                            #16 and 32 are magics
                            #disbale for bundle
                            if dst in ["g" + str(i) for i in range(16)]:
                                self.instr_name = "movi"
                                self.operator_modifier = None
                                self.dst += ".u32"
                            elif dst in ["q" + str(i) for i in range(32)]:
                                self.instr_name = "smov"
                                self.operator_modifier = None


    def fill_inst(
            self, indent_level=None, modifier=None, dst=None,
            src1=None, src2=None, src3=None, desc=None, target=None, operands=None,
            comment=None):
        if indent_level is not None:
            self.indent_level = indent_level

        if dst is not None:
            self.dst = dst
        if src1 is not None:
            self.src1 = src1
        # if src2 is not None:
        self.src2 = src2
        self.src3 = src3
        if desc is not None:
            self.desc = desc
        if target is not None:
            self.target = target

        if operands is not None:
            if self.type == "SCAL_CT":
                self.dst = operands[2]
                self.src1 = operands[0]
                self.src2 = operands[1]
            elif self.type == "SCAL_CT2":
                self.dst = operands[0]
                self.src1 = operands[1]
            elif self.type == "SCAL_ALU":
                self.dst = operands[0]
            elif self.type == "SCAL_ALU2":
                self.dst = operands[0]
                self.src1 = operands[1]
                if len(operands) == 3:
                    self.src2 = operands[2]
            elif self.type == "SIMT_ALU2":
                self.dst = operands[0]
                self.src1 = operands[1]
                self.src2 = operands[2]
            elif self.type == "SIMT_ALU3":
                self.dst = operands[0]
                self.src1 = operands[1]
                self.src2 = operands[2]
                self.src3 = operands[3]
            elif self.type == "SIMT_MOV":
                self.dst = operands[0]
                self.src1 = operands[1]
            else:
                assert("add more inst support!!")


class SCAL(INSTR):
    def __init__(self, indent=None):
        super().__init__()

        self.fields["Parallel"] = 0
        self.fields["SIMT"] = 0
        self.fields["Hold"] = None #TODO:implements hold later
        self.fields["Opcode"] = None
        self.fields["Dst"] = None
        self.fields["BarScope"] = None
        self.fields["BarMode"] = None
        self.fields["Relative"] = None
        self.fields["IDType"] = None #ID type for SYSID instruction
        self.fields["S1lmm"] = None
        self.fields["Fresh"] = None
        self.fields["S1Neg"] = None
        self.fields["S1Rel"] = None
        self.fields["BarType"] = None
        self.fields["S2Neg"] = None
        self.fields["DstRel"] = None
        self.fields["Src1"] = None
        self.fields["Src2"] = None
        self.fields["Longlmm"] = None

        if indent is not None:
            self.indent_level = indent
        self.instr_name = "scal_instr"

    def generate(
            self, indent_level=None, parallel=None, modifier=None, dst=None,
            src1=None, src2=None, desc=None, target=None, operands=None,
            comment=None):

        self.fields["Parallel"] = parallel
        return super().generate(
            indent_level, modifier, dst, src1, src2, desc, target, operands,
            comment=comment)

class sysid(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "sysid"
        self.type = "SCAL_ALU"

class snop(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "snop"
        self.type = "SCAL_ALU2_SNOP"

class nop(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "nop"
        self.type = "SCAL_ALU2_NOP"

class smov(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "smov"
        self.original_instr_name = "smov"
        self.fields["Opcode"] = "SMOV"
        self.type = "SCAL_ALU2"

class smovs(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "smovs"
        self.fields["Opcode"] = "SMOVS"
        self.type = "SCAL_ALU2"

class smovg(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "smovg"
        self.fields["Opcode"] = "SMOVG"
        self.type = "SCAL_ALU2"

class saddg(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "saddg"
        self.original_instr_name = "saddg"
        self.fields["Opcode"] = "SADDG"
        self.type = "SCAL_ALU2"

class sadd(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "sadd"
        self.original_instr_name = "sadd"
        self.fields["Opcode"] = "SADD"
        self.type = "SCAL_ALU2"

class sadda(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "sadda"
        self.fields["Opcode"] = "SADDA"
        self.type = "SCAL_ALU2"

class sor(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "sor"
        self.fields["Opcode"] = "SOR"
        self.type = "SCAL_ALU2"

class sxor(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "sxor"
        self.fields["Opcode"] = "SXOR"
        self.type = "SCAL_ALU2"

class sand(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "sand"
        self.fields["Opcode"] = "SAND"
        self.type = "SCAL_ALU2"

class sshl(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "sshl"
        self.fields["Opcode"] = "SSHL"
        self.type = "SCAL_ALU2"

class sshr(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "sshr"
        self.fields["Opcode"] = "SSHR"
        self.type = "SCAL_ALU2"

class beq(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "beq"
        self.fields["Opcode"] = "BEQ"
        self.type = "SCAL_CT"

    def generate(
        self, indent_level=None, parallel=None, modifier=None,
        rel=None, dst=None, src1=None, src2=None, target=None,
        operands=None, comment=None):

        if rel is not None:
            self.fields["Relative"] = rel

        return super().generate(indent_level=indent_level,
            parallel=parallel, modifier=modifier, dst=dst,
            src1=src1, src2=src2, target=target, operands=operands,
            comment=comment)


class bar(SCAL):
    def __init__(self, indent=None, scope="tg", mode="sync", bartype="all"):
        super().__init__(self)
        self.instr_name = "bar"
        self.type = "SCAL_CT2"

    def generate(
        self, indent=None, scope=None, mode=None, modifier=None,
        bartype=None, src1=None, src2=None, operands=None, comment=None):
        self.fields["Opcode"] = "BAR"

        if scope is not None:
            self.fields["BarScope"] = scope
        if mode is not None:
            self.fields["BarMode"] = mode
        if bartype is not None:
            self.fields["BarType"] = bartype

        new_src2 = src2
        new_modifier = None
        if mode == "csm" and src2 == "all":
            new_src2 = None
            if modifier is not None:
                new_modifier = modifier + ".all"
            else:
                new_modifier = "all"

        if src2 != "all":
            new_modifier = "cnt"
 
        return super().generate(indent_level=indent, src1=src1, src2=new_src2,
                                modifier=new_modifier, operands=operands, comment=comment)


class sleep(SCAL):
    def __init__(self, indent=None, src1=None):
        super().__init__(indent)
        self.instr_name = "sleep"
        self.fields["Opcode"] = "SLEEP"
        self.type = "SCAL_CT"

class call(SCAL):
    def __init__(self, indent=None, rel=None, dst=None, target=None):
        super().__init__(indent)
        self.instr_name = "call"
        self.fields["Opcode"] = "CALL"
        self.dst = dst
        self.target = target
        self.type = "SCAL_CT"

    def generate(
        self, indent=None, rel=None, modifier=None, dst=None,
        target=None, operands=None, comment=None):

        if rel is not None:
            self.fields["Relative"] = rel

        return super().generate(indent_level=indent, modifier=modifier, dst=dst,
                                target=target, operands=operands, comment=comment)


class jump(SCAL):
    def __init__(self, indent=None, rel=None, target=None):
        super().__init__(indent)
        self.instr_name = "jump"
        self.fields["Opcode"] = "JUMP"
        self.target = target
        self.type = "SCAL_CT"

    def generate(
        self, indent=None, rel=None, modifier=None,
        target=None, operands=None, comment=None):

        if rel is not None:
            self.fields["Relative"] = rel

        return super().generate(indent_level=indent, modifier=modifier,
                                target=target, operands=operands, comment=comment)


class fll1(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "fll1"
        self.fields["Opcode"] = "FLL1"
        self.type = "SCAL_LSA"


class ackgmb(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "ackgmb"
        self.fields["Opcode"] = "ACKGMB"
        self.type = "SCAL_LSA"


class branch(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "branch"
        self.fields["Opcode"] = "BRANCH_INST"
        self.type = "SCAL_CT"

    def generate(
        self, indent_level=None, parallel=None, modifier=None,
        rel=None, dst=None, src1=None, src2=None, desc=None,
        target=None, operands=None, comment=None):

        if rel is not None:
            self.fields["Relative"] = rel

        return super().generate(indent_level=indent_level,
            parallel=parallel, modifier=modifier, dst=dst,
            src1=src1, src2=src2, desc=desc, target=target, operands=operands,
            comment=comment)


class bne(branch):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "bne"
        self.fields["Opcode"] = "BNE"


class blts(branch):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "blts"
        self.fields["Opcode"] = "BLTS"

    def generate(
        self, indent_level=None, parallel=None, modifier=None,
        rel=None, dst=None, src1=None, src2=None, desc=None,
        target=None, operands=None, comment=None):

        if rel is not None:
            self.fields["Relative"] = rel

        return super().generate(indent_level=indent_level,
            parallel=parallel, modifier=modifier, dst=dst,
            src1=src1, src2=src2, desc=desc, target=target, operands=operands,
            comment=comment)

class bltu(branch):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "bltu"
        self.fields["Opcode"] = "BLTU"


class bles(branch):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "bles"
        self.fields["Opcode"] = "BLES"


class bleu(branch):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "bleu"
        self.fields["Opcode"] = "BLEU"


class brancha(SCAL):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "brancha"
        self.fields["Opcode"] = "BRANCHA_INST"

    def generate(
        self, indent_level=None, parallel=None, modifier=None,
        rel=None, fresh=None, dst=None, src1=None, target=None,
        operands=None, comment=None):

        if rel is not None:
            self.fields["Relative"] = rel

        if fresh is not None:
            self.fields["Fresh"] = fresh

        return super().generate(indent_level=indent_level, parallel=parallel,
                                modifier=modifier, dst=dst, src1=src1, target=target,
                                 operands=operands, comment=comment)


class baf(brancha):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "baf"
        self.fields["Opcode"] = "BAF"


class bat(brancha):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "bat"
        self.fields["Opcode"] = "BAT"


class bany(brancha):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "bany"
        self.fields["Opcode"] = "BANY"


class SIMT_ALU2(INSTR):
    def __init__(self, indent=None):
        super().__init__()
        self.fields["Parallel"] = 0
        self.fields["SIMT"] = 1
        self.fields["SrcCnt"] = 0
        self.fields["Opcode"] = None
        self.fields["S1Abs"] = None
        self.fields["Compare"] = None
        self.fields["SubFmt"] = None
        self.fields["Mask"] = None
        self.fields["Sync"] = None
        self.fields["VectorCnt"] = None
        self.fields["DstMod"] = None
        self.fields["Dst"] = None
        self.fields["Src1"] = None
        self.fields["S1Array"] = None
        self.fields["S2Array"] = None
        self.fields["S1Neg"] = None
        self.fields["S2Neg"] = None
        self.fields["DemSize"] = None
        self.fields["Hold"] = None
        self.fields["Staging"] = None
        self.fields["Fused"] = None
        self.fields["Src2"] = None
        self.type = "SIMT_ALU2"

        if indent is not None:
           self.indent_level = indent

        self.instr_name = "alu2_instr"

    def generate(
        self, indent_level=None, parallel=None, modifier=None, dst=None, mask=None,
        src1=None, src2=None, desc=None, target=None, operands=None, comment=None):

        self.fields["Parallel"] = parallel
        self.fields["Mask"] = mask
        return super().generate(indent_level, modifier, dst, src1, src2, desc, target, operands, comment=comment)


class addu(SIMT_ALU2):
    def __init__(self, indent=None, vcnt="v1", dem="b8",
        prec="lo", hold=None, sync=None):
        super().__init__(indent)

        self.fields["VectorCnt"] = vcnt
        self.fields["DemSize"] = dem
        self.fields["Hold"] = hold
        self.fields["Sync"] = sync

        self.fields["Opcode"] = "ADDU"
        self.instr_name = "addu"


class fmul(SIMT_ALU2):
    def __init__(self, indent=None):
        super().__init__(indent)

        self.fields["Opcode"] = "FMUL"
        self.instr_name = "fmul"


class fmax(SIMT_ALU2):
    def __init__(self, indent=None):
        super().__init__(indent)

        self.fields["Opcode"] = "FMAX"
        self.instr_name = "fmax"


class fadd(SIMT_ALU2):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.fields["Opcode"] = "FADD"
        self.instr_name = "fadd"

class mulu(SIMT_ALU2):
    def __init__(
        self, indent=None, mask=0, vcnt="v1",
        dem="b8", prec="lo", hold="h1", sync="sc1"):
        super().__init__(indent)

        self.fields["Mask"] = mask
        self.fields["VectorCnt"] = vcnt
        self.fields["DemSize"] = dem
        self.fields["Hold"] = hold
        self.fields["Sync"] = sync

        self.fields["Opcode"] = "MULU"
        self.instr_name = "mulu"

class adds(SIMT_ALU2):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "adds"
        self.original_instr_name = "adds"
        self.fields["Opcode"] = "ADDS"


class cmpu(SIMT_ALU2):
    def __init__(
        self, indent=None, mask=None, cm=None, vcnt=None,
        dem=None, hold=None, sync=None):
        super().__init__(indent)

        self.fields["Mask"] = mask
        self.fields["Compare"] = cm
        self.fields["VectorCnt"] = vcnt
        self.fields["DemSize"] = dem
        self.fields["Hold"] = hold
        self.fields["Sync"] = sync

        self.fields["Opcode"] = "CMPU"
        self.instr_name = "cmpu"

    def generate(
        self, indent=None, mask=None,vcnt=None,  dst=None, src1=None, src2=None,
        dem=None, hold=None, sync=None, cm=None, modifier=None, operands=None, comment=None):

        if mask is not None:
            self.fields["Mask"] = mask
        if cm is not None:
            self.fields["Compare"] = cm
        if vcnt is not None:
            self.fields["VectorCnt"] = vcnt
        if dem is not None:
            self.fields["DemSize"] = dem
        if hold is not None:
            self.fields["Hold"] = hold
        if sync is not None:
            self.fields["Sync"] = sync

        return super().generate(indent, modifier=modifier, dst=dst, src1=src1, src2=src2, operands=operands, comment=comment)

class shl(SIMT_ALU2):
    def __init__(
        self, indent=None, mask=None, vcnt=None,
        dem=None, hold=None, sync=None):
        super().__init__(indent)

        self.fields["Mask"] = mask
        self.fields["VectorCnt"] = vcnt
        self.fields["DemSize"] = dem
        self.fields["Hold"] = hold
        self.fields["Sync"] = sync

        self.fields["Opcode"] = "SHL"
        self.instr_name = "shl"

    def generate(
        self, indent=None, mask=None,vcnt=None,  dst=None, src1=None, src2=None,
        dem=None, hold=None, sync=None, pre=None, modifier=None, operands=None, comment=None):

        if mask is not None:
            self.fields["Mask"] = mask
        if vcnt is not None:
            self.fields["VectorCnt"] = vcnt
        if dem is not None:
            self.fields["DemSize"] = dem
        if hold is not None:
            self.fields["Hold"] = hold
        if sync is not None:
            self.fields["Sync"] = sync

        return super().generate(indent, modifier=modifier, dst=dst, src1=src1, src2=src2, operands=operands, comment=comment)

class shr(SIMT_ALU2):
    def __init__(
        self, indent=None, mask=None, vcnt=None,
        dem=None, hold=None, sync=None):
        super().__init__(indent)

        self.fields["Mask"] = mask
        self.fields["VectorCnt"] = vcnt
        self.fields["DemSize"] = dem
        self.fields["Hold"] = hold
        self.fields["Sync"] = sync

        self.fields["Opcode"] = "SHR"
        self.instr_name = "shr"

    def generate(
        self, indent=None, mask=None,vcnt=None,  dst=None, src1=None, src2=None,
        dem=None, hold=None, sync=None, pre=None, modifier=None, operands=None, comment=None):

        if mask is not None:
            self.fields["Mask"] = mask
        if vcnt is not None:
            self.fields["VectorCnt"] = vcnt
        if dem is not None:
            self.fields["DemSize"] = dem
        if hold is not None:
            self.fields["Hold"] = hold
        if sync is not None:
            self.fields["Sync"] = sync

        return super().generate(indent, modifier=modifier, dst=dst, src1=src1, src2=src2, operands=operands, comment=comment)

class vor(SIMT_ALU2):
    def __init__(
        self, indent=None, mask=None, vcnt=None,
        dem=None, hold=None, sync=None):
        super().__init__(indent)

        self.fields["Mask"] = mask
        self.fields["VectorCnt"] = vcnt
        self.fields["DemSize"] = dem
        self.fields["Hold"] = hold
        self.fields["Sync"] = sync

        self.fields["Opcode"] = "OR"
        self.instr_name = "or"

    def generate(
        self, indent=None, mask=None,vcnt=None,  dst=None, src1=None, src2=None,
        dem=None, hold=None, sync=None, pre=None, modifier=None, operands=None, comment=None):

        if mask is not None:
            self.fields["Mask"] = mask
        if vcnt is not None:
            self.fields["VectorCnt"] = vcnt
        if dem is not None:
            self.fields["DemSize"] = dem
        if hold is not None:
            self.fields["Hold"] = hold
        if sync is not None:
            self.fields["Sync"] = sync

        return super().generate(indent, modifier=modifier, dst=dst, src1=src1, src2=src2, operands=operands, comment=comment)


class xor(SIMT_ALU2):
    def __init__(
        self, indent=None, mask=None, vcnt=None,
        dem=None, hold=None, sync=None):
        super().__init__(indent)

        self.fields["Mask"] = mask
        self.fields["VectorCnt"] = vcnt
        self.fields["DemSize"] = dem
        self.fields["Hold"] = hold
        self.fields["Sync"] = sync

        self.fields["Opcode"] = "XOR"
        self.instr_name = "xor"

    def generate(
        self, indent=None, parallel=None, mask=None,vcnt=None,  dst=None, src1=None, src2=None,
        dem=None, hold=None, sync=None, pre=None, modifier=None, operands=None, comment=None):

        if mask is not None:
            self.fields["Mask"] = mask
        if vcnt is not None:
            self.fields["VectorCnt"] = vcnt
        if dem is not None:
            self.fields["DemSize"] = dem
        if hold is not None:
            self.fields["Hold"] = hold
        if sync is not None:
            self.fields["Sync"] = sync

        return super().generate(
            indent, modifier=modifier, parallel=parallel,
            dst=dst, src1=src1, src2=src2, operands=operands, comment=comment)

class SIMT_ALU3(INSTR):
    def __init__(self, indent=None):
        super().__init__()

        self.fields["Parallel"] = 0
        self.fields["SIMT"] = 1
        self.fields["SrcCnt"] = 1
        self.fields["Opcode"] = None
        self.fields["Src2"] = None
        self.fields["Mask"] = None
        self.fields["Sync"] = None
        self.fields["VectorCnt"] = None
        self.fields["DstMod"] = None
        self.fields["Dst"] = None
        self.fields["Src1"] = None
        self.fields["S1Array"] = None
        self.fields["S2Array"] = None
        self.fields["S3Array"] = None
        self.fields["S1Neg"] = None
        self.fields["S3Neg"] = None
        self.fields["DemSize"] = None
        self.fields["Hold"] = None
        self.fields["Staging"] = None
        self.fields["Fused"] = None
        self.fields["Src3"] = None
        self.type = "SIMT_ALU3"

        if indent is not None:
               self.indent_level = indent
        self.instr_name = "alu3_instr"

    def generate(
        self, indent_level=None, parallel=None, modifier=None, dst=None, mask=None,
        src1=None, src2=None, src3=None, desc=None, target=None, operands=None, comment=None):

        self.fields["Parallel"] = parallel
        self.fields["Mask"] = mask
        return super().generate(indent_level, modifier, dst, src1, src2, src3, desc, target, operands, comment=comment)

class fmad(SIMT_ALU3):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.fields["Opcode"] = "FMAD"
        self.instr_name = "fmad"


class madu(SIMT_ALU3):
    def __init__(self, indent=None):
        super().__init__(indent)

        self.fields["Opcode"] = "MADU"
        self.instr_name = "madu"

class SIMT_MOV(INSTR):
    def __init__(self, indent=None):
        super().__init__()

        self.fields["Parallel"] = 0
        self.fields["SIMT"] = 1
        self.fields["Mask"] = None
        self.fields["SrcCnt"] = None
        self.fields["Opcode"] = None
        self.fields["SrcType"] = None
        self.fields["DstType"] = None
        self.fields["Away"] = None
        self.fields["DstDem"] = None
        self.fields["DstRel"] = None
        self.fields["SubFmt"] = None

        self.fields["Sync"] = None
        self.fields["SrcVecCnt"] = None
        self.fields["DstMod"] = None
        self.fields["Dst"] = None
        self.fields["Src1"] = None
        self.fields["S1Array"] = None
        self.fields["Rounding"] = None
        self.fields["Timer"] = None
        self.fields["S1Neg"] = None
        self.fields["SrcDem"] = None
        self.fields["Hold"] = None
        self.fields["Staging"] = None
        self.type = "SIMT_MOV"

        if indent is not None:
            self.indent_level = indent
        self.instr_name = "mov_instr"

    def generate(
        self, indent_level=None, parallel=None, modifier = None, dst=None,
        src1=None, src2=None, desc=None, target=None, operands=None, comment=None):

        self.fields["Parallel"] = parallel
        return super().generate(indent_level, modifier, dst, src1, src2, desc, target, operands,  comment=comment)

class movi(SIMT_MOV):
    def __init__(self, indent=None):
        super().__init__(indent)

        self.instr_name = "movi"
        self.fields["Opcode"] = "MOVI"

class mov(SIMT_MOV):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "mov"
        self.fields["Opcode"] = "MOV"

class movw(SIMT_MOV):
    def __init__(self, indent=None):
        super().__init__(indent)
        self.instr_name = "movw"
        self.fields["Opcode"] = "MOVW"


class SIMT_LSA(INSTR):
    def __init__(self, indent=None):
        super().__init__()
        self.fields["Type"] = 0
        self.fields["Subtype"] = None
        self.fields["Opcode"] = None
        self.fields["WriteThru"] = None
        self.fields["MemDem"] = None
        self.fields["RegDem"] = None
        self.fields["DataType"] = None
        self.fields["DemCnt"] = None
        self.fields["CacheAttr"] = None
        self.fields["L2Control"] = None
        self.fields["RedMode"] = None
        self.fields["DescIndex"] = None
        self.fields["StagingCnt"] = None
        self.fields["Org"] = None
        self.fields["SrcSite"] = None
        self.fields["Reduction"] = None
        self.fields["AccessAttr"] = None
        self.fields["Sync"] = None
        self.fields["MemType"] = None
        self.fields["ShuffleMode"] = None
        self.fields["DescSetID"] = None
        self.type = "SIMT_LSA"

        if indent is not None:
            self.indent_level = indent
        self.instr_name = "lsa_instr"


class stm(SIMT_LSA):
    def __init__(self):
        super().__init__()
        self.instr_name = "stm"


class sld(SIMT_LSA):
    def __init__(self):
        super().__init__()
        self.instr_name = "sld"


class sldm(SIMT_LSA):
    def __init__(self):
        super().__init__()
        self.instr_name = "sldm"


class ldm(SIMT_LSA):
    def __init__(self, indent=None):
        super().__init__(indent=indent)
        self.instr_name = "ldm"


class lddw(SIMT_LSA):
    def __init__(
        self, indent=None, dt="int", mdem="rdne",
        rdem="rb8", sync="sc1", dcnt="e1", gc="gc1"):
        super().__init__(indent)

        self.fields["DataType"] = dt
        self.fields["MemDem"] = mdem
        self.fields["RegDem"] = rdem
        self.fields["Sync"] = sync
        self.fields["DemCnt"] = dcnt
        self.fields["StagingCnt"] = gc

        self.instr_name = "lddw"


class wred(SIMT_LSA):
    def __init__(
        self, indent=None):
        super().__init__(indent)
        self.fields["Opcode"] = "WRED"
        self.instr_name = "wred"

    def generate(
        self, indent=None, modifier = None, mode=None, src=None,
        dcnt=None, memtype=None, gc=None, operands=None, comment=None):
        if mode is not None:
            self.fields["RedMmode"] = mode
        if src is not None:
            self.fields["SrcSite"] = src
        if dcnt is not None:
            self.fields["DemCnt"] = dcnt
        if memtype is not None:
            self.fields["MemType"] = memtype
        if gc is not None:
            self.fields["StagingCnt"] = gc
        return super().generate(indent, modifier=modifier, operands=operands, comment=comment)


