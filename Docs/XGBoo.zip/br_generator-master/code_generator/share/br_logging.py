import logging
from logging.handlers import RotatingFileHandler
import os


class br_logging:
    def __init__(self, name, output_dir, enable_log=False):
        self.name = name
        self.output_dir = output_dir
        self.enable_log = enable_log
        if self.enable_log is True:
            self.log = logging.getLogger(self.name)
            log_file_handler = RotatingFileHandler(os.path.join(
                self.output_dir, self.name + ".log"),
                                                   maxBytes=10 * 1024 * 1024,
                                                   backupCount=5)
            self.log.setLevel(logging.DEBUG)
            formatter = logging.Formatter(
                '[%(levelname)-5s] %(filename)-10s:%(lineno)-4d: %(message)s')
            log_file_handler.setFormatter(formatter)
            self.log.addHandler(log_file_handler)
        else:
            pass

    def debug(self, message):
        if self.enable_log is True:
            self.log.debug(message)
        else:
            pass

    def info(self, message):
        if self.enable_log is True:
            self.log.info(message)
        else:
            pass

    def warn(self, message):
        if self.enable_log is True:
            self.log.warning(message)
        else:
            pass

    def error(self, message):
        if self.enable_log is True:
            self.log.error(message)
        else:
            pass

    def critical(self, message):
        if self.enable_log is True:
            self.log.critical(message)
        else:
            pass