#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.


class singleton(object):
    def __init__(self):
        super().__init__()

    @staticmethod
    def reset():
        for asub in singleton.__subclasses__():
            for akey in asub.__dict__.keys():
                if "__instance" in akey:
                    setattr(asub, akey, None)



