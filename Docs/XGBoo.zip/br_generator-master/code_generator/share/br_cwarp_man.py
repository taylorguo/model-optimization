#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
from code_generator.share.br_singleton_base import singleton
from code_generator.share import br_resource_manager as rm
from code_generator.share import br_defined_print
from code_generator.share import br_loop_manager
from code_generator.share import br_const_defs as icd
from code_generator.share import br_utils
from code_generator.tcore import br_tcore_loop_man_base as tlmb
from collections import OrderedDict

warp_prefix = "CWARP{}_START:"
warp_suffix = "CWARP{}_END:"
# assemble_prefix = ".global {} \n .type {}, @function \n"


def print_file_header():
    br_defined_print.br_print(
        '''// This file is generated automatically'''
        ''' by the module code_generator of br_generator.'''
        '''\n// Copyright 2020, Biren Technologies Inc.'''
        '''\n// All rights reserved.\n\n''',
        print_level=br_defined_print.BR_PRINT_LEVEL_TOP_HEADER)
    # br_defined_print.br_print(
    #     ".global start \n start: \n jump.rel main",
    #     comment="// Always jump to the main function!",
    #     print_level=br_defined_print.BR_PRINT_LEVEL_TOP_HEADER)


class cwarp_top(singleton):
    __instance = None  # singlton class

    def __new__(cls, *args, **kwargs):
        if cls.__instance is None:
            cls.__instance = super(cwarp_top, cls).__new__(cls)
            cls.__instance.__initialized = False
            cls.__instance.__file_start = True

        return cls.__instance

    def __init__(self, warp_number=icd.CWARP_NUM):
        if(self.__initialized):
            return

        self.__initialized = True

        if warp_number is not None and warp_number > 8:
            print("Error: Warp number cannot be greater than 8!")
        if warp_number is not None:
            self.__init_state(warp_number)

    def __init_state(self, warp_number):
        self.cwarp_num = warp_number
        self.current_warp = -1
        self.existing_warp = []
        self.warp_entry = None
        self.new_warp = False
        self.dry_run = False
        self.label_avail = OrderedDict()
        self.indent = br_utils.Br_Indent()
        self.loop_man = tlmb.loop_man_base(self.indent)
        self.sysid_reg = rm.wsr_alloc(alias="sys_id", warp_man=self)
        self.warpid_reg = rm.wsr_alloc("warp_id")
        self.euid_reg = rm.wsr_alloc("eu_id")

    def generate_top_header(self):
        dry_run_status = br_defined_print.dry_run
        br_defined_print.dry_run = False
        print_file_header()
        br_defined_print.br_print(
            "\n.global main \n.align 512",
            print_level=br_defined_print.BR_PRINT_LEVEL_TOP_HEADER)
        br_defined_print.br_print(
            ".type main, @function",
            print_level=br_defined_print.BR_PRINT_LEVEL_TOP_HEADER)
        br_defined_print.br_print(
            "main:",
            print_level=br_defined_print.BR_PRINT_LEVEL_TOP_HEADER)
        br_defined_print.br_print(
            "sysid.work      {}".format(self.sysid_reg),
            print_level=br_defined_print.BR_PRINT_LEVEL_TOP_HEADER)
        br_defined_print.br_print(
            "sshr.h3 {}, {}, 4"
            .format(self.warpid_reg, self.sysid_reg),
            print_level=br_defined_print.BR_PRINT_LEVEL_TOP_HEADER)
        br_defined_print.br_print(
            "sand    {}, {}, 15"
            .format(self.euid_reg, self.sysid_reg),
            print_level=br_defined_print.BR_PRINT_LEVEL_TOP_HEADER)
        br_defined_print.br_print(
            "sand.h2 {}, {}, 7"
            .format(self.warpid_reg, self.warpid_reg),
            print_level=br_defined_print.BR_PRINT_LEVEL_TOP_HEADER)
        br_defined_print.br_print(
            "nop.v3",
            print_level=br_defined_print.BR_PRINT_LEVEL_TOP_HEADER)

        global warp_prefix
        entry = warp_prefix[:-1].format(0)
        br_defined_print.br_print(
            "beq.rel {},".format(self.warpid_reg),
            " {}, ".format(0), entry,
            print_level=br_defined_print.BR_PRINT_LEVEL_TOP_HEADER)
        br_defined_print.br_print(
            "end\n\n",
            print_level=br_defined_print.BR_PRINT_LEVEL_TOP_HEADER)
        br_defined_print.dry_run = dry_run_status

    def start_warp(self, warpid=None):
        if self.__file_start:
            self.generate_top_header()
            self.__file_start = False
        # if self.dry_run:
        #     return self._start_dry_cwarp()

        self.new_warp = False
        if warpid is not None:
            if warpid not in self.existing_warp:
                self.new_warp = True
            else:
                self.new_warp = False
            self.current_warp = warpid
        else:
            self.current_warp += 1
            self.new_warp = True

        if self.dry_run:
            return self._start_dry_cwarp()

        self.warp_entry = warp_prefix.format(self.current_warp)
        br_defined_print.set_warp_end_flag(self.get_cwarp_end())
        br_defined_print.set_new_cwarp_flag(self.new_warp)
        if self.new_warp:
            self.existing_warp.append(self.current_warp)
            self.new_cwarp_label()

        if (self.current_warp != 0):
            br_defined_print.br_print(
                "beq.rel {},".format(self.warpid_reg), " {}, "
                .format(self.current_warp),
                warp_prefix[:-1].format(self.current_warp),
                print_level=br_defined_print.BR_PRINT_LEVEL_TOP_SWITCH)

        # warp_assm_prefix = assemble_prefix.format(
        #    self.warp_entry.split(":")[0],
        #    self.warp_entry.split(":")[0])
        br_defined_print.br_print(
            # warp_assm_prefix + self.warp_entry,
            self.warp_entry,
            print_level=br_defined_print.BR_PRINT_LEVEL_CWARP_START)

        return self.current_warp, self.warp_entry

    def _start_dry_cwarp(self):
        self.new_warp = False
        self.current_warp = icd.MAX_CWARP_NUM + self.current_warp
        self.warp_entry = warp_prefix.format(self.current_warp)
        self.new_cwarp_label()
        return self.current_warp, self.warp_entry

    def end_warp(self):
        br_loop_manager.reset_label_space()

    def gen_warp_header(self, warpid):
        warp_end = warp_suffix.format(warpid)[:-1]
        br_defined_print.br_print(
            "bne.rel {}, 0, {}".format(self.euid_reg, warp_end))

    def only_two_cwarps(self):
        return self.cwarp_num <= 2

    def only_one_cwarp(self):
        return self.cwarp_num <= 1

    def get_warp_entry_head(self):
        return self.warp_entry.split("_")[0]

    def get_current_cwarp(self):
        return self.current_warp

    def get_format_end(self, warp_id):
        return warp_suffix.format(warp_id)

    def get_cwarp_end(self):
        return warp_suffix.format(self.current_warp)

    def get_warp_entry(self):
        return self.warp_entry

    def is_new_cwarp(self):
        return self.new_warp

    def get_a_label(self):
        header = self.get_warp_entry_head()
        if len(self.label_avail[header]) != 0:
            lb = self.label_avail[header][0]
            label = "{}".format(lb)
            self.label_avail[header].remove(lb)
        else:
            print("Error: labels are used up!")
        return label

    def new_cwarp_label(self):
        header = self.get_warp_entry_head()
        self.label_avail[header] = [i for i in range(10000)]

    def set_dry_run(self, flag):
        br_defined_print.set_dry_run(flag)
        if flag:
            rm.reset_for_dry_mode()
        self.dry_run = flag

    def get_dry_run(self):
        return self.dry_run
