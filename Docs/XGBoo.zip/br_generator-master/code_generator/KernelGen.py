#!/usr/bin/env python3

import sys as sys
import os

import vector.common.hwCaps as hwCaps
import vector.common.flowLib as flowLib
import vector.common.funcLib as funcLib
import vector.common.funcgen as funcgen
import vector.common.compiler as compiler
import vector.common.cwarp as cwarp

import vector.br_vector_fc_funcs as fc
import vector.br_vector_bn_funcs as bn
import vector.br_vector_dwc_funcs as dwc
import vector.br_vector_reduce_funcs as reduce
import vector.br_vector_loss_funcs as loss
import vector.br_vector_pbk_funcs as pbk
import vector.br_vector_avgpool_funcs as avgpool

from code_generator.share.br_defined_print import br_print


def main():
  flowHandler = flowLib.FlowHandler("", 1, 31, compiler.GetASMMode())

  qIndex = flowHandler.getQTempStart()
  indentstring = flowHandler.getIndentStr()

  br_print (indentstring + "sysid.work q" + str(qIndex))
  funcLib.AlignPrint(indentstring + "sshr q" + str(qIndex) + ", q" + str(qIndex) + ", 4", flowLib.GetCommentPos(), "// obtain cwarp id")
  for z in range (cwarp.CWarpNumber()):
    br_print (indentstring + "beq.rel q" + str(qIndex) + ", " + str(z) + ", " + "MAIN_WARP_ENTRY_" + str(z))

  br_print (indentstring + "end")

  surfaceInfo   = [16, 64, 56, 56]

  argc = len(sys.argv)
  if (argc > 1):
    surfaceInfo[3] = int (sys.argv[1])

    if (argc > 2):
      surfaceInfo[2] = int (sys.argv[2])

  #activationUSharpIndex = 0
  #refUSharpIndex = 1
  #lossUSharpIndex = 2
  #gradientUSharpIndex = 3

  lossUSharps = [[0, hwCaps.SurfaceType1DVector(),      1,  1,  1, 500, "input, 1D vector, fc output, also serve as input to softmax"],
                 [1, hwCaps.SurfaceType1DVector(),      1,  1,  1, 500, "input, 1D vector, ref"],
                 [2, hwCaps.SurfaceType1DVector(),      1,  1,  1,   1, "output, 1D vector, final loss"],
                 [3, hwCaps.SurfaceType1DVector(),      1,  1,  1, 500, "output, 1D vector, gradient for back propagation"]
                ]

  reduceUSharps = [[0, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1],  surfaceInfo[2], surfaceInfo[3], "input, 3d activation, pnly channel in use"],
                ]

  poolUSharps = [[0, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1],  surfaceInfo[2], surfaceInfo[3], "input, 3d activation"],
                 [1, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1],  surfaceInfo[2], surfaceInfo[3], "output, 3d activation"]
                ]

  dwcUSharps =  [[0, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1],  surfaceInfo[2], surfaceInfo[3], "input, 3d activation"],
                 [1, hwCaps.SurfaceType1DVector(),                   1,               1,               1, surfaceInfo[1], "weight, 1d vector"],
                 [2, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1],  surfaceInfo[2], surfaceInfo[3], "output, 3d activation"]
                ]

  bnUSharps =   [[0, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1],  surfaceInfo[2], surfaceInfo[3], "input, 3d activation"],
                 [1, hwCaps.SurfaceType1DVector(),                   1,               1,               1, surfaceInfo[1], "gamma/beta, 1d vector"],
                 [2, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1],  surfaceInfo[2], surfaceInfo[3], "output, 3d activation"]
                ]

  dwcBnUSharps = [[0, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1], surfaceInfo[2], surfaceInfo[3], "input, 3d activation"],
                  [1, hwCaps.SurfaceType1DVector(),                   1,               1,               1, surfaceInfo[1], "input weight, 1d vector"],
                  [2, hwCaps.SurfaceType1DVector(),                   1,               1,               1, surfaceInfo[1], "input gamma/beta, 1d vector"],
                  [3, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1],  surfaceInfo[2], surfaceInfo[3], "output, 3d activation"]
                 ]

  pbkUSharps =   [[0, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1], surfaceInfo[2], surfaceInfo[3], "input, 3d activation"],
                  [1, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1], surfaceInfo[2], surfaceInfo[3], "input weight, 1d vector"],
                  [2, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1], surfaceInfo[2], surfaceInfo[3], "input gamma/beta, 1d vector"],
                  [3, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1], surfaceInfo[2] * 2, surfaceInfo[3] * 2, "output, 3d activation"]
                 ]

  avgpoolUSharps =   [[0, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1], surfaceInfo[2], surfaceInfo[3], "input, 3d activation"],
                  [1, hwCaps.SurfaceType3DActivation(),  surfaceInfo[0],  surfaceInfo[1], (surfaceInfo[2] + 1) >> 1, (surfaceInfo[3] + 1) >> 1, "output, 3d activation"]
                 ]


  fc1USharps =   [[0, hwCaps.SurfaceType4DWeight(),    500, 20, 10,  10, "input, 4D weight, order is row, channel, height, width, channel/height/width are packed into col"],
                  [1, hwCaps.SurfaceType3DActivation(),  1, 20, 10,  10, "input, 3D activation, order is 1, channel, height, width, origin is previous layer's output, from hbm"],
                  [2, hwCaps.SurfaceType1DVector(),      1,  1,  1, 500, "input, 1D vector, bias"],
                  [3, hwCaps.SurfaceType1DVector(),      1,  1,  1, 500, "output, 1D vector, fc output, also serve as input to softmax"]
                 ]

  fc2USharps =   [[0, hwCaps.SurfaceType2DWeight(),      1,  1, 1000, 2048, "input, 2D weight"],
                  [1, hwCaps.SurfaceType1DVector(),      1,  1,    1, 2048, "input, 1D vector"],
                  [2, hwCaps.SurfaceType1DVector(),      1,  1,    1, 1000, "input, 1D vector, bias"],
                  [3, hwCaps.SurfaceType1DVector(),      1,  1,    1, 1000, "output, 1D vector, fc output, also serve as input to softmax"]
                 ]

  fc1backUsharps = [[0, hwCaps.SurfaceType1DVector(),      1,  1,   1,  500, "input, 1D vector, e.g., gradient from previous layer"],
                    [1, hwCaps.SurfaceType2DWeight(),      1,  1, 500, 2000, "input, 2D weight"],
                    [2, hwCaps.SurfaceType3DActivation(),  1, 20, 10,   10, "output, 3D activation, gradient to 3d activation"],
                    [3, hwCaps.SurfaceType3DActivation(),  1, 20, 10,  10, "input, 3D activation, order is channel, height, width, e.g., 3D activation in forward pass"],
                    [4, hwCaps.SurfaceType2DWeight(),      1,  1, 500, 2000, "output, 4D weight, e.g., gradient to weight"],
                   ]

  fc2BackUSharps = [[0, hwCaps.SurfaceType1DVector(),      1,  1,   1,   10, "input, 1D vector, gradient"],
                    [1, hwCaps.SurfaceType2DWeight(),      1,  1,  10,  500, "input, 2D weight"],
                    [2, hwCaps.SurfaceType1DVector(),      1,  1,   1,  500, "output, 1D vector, gradient to vector input in fwd pass"],
                    [3, hwCaps.SurfaceType2DWeight(),      1,  1,   1,  500, "input, 1D vector input in fwd pass"],
                    [4, hwCaps.SurfaceType1DVector(),      1,  1,  10,  500, "output, gradient to 2d weight"]
                 ]

  fusedOpGroup = [[
                   ["nop",    [],            [],         [0]],
                   ["nop",    [],            [],         [0]],
                   ["nop",    [],            [],         [0]],
                   ["nop",    [],            [],         [0]],
#                   ["fc",     fc2USharps,    [],         [0]],
#                   ["fc",     fc2BackUSharps,    [],         [0]],
#                   ["loss",   lossUSharps,   [],         [1, 1, 1]],
#                   ["reduce", reduceUSharps, [],         [0]],
#                   ["nop",     bnUSharps,     [156, 256], [0]]
                   ["dwc",   dwcBnUSharps,   [16, 156],  [3, 3, 1, 1, 1, 1, 0]]
#                   ["avgpool",    avgpoolUSharps,    [16, 156],  [7, 7, 3, 3, 1, 1, 0]]
                  ]
                 ]

  fusedOpGroupSize = len(fusedOpGroup)

  for z in range (cwarp.CWarpNumber()):
    cwarpId = z
    fusedOpId = 0

    br_print (indentstring + "MAIN_WARP_ENTRY_" + str(cwarpId) + ":")

    for fusedOp in fusedOpGroup:
      flowHandler.saveState()

      if (fusedOp[cwarpId][0] == "nop"):
        pass
      elif (fusedOp[cwarpId][0] == "avgpool"):
        avgpool.gen_layer_main_kernel(fusedOpId, fusedOpGroupSize, cwarpId, fusedOp[cwarpId], flowHandler)
      elif (fusedOp[cwarpId][0] == "pbk"):
        pbk.gen_layer_main_kernel(fusedOpId, fusedOpGroupSize, cwarpId, fusedOp[cwarpId], flowHandler)
      elif (fusedOp[cwarpId][0] == "dwc" or fusedOp[cwarpId][0] == "pool"):
        dwc.gen_layer_main_kernel(fusedOpId, fusedOpGroupSize, cwarpId, fusedOp[cwarpId], flowHandler)
      elif (fusedOp[cwarpId][0] == "fc"):
        fc.gen_layer_main_kernel(fusedOpId, fusedOpGroupSize, cwarpId, fusedOp[cwarpId], flowHandler)
      elif (fusedOp[cwarpId][0] == "loss"):
        loss.gen_layer_main_kernel(fusedOpId, fusedOpGroupSize, cwarpId, fusedOp[cwarpId], flowHandler)
      elif (fusedOp[cwarpId][0] == "reduce"):
        reduce.gen_layer_main_kernel(fusedOpId, fusedOpGroupSize, cwarpId, fusedOp[cwarpId], flowHandler)
      elif (fusedOp[cwarpId][0] == "bn"):
        bn.gen_layer_main_kernel(fusedOpId, fusedOpGroupSize, cwarpId, fusedOp[cwarpId], flowHandler)
      else:
        pass

      fusedOpId += 1

      flowHandler.restoreState()

    if (compiler.GetASMMode() != 0):
      br_print (("layer_" + str(fusedOpGroupSize) + "_warp_" + str(cwarpId) + "_main_kernel:").upper())

    br_print (indentstring + "end")
    br_print (indentstring + "\n\n\n\n\n\n")


if __name__ == '__main__':
  main()

