import os, re
import collections


def txt_to_dic(file_path):
    dic = {}
    with open(file_path, 'r') as file:
        find_lines = file.readlines()

    if not find_lines:
        print("Error: file not found: ", file_path)
        return dic

    for line in find_lines:
        kv = line.split(';')[0].split(':')
        dic[kv[-1].strip()] = kv[0].strip()
    return dic


def order_with_size(dic):
    #temp_dic = collections.OrderedDict()
    temp_list = []
    name_l = []
    for key in dic.keys():
        if key[:3] != 'fwd':
            continue
        params = re.findall(r"\d+\.?\d*", key)
        temp = []
        for ele in params:
            temp.append(int(ele))
        temp_list.append(temp)
    b = sorted(temp_list,
           key=(lambda x: [x[0], x[1], x[2], x[3], x[4], x[5], x[6], x[7], x[8], x[9], x[10], x[11]]))
    for x in b:
        name = 'fwd_in_' + str(x[0]) + 'x' + str(x[1]) + 'x' + str(x[2]) + 'x' +\
               str(x[3]) + '_w_' + str(x[4]) + 'x' + str(x[5]) + 'x' + str(x[6]) + 'x' +\
               str(x[7]) + '_px' + str(x[8]) + '_py' + str(x[9]) + '_s' + str(x[10]) + '_d' + str(x[11])
        name_l.append(name)

    temp_list = []
    for key in dic.keys():
        if key[:3] != 'mma':
            continue
        params = re.findall(r"\d+\.?\d*", key)
        temp = []
        for ele in params:
            temp.append(int(ele))
        temp_list.append(temp)
    b = sorted(temp_list,
           key=(lambda x: [x[0], x[1], x[2], x[3]]))
    for x in b:
        name = 'mma_in_' + str(x[0]) + 'x' + str(x[1]) + \
               '_w_' + str(x[2]) + 'x' + str(x[3])
        name_l.append(name)

    for key in dic.keys():
        if key[:3] == 'cbr':
            name_l.append(key)

    return name_l


def reset_name(name):
    num = name[3:]
    if len(num) == 3:
        return name

    if len(num) == 1:
        new_num = '00' + num
    elif len(num) == 2:
        new_num = '0' + num
    else:
        new_num = num
    new_name = name[:3] + new_num
    return new_name


def order_case(readme_path):
    dic = txt_to_dic(readme_path)
    lines = order_with_size(dic)
    index_fwd = 0
    index_mma = 0
    index_cbr = 0
    file = open('readme_new.txt', 'w')
    for name in lines:
        if name[:3] == 'fwd':
            line = reset_name(name[:3] + str(index_fwd)) + ": " + name
            index_fwd += 1
            file.write(line)
            file.write('\n')
        elif name[:3] == 'mma':
            line = reset_name(name[:3] + str(index_mma)) + ": " + name
            index_mma += 1
            file.write(line)
            file.write('\n')
        elif name[:3] == 'cbr':
            line = reset_name(name[:3] + str(index_cbr)) + ": " + name
            index_cbr += 1
            file.write(line)
            file.write('\n')
    file.close()


def main():
    readme_path = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'readme_old.txt')
    order_case(readme_path)


if __name__ == '__main__':
    main()
    
    