from BaseReg import Reg

class CSR(Reg):
    def __init__(self, no, instno):
        super(CSR, self).__init__(no, instno, "csr")
        # print("construct CSR:", no)
        self.max_reg = 1024
