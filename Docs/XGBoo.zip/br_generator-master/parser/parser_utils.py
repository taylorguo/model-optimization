from __future__ import print_function
import os
import json
import re
import string
import math
import subprocess
import time
import abc, six
import traceback
import contextlib
import numpy as np
from parser.function import AsmFun
from command_generator import utils
import code_generator.share.br_const_defs as bcd


biren_as = "biren-as "
biren_as_prefix = " -O1 "
llvm_objcopy = "llvm-objcopy "
llvm_objcopy_prefix = " -O binary -j .text "
llvm_readelf = "llvm-readelf "
xxd = 'xxd -e -g 8 -c 8 '
biren_llvm_mc = "llvm-mc"
biren_llvm_mc_prefix = " --triple=biren --filetype=asm --disassemble "
biren_llvm_mc_dis = "kernel_dis.txt"
biren_objdump = 'llvm-objdump --triple=biren --disassemble-zeroes -d '
brgen_root = utils.brgen_root
update_asm = True

class Program(object):
    def __init__(self):
        self.inst_num = 0
        self.tlr_num = 0
        self.csr_num = 0
        self.wsr_num = 0
        self.usharp_num = 0
        self.fun = list()
        self.cur_fun = None
        self.num_fun = 0
        self.cwarps = 0
        self.binsize = 0
        self.params = 0
        self.param_name = []
        self.param_csr = []
        self.atomic = False
        self.gmode = True

    def parse_asm(self, file):
        f = open(file)
        for line in f.readlines():
            line = line.strip()
            x = re.search(r'[\w]', line)
            cwarp_check = re.search(r'MAIN_WARP_ENTRY_[0-9]:', line)
            atomic_check = re.search(r'^at[a-z]', line)
            # gmode_check = re.search(r'ldconv|ldmma', line)
            gmode_check = re.search(r'CWARP', line)
            param_check = re.search(r'^//[ ]*c[\d-]*:', line)
            if line.strip().startswith("main:"):
                fname = line[0:-2]
                #print("functin name:", fname)
                self.cur_fun = AsmFun(fname)
                self.fun.append(self.cur_fun)
                self.num_fun += 1
            elif not line.strip().startswith("//") \
                    and not line.strip().startswith(".") \
                    and not line.strip().startswith("#") \
                    and x:
                # if .s not defined main function, create a default main block
                if self.cur_fun is None:
                    self.cur_fun = AsmFun("main")
                    self.fun.append(self.cur_fun)
                    self.num_fun += 1

                pos1 = line.find("//")
                pos2 = line.find("/*")

                if pos1 != -1:
                    line = line[0:pos1]
                if pos2 != -1:
                    line = line[0:pos2]
                self.cur_fun.insert_inst(line)
                self.inst_num += 1
            elif line.strip().startswith("//"):
                if param_check:
                    self.params += 1
                    csr, name = line.split(':')
                    self.param_name.append(name)
                    # save param csr
                    c = csr[csr.find("c") + 1:len(csr)]
                    c = c.split('-')
                    [self.param_csr.append(i) for i in c]
            # check cwarp
            if cwarp_check:
                self.cwarps += 1
            if atomic_check:
                self.atomic = True
            if gmode_check is not None:
                self.gmode = False

    def parse_reg(self):
        # reg_dict = dict()
        # reg_dict["tlr"] = list()
        # reg_dict["wsr"] = list()
        # reg_dict["csr"] = list()
        usharp_list = []
        insts = 0
        for i in range(self.num_fun):
            ff = self.fun[i]
            ff.analyze_function()
            reg_dict = ff.compute_regs()
            usharp = ff.compute_usharp()

            if usharp_list:
                for ele in usharp:
                    if ele not in usharp_list:
                        usharp_list.append(ele)
            else:
                usharp_list = usharp
            self.tlr_num += len(reg_dict["tlr"])
            self.csr_num += len(reg_dict["csr"])
            self.wsr_num += len(reg_dict["wsr"])
            insts += ff.get_insts()
        self.binsize = insts * 8
        self.usharp_num = len(usharp_list)
        #print("inst bin size is:", self.binsize, "cwarps:", self.cwarps)
        #print(self.tlr_num, self.csr_num, self.wsr_num)
        return self.tlr_num, self.csr_num, self.wsr_num, insts * 8, self.usharp_num

    def getJSONString(*args, **kwargs):
        join = ""
        for a in args:
            top1 = "NumOfKernels:" + str(a) + ","

        top2 = "Kernels:["
        rs = "{"
        for key in kwargs.keys():
            rs += join + '"' + str(key) + '":"' + str(kwargs[key]) + '"'
            join = ","
        rs += "}"
        top2 += rs + "]"
        top = "{" + top1 + top2 + "}"
        #print(top)
        return top

    def getDict(*args, **kwargs):
        jsdict = {}
        for key in kwargs.keys():
            jsdict[key] = kwargs[key]
        return jsdict

    def store_json(self, fname, value):
        with open(fname, 'w') as fw:
            json.dump(value, fw, sort_keys=False)

    def get_instbin(self):
        return self.binsize


def count_cwarp(file_path):
    kernel_name = file_path.split(os.sep)[-1]
    input_folder = os.path.abspath(os.path.dirname(file_path))
    files = os.listdir(input_folder)

    if kernel_name:
        ass_path = os.path.join(input_folder, kernel_name)
        find_lines = []
        with open(ass_path, 'r') as file:
            find_lines = file.readlines()
        if not find_lines:
            return 0

        count = 0
        for line in find_lines:
            while 'CWARP' in line and '_START' in line:
                count += 1
                line = find_lines[find_lines.index(line) + 1]
            if count != 0:
                break
        return count 


def read_pc(obj_file):
    startpc_name = 'startpc_'+str(os.getpid())+'.log'
    parent = os.path.abspath(os.path.dirname(brgen_root))
    asm_path = os.path.join(parent, "br_assembler",
                            utils.check_linux_type())
    if os.path.exists(asm_path):
        cmd = os.path.join(asm_path, llvm_readelf)
    else:
        cmd = os.path.join(os.path.join(os.environ['HOME'] , 'biren_tools'),
                            utils.check_linux_type(), llvm_readelf)
    cmd += ' -s  ' + obj_file + ' > '+startpc_name
    res = os.system(cmd)
    file = open(startpc_name, 'r')
    find_lines = file.readlines()
    file.close()
    os.remove(startpc_name)
    for line in find_lines:
        if 'FUNC' in line and 'GLOBAL' in line \
            and 'DEFAULT' in line and 'main' in line:
            params = line.split()
            pc = int('0x' + params[1], 16)
            return pc


def gen_metadata(fname, gmode, isa, cwarp=0):
    p = Program()
    p.parse_asm(fname)
    cwarp_num = cwarp if cwarp != 0 else count_cwarp(fname)
    enable_gmode = gmode
    isav = isa
    enable_cwarp = False

    if p.cwarps > 0 or cwarp_num > 0:
        enable_cwarp = True
        if cwarp_num == 0:
            cwarp_num = p.cwarps

    tlr_num, csr_num, wsr_num, insts, usharp = p.parse_reg()
    if csr_num < len(p.param_csr):
        csr_num = len(p.param_csr)
    if not p.gmode and not enable_gmode:
        tlr_num = 256
    gmode = p.gmode or enable_gmode
    obj_file = fname[:-2] + '.o'
    pc = read_pc(obj_file)

    # print('usharp num is:', usharp)
    # encoded = p.getJSONString(1, NumOfVec4RegUsed=math.ceil(tlr_num / 4),  NumOfCSRUsed=csr_num, CWarpEnabled=enable_cwarp,
    #                NumOfCWarp=p.cwarps, AtomicEnabled=0, NumOfUSharp=0, NumOfArguments=0, StartPC=0, InstrSizeInByte=p.binsize,
    #                GMode=False, ThreadIDx="r0", ISAVersion=isav)
    # decoded = json.loads(encoded)
    basef = os.path.basename(fname)
    kernel_name = basef.split('.')[0]
    bin_file = os.path.join(os.path.dirname(fname), kernel_name + '.bin')
    bin_size = os.path.getsize(bin_file)
    keykernels = [
        {'NumOfVec4RegUsed': int(math.ceil((tlr_num + 3) / 4)), 'KernelName': kernel_name, 'NumOfCSRUsed': csr_num,
         'CWarpEnabled': enable_cwarp,
         'NumOfCWarp': cwarp_num, 'AtomicEnabled': p.atomic, 'NumOfUSharp': usharp, 'NumOfArguments': p.params,
         'StartPC': pc, 'InstrSizeInByte': bin_size,
         'G-Mode': gmode, 'ThreadID.x': "r0", 'ISAVersion': isav}]
    decoded = p.getDict(NumOfKernels=1, Kernels=keykernels)
    parent = os.path.abspath(os.path.dirname(fname))
    filename = os.path.join(parent, fname.split(os.sep)[-1].split('.')[0] + ".json")
    if os.path.exists(filename):
        os.remove(filename)
    p.store_json(filename, decoded)

    def get_binsize():
        return bin_size

    return get_binsize


def gen_binary(fname, opt):
    parent = os.path.abspath(os.path.dirname(fname))
    outname = os.path.join(parent, 
            fname.split(os.sep)[-1].split('.')[0] + ".o")
    para = fname + " -o " + outname  + ' -no-br-autobundle'
    #para = fname + " -o " + outname
        
    parent_root = os.path.abspath(os.path.dirname(brgen_root))
    asm_path = os.path.join(parent_root, "br_assembler",
                            utils.check_linux_type())
    if os.path.exists(asm_path):
        cmd = os.path.join(asm_path, biren_as)
    else:
        cmd = os.path.join(os.path.join(os.environ['HOME'] , 'biren_tools'),
                            utils.check_linux_type(), biren_as)
    if opt:
      cmd += biren_as_prefix
    cmd += para
    if subprocess.call(cmd, shell=True):
        raise Exception("{} execute failed".format(cmd))
    binname = os.path.join(parent, fname.split(os.sep)[-1].split('.')[0] + ".bin")

    if os.path.exists(asm_path):
        cmd = os.path.join(asm_path, llvm_objcopy)
    else:
        cmd = os.path.join(os.path.join(os.environ['HOME'] , 'biren_tools'),
                            utils.check_linux_type(), llvm_objcopy)
    cmd += llvm_objcopy_prefix + outname + ' ' + binname
    if subprocess.call(cmd, shell=True):
        raise Exception("{} execute failed".format(cmd))
    def gen_file():
        return binname
    return gen_file


def verify_bin(fname, size):
    if os.path.isfile(fname):
        fsize = os.path.getsize(fname)
        if size != fsize:
            raise Exception("{0} size not equal to {1}".format(fname, size))
        #else:
        #    print("{0} size is matched with inst size:{1}".format(fname, size))
    else:
        raise Exception("{} not generated".format(fname))


def make_program(asmfile, gmode=False, isa="0.96", cwarp=0, opt=True):
    utils.update_assembler()
    assembly_name = asmfile.split(os.sep)[-1]
    if assembly_name[-2:] != '.s':
        files = os.listdir(asmfile)
        for file in files:
            if file[-2:] == '.s':
                asmfile = os.path.join(asmfile, file)
                break
    assert asmfile, "assembly file is not found"
    f = gen_binary(asmfile, opt)
    bin = gen_metadata(asmfile, gmode, isa, cwarp)

    if not opt:
        verify_bin(f(), bin())
