from BaseReg import Reg

class Imm(Reg):
    def __init__(self, val, isusharp, instno):
        super(Imm, self).__init__(val, instno, "Imm")
        # print("construct IMM:", val)
        self.max_reg = 32
        self.usharp = isusharp
        self.usharpno = val