from __future__ import print_function

import time
import abc, six
import traceback
import contextlib
import numpy as np

@six.add_metaclass(abc.ABCMeta)
class Reg(object):
    '''base reg class for define different regs, also can be used to find liveness'''
    def __init__(self, no, instno, reg_type):
        self.name = self.__class__.__name__
        self.type = reg_type
        self.regno = no
        self.uses = 0
        self.inst_no = instno


