from BaseReg import Reg

class TLR(Reg):
    def __init__(self, no, instno):
        super(TLR, self).__init__(no, instno, "tlr")
        #print("construct tlr:", no)
        self.max_reg = 256