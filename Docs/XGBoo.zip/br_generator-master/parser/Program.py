import parser_utils


if __name__ == "__main__":
    args = parse_args()
    parser_utils.make_program(args.asmfile, args.gmode,
                              args.isa, args.cwarp, args.opt)

