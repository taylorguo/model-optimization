from BaseReg import Reg

class SR(Reg):
    def __init__(self, no, instno):
        super(SR, self).__init__(no, instno, "sr")
        #print("construct SR:", no)
        self.max_reg = 16