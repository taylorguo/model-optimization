# ASM PARSER
This is used for parse ASM kernel to generate bin and metadata.js. Before use this parser, please make sure you have *biren-as* & *llvm-objcopy*, which will be used to generate binary.

## Arguments
+ asmfile
  - this argument is used to mark the file need to be processed. usage: **--asmfile=xxx.s**
+ gmode
  - this argument is used to enable gmode. usage: **--gmode=1**
+ cwarp
  - this argument is used to set cwarp number. usage: **--cwarp=1**
+ isa
  - this argument is used to set isa version. usage: **--isa=0.96**
+ opt
  - this argument is used to enable -O1 opt, which will insert nop and sync. usage: **--opt 1**
+ formatInst
  - this argument is used to check instruction format, not ready.
+ schedule
  - this argument is used to change the instruction order, not ready
+ liveness
  - this argument is used to check register, and can reuse some registers, not ready
+ log\_level
  - this argument is used to set different level of logging, not ready

## example
```python Program.py --asmfile=tests/mat-vec.s --gmode 1 --isa 0.96```
