from BaseReg import Reg

class WSR(Reg):
    def __init__(self, no, instno):
        super(WSR, self).__init__(no, instno, "wsr")
        #print("construct WSR:", no)
        self.max_reg = 32
