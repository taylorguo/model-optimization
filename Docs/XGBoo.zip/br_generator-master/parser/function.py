from __future__ import print_function

import os
import json
import re
import string
from BasicBlock import BB
from Instruction import Instruction

class AsmFun(object):
    def __init__(self, name):
        self.fname = name
        self.BBbuf = list()
        self.num_bb = 0
        self.cur_bb = None
        self.inst_num = 0
        self.usharp_num = 0
        self.inst_buf = list()
        self.insts = list()
        self.reg_dict = dict()
        self.reg_dict["tlr"]=[]
        self.reg_dict["wsr"]=[]
        self.reg_dict["csr"]=[]
        self.reg_dict["sr"]=[]
        self.reg_dict["Imm"]=[]
        self.reg_dict['usharp']=[]

    def build_function(self, inst):
        self.inst_buf.append(inst)
        #if self.cur_bb == None:
        #    self.cur_bb = BB()
        #self.cur_bb.insert_inst(inst)
    def insert_inst(self, inst):
        self.inst_buf.append(inst)
    def analyze_function(self):
        inst_num = 0
        if self.cur_bb is None:
            self.cur_bb = BB("main")
            self.BBbuf.append(self.cur_bb)
            self.num_bb += 1
        for line in self.inst_buf:
            if line.find(":") != -1:
                bbname = line[:-2]
                self.cur_bb = BB(bbname)
                self.BBbuf.append(self.cur_bb)
                self.num_bb += 1
                #print("bb num:", self.num_bb, " name:", bbname)
                # skip label
                continue
            inst = line.split(',')

            #skip bundle & signW
            if inst[0].startswith("&"):
                inst[0] = inst[0][1:len(inst[0])]
            #check nop and end inst
            if inst[0].find("nop") != -1 or inst[0].find("end") != -1:
                mcinst = Instruction(inst_num, inst, None, None)
                self.insts.append(mcinst)
                self.cur_bb.insert_inst(mcinst)
                inst_num += 1
                continue #skip nop
            #check single inst, no src
            if len(inst) == 1:
                sp = inst[0].split(" ")
                #print("inst is ", inst[0])
                #check no dsr
                if len(sp) == 1:
                    mcinst = Instruction(inst_num, inst, None, None)
                    self.insts.append(mcinst)
                    self.cur_bb.insert_inst(mcinst)
                elif len(sp) == 2:
                    mcinst = Instruction(inst_num, sp[0], sp[1], None)
                    self.insts.append(mcinst)
                    self.cur_bb.insert_inst(mcinst)
                    mcinst.compute_reg()
                inst_num += 1
                continue
            try:
                opc, dst = inst[0].split()
            except ValueError:
                raise Exception("process instruction {0} failed, please check it!".format(inst))
            #remove inst0 as opc & dst
            inst.pop(0)

            oprands_num = len(inst)
            operands = []
            src = []
            for i in range(oprands_num):
                src.append(inst[i])
            #print(opc, dst, src)

            mcinst =  Instruction(inst_num, opc, dst, src)
            mcinst.compute_reg()

            self.insts.append(mcinst)
            self.cur_bb.insert_inst(mcinst)
            dst_type, dst_regno = dst[0], dst[1:-1]

            src_num = len(src)
            inst_num += 1
        self.inst_num = inst_num
            #for i in range(src_num):
            #    src + str(i) + "_type" =  src[i][0]
            #    src + str(i) + "regno" = src[i][1:-1]
    def compute_regs(self):
        for inst in self.insts:

            for dst in inst.dstreg:
                if dst.regno not in self.reg_dict[dst.type]:
                    self.reg_dict[dst.type].append(dst.regno)
                    #if dst.type == "Imm" and dst.usharp:
                    #    print(dst.type)
                    #    self.usharp_num += 1
            for i in range(inst.src_num):
                for src1 in inst.srcreg[i]:
                    if src1.regno not in self.reg_dict[src1.type]:
                        self.reg_dict[src1.type].append(src1.regno)
                        #if src1.type == "Imm" and src1.usharp:
                        #    self.usharp_num += 1

        #for key, value in self.reg_dict.items():
        #    print(key, value)
        return self.reg_dict

    def compute_usharp(self):
        for inst in self.insts:
            #print("get_usharp is ", inst.get_usharp())
            for u in inst.get_usharp():
                if u not in self.reg_dict['usharp']:
                    self.reg_dict['usharp'].append(u)
        return self.reg_dict['usharp']

    def get_insts(self):
        return self.inst_num

