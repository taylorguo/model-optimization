class BB(object):
    def __init__(self, name):
        self.bname = name
        self.insts = list()
        self.prev = None
        self.next = None
        self.tlr = 0
        self.csr = 0
        self.wsr = 0
        self.RegDict = dict()
        self.inst_num = 0
    def insert_inst(self, inst):
        self.insts.append(inst)
        self.inst_num += 1