import re

from TLRReg import TLR
from CSRReg import CSR
from WSRReg import WSR
from WSRReg import WSR
from SRReg import SR
from Immediate import Imm

class Instruction(object):
    def __init__(self, inst_num, opc, dst, src):
        self.opc = opc
        self.dst = dst
        self.src = src
        self.inst_num = inst_num

        #default value below
        self.vec = 1
        self.reg_num = 1
        self.dstreg = []
        self.srcreg = []
        self.src_num = 0
        self.src1_regnum = 1
        self.dst_regnum = 1
        self.usharp = []
        self.lsc=['ld','st','atadd','stm', 'ldm', 'wred', 'sld', 'sldm', 'lddw']
        self.lst=['ldmma0','ldmma1','ldconv0','ldconv1','conv','mma']

    def get_usharp(self):
        return self.usharp

    def compute_reg(self):
        opc= self.opc.split('.')
        self.opc = opc[0]
        mods = opc[1:-1]
        for mod in mods:

            if mod in ["v2", "v3", "v4"]:
                self.vec = mod[1:len(mod)]
            elif mod in ["b32", "b64"]:
                self.reg_num = int(mod[1:3]) // 32
                self.src1_regnum = self.reg_num
                self.dst_regnum = self.reg_num
            elif mod in ["ww"]:
                self.src1_regnum = 2
                self.dst_regnum = 2

        expand_reg = self.reg_num * self.vec

        #process source operands
        if self.src is not None:
            self.src_num = len(self.src)

        self.srcreg = [[] for _ in range(self.src_num)]
        self.dst = self.dst.strip()

        for i in range(int(expand_reg)):
            dsts = self.dst[1:len(self.dst)]
            #special case for tensor lsc
            if dsts.isdigit() and self.dst[0] == 'u':
                isusharp = False

                if self.opc in self.lst:
                    isusharp = True
                #take tensor lsc source as dst
                #print("dst is ", self.dst)
                if self.dst not in self.usharp:
                    self.usharp.append(self.dst)
                #self.dstreg.append(Imm(self.dst, isusharp, self.inst_num))
                continue

            dstmods = dsts.split('.')
            dst = dstmods[0]
            d_mod = dstmods[1:len(dstmods)]

            if self.dst[0] == "r":
                for m in range(self.dst_regnum):
                    self.dstreg.append(TLR(int(dst) + i + m, self.inst_num))
            elif self.dst[0] == "q":
                for m in range(self.dst_regnum):
                    self.dstreg.append(WSR(int(dst) + i + m, self.inst_num))
            elif self.dst[0] == "g":
                for m in range(self.dst_regnum):
                    self.dstreg.append(SR(int(dst) + i + m, self.inst_num))
            #csr should be src, but here take it as dst for inst as mate... refine later
            elif self.dst[0] == "c":
                for m in range(self.dst_regnum):
                    self.dstreg.append(CSR(int(dst) + i + m, self.inst_num))

            for j in range(self.src_num):
                self.src[j] = self.src[j].strip()
                #src is imm
                #print(self.opc, self.src[j])
                if self.src[j].isdigit():
                    isusharp = False

                    if self.opc in self.lst or self.opc in self.lsc:
                        #print("opt is ", self.opc)
                        isusharp = True
                        if self.src[j] not in self.usharp:
                            self.usharp.append('u' + self.src[j])
                    else:
                        self.srcreg[j].append(Imm(self.src[j], isusharp, self.inst_num))

                    continue
                srcs = self.src[j][1:len(self.src[j])]

                # r0 is 0 null string
                #if len(srcs) == 0:
                #    srcs = "0"
                srcsmods = srcs.strip(';').split('.')
                src = srcsmods[0]
                contain_label = re.search('[a-z,A-Z,_]+', src)
                if contain_label:
                    src = src.split()[0]
                src_mod = srcsmods[1:-1]
                
                if self.src[j][0]  == "r":
                    if j == 0:
                        for m in range(self.src1_regnum):
                            self.srcreg[j].append(TLR(int(src) + i + m, self.inst_num))
                    else:
                        self.srcreg[j].append(TLR(int(src) + i, self.inst_num))
                elif self.src[j][0]  == "c":
                    if j == 0:
                        for m in range(self.src1_regnum):
                            self.srcreg[j].append(CSR(int(src) + i + m, self.inst_num))
                    else:
                        self.srcreg[j].append(CSR(int(src) + i, self.inst_num))
                    
                elif self.src[j][0]  == "q":
                    if j == 0:
                        for m in range(self.src1_regnum):
                            self.srcreg[j].append(WSR(int(src) + i + m, self.inst_num))
                    else:
                        self.srcreg[j].append(WSR(int(src) + i, self.inst_num))

                elif self.src[j][0]  == "g":
                    if j == 0:
                        for m in range(self.src1_regnum):
                            self.srcreg[j].append(SR(int(src) + i + m, self.inst_num))
                    else:
                        self.srcreg[j].append(SR(int(src) + i, self.inst_num))
                elif self.src[j][0]  == "u":
                    if src.isdigit():
                        isusharp = False
                        if self.opc in self.lsc or self.opc in self.lst:
                            #print("opt is ", self.opc)
                            if 'u' + src not in self.usharp:
                                self.usharp.append('u' + src)
                            isusharp = True
                        else:
                            self.srcreg[j].append(Imm(int(src), isusharp, self.inst_num))

         