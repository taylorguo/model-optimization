import os, shutil

def rename(path):
    for root, dirs, file_names in os.walk(path):
        root_name = root.split(os.sep)[-1]
        if root_name.startswith("fwd_in_"):
            params = root_name.split("_")
            print(params)
            if params[-1][0] == "d" and len(params[-1]) == 2:
                new_name = root_name + "_bf16xbf16xbf16"
            else:
                new_name = root_name[:-3] + "bf16xbf16xbf16_" + params[-1]
            old_path = os.path.join(root)
            new_path = os.path.join(os.path.abspath(os.path.dirname(root)), new_name)
            os.rename(old_path, new_path)

if __name__ == '__main__':
    rename(os.getcwd())
