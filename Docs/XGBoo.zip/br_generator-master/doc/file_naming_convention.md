# Purpose
In order to generate the command packet configurations automatically, the input files of each layer or operator needs to be named observing the following rules:

"header-modelname-passtype-usharpindex-layername-tensortype-layouttype-dimensions-format.bin"

# Explanations
## *header*: 
The prefix for Biren Tech. It is always "br" currently.

## *modelname*:
Specify the name of model: Fox example, Lenet, ResNet, Bert, dlrm etc, if not a model dump, can be UNIT.

## *passtype*: 
There two types of pass type, use "fwd" to indicate forward pass, use "bwd" to represent backward pass.

## *usharpindex*:
There are totally 256 u# in BR100, so "U0" to "U255" can be used to indicate which u# id is corresponded with.

## *layername*: 
Represent which layer this tensor is for with the layer's corresponding name. "conv0" indicates this is the first convolution layer. Names can like belows: bn0, relu0, pool0

## *tensortype*:
A indicates Activation; W indicates Weight, B indicates Bias, R indicates Reference.

## *layoutype*:
1DV indicates 1 dimension vector, 2DW indicates 2D weight, 2DA indicates 2D activation, 3DA indicates 3D activation, 4DW indicates 4D weight.

## *dimensions*:
Specify the dimension of the tensor. it follows format MxNxOxP format, for example, for 4D weight, it can be 10x32x3x3, 10 in here means there is 10 output channel, 32 means there is 32 input channel, 3x3 is the shape of the weight.

## *format*: 
Specify format of data element, "BF16" means its data type is bf16. "RGB888_Norm" means it is a normal RGB888 format.


# Examples
For example:
br-lenet-fwd-U0-conv0-W-4DW-10x32x3x3-bf16.bin, br-resnet-bwd-U3-relu4-A-3DA-1x32x64x64-bf16.bin, br-unit-bwd-U3-conv0-A-3DA-1x32x64x64-bf16.bin