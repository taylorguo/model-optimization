1.Prepare the running environment.
==========================================
    ---- Use cd to enter the root folder of this tool. for example: cd br_generator_1.0.0  
    ---- Run command "source ./setup.sh" to set up the environment variables.  
    Environment should be ready now for generating test vectors.  

2.If the test already exists
==========================================
    ---- Use cd to enter the corresponding foler of test under ./br_generator_1.0.0/vectors  
    ---- Overwrite the files under the input folder with the latest files that have been updated for some reasons.  
    ---- Run command "bash make_vectors.sh" to update the test vector.  
    ---- Copy the new generated test vectors from the vector folder under the corresponding test vector folder.  

Note: the file name must be completely the same as the old ones. And the file naming conventions must be followed.


3.Create a TCore test based on input files, output files, a kernel binary file, a kernel meta file provided from other side.
==========================================
**1. Use command (Windows)**  
Under ***br_generator*** directory, set the path using:
```
    setup.bat
    install_libs.bat
```

The paths are shown below:  
![Figure 3.1: set up path (windows)](https://github01.birentech.com/raw/arch/br_generator/master/doc/image/setup_win.PNG?token=AAAAAKX5MR7G4QSUMOJI4HS7KBGOA)  
  
Then create the TCore test using  
```
    make_vectors.bat
```
  

**2. Use terminal (Linux)**  
Under ***br_generator*** directory, set the path using:
```
    source setup.sh
    bash install_libs.sh
```

The paths are shown below:  
![Figure 3.2: set up path (linux)](https://github01.birentech.com/raw/arch/br_generator/master/doc/image/setup_linux.PNG?token=AAAAAKQA2PZAA5XUOXC63EK7KBGPU)  
  
Then create the TCore test using  
```
    bash make_vectors.sh
```
  
  
  
4.Create a TCore unit test with self-generated golden output
==========================================




Examples for updating a test vectors with a new *lenet_96_fc1_s.bin* file for tc1 test case of lenet FC1.  
----------------------------------------------
  
  
**1. Using command (Windows):**  
Under ***br_generator***, go into ***input*** folder using  
```
    cd vectors\test2_lenet\lenet_96_fc1\TC1\input
```

All these files are shown in figure below (highlighted part is what we need to copy to vector directory).  
![Figure eg.1: input folder (windows)](https://github01.birentech.com/raw/arch/br_generator/master/doc/image/win_dir.PNG?token=AAAAAKRTUG72JDSVW2YQP7C7KBGTA)  

Copy the ***inpu&output BIN files*** and ***lenet_96_fc1_s.bin*** to the ***vector*** directory using  
```
    copy *.bin ../vector
```

Then copy ***lenet_96_fc1_s.json*** and ***lenet_96_fc1_s.s*** to ***vector*** directory.  
```
    copy lenet_96_fc1_s.json ../vector
    copy lenet_96_fc1_s.s ../vector
```

If these files doesn't exist in ***vector*** directory, the following information will be shown in command.  
![Figure eg.2: copy files (not exist)](https://github01.birentech.com/raw/arch/br_generator/master/doc/image/copy_win.PNG?token=AAAAAKXYSCWSMCUCNOZXY3C7KBGUS)  
  
  

If these files exist in ***vector*** directory, the following information willbe shown in command. We need to type ***ALL*** to overwrite files.  
![Figure eg.3: copy files (exist)](https://github01.birentech.com/raw/arch/br_generator/master/doc/image/overwrite_win.PNG?token=AAAAAKWETFWJSJFHPFSZEPS7KBGWE)  

The output files have been copied into ***vector*** folder automatically, so we don't need to do anything about it.  
      


**2. Using terminal (Linux):**  
Under ***br_generator***, go into ***input*** folder using  
```
    cd vectors/test2_lenet/lenet_96_fc1/TC1/input
```

All these files are shown in figure below (highlighted part is what we need to copy to vector directory).  
![Figure eg.4: input folder (linux)](https://github01.birentech.com/raw/arch/br_generator/master/doc/image/linux_dir.PNG?token=AAAAAKTN2SB6F57JCZ45B7C7KBGXW)   

Copy the ***inpu&output BIN files*** and ***lenet_96_fc1_s.bin*** to the vector directory using  
```
    cp -r *.bin ../vector
```

Then copy ***lenet_96_fc1_s.json*** and ***lenet_96_fc1_s.s*** to vector directory.  
```
    cp -r lenet_96_fc1_s.json ../vector
    cp -r lenet_96_fc1_s.s ../vector
```

If these files exists in ***vector*** directory, these three commands will copy without feedback. If these files doesn't exist in ***vector*** directory, it will overwrite original files. Similarly, it wil not give feedback.  
The output files have been copied into ***vector*** folder automatically, so we don't need to do anything about it.  

5.Create an unit test with self-generated golden output and code-gen generated assemble file.
==========================================


