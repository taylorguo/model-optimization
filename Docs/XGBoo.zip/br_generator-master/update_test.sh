#!/bin/bash
echo $BASH_SOURCE
# python3 $(dirname $BASH_SOURCE)/vectors/copy_vector.py:
if [ "$1" == "-h" ]
  then
  echo "$1"
  python3 $(dirname $BASH_SOURCE)/command_generator/copy_vector.py -h
  
  else
  python3 $(dirname $BASH_SOURCE)/command_generator/copy_vector.py $*
fi
