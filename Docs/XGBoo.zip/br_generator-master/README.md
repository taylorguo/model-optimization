'''
This tool set is for generating the biren assemble file .s, generating command configuration file descirptors.json and corresponding command vectors. Actually, this tool set can be used  as single tool to genereate a unit operator test from basic shapes to the final command vector

'''

### Requirements

1. python3.5 above, this version is the default python version of Ubuntu18.04
2. "pip3 install xlrd" to install python package of xlrd for processing excel spreed sheet
3. "pip3 install bitstring" to install python package of bitstring for processing data with granularity of bits.
4. "pip3 install xlutils" to install some utitilities
5. "pip3 install opencv-python" to install opencv library
6. "pip3 install xlwt" to install xlwt library
7. "pip3 install openpyxl" to install openpyxl library
8. In order to do test, use "pip3 install pytest" to install the python test framework.

Usage: Sep.20, 2020

if it is the first time to run these tools, you need to run below command to install required libraries.

### install python libraries
./install_lib.sh 

### run unit test
source ./setup.sh
cd ../..
cd tests/code_gen
pytest test_resnet_head.py

## Pull Request

### Do format checker before push code
- **pip install pre-commit**
- **pip install flake8**
- **pip install black**
- **pre-commit install**

## Where is the assembler?
Usually, the first choice is **br_assembler** at the same hierarchy with br_generator. If it doesn't exist, the assembler will be obtained from **~/biren_tools**.

## How to run test case

cd br_generator/tests/code_gen

### run a file

pytest test_tcore_fwd_conv_1x8x16x16.py

### run a single test case 

python run_designated_case.py [case name]

For example: python run_designated_case.py test_fwd_in_4x32x28x28_w_32x32x3x3_hwshape_2x32x56x28_px0_py0_s2_d1

## How pytest check result

The following two steps should all passed before PR merged into master

### Compare .s diff

- when run pytest, result will be generateed at br_generator/tests/code_gen/vector/case, and run diff on case/vector/kernel.s and golden_vector/case/kernel.s

### Check cmodel run results


----continue-------
