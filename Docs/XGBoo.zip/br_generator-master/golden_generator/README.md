# readme for golden generator
Golden generator is for producing golden output tensor with Pytorch framework if Pytorch support.
if there is no corresponding Pytorch operator such BN, then a self-written algorithm will be applied to generate the golden data.
Further, this golden tensor including the input tensors will be provided as the input data of vector running on CModel, Emulator and Simulation. The so called golden output can be used to verify if output of CModel, Eulator and Simulation right or not.

## How to use

1. Entering folder under golden_generator: mini_test 
2. Finding corresponding python scripts related to the algorith.
3. run it, with command "python xxxx.py -h" to get the detailed input parameters
4. run it with wanted parameters.

For example: 
'''
[e00042@AR03 mini_test]$ python simple_conv.py -h
usage: simple_conv.py [-h] [--weight_data_type {s4,u8,s8,f8,bf8,bf16,fp32}]
                      [--input_data_type {s4,u8,s8,f8,bf8,bf16,fp32}]
                      [--output_data_type {s4,u8,s8,f8,bf8,bf16,fp32}]
                      [--type {fwd,bpa,bpw}] [--index INDEX] [--wred WRED]
                      [--expansion {False,True}]
                      input weight dilation stride padx pady

positional arguments:
  input                 Specify the input tenosr shape with format NxCxHxW,
                        for example: 1x32x8x8.
  weight                Specify the weight tensor shape with format OxIxKHxKW,
                        for example: 8x32x3x3.
  dilation              Specify the dilation, for example: 1.
  stride                Specify the stride, for example: 1.
  padx                  Specify the padx, for example: 1.
  pady                  Specify the pady, for example: 1.

optional arguments:
  -h, --help            show this help message and exit
  --weight_data_type {s4,u8,s8,f8,bf8,bf16,fp32}, -wdt {s4,u8,s8,f8,bf8,bf16,fp32}
                        Specify the weight data type, for example: bf16.
  --input_data_type {s4,u8,s8,f8,bf8,bf16,fp32}, -idt {s4,u8,s8,f8,bf8,bf16,fp32}
                        Specify the input data type, for example: bf16.
  --output_data_type {s4,u8,s8,f8,bf8,bf16,fp32}, -odt {s4,u8,s8,f8,bf8,bf16,fp32}
                        Specify the output data type, for example: bf16.
  --type {fwd,bpa,bpw}, -t {fwd,bpa,bpw}
                        Specify the operator type currently, only support fwd,
                        bpa, bpw
  --index INDEX, -i INDEX
                        Specify which weight is grandient weight generation
                        when bpw or "all" to generate all weight
  --wred WRED           enable conv wred eg. True
  --expansion {False,True}
                        enable axsis expansion,now only support top/bottom
'''

After that: run below command:

python simple_conv.py 1x32x8x8 8x32x3x3 1 1 0 0

The output input tensor and golden data is located:
/data/workspace/your employee number/demo/br_generator/command_generator/vectors/unit
