/**
 * Copyright 2020, Biren Technologies Inc.
 * All rights reserved.
 */

#include "BrTool.h"


//May multiply magic number: *1.001957 before conversion ?
void FloatToBFloat16(const float* src, uint16_t* dst, int64_t size) {
    const uint16_t* p = reinterpret_cast<const uint16_t*>(src);
    uint16_t* q = dst;

    for (; size != 0; p += 2, q++, size--) {
        *q = p[1];
    }
}

void BFloat16ToFloat(const uint16_t* src, float* dst, int64_t size) {
    const uint16_t* p = src;
    uint16_t* q = reinterpret_cast<uint16_t*>(dst);

    for (; size != 0; p++, q += 2, size--) {
        q[0] = 0;
        q[1] = *p;
    }
}
