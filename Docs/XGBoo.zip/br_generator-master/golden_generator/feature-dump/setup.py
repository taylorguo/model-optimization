# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
from setuptools import setup
from torch.utils.cpp_extension import CppExtension, BuildExtension
import setuptools
import torch

setup(description='A Biren PyTorch extension for dumping tensor value',
      author='xihanzhang',
      version='0.1.0',
      author_email='xihanzhang@birentech.com',
      name='BrThDump',
      ext_modules=[CppExtension('BrThDump', ['BrThDump.cpp',
                                             'BrTool.cpp'])],
      cmdclass={'build_ext': BuildExtension})


