#include <torch/torch.h>
#include <iostream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>

void FloatToBFloat16(const float* src, uint16_t* dst, int64_t size);
void BFloat16ToFloat(const uint16_t* src, float* dst, int64_t size);