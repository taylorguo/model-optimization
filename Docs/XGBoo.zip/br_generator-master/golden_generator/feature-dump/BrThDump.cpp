/**
 * Copyright 2020, Biren Technologies Inc.
 * All rights reserved.
 */
#include <torch/torch.h>
#include <iostream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>

#include "BrTool.h"

using namespace std;

#define _FC1W 512
#define _FC1WVAL 500
#define _FC1H 1000
#define _FC1SU 64 //swizzle unit
#define _FC1SUHalf (_FC1SU / 2)

#define _FC2W 64
#define _FC2WVAL 10
#define _FC2H 250
#define _FC2SU (_FC2W / 2)

//Follow the U# active tensor definition
//channel count of one block
#define _ACTT_CHNL 8
//elements count of active tensor per channel
#define _ACTT_PER_CHNL_ELEM 32
//one block size, including 4 sub blocks
#define _ACTT_BLK_SIZE 512
#define _ACTT_BLK_SIZE_WORD (_ACTT_BLK_SIZE >> 1)
#define _ACTT_CHNL_PER_SUBBLK 2
#define _ACTT_SUBBLK 4
#define _ACTT_SUBBLK_SIZE_WORD (_ACTT_BLK_SIZE_WORD / _ACTT_SUBBLK)
#define _ACCT_MBW 8
#define _ACCT_MBH 4
#define _ACCT_ALGN_IMG_W 8
#define _ACCT_ALGN_IMG_H 8

#define _WTT_CHNLI 32
#define _WTT_CHNLO 8
#define _WTT_CHNLI_WORD (_WTT_CHNLI >> 1)
#define _WTT_CHNLO_WORD (_WTT_CHNLO >> 1)
#define _WTT_PER_SUBBLK_ELEM 32
#define _WTT_BLK_SIZE 512
#define _WTT_BLK_SIZE_WORD (_WTT_BLK_SIZE >> 1)
#define _WTT_CHNL_PER_SUBBLK 2
#define _WTT_SUBBLK 4
#define _WTT_SUBBLK_SIZE_WORD (_WTT_BLK_SIZE_WORD / _WTT_SUBBLK)

#define BR_DEBUG 0
#define ROUND_UP(x, align) (((int) (x) + (align - 1)) & ~(align - 1))
#define ROUND_DOWN(x, align) ((int)(x) & ~(align - 1))

string dump_path;

void SetDumpPath(string pth){
    dump_path = pth;
    printf("Set dump path done: %s \n", dump_path.c_str());
}


at::Tensor Fc1inW;
at::Tensor Fc1inB;
at::Tensor Fc2inW;
at::Tensor Fc2inB;

at::Tensor ConvW[300];
at::Tensor ConvB[300];

void SetFc1Weight(at::Tensor inW){
    Fc1inW = inW;
}

void SetFc1Bias(at::Tensor inB){
    Fc1inB = inB;
}

void SetFc2Weight(at::Tensor inW){
    Fc2inW = inW;
}

void SetFc2Bias(at::Tensor inB){
    Fc2inB = inB;
}

void SetConvWeightByIdx(at::Tensor inW, int idx){
    ConvW[idx] = inW;
}

void SetConvBiasByIdx(at::Tensor inB, int idx){
    ConvB[idx] = inB;
}

void Dump1dTensorToBF16(string scope_str, string desc, int verbose, int idx){
    char pathbuf[1024];
    at::Tensor inb = ConvB[idx];
    int64_t bL = inb.size(0);

    printf("Tensor 1d length %d\n", bL);
    float* bdata = inb.data<float>();
    uint16_t* bdata_bf16 = (uint16_t*)malloc(bL * sizeof(uint16_t));
    AT_ASSERTM(bdata_bf16 != 0, "BR: Bad allocate bdata_bf16");
    memset(bdata_bf16, 0, bL * sizeof(uint16_t));
    FloatToBFloat16(bdata, bdata_bf16, bL);

    sprintf(pathbuf, "%s/%s-%s-%d-BF16.bin", dump_path.c_str(),
        scope_str.c_str(), desc.c_str(), bL);

    FILE *fp = fopen(pathbuf, "wb");
    AT_ASSERTM(fp != 0, "BR: can not open file.");
    if(verbose)
      printf("==== %s fp 0x%x\n", pathbuf, fp);

    fwrite(bdata_bf16, bL, sizeof(uint16_t), fp);
    printf("Dump path: %s  [%d bytes] dumped. /Verbose:%d\n", pathbuf, bL * sizeof(uint16_t), verbose);
    fclose(fp);

    free(bdata_bf16);
}

void DumpFc1TensorToBF16(string scope_str, string desc, int verbose){
    char pathbuf[1024];
    at::Tensor tinw = Fc1inW.t();
    int64_t wH = tinw.size(0);
    int64_t wW = tinw.size(1);

    printf("Tensor fc1 weight H %d W %d\n", wH, wW);
    float* wdata = tinw.data<float>();
    uint16_t* wdata_bf16 = (uint16_t*)malloc(wH * wW * sizeof(uint16_t));
    AT_ASSERTM(wdata_bf16 != 0, "BR: Bad allocate wdata_bf16");
    memset(wdata_bf16, 0, wH * wW * sizeof(uint16_t));
    if(verbose)
        printf("Tensor fc1 w0 %f\n", wdata[0]);
    FloatToBFloat16(wdata, wdata_bf16, wH * wW);
    if(verbose)
        printf("Tensor fc1 bf16 w0 0x%x\n", wdata_bf16[0]);

    int64_t bW = Fc1inB.size(0);
    printf("Tensor fc1 bias W %d\n", bW);
    float* bdata = Fc1inB.data<float>();
    uint16_t* bdata_bf16 = (uint16_t*)malloc(bW * sizeof(uint16_t));
    AT_ASSERTM(bdata_bf16 != 0, "BR: Bad allocate bdata_bf16");
    memset(bdata_bf16, 0, bW * sizeof(uint16_t));
    if(verbose)
        printf("Tensor fc1 b0 %f\n", bdata[0]);
    FloatToBFloat16(bdata, bdata_bf16, bW);
    if(verbose)
        printf("Tensor fc1 bf16 b0 0x%x\n", bdata_bf16[0]);

    sprintf(pathbuf, "%s/%s-%s-weight%dx%d-bias%d-BF16.bin", dump_path.c_str(),
        scope_str.c_str(), desc.c_str(), wH, wW, bW);

    //Allocate for U# storage and rank to U# layout
    int j, i;
    int stlen = _FC1W * (_FC1H + 1 /* with one row bias */);
    uint16_t* targ = (uint16_t*)malloc(stlen * sizeof(uint /* dword */));
    AT_ASSERTM(targ != 0, "BR: Bad allocate target Usharp storage");

    //weight
#if BR_DEBUG
    printf("######FC1\n");
#endif
    for(j = 0; j < _FC1H ; j++){
#if BR_DEBUG
        printf("##\n");
#endif
        for(i = 0; i < _FC1W ; i++){
            int wn = i / _FC1SU; //su index
            int winsu = i % _FC1SU; //offset in su
            int wn_h = winsu / _FC1SUHalf; //half index: 0-left half, 1-right half
            int winsu_h = i % _FC1SUHalf; //offset in each half
            int isPadding = 0;
            int idx0 = wn * _FC1SU; //In the source tensor domain
            int idx1 = 0;
            if(wn_h == 0){ //even
                idx0 = idx0 + (winsu_h << 1);
                if(idx0 >= _FC1WVAL) isPadding = 1;
            }
            else{ //odd
                idx0 =  idx0 + (winsu_h << 1) + 1;
                if(idx0 >= _FC1WVAL) isPadding = 1;
            }
#if BR_DEBUG
            printf("%d\t", idx0);
#endif
            if(!isPadding){
                idx0 += wW * (j << 1);
                idx1 = idx0 + wW; //next line, the same x
                targ[j * (_FC1W << 1) + (i << 1)] = wdata_bf16[idx0];
                targ[j * (_FC1W << 1) + (i << 1) + 1] = wdata_bf16[idx1];
#if BR_DEBUG
                printf("(%d,%d)\t", j, i);
#endif
            }
            else{
                targ[j * (_FC1W << 1) + (i << 1)] = 0xccdd;
                targ[j * (_FC1W << 1) + (i << 1) + 1] = 0xccdd;
            }
        }
#if BR_DEBUG
        printf("\n\n");
#endif
    }

    //bias
    int blen = _FC1W << 1;
    uint16_t* targ_b = &targ[_FC1H * (_FC1W << 1)];
    for(i = 0 ; i < blen ; i++){
        if(i < _FC1WVAL)
            targ_b[i] =  bdata_bf16[i];
        else
            targ_b[i] =  0xccdd;
    }

    FILE *fp = fopen(pathbuf, "wb");
    AT_ASSERTM(fp != 0, "BR: can not open file.");
    if(verbose)
      printf("==== %s fp 0x%x\n", pathbuf, fp);

    fwrite(targ, stlen, sizeof(uint), fp);
    printf("Dump path: %s  [%d bytes] dumped. /Verbose:%d\n", pathbuf, stlen * sizeof(uint), verbose);
    fclose(fp);

    free(wdata_bf16);
    free(bdata_bf16);
    free(targ);
}

//Input tensor to U# layout weight tensor
void DumpWeight4dTensorToBF16(string scope_str, string desc, int verbose, int idx){
    at::Tensor convw = ConvW[idx];
    int dim = convw.dim();
    AT_ASSERTM(dim == 4, "BR: Bad tensor dimension. Need 4");
    int wcnt = 0;
    char pathbuf[1024];
    int64_t Oc = convw.size(0);
    int64_t Ic = convw.size(1);
    int64_t kh = convw.size(2);
    int64_t kw = convw.size(3);

    int64_t sOc = convw.stride(0);
    int64_t sIc = convw.stride(1);
    int64_t skh = convw.stride(2);
    int64_t skw = convw.stride(3);
    // AT_ASSERTM(Ic <= 32, "BR: Can not support input channel > 32 now.");

    wcnt = Oc * Ic * kh * kw;
    sprintf(pathbuf, "%s/%s-%s-%dx%dx%dx%d-BF16.bin", dump_path.c_str(),
    scope_str.c_str(), desc.c_str(), Oc, Ic, kh, kw);

    printf("Tensor dim is %d\n", dim);
    printf("Tensor input size d %d c %d h %d w %d\n", Oc, Ic, kh, kw);
    printf("Tensor input stride d %d c %d h %d w %d\n", sOc, sIc, skh, skw);

    //The data is the pure tensor data
    float* data = convw.data<float>();

    //To bf16
    uint16_t* idata_bf16 = (uint16_t*)malloc(wcnt * sizeof(uint16_t));
    AT_ASSERTM(idata_bf16 != 0, "BR: Bad allocate idata_bf16");
    memset(idata_bf16, 0, wcnt * sizeof(uint16_t));
    FloatToBFloat16(data, idata_bf16, wcnt);


    int m, k, j, i, a, b, c;
    int kF = kh * kw;
    int iF = (Ic + _WTT_CHNLI - 1) /_WTT_CHNLI; // in channel factor
    int oF = (Oc + _WTT_CHNLO - 1) /_WTT_CHNLO; // out channel factor
    int wtt_blk_cnt = kF * iF * oF;

    printf("kF %d iF %d oF %d wtt_blk_cnt %d\n", kF, iF, oF, wtt_blk_cnt);
    uint16_t* targ = (uint16_t*)malloc(_WTT_BLK_SIZE * wtt_blk_cnt);
    // For debugging
    for (int l = 0; l < _WTT_BLK_SIZE * wtt_blk_cnt; l += 4)
    {
        uint8_t * temp = (uint8_t *)targ;
        temp[l + 0] = 0xef;
        temp[l + 1] = 0xbe;
        temp[l + 2] = 0xad;
        temp[l + 3] = 0xde;
    }

    // std::vector<uintptr_t>  used_indices;    // for debugging only
    int8_t *used_indices = (int8_t*)malloc(_WTT_BLK_SIZE * wtt_blk_cnt * sizeof(int8_t));
    memset(used_indices, 0, _WTT_BLK_SIZE * wtt_blk_cnt * sizeof(int8_t));

    printf("Total Usharp size is %d\n", _WTT_BLK_SIZE * wtt_blk_cnt);
    AT_ASSERTM(targ != 0, "BR: Bad allocate target Usharp storage");


    int klen = kw * kh; //per ic len
    for (a = 0; a < oF; a++) // a indicates o channels
    {
#if BR_DEBUG
        printf("======== a  = %d in oF = %d\n", a, oF);
#endif
        for (b = 0; b < iF; b++) // b indicates ichannels
        {
#if BR_DEBUG
            printf("======== b  = %d in iF = %d\n", b, iF);
#endif
            for (c = 0; c < klen; c++) // c indicates w index
            {
#if BR_DEBUG
                printf("======== c  = %d in klen = %d\n", c, klen);
#endif
                // m = a * b + (a - 1) * iF * kF;
                m = c + (b + a * iF) * klen;
#if BR_DEBUG
                printf("======== blk %d\n", m);
#endif
                for (k = 0; k < _WTT_SUBBLK; k++)   // 2 oc id combined into one subblock
                { // 0~3
#if BR_DEBUG
                    printf("==== subblock %d\n", k);
#endif
                    for (j = 0; j < _WTT_PER_SUBBLK_ELEM; j++)
                    {
                        // j is the input channel
                        // m % klen is the index in the kh*kw
                        int idxkhkw = c;
                        int nOcg = a; 
                        int ich = j + b * _WTT_CHNLI;
                        int och = (k << 1) + _WTT_CHNLO * nOcg; //channel cnt in one block
                        int noch = och + 1;

                        int dest_addr = m * _WTT_BLK_SIZE_WORD + k * _WTT_SUBBLK_SIZE_WORD + j * 2;
                        int src_addr = och * sOc + sIc * ich + idxkhkw;

                        int prev_dest_value = 0xbeef;
#if BR_DEBUG
                        printf("First channel: targ[dest_addr] = 0x%x, prev_dest_value = 0x%x\n", targ[dest_addr], prev_dest_value);
#endif
                        AT_ASSERTM(targ[dest_addr] == prev_dest_value, "BR: old value in dest_addr index %x is not 0xdeadbeef\n", dest_addr);

                        if (och < Oc && ich < Ic)
                        {
#if BR_DEBUG
                            printf("First channel: used_indices[src_addr] = 0x%x, src_addr = 0x%x\n", used_indices[src_addr], src_addr);
#endif
                            AT_ASSERTM(used_indices[src_addr] == 0, "BR: Source index 0x%x referenced more times\n", src_addr);
                            used_indices[src_addr] = 1;

                            targ[m * _WTT_BLK_SIZE_WORD + k * _WTT_SUBBLK_SIZE_WORD + j * 2] = idata_bf16[och * sOc + sIc * ich + idxkhkw];
                            // targ[m * _WTT_BLK_SIZE_WORD + k * _WTT_SUBBLK_SIZE_WORD + j * 2] = idata_bf16[new_even_src_addr];
#if BR_DEBUG
                            printf("Normal case: == m %d nOcg %d ich %d och %d idxkhkw %d\n", m, nOcg, ich, och, idxkhkw);
#endif
                        }
                        else
                        {
                            targ[m * _WTT_BLK_SIZE_WORD + k * _WTT_SUBBLK_SIZE_WORD + j * 2] = 0x0;
#if BR_DEBUG
                            printf("Padding case: == m %d nOcg %d ich %d och %d idxkhkw %d pad\n", m, nOcg, ich, och, idxkhkw);
#endif
                        }

                        dest_addr = m * _WTT_BLK_SIZE_WORD + k * _WTT_SUBBLK_SIZE_WORD + j * 2 + 1;
                        src_addr = noch * sOc + sIc * ich + idxkhkw;

                        prev_dest_value = 0xdead;
#if BR_DEBUG
                        printf("Second channel: targ[dest_addr] = 0x%x, prev_dest_value = 0x%x\n", targ[dest_addr], prev_dest_value);
#endif
                        AT_ASSERTM(targ[dest_addr] == prev_dest_value, "BR: old value in dest_addr index 0x%x is not 0xdeadbeef\n", dest_addr);
                        //dual channels in one loop to a DW
                        if (noch < Oc && ich < Ic)
                        {
#if BR_DEBUG
                            printf("Second channel: used_indices[src_addr] = 0x%x, src_addr = 0x%x\n", used_indices[src_addr], src_addr);
#endif
                            AT_ASSERTM(used_indices[src_addr] == 0, "BR: Source index %x referenced more times\n", src_addr);
                            used_indices[src_addr] = 1;

                            targ[m * _WTT_BLK_SIZE_WORD + k * _WTT_SUBBLK_SIZE_WORD + j * 2 + 1] = idata_bf16[noch * sOc + sIc * ich + idxkhkw];
                            // targ[m * _WTT_BLK_SIZE_WORD + k * _WTT_SUBBLK_SIZE_WORD + j * 2 + 1] = idata_bf16[new_odd_src_addr];
#if BR_DEBUG
                            printf("Normal case: == m %d nOcg %d ich %d och %d idxkhkw %d\n", m, nOcg, ich, och, idxkhkw);
#endif
                        }
                        else
                        {
                            targ[m * _WTT_BLK_SIZE_WORD + k * _WTT_SUBBLK_SIZE_WORD + j * 2 + 1] = 0x0;
#if BR_DEBUG
                            printf("Padding case: == m %d nOcg %d ich %d och %d idxkhkw %d pad\n", m, nOcg, ich, och, idxkhkw);
#endif
                        }
                    }
                }
            }
        }
    }

    FILE *fp = fopen(pathbuf, "wb");
    AT_ASSERTM(fp != 0, "BR: can not open file.");
    if(verbose)
      printf("==== %s fp 0x%x\n", pathbuf, fp);

    fwrite(targ, _WTT_BLK_SIZE * wtt_blk_cnt, 1, fp);
    printf("Dump path: %s  [%d bytes] dumped. /Verbose:%d\n", pathbuf, _WTT_BLK_SIZE * wtt_blk_cnt, verbose);
    fclose(fp);

    free(idata_bf16);
    free(targ);
}

void DumpFc2TensorToBF16(string scope_str, string desc, int verbose){
    char pathbuf[1024];
    at::Tensor tinw = Fc2inW.t();
    int64_t wH = tinw.size(0);
    int64_t wW = tinw.size(1);

    printf("Tensor fc2 weight H %d W %d\n", wH, wW);
    float* wdata = tinw.data<float>();
    uint16_t* wdata_bf16 = (uint16_t*)malloc(wH * wW * sizeof(uint16_t));
    AT_ASSERTM(wdata_bf16 != 0, "BR: Bad allocate wdata_bf16");
    memset(wdata_bf16, 0, wH * wW * sizeof(uint16_t));
    if(verbose)
        printf("Tensor fc2 w0 %f\n", wdata[0]);
    FloatToBFloat16(wdata, wdata_bf16, wH * wW);
    if(verbose)
        printf("Tensor fc2 bf16 w0 0x%x\n", wdata_bf16[0]);

    int64_t bW = Fc2inB.size(0);
    printf("Tensor fc2 bias W %d\n", bW);
    float* bdata = Fc2inB.data<float>();
    uint16_t* bdata_bf16 = (uint16_t*)malloc(bW * sizeof(uint16_t));
    AT_ASSERTM(bdata_bf16 != 0, "BR: Bad allocate bdata_bf16");
    memset(bdata_bf16, 0, bW * sizeof(uint16_t));
    if(verbose)
        printf("Tensor fc2 b0 %f\n", bdata[0]);
    FloatToBFloat16(bdata, bdata_bf16, bW);
    if(verbose)
        printf("Tensor fc2 bf16 b0 0x%x\n", bdata_bf16[0]);

    sprintf(pathbuf, "%s/%s-%s-weight%dx%d-bias%d.bin", dump_path.c_str(),
        scope_str.c_str(), desc.c_str(), wH, wW, bW);

    //Allocate for U# storage and rank to U# layout
    int j, i;
    int stlen = _FC2W * (_FC2H + 1 /* with one row bias */);
    uint16_t* targ = (uint16_t*)malloc(stlen * sizeof(uint /* dword */));
    AT_ASSERTM(targ != 0, "BR: Bad allocate target Usharp storage");

#if 1
    //weight
#if BR_DEBUG
    printf("######FC2\n");
#endif
    for(j = 0; j < _FC2H ; j++){
#if BR_DEBUG
        printf("##\n");
#endif
        for(i = 0; i < _FC2W ; i++){
            int wn = i / _FC2SU; //su index 0 or 1
            int winsu = i % _FC2SU; //offset in su 0~31
            int wn_h = wW >> 1; //half width of tensor: 5

            int isPadding = 0;
            int idx0 = 0; //In the source tensor domain
            int idx1 = 0;
            if(winsu < wn_h){
                idx0 = (winsu << 1) + wn; //2n+1, n=winsu,1:wn
#if BR_DEBUG
            printf("%d\t", idx0);
#endif
            }
            else isPadding = 1;

#if BR_DEBUG
            printf("%d\t", idx0);
#endif
            if(!isPadding){
                idx0 += wW * (j << 1);
                idx1 = idx0 + wW; //next line, the same x
                targ[j * (_FC2W << 1) + (i << 1)] = wdata_bf16[idx0];
                targ[j * (_FC2W << 1) + (i << 1) + 1] = wdata_bf16[idx1];
#if BR_DEBUG
                printf("(%d,%d)\t", j, i);
#endif
            }
            else{
                targ[j * (_FC2W << 1) + (i << 1)] = 0xccdd;
                targ[j * (_FC2W << 1) + (i << 1) + 1] = 0xccdd;
            }
        }
#if BR_DEBUG
        printf("\n\n");
#endif
    }

    //bias
    int blen = _FC2W << 1;
    uint16_t* targ_b = &targ[_FC2H * (_FC2W << 1)];
    for(i = 0 ; i < blen ; i++){
        if(i < _FC2WVAL)
            targ_b[i] =  bdata_bf16[i];
        else
            targ_b[i] =  0xccdd;
    }

    FILE *fp = fopen(pathbuf, "wb");
    AT_ASSERTM(fp != 0, "BR: can not open file.");
    if(verbose)
      printf("==== %s fp 0x%x\n", pathbuf, fp);

    fwrite(targ, stlen, sizeof(uint), fp);
    printf("Dump path: %s  [%d bytes] dumped. /Verbose:%d\n", pathbuf, stlen * sizeof(uint), verbose);
    fclose(fp);
#endif
    free(wdata_bf16);
    free(bdata_bf16);
    free(targ);
}

//3D Activation tensor to U# layout activation tensor
void DumpInput4dTensorToBF16(string scope_str, string desc, int verbose, at::Tensor input){
    int dim = input.dim();
    AT_ASSERTM(dim == 4, "BR: Bad tensor dimension. Need 4");
    int wcnt = 0;
    char pathbuf[1024];
    int64_t n = input.size(0);
    int64_t c = input.size(1);
    int64_t h = input.size(2);
    int64_t w = input.size(3);
    //print("n, c, h, w are ", n, c, h, w)

    int64_t sn = input.stride(0);
    int64_t sc = input.stride(1);
    int64_t sh = input.stride(2);
    int64_t sw = input.stride(3);

    wcnt = n * c * h * w;
    sprintf(pathbuf, "%s/%s-%s-%dx%dx%dx%d-BF16.bin", dump_path.c_str(),
    scope_str.c_str(), desc.c_str(), n, c, h, w);

    printf("Tensor dim is %d\n", dim);
    printf("Tensor input size d %d c %d h %d w %d\n", n, c, h, w);
    printf("Tensor input stride d %d c %d h %d w %d\n", sn, sc, sh, sw);

    //The data is the pure tensor data
    float* data = input.data<float>();

    //To bf16
    uint16_t* idata_bf16 = (uint16_t*)malloc(wcnt * sizeof(uint16_t));
    AT_ASSERTM(idata_bf16 != 0, "BR: Bad allocate idata_bf16");
    memset(idata_bf16, 0, wcnt * sizeof(uint16_t));
    FloatToBFloat16(data, idata_bf16, wcnt);

    int m, k, j, i;
    int Rh = ROUND_UP(h, _ACCT_ALGN_IMG_H); // As suntong's opinion
    int Rw = ROUND_UP(w, _ACCT_ALGN_IMG_W);
    int MBW = Rw / _ACCT_MBW;
    int MBH = Rh / _ACCT_MBH;
    int oF = (c + _ACTT_CHNL - 1) /_ACTT_CHNL; // out channel factor
    int hF = Rh * Rw / _ACTT_PER_CHNL_ELEM; // Block factor
    int actt_blk_cnt = hF * oF;

    printf("Rh %d Rw %d oF %d hF %d actt_blk_cnt %d\n", Rh, Rw, oF, hF, actt_blk_cnt);
    uint16_t* targ = (uint16_t*)malloc(_ACTT_BLK_SIZE * actt_blk_cnt);
    AT_ASSERTM(targ != 0, "BR: Bad allocate target Usharp storage");

    // For debugging
    for (int l = 0; l < _ACTT_BLK_SIZE * actt_blk_cnt; l += 4)
    {
        uint8_t * temp = (uint8_t *)targ;
        temp[l + 0] = 0xef;
        temp[l + 1] = 0xbe;
        temp[l + 2] = 0xad;
        temp[l + 3] = 0xde;
    }

    // std::vector<uintptr_t>  used_indices;    // for debugging only
    int8_t *used_indices = (int8_t*)malloc(_ACTT_BLK_SIZE * actt_blk_cnt * sizeof(int8_t));
    memset(used_indices, 0, _ACTT_BLK_SIZE * actt_blk_cnt * sizeof(int8_t));

    for(m = 0 ; m < actt_blk_cnt ; m++){
#if BR_DEBUG
        printf("======== blk %d\n", m);
#endif
        // macro block coordinate in vertical scan mode
        int mbw = (m % hF) / MBH; // Round in each block group
        int mbh = (m % hF) % MBH;
#if BR_DEBUG
            printf("==== mbw %d mbh %d\n", mbw, mbh);
#endif

        for(k = 0; k < _ACTT_SUBBLK ; k++){ // 0~3
#if BR_DEBUG
            printf("==== subblock %d\n", k);
#endif
            for(j = 0; j < _ACTT_PER_CHNL_ELEM ; j++){
                int isPadding = 0;
                // j is in the macro block(4x8 scan line mode)
                int nOcg = m / hF; // group of channel
                int och = (k << 1) + _ACTT_CHNL * nOcg; //channel cnt in one block
                int noch = och + 1;

                // Calculate absolute coordinate in src image
                // by the vertical scan order.
                // x,y are in the padded src image domain
                int x = mbw * _ACCT_MBW + (j % _ACCT_MBW);
                int y = mbh * _ACCT_MBH + (j / _ACCT_MBW);

                // Padding boundary checking
                if(x >= w) isPadding = 1;
                if(y >= h) isPadding = 1;

                int dest_addr = m * _ACTT_BLK_SIZE_WORD + k * _ACTT_SUBBLK_SIZE_WORD + j * 2;
                int src_addr = och * sc + y * sh + x;


#if BR_DEBUG
                printf("==== m %d nOcg %d och %d (x%d y%d) pd %d\n", m, nOcg, och, x, y, !(x < w && y < h && och < c));
#endif
                int prev_dest_value = 0xbeef;
#if BR_DEBUG
                printf("First channel: targ[dest_addr] = 0x%x, prev_dest_value = 0x%x\n", targ[dest_addr], prev_dest_value);
#endif
                AT_ASSERTM(targ[dest_addr] == prev_dest_value, "BR: old value in dest_addr index %x is not 0xdeadbeef\n", dest_addr);

                if(och < c){
                    uint16_t value = 0x0;
                    if(!isPadding)
                    {
#if BR_DEBUG
                        printf("First channel: used_indices[src_addr] = 0x%x, src_addr = 0x%x\n", used_indices[src_addr], src_addr);
#endif
                        AT_ASSERTM(used_indices[src_addr] == 0, "BR: Source index 0x%x referenced more times\n", src_addr);
                        used_indices[src_addr] = 1;
                        value = idata_bf16[och * sc + y * sh + x];
                    }
                    else
                      value = 0x0;

                    // targ's coordinate is in the sub-block domain
                    targ[m * _ACTT_BLK_SIZE_WORD + k * _ACTT_SUBBLK_SIZE_WORD
                    + j * 2] = value;
#if BR_DEBUG
                    printf("== nOcg %d och %d\n", nOcg, och);
#endif
                }
                else{
                    targ[m * _ACTT_BLK_SIZE_WORD + k * _ACTT_SUBBLK_SIZE_WORD
                    + j * 2] = 0x0;
#if BR_DEBUG
                    printf("== PAD: nOcg %d och %d\n", nOcg, och);
#endif
                }

                dest_addr = m * _ACTT_BLK_SIZE_WORD + k * _ACTT_SUBBLK_SIZE_WORD + j * 2 + 1;
                src_addr = noch * sc + y * sh + x;

                prev_dest_value = 0xdead;
#if BR_DEBUG
                printf("Second channel: targ[dest_addr] = 0x%x, prev_dest_value = 0x%x\n", targ[dest_addr], prev_dest_value);
#endif

                //dual channels in one loop to a DW
                if(noch < c){
                    uint16_t value = 0x0;
                    if(!isPadding)
                    {
#if BR_DEBUG
                        printf("Second channel: used_indices[src_addr] = 0x%x, src_addr = 0x%x\n", used_indices[src_addr], src_addr);
#endif
                        AT_ASSERTM(used_indices[src_addr] == 0, "BR: Source index %x referenced more times\n", src_addr);
                        used_indices[src_addr] = 1;
                        value = idata_bf16[noch * sc + y * sh + x];
                    }
                    else
                        value = 0x0;

                    targ[m * _ACTT_BLK_SIZE_WORD + k * _ACTT_SUBBLK_SIZE_WORD
                    + j * 2 + 1] = value;
                }
                else{
                    targ[m * _WTT_BLK_SIZE_WORD + k * _WTT_SUBBLK_SIZE_WORD
                    + j * 2 + 1] = 0x0;
                }
            }
        }
    }

    FILE *fp = fopen(pathbuf, "wb");
    AT_ASSERTM(fp != 0, "BR: can not open file.");
    if(verbose)
      printf("==== %s fp 0x%x\n", pathbuf, fp);

    fwrite(targ, _ACTT_BLK_SIZE * actt_blk_cnt, 1, fp);
    printf("Dump path: %s  [%d bytes] dumped. /Verbose:%d\n", pathbuf, _ACTT_BLK_SIZE * actt_blk_cnt, verbose);
    fclose(fp);

    free(idata_bf16);
    free(targ);
}

//This function must has input as 4D-tensor
at::Tensor Dump4dTensorToFloat32(string scope_str, string desc, int verbose, at::Tensor input){
    int dim = input.dim();
    AT_ASSERTM(dim == 4, "BR: Bad tensor dimension. Need 4");
    int wcnt = 0;
    char pathbuf[1024];
    int64_t n = input.size(0);
    int64_t c = input.size(1);
    int64_t h = input.size(2);
    int64_t w = input.size(3);

    int64_t sn = input.stride(0);
    int64_t sc = input.stride(1);
    int64_t sh = input.stride(2);
    int64_t sw = input.stride(3);

    wcnt = n * c * h * w;
    sprintf(pathbuf, "%s/%s-%s-N%d-C%d-H%d-W%d-Ns%d-Cs%d-Hs%d-Ws%d-F32.bin", dump_path.c_str(),
    scope_str.c_str(), desc.c_str(), n, c, h, w, sn, sc, sh, sw);

    printf("Tensor dim is %d\n", dim);
    printf("Tensor input size d %d c %d h %d w %d\n", n, c, h, w);
    printf("Tensor input stride d %d c %d h %d w %d\n", sn, sc, sh, sw);

    //The data is the pure tensor data
    float* data = input.data<float>();
/*
    int i, j, k, g;
    for(k = 0 ; k < n ; k++){
        for(g = 0; g < c ;g++){
            for(j = 0 ; j < h ; j ++){
                for(i = 0 ; i < w ; i++){
                    printf("%.2f\t", data[k*w*h*c + j*w + i]);
                }
                printf("\n");
            }
            printf("===========\n");
        }
        printf("=======================\n");
    }
*/

    FILE *fp = fopen(pathbuf, "wb");
    AT_ASSERTM(fp != 0, "BR: can not open file.");
    if(verbose)
      printf("==== %s fp 0x%x\n", pathbuf, fp);

    fwrite(data, wcnt, sizeof(float), fp);
    printf("Dump path: %s  [%d bytes] dumped. /Verbose:%d\n", pathbuf, wcnt * sizeof(float), verbose);
    fclose(fp);

    return input;
}


at::Tensor Dump4dTensorToBF16(string scope_str, string desc, int verbose, at::Tensor input){
    int dim = input.dim();
    AT_ASSERTM(dim == 4, "BR: Bad tensor dimension. Need 4");
    int wcnt = 0;
    char pathbuf[1024];
    int64_t n = input.size(0);
    int64_t c = input.size(1);
    int64_t h = input.size(2);
    int64_t w = input.size(3);

    int64_t sn = input.stride(0);
    int64_t sc = input.stride(1);
    int64_t sh = input.stride(2);
    int64_t sw = input.stride(3);

    wcnt = n * c * h * w;
    sprintf(pathbuf, "%s/%s-%s-N%d-C%d-H%d-W%d-Ns%d-Cs%d-Hs%d-Ws%d-BF16.bin", dump_path.c_str(),
    scope_str.c_str(), desc.c_str(), n, c, h, w, sn, sc, sh, sw);

    printf("Tensor dim is %d\n", dim);
    printf("Tensor input size d %d c %d h %d w %d\n", n, c, h, w);
    printf("Tensor input stride d %d c %d h %d w %d\n", sn, sc, sh, sw);

    //The data is the pure tensor data
    float* data = input.data<float>();

    //To bf16
    uint16_t* idata_bf16 = (uint16_t*)malloc(wcnt * sizeof(uint16_t));
    AT_ASSERTM(idata_bf16 != 0, "BR: Bad allocate idata_bf16");
    memset(idata_bf16, 0, wcnt * sizeof(uint16_t));
    FloatToBFloat16(data, idata_bf16, wcnt);

    FILE *fp = fopen(pathbuf, "wb");
    AT_ASSERTM(fp != 0, "BR: can not open file.");
    if(verbose)
      printf("==== %s fp 0x%x\n", pathbuf, fp);

    fwrite(idata_bf16, wcnt, sizeof(uint16_t), fp);
    printf("Dump path: %s  [%d bytes] dumped. /Verbose:%d\n", pathbuf, wcnt * sizeof(uint16_t), verbose);
    fclose(fp);

    free(idata_bf16);
    return input;
}


//This function must has input as 1D-tensor
at::Tensor Dump1dTensorToFloat32(string scope_str, string desc, int verbose, at::Tensor input){
    int dim = input.dim();
    AT_ASSERTM(dim == 1, "BR: Bad tensor dimension. Need 1");
    int wcnt = 0;
    char pathbuf[1024];
    int64_t n = input.size(0);
    int64_t sn = input.stride(0);

    wcnt = n;
    sprintf(pathbuf, "%s/%s-%s-L%d-Ls%d-F32.bin", dump_path.c_str(),
      scope_str.c_str(), desc.c_str(), n, sn);

    printf("Tensor dim is %d\n", dim);
    printf("Tensor input size length %d\n", n);
    printf("Tensor input stride \n", sn);

    //The data is the pure tensor data
    float* data = input.data<float>();

    FILE *fp = fopen(pathbuf, "wb");
    AT_ASSERTM(fp != 0, "BR: can not open file.");
    if(verbose)
      printf("==== %s fp 0x%x\n", pathbuf, fp);

    fwrite(data, wcnt, sizeof(float), fp);
    printf("Dump path: %s  [%d bytes] dumped. /Verbose:%d\n", pathbuf, wcnt * sizeof(float), verbose);
    fclose(fp);

    return input;
}


at::Tensor Dump1dTensorToBF16FC(string scope_str, string desc, int verbose, at::Tensor input){
    int dim = input.dim();
    AT_ASSERTM(dim == 1, "BR: Bad tensor dimension. Need 1");
    int wcnt = 0;
    char pathbuf[1024];
    int64_t n = input.size(0);
    int64_t sn = input.stride(0);

    wcnt = n;
    sprintf(pathbuf, "%s/%s-%s-L%d-Ls%d-BF16.bin", dump_path.c_str(),
      scope_str.c_str(), desc.c_str(), n, sn);

    printf("Tensor dim is %d\n", dim);
    printf("Tensor input size length %d\n", n);
    printf("Tensor input stride \n", sn);

    //The data is the pure tensor data
    float* data = input.data<float>();

    //To bf16
    uint16_t* idata_bf16 = (uint16_t*)malloc(wcnt * sizeof(uint16_t));
    AT_ASSERTM(idata_bf16 != 0, "BR: Bad allocate idata_bf16");
    memset(idata_bf16, 0, wcnt * sizeof(uint16_t));
    FloatToBFloat16(data, idata_bf16, wcnt);

    FILE *fp = fopen(pathbuf, "wb");
    AT_ASSERTM(fp != 0, "BR: can not open file.");
    if(verbose)
      printf("==== %s fp 0x%x\n", pathbuf, fp);

    fwrite(data, wcnt, sizeof(uint16_t), fp);
    printf("Dump path: %s  [%d bytes] dumped. /Verbose:%d\n", pathbuf, wcnt * sizeof(uint16_t), verbose);
    fclose(fp);

    free(idata_bf16);
    return input;
}


PYBIND11_MODULE(TORCH_EXTENSION_NAME, m){
    m.def("SetDumpPath", &SetDumpPath, "Set the path to dump.");
    m.def("SetConvWeightByIdx", &SetConvWeightByIdx, "Pass convolution weight tensor by index");
    m.def("SetConvBiasByIdx", &SetConvBiasByIdx, "Pass convolution bias tensor by index");
    m.def("SetFc1Weight", &SetFc1Weight, "Pass fc1 weight tensor");
    m.def("SetFc1Bias", &SetFc1Bias, "Pass fc1 bias tensor");
    m.def("SetFc2Weight", &SetFc2Weight, "Pass fc2 weight tensor");
    m.def("SetFc2Bias", &SetFc2Bias, "Pass fc2 bias tensor");
    m.def("Dump1dTensorToBF16", &Dump1dTensorToBF16, "Dump 1d tensor as bf16");
    m.def("DumpFc1TensorToBF16", &DumpFc1TensorToBF16, "Dump fc1 w/b tensor as bf16");
    m.def("DumpFc2TensorToBF16", &DumpFc2TensorToBF16, "Dump fc2 w/b tensor as bf16");
    m.def("DumpWeight4dTensorToBF16", &DumpWeight4dTensorToBF16, "Dump convolution weight 4d tensor as bf16");
    m.def("DumpInput4dTensorToBF16", &DumpInput4dTensorToBF16, "Dump input 4d tensor as bf16");
    m.def("Dump4dTensorToFloat32", &Dump4dTensorToFloat32, "Pass a 4D tensor to dump it!");
    m.def("Dump4dTensorToBF16", &Dump4dTensorToBF16, "Pass a 4D tensor to dump as bf16!");
    m.def("Dump1dTensorToFloat32", &Dump1dTensorToFloat32, "Pass a 1D tensor to dump it!");
   m.def("Dump1dTensorToBF16FC", &Dump1dTensorToBF16FC, "Pass a 1D tensor to dump as bf16!");
}

