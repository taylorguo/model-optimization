# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import math
from torch import nn
import numpy,copy
import time
import os
from br_reshape import *
import torch.nn.functional as F
import torch as pt

unit_dest_path = os.path.join('command_generator', 'vectors', 'unit')

def br_dump_tensor_in_fp32(file_info,n_tensor):

    root_path = os.path.abspath(os.path.dirname(__file__))

    file_name = os.path.join(root_path, 'save_tensor', 'br_format',"{}-fp32.bin".format(file_info))

    n_tensor.tofile(file_name)

def br_dump_tensor_in_bf16(file_info,n_tensor):

    root_path = os.path.abspath(os.path.dirname(__file__))

    file_name = os.path.join(root_path, 'save_tensor', 'br_format',"{}-bf16.bin".format(file_info))

    n_tensor.tofile(file_name)

def br_fp32Tobf16Tofp32(tensor):
    tensor_cp = tensor.clone().detach()
    shape_cp = tensor_cp.shape
    if len(tensor_cp.shape) == 1:
        tensor_cp = tensor_cp.reshape((1, tensor_cp.shape[0]))
    # convert from fp32 to bf16
    tensor_n = fp32Tobf16(tensor_cp.numpy())
    # convert from bf16 to fp32
    tensor_c = bf16Tofp32(tensor_n)
    tensor_c = tensor_c.reshape(shape_cp)
    tensor_c_cp = copy.deepcopy(tensor_c)
    return tensor_c_cp

def br_dump_ConvActivation_in_bf16(file_info,tensor):
    tensor_cp = tensor.clone().detach()
    shape_cp = tensor_cp.shape
    if len(tensor_cp.shape) == 1:
        tensor_cp = tensor_cp.reshape((1, tensor_cp.shape[0]))
    if tensor_cp.dtype == pt.int32:
        tensor_cp = tensor_cp.float()
    # convert from fp32 to bf16
    tensor_n = fp32Tobf16(tensor_cp.numpy())

    # # dump_tensor_in_bf16(file_info + '-without-conversion', tensor_n)
    # file_name_raw = file_info + '-without-conversion-bf16.bin'
    # tensor_n.tofile(file_name_raw)

    tensor_n_cp = copy.deepcopy(tensor_n)
    # align 8*8, tile 4*8,8-ch,
    tensor_ct = convertConvActivation(pt.from_numpy(tensor_n_cp).reshape(shape_cp))
    # dump data
    # br_dump_tensor_in_bf16(file_info, tensor_ct.numpy())
    file_name = file_info + '-bf16.bin'
    tensor_ct.numpy().tofile(file_name)


def br_dump_ConvActivation_in_fp32(file_info, tensor, dtype='fp32'):
    tensor_cp = tensor.clone().detach()
    shape_cp = tensor_cp.shape
    if len(tensor_cp.shape) == 1:
        tensor_cp = tensor_cp.reshape((1, tensor_cp.shape[0]))

    # align 8*8, tile 4*8,4-ch,
    tensor_ct = convertConvActivationFP32(tensor_cp)
    # dump data
    # br_dump_tensor_in_bf16(file_info, tensor_ct.numpy())
    file_name = file_info + '-' + dtype + '.bin'
    tensor_ct.numpy().tofile(file_name)


def br_dump_ConvActivation_in_s8_u8(file_info, tensor, dt):
    tensor_cp = tensor.clone().detach()
    shape_cp = tensor_cp.shape
    if len(tensor_cp.shape) == 1:
        tensor_cp = tensor_cp.reshape((1, tensor_cp.shape[0]))

    tensor_ct = convertConvActivationS8(tensor_cp)
    file_name = file_info + '-' + dt + '.bin'
    tensor_ct.numpy().tofile(file_name)


def br_dump_ConvWeight_in_bf16(file_info,tensor):
    tensor_cp = tensor.clone().detach()
    shape_cp = tensor_cp.shape
    if len(tensor_cp.shape) == 1:
        tensor_cp = tensor_cp.reshape((1, tensor_cp.shape[0]))
    # convert from fp32 to bf16
    tensor_n = fp32Tobf16(tensor_cp.numpy())

    # dump_tensor_in_bf16(file_info + '-without-conversion', tensor_n)

    tensor_n_cp = copy.deepcopy(tensor_n)
    # align 8*32
    tensor_ct = convertConvWeight(pt.from_numpy(tensor_n_cp).reshape(shape_cp))
    # dump data
    # dump_tensor_in_bf16(file_info, tensor_ct.numpy())
    file_name = file_info + '-bf16.bin'
    tensor_ct.numpy().tofile(file_name)


def br_dump_ConvWeight_in_fp32(file_info,tensor):
    tensor_cp = tensor.clone().detach()
    shape_cp = tensor_cp.shape
    if len(tensor_cp.shape) == 1:
        tensor_cp = tensor_cp.reshape((1, tensor_cp.shape[0]))

    # align 4*32
    tensor_ct = convertConvWeightFP32(tensor_cp)
    # dump data
    # dump_tensor_in_bf16(file_info, tensor_ct.numpy())
    file_name = file_info + '-fp32.bin'
    tensor_ct.numpy().tofile(file_name)


def br_dump_ConvWeight_in_s8_u8(file_info, tensor, dt):
    tensor_cp = tensor.clone().detach()
    shape_cp = tensor_cp.shape
    if len(tensor_cp.shape) == 1:
        tensor_cp = tensor_cp.reshape((1, tensor_cp.shape[0]))

    # align 4*32
    tensor_ct = convertConvWeightS8(tensor_cp)
    # dump data
    # dump_tensor_in_bf16(file_info, tensor_ct.numpy())
    file_name = file_info + '-' + dt + '.bin'
    tensor_ct.numpy().tofile(file_name)

ALIGN_OC = 64
BN_CACHE_C_TILE=2
# bn_cache:weight,bias,out_sq_sum,out_sum
def br_bn2d_dump_cache_in_fp32(file_info,cache_tuple,bn_include_sample_loop=False):
    if not bn_include_sample_loop:
        weight_tuple_cp = cache_tuple
        assert len(weight_tuple_cp)==4,\
            "make sure the weight_tuple is right"
        all_in_one = pt.cat(weight_tuple_cp,0).clone().detach()
        all_in_one = all_in_one.reshape(4,-1)
        #align to oc32
        h = all_in_one.shape[0]
        w = all_in_one.shape[1]
        align_w_block = int(math.ceil(w / ALIGN_OC))
        aligned_w = align_w_block * ALIGN_OC
        pad_w = aligned_w - w
        oc_aligned = F.pad(input=all_in_one, pad=(0, pad_w, 0, 0), mode="constant", value=0)
        print("bn cache shape is :",all_in_one.shape)
        total = oc_aligned.shape[0]*oc_aligned.shape[1]
        tensor_ct = oc_aligned.reshape(2,2,-1)
        c = tensor_ct.shape[2]
        c_block = int(math.ceil(c / BN_CACHE_C_TILE))
        tensor_ct = tensor_ct.reshape(2,2,c_block,BN_CACHE_C_TILE)
        tensor_ct = tensor_ct.permute(0,2,1,3)
        file_name = file_info.format(total) + '-fp32.bin'
        tensor_ct.numpy().tofile(file_name)
        return total
    else:
        assert isinstance(cache_tuple,list)
        sample_num = len(cache_tuple)
        weight_tuple_cp = cache_tuple
        weight_tp_list = []
        for i in range(sample_num):
            assert len(weight_tuple_cp[i])==4,\
                "make sure the weight_tuple is right"
            per_sample_all_in_one = pt.cat(weight_tuple_cp[i],0).clone().detach()
            per_sample_all_in_one = per_sample_all_in_one.reshape(4,-1)
            weight_tp_list.append(per_sample_all_in_one.unsqueeze(0))
        all_in_one = pt.cat(weight_tp_list,0)
        #align to oc32
        n = all_in_one.shape[0]
        h = all_in_one.shape[1]
        w = all_in_one.shape[2]
        align_w_block = int(math.ceil(w / ALIGN_OC))
        aligned_w = align_w_block * ALIGN_OC
        pad_w = aligned_w - w
        oc_aligned = F.pad(input=all_in_one, pad=(0, pad_w, 0, 0, 0, 0), mode="constant", value=0)
        print("bn cache shape is :",all_in_one.shape)
        total = oc_aligned.shape[2]*oc_aligned.shape[1]
        tensor_ct = oc_aligned.reshape(n,2,2,-1)
        c = tensor_ct.shape[3]
        c_block = int(math.ceil(c / BN_CACHE_C_TILE))
        tensor_ct = tensor_ct.reshape(n,2,2,c_block,BN_CACHE_C_TILE)
        tensor_ct = tensor_ct.permute(0,1,3,2,4)
        file_name = file_info.format(sample_num,total) + '-fp32.bin'
        tensor_ct.numpy().tofile(file_name)
        return total


def br_dump_conv_wred_in_fp32(file_info,wred_tuple):
    assert len(wred_tuple)==4,\
        "make sure the wred_tuple is right"
    all_in_one = pt.cat(wred_tuple,0).clone().detach()
    all_in_one = all_in_one.reshape(4,-1)
    #align to oc32
    h = all_in_one.shape[0]
    w = all_in_one.shape[1]
    align_w_block = int(math.ceil(w / ALIGN_OC))
    aligned_w = align_w_block * ALIGN_OC
    pad_w = aligned_w - w
    oc_aligned = F.pad(input=all_in_one, pad=(0, pad_w, 0, 0), mode="constant", value=0)
    print("conv wred shape is :",oc_aligned.shape)
    total = oc_aligned.shape[0]*oc_aligned.shape[1]
    tensor_ct = oc_aligned.reshape(2,2,-1)
    c = tensor_ct.shape[2]
    c_block = int(math.ceil(c / BN_CACHE_C_TILE))
    tensor_ct = tensor_ct.reshape(2,2,c_block,BN_CACHE_C_TILE)
    tensor_ct = tensor_ct.permute(0,2,1,3)
    file_name = file_info.format(total) + '-fp32.bin'
    tensor_ct.numpy().tofile(file_name)

def tuple_to_string(t):
    str1 = ''
    for ele in t:
        str1 = str1 + str(ele) + 'x'
    return str1[:-1]

def biren_mkdir(file_path):
    if not os.access(file_path, os.R_OK):
        # print("len of file path is ", len(file_path))
        if len(file_path) == 0:
            return
        path_last = len(file_path) - 1
        if (file_path[path_last] == '/' or file_path[path_last] == '\\'):
            file_path = file_path[0:path_last]
        # print("file_path is ", file_path)
        biren_mkdir(os.path.dirname(file_path))

        if not os.path.isfile(file_path):
            os.mkdir(file_path)


def br_dump_DWCWeight_in_bf16(file_info,tensor):
    tensor_cp = tensor.clone().detach()
    shape_cp = tensor_cp.shape
    if len(tensor_cp.shape) == 1:
        tensor_cp = tensor_cp.reshape((1, tensor_cp.shape[0]))
    # convert from fp32 to bf16
    tensor_n = fp32Tobf16(tensor_cp.numpy())

    # dump_tensor_in_bf16(file_info + '-without-conversion', tensor_n)

    tensor_n_cp = copy.deepcopy(tensor_n)
    # align 8*32
    tensor_ct = convertDWCWeight(pt.from_numpy(tensor_n_cp).reshape(shape_cp))
    # dump data
    # dump_tensor_in_bf16(file_info, tensor_ct.numpy())
    shape_ct = tensor_ct.shape
    total = shape_ct[0] * shape_ct[1] * shape_ct[2]
    file_name = file_info.format(total) + '-bf16.bin'
    tensor_ct.numpy().tofile(file_name)


def br_dump_DWCWeight_in_s8_u8(file_info,tensor,dtype):
    tensor_cp = tensor.clone().detach()
    shape_cp = tensor_cp.shape
    if len(tensor_cp.shape) == 1:
        tensor_cp = tensor_cp.reshape((1, tensor_cp.shape[0]))
    # convert from fp32 to bf16
    tensor_n = tensor_cp.numpy()
    tensor_n_cp = copy.deepcopy(tensor_n)
    # align 8*32
    tensor_ct = convertDWCWeight(pt.from_numpy(tensor_n_cp).reshape(shape_cp), dtype=dtype)
    # dump data
    # dump_tensor_in_bf16(file_info, tensor_ct.numpy())
    shape_ct = tensor_ct.shape
    total = shape_ct[0] * shape_ct[1] * shape_ct[2]
    file_name = file_info.format(total) + '-{}.bin'.format(dtype)
    tensor_ct.numpy().tofile(file_name)