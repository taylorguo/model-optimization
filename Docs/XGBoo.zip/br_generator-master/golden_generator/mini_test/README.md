This is the script for generating the golden result of simple convolution tests.

It is the the starting point, more test logic can be added to product more test goldens.