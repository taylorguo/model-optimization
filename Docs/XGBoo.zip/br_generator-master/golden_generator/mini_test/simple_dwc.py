# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import torch
import torch.nn as nn
import torch.nn.functional as F
import argparse
import shutil,copy
from command_generator import utils
from simple_reduce import br_sum,br_sq_sum
from br_dump import *

def br_dwc(tensor_image, kernel, dilation_value, stride_value, padding_value):
    if dilation_value > 1:
        if tensor_image.dtype == torch.int32:
            tensor_image = tensor_image.double()
            kernel = kernel.double()
    weight = nn.Parameter(data=kernel, requires_grad=False)

    group_num = tensor_image.shape[1]
    result = F.conv2d(tensor_image, weight, bias=None, stride=stride_value,
                      padding=padding_value, dilation=dilation_value, groups=group_num)
    # print("result is ", result)
    return result

def construct_fake_tensor_batch(shape=(2, 3, 224, 224), data_pattern="", value=None, dtype="bf16"):
    if data_pattern == "random":
        if dtype == "bf16" or dtype == "fp32":
            return torch.randn(shape)
        elif dtype == "s8":
            return torch.random(shape).char()
        elif dtype == "u8":
            return torch.random(shape).byte()
    elif data_pattern == "one":
        if dtype == "bf16" or dtype == "fp32":
            return torch.ones(shape)
        elif dtype == "s8":
            return torch.ones(shape).char()
        elif dtype == "u8":
            return torch.ones(shape).byte()

    else:
        t = []
        total = shape[0]*shape[1]*shape[2]*shape[3]
        if value == None:
            for i in range(total):
                t.append(i)
        else:
            for i in range(total):
                t.append(value)
        # return torch.FloatTensor(t).reshape(shape)
        if dtype == "fp32" or dtype == "bf16":
            tensor = torch.FloatTensor(t).reshape(shape)
        elif dtype == "s8":
            tensor = torch.CharTensor(t).reshape(shape)
        elif dtype == "u8":
            tensor = torch.ByteTensor(t).reshape(shape)
        return tensor

def construct_fake_kernel(shape=(64, 3, 7, 7), data_pattern="", value=None, dtype="bf16"):
    if data_pattern == "random":
        if dtype == "bf16" or dtype == "fp32":
            return torch.randn(shape)
        elif dtype == "s8":
            return torch.random(shape).char()
        elif dtype == "u8":
            return torch.random(shape).byte()
    elif data_pattern == "one":
        if dtype == "bf16" or dtype == "fp32":
            return torch.ones(shape)
        elif dtype == "s8":
            return torch.ones(shape).char()
        elif dtype == "u8":
            return torch.ones(shape).byte()
    else:
        t = []
        total = shape[0]*shape[1]*shape[2]*shape[3]
        if value == None:
            for i in range(total):
                t.append(i+1.0)
        else:
            for i in range(total):
                t.append(value)
        # return torch.FloatTensor(t).reshape(shape)
        if dtype == "fp32" or dtype == "bf16":
            tensor = torch.FloatTensor(t).reshape(shape)
        elif dtype == "s8":
            tensor = torch.CharTensor(t).reshape(shape)
        elif dtype == "u8":
            tensor = torch.ByteTensor(t).reshape(shape)
        return tensor


def gen_simple_dwc(input_shape,
                   weight_shape,
                   dilation_value,
                   stride_value,
                   padding_value,
                   dest_path=None,
                   input_dtype="bf16",
                   weight_dtype="bf16",
                   output_dtype="bf16"):
    assert (len(input_shape) == 4), "make sure the shape of input_shape is 4D"
    assert (len(weight_shape) == 4), "make sure the shape of weight_shape is 4D"
    assert (input_shape[1] == weight_shape[0]), "make sure the input channel equal to output channel"
    assert (1 == weight_shape[1]), "make sure the input channel matches for in_tensor and kernel"
    input_tensor = construct_fake_tensor_batch(shape=input_shape, dtype=input_dtype)
    weight = construct_fake_kernel(shape=weight_shape, dtype=weight_dtype)
    if input_dtype == "bf16":
        input_tensor = torch.from_numpy(br_fp32Tobf16Tofp32(input_tensor))
    if weight_dtype == "bf16":
        weight = torch.from_numpy(br_fp32Tobf16Tofp32(weight))
    input_old = copy.deepcopy(input_tensor)
    weight_old = copy.deepcopy(weight)
    if input_dtype == "s8" or input_dtype == "u8":
        if weight_dtype == "s8" or weight_dtype == "u8":
            input_tensor = input_tensor.int()
            weight = weight.int()
        else:
            input_tensor = input_tensor.float()
    elif input_dtype == "bf16":
        weight = weight.float()
    output = br_dwc(input_tensor, weight, dilation_value, stride_value,
                    padding_value)
    output_shape = output.shape
    if not dest_path:
        target_addr = os.path.join(utils.brgen_root, unit_dest_path)
        folder_name = 'dwc_in_' + tuple_to_string(
            input_shape) + '_weight_' + tuple_to_string(
                weight_shape) + '_out_' + tuple_to_string(
                    output_shape) + '_dt_{}x{}x{}'.format(input_dtype,weight_dtype,output_dtype)
        target_path = os.path.join(target_addr, folder_name, 'input')
    else:
        target_path = os.path.join(dest_path, 'input')
    if os.path.exists(target_path):
        shutil.rmtree(target_path)
    biren_mkdir(target_path)

    file_info = os.path.join(
        target_path,
        "br-unit-fwd-U0-dwc-A-4DA-" + tuple_to_string(input_shape))
    if input_dtype == "bf16":
        br_dump_ConvActivation_in_bf16(file_info, input_old)
    elif input_dtype == "s8" or input_dtype == "u8":
        br_dump_ConvActivation_in_s8_u8(file_info, input_old, input_dtype)

    file_info = os.path.join(target_path, "br-unit-fwd-U1-dwc-R-1DV-1x1x1x{}")
    if weight_dtype == "bf16":
        br_dump_DWCWeight_in_bf16(file_info, weight_old)
    elif weight_dtype == "s8" or weight_dtype == "u8":
        br_dump_DWCWeight_in_s8_u8(file_info, weight_old, weight_dtype)

    file_info = os.path.join(
        target_path,
        "br-unit-fwd-U2-dwc-A-4DA-" + tuple_to_string(output_shape))
    if output_dtype == "bf16":
        if output.dtype == torch.float64:
            output = output.float()
        assert output.dtype == torch.float32 or output.dtype == torch.int32, "please double check what output dtype is used"
        br_dump_ConvActivation_in_bf16(file_info, output)
    elif output_dtype == "s32" or output_dtype == "fp32":
        assert output.dtype == torch.int32, "please double check the act&&weight dtype of DWC"
        br_dump_ConvActivation_in_fp32(file_info, output, output_dtype)
    else:
        raise NotImplementedError

    return target_path


def get_params():
    parser = argparse.ArgumentParser()
    parser.add_argument('input', default='2x8x8x8',\
        help='Specify the input tenosr shape with format NxCxHxW,for example: 2x8x8x8.')

    parser.add_argument('weight', default='8x1x3x3',\
        help='Specify the weight tensor shape with format OxIxKHxKW,for example: 8x1x3x3.')

    parser.add_argument('dilation', default='1',\
        help='Specify the dilation,for example: 1.')

    parser.add_argument('stride', default='1',\
        help='Specify the stride, for example: 1.')

    parser.add_argument('padx', default='1',\
        help='Specify the padx,for example: 1.')

    parser.add_argument('pady', default='1',\
        help='Specify the pady,for example: 1.')

    parser.add_argument('--weight_data_type', '-wdt', default='bf16',\
        choices=utils.data_types,
        help='Specify the weight data type, for example: bf16.')
    parser.add_argument('--input_data_type', '-idt', default='bf16',\
        choices=utils.data_types,
        help='Specify the input data type, for example: bf16.')
    parser.add_argument('--output_data_type', '-odt', default='s32',\
        choices=["bf16","fp32","s32"],
        help='Specify the output data type, for example: bf16.')

    parser.add_argument('--type', '-t', default="fwd", \
        choices=["fwd", "bpa", "bpw"],help='Specify the operator type currently, only support fwd, bpa, bpw')
    return parser

if __name__ == '__main__':
    parser = get_params()
    args = parser.parse_args()

    input_shape = [int(e) for e in args.input.split("x")]

    weight_shape = [int(e) for e in args.weight.split("x")]

    dilation_value = int(args.dilation)
    stride_value = int(args.stride)
    padx_value = int(args.padx)
    pady_value = int(args.pady)
    padding_value = (pady_value, padx_value)
    weight_dt = args.weight_data_type
    input_dt = args.input_data_type
    output_dt = args.output_data_type
    operator_type = args.type

    if (input_dt != "bf16" and input_dt != "s8") or (
            output_dt != "bf16"
            and output_dt != "s32") or (weight_dt != "bf16"
                                       and weight_dt != "s8"):
        raise NotImplementedError

    if operator_type != "fwd":
        raise NotImplementedError

    ret = gen_simple_dwc(input_shape,
                         weight_shape,
                         dilation_value,
                         stride_value,
                         padding_value,
                         input_dtype=input_dt,
                         weight_dtype=weight_dt,
                         output_dtype=output_dt)
    print("target path is :", ret)
