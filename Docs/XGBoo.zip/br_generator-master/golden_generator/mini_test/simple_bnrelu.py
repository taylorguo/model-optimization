# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import torch
import torch.nn as nn
import torch.nn.functional as F
import argparse
import shutil
from command_generator import utils
from simple_reduce import br_sum,br_sq_sum
from br_dump import *
from simple_bn import br_bn2d
from simple_relu import br_relu
import copy
def br_bn2relu(tensor_batch,running_mean,running_var,\
    weight,bias,is_training=True,momentum=0.1,eps=1e-05,inplace = False):
    tmp = br_bn2d(tensor_batch,running_mean,running_var,weight,bias,is_training,momentum,eps)
    tmp_cp = copy.deepcopy(tmp)
    ret = br_relu(tmp_cp,inplace)
    return tmp,ret

def construct_fake_tensor_batch(shape=(64,64,56,56), data_pattern="", value=None):
    if data_pattern == "random":
        return torch.randn(shape)
    elif data_pattern == "one":
        return torch.ones(shape)
    else:
        t = []
        total = shape[0]*shape[1]*shape[2]*shape[3]
        if value == None:
            for i in range(total):
                t.append(i)
        else:
            for i in range(total):
                t.append(value)
        return torch.FloatTensor(t).reshape(shape)

def construct_fake_weight(shape):
    return torch.ones(shape)

def construct_fake_bias(shape):
    return torch.zeros(shape)

def br_bn2relu_test(input,is_faked=True):
    if is_faked == True:
        batch_sample_shape = tuple(input.size())
        weight = construct_fake_weight(batch_sample_shape)
        bias = construct_fake_bias(batch_sample_shape)
        x_sum = br_sum(input)
        x_sq_sum = br_sq_sum(input)
        output = br_bn2relu(input,x_sum,x_sq_sum,weight,bias)
        return input,weight,bias,x_sq_sum,x_sum,output
    else:
        raise NotImplementedError

def gen_simple_bn2relu(input_tensor,weight_shape,bias_shape,\
    is_training=True,momentum=0.1,eps=1e-05,inplace=False, dest_path=None):

    input_shape = input_tensor.shape
    if not dest_path:
        target_addr = os.path.join(utils.brgen_root, unit_dest_path)
        folder_name = 'bn2relu_in_' + tuple_to_string(input_shape) + '_cache_4x' + str(weight_shape[0])\
            + '_out_' + tuple_to_string(input_shape) + '_dt_bf16xfp32xbf16'
        print("folder name is :",folder_name)
        target_path = os.path.join(target_addr, folder_name, 'input')
    else:
        target_path = os.path.join(dest_path, 'input')
    if os.path.exists(target_path):
        shutil.rmtree(target_path)
    biren_mkdir(target_path)

    # check the input from dump data
    input_tensor = pt.from_numpy(br_fp32Tobf16Tofp32(input_tensor))
    weight = construct_fake_weight(weight_shape[0])
    bias = construct_fake_bias(bias_shape[0])
    x_sum = br_sum(input_tensor)
    x_sq_sum = br_sq_sum(input_tensor)
    output = br_bn2relu(input_tensor,x_sum,x_sq_sum,weight,bias,is_training,momentum,eps,inplace)
    
    file_info = os.path.join(target_path,"br-unit-fwd-U0-bn-A-4DA-" + tuple_to_string(input_shape))
    br_dump_ConvActivation_in_bf16(file_info,input_tensor)
    
    tensor_tp = (weight,bias,x_sum,x_sq_sum)
    file_info = os.path.join(target_path,"br-unit-fwd-U1-bn-R-1DV-1x1x1x{}")
    br_bn2d_dump_cache_in_fp32(file_info,tensor_tp)

    file_info = os.path.join(target_path,"br-unit-fwd-U2-relu-A-4DA-" + tuple_to_string(input_shape))
    br_dump_ConvActivation_in_bf16(file_info,output[0])

    file_info = os.path.join(target_path,"br-unit-fwd-U3-relu-A-4DA-" + tuple_to_string(input_shape))
    br_dump_ConvActivation_in_bf16(file_info,output[1])

    return target_path

def get_params():
    parser = argparse.ArgumentParser()

    parser.add_argument('input', default='2x64x122x122',\
        help='Specify the input tenosr shape with format NxCxHxW,for example: 1x64x8x8.')

    parser.add_argument('weight', default='1x64',\
        help='Specify the weight tensor shape with format 1xN,for example: 1x64.')

    parser.add_argument('bias', default='1x64',\
        help='Specify the bias tensor shape with format 1xN,for example: 1x64.')

    parser.add_argument('--is_training', type=bool, default=True, \
        help='Specify the dilation, for example: True')

    parser.add_argument('--momentum', default='0.1', \
        help='Specify the momentum,for example: 0.1')

    parser.add_argument('--eps', default='1e-05', \
        help='Specify the padx,for example: 1e-05')

    parser.add_argument('--weight_data_type', '-wdt', default='fp32',\
        choices=utils.data_types,\
            help='Specify the weight data type, for example: bf16.')

    parser.add_argument('--input_data_type', '-idt', default='bf16',\
        choices=utils.data_types,\
            help='Specify the input data type, for example: bf16.')

    parser.add_argument('--output_data_type', '-odt', default='bf16',\
        choices=utils.data_types,\
            help='Specify the output data type, for example: bf16.')

    parser.add_argument('--type', '-t', default="fwd", \
        choices=["fwd", "bpa", "bpw"],\
            help='Specify the operator type currently,only support fwd, bpa, bpw')

    parser.add_argument('--in_place', type=bool, default=False, \
        help='Specify the dilation, for example: False')

    return parser

if __name__ == '__main__':

    parser = get_params()
    args = parser.parse_args()

    input_shape = [int(e) for e in args.input.split("x")]
    assert(len(input_shape) == 4),"make sure the shape of input_shape is 4D"
    weight_shape = [int(e) for e in args.weight.split("x")]
    assert(len(weight_shape) == 1),"make sure the shape of weight_shape is 1D"
    bias_shape = [int(e) for e in args.bias.split("x")]
    assert(len(bias_shape) == 1),"make sure the shape of weight_shape is 1D"

    assert(input_shape[1] == weight_shape[0]),"make sure the weight size is right!"
    assert(input_shape[1] == bias_shape[0]),"make sure the bias size is right!"

    is_training = args.is_training
    momentum_value = float(args.momentum)
    eps_value = float(args.eps)
    
    weight_dt = args.weight_data_type
    input_dt = args.input_data_type
    output_dt = args.output_data_type
    operator_type = args.type
    in_place = args.in_place
    
    if input_dt != "bf16" or output_dt != "bf16" or weight_dt != "fp32":
        raise NotImplementedError

    if is_training != True:
        raise NotImplementedError

    input_shape = tuple(input_shape)
    input_tensor = construct_fake_tensor_batch(input_shape)
    # input,weight,bias,x_sq_sum,x_sum,output
    # instead, the ret is target path now
    ret = gen_simple_bn2relu(input_tensor,weight_shape,bias_shape,is_training,momentum_value,eps_value,in_place)
    print("target path is :",ret)
    # # maybe use in future for backward
    # nn_bn2d = nn.BatchNorm2d(input_shape[1],eps_value,momentum_value,is_training)
    # nn_relu = nn.ReLU(in_place)
    # nn_output = nn_relu(nn_bn2d(input))

    # delta_out = torch.dist(ret[5],nn_output,2)
    # print("Delta output for the two ways : ",delta_out)