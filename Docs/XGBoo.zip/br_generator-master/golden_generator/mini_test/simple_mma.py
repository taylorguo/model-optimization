import argparse, os, shutil
import numpy as np
from golden_generator.mini_test import MM_dump
from command_generator import utils
from command_generator import io_handler as ioh

dest_path = os.path.join('command_generator', 'vectors', 'unit')


def get_params():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        'input',
        default='128x512',
        help='Specify the input tenosr shape with format NxCxHxW,'
        ' for example: 128x512.')
    parser.add_argument(
        'weight',
        default='512x256',
        help='Specify the weight tensor shape with format OxIxKHxKW,'
        ' for example: 512x256.')
    parser.add_argument(
        '--weight_data_type',
        '-wdt',
        default='bf16',
        choices=utils.data_types,
        help='Specify the weight data type, for example: bf16.')
    parser.add_argument('--input_data_type',
                        '-idt',
                        default='bf16',
                        choices=utils.data_types,
                        help='Specify the input data type, for example: bf16.')
    parser.add_argument(
        '--output_data_type',
        '-odt',
        default='bf16',
        choices=utils.data_types,
        help='Specify the output data type, for example: bf16.')
    return parser


def gen_simple_mma(input_shape, weight_shape, weight_dt='bf16',
                    input_dt='bf16', output_dt='bf16', target_addr=None):
    if input_shape[0] != weight_shape[1]:
        print("Error: the input shape or weight shape is illegal!!!")
        return
    out_shape = (weight_shape[0], input_shape[1])

    folder_name = 'mma_in_' + utils.tuple_to_string(input_shape) + '_w_' \
            + utils.tuple_to_string(weight_shape) \
            + '_' + weight_dt + 'x' +input_dt + 'x' + output_dt

    if not target_addr:
        target_addr = os.path.join(utils.brgen_root, dest_path)
        target_path = os.path.join(target_addr, folder_name, 'input')
    else:
        target_path = os.path.join(target_addr, 'input')
    if os.path.exists(target_path):
        shutil.rmtree(target_path)
    ioh.biren_mkdir(target_path)

    if isinstance(input_shape, list):
        input_shape = tuple(input_shape)
        weight_shape = tuple(weight_shape)
    if isinstance(input_shape[0], str):
        ishape = (int(input_shape[0]), int(input_shape[1]))
        wshape = (int(weight_shape[0]), int(weight_shape[1]))
    else:
        ishape = input_shape
        wshape = weight_shape
    matrix_1, matrix_2, res = MM_dump.testMMWeightAndActivation(
        ishape, wshape, weight_dt, input_dt, output_dt, target_path)

    return target_path


if __name__ == '__main__':
    parser = get_params()
    args = parser.parse_args()
    input_shape = [int(e) for e in args.input.split("x")]
    weight_shape = [int(e) for e in args.weight.split("x")]
    weight_dt = args.weight_data_type
    input_dt = args.input_data_type
    output_dt = args.output_data_type
    gen_simple_mma(input_shape,
                   weight_shape,
                   weight_dt=weight_dt,
                   input_dt=input_dt,
                   output_dt=output_dt)
