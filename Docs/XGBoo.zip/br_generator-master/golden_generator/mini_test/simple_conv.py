# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import argparse
import shutil
import os
import copy
import sys
from collections import OrderedDict
from command_generator import make_dump
from command_generator import assemble_instrution
from command_generator import io_handler
from command_generator import utils
import re
import br_layout
import math
from br_dump import *
from simple_reduce import br_sum,br_sq_sum


WEIGHT_BLOCK_ICH_SIZE = 32
WEIGHT_BLOCK_OCH_SIZE = 8

ACTIVATION_BLOCK_W_SIZE = 8
ACTIVATION_BLOCK_H_SIZE = 8
ACTIVATION_BLOCK_I_SIZE = 32

WEIGHT_OCH_LD_SIZE = 32

A_BUFFER_ENTRY_OCH_NUM = 32
A_BUFFER_ENTRY_ICH_NUM = 8

B_BUFFER_ENTRY_PIXEL_NUM = 64
B_BUFFER_ENTRY_ICH_NUM = 8

LOAD_SYNC_SIZE = 16 * 1024
SYNC_STATION_NUM = 16

A_BUFFER_ENTRY_NUM = 512
A_BUFFER_SIZE_PER_ENTRY = (32 * 128 >> 3)

B_BUFFER_ENTRY_NUM = 256 - 128
B_BUFFER_SIZE_PER_ENTRY = (64 * 128 >> 3)

CONV_OCH_SIZE = 32

HALF_B_BUFFER_SIZE = 128

AXIS_EXPANSION_SAMPLE_NUM = 2

# DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# Pure cpu as reference
DEVICE = torch.device("cpu")


class Block01_Gen(object):
    def __init__(
            self, isa_params, op_type, dt, shape, w_shape, selected_inchannel):
        self.block = OrderedDict()
        self.psr_index = 0
        self.ld_index = 0
        self.stg_index = 0
        self.isa_params = isa_params
        self.op_type = op_type
        self.dt = dt
        self.shape = shape
        self.w_shape = w_shape
        self.in_channel_num = int(selected_inchannel[3:])
        self.in_channel = selected_inchannel
        self.cumulate_load_size = 0
        self.sync_times = 0
        self.stg_ssc = None
        self.stg_wsc = None
        self.s_gsc = "snil"
        self.w_gsc = "wnil"
        self.pad_mode = "pb"
        self.need_waitsync = False
        self.w_sync_times = 0
        self.s_sync_times = 0
        self.i_dt, self. w_dt, self.o_dt = self.dt.split("x")
        self.aligned_w_ld_tm = int(
            ((self.shape[3] + ACTIVATION_BLOCK_W_SIZE - 1) /
             ACTIVATION_BLOCK_W_SIZE))
        self.aligned_h_ld_tm = int(
            ((self.shape[2] + ACTIVATION_BLOCK_H_SIZE - 1) /
             ACTIVATION_BLOCK_H_SIZE))
        self.aligned_i_block = int(
            ((self.shape[1] + ACTIVATION_BLOCK_I_SIZE - 1) /
             ACTIVATION_BLOCK_I_SIZE))
        self.aligned_i_ld_tm = int(
            math.ceil(
                (self.aligned_i_block * ACTIVATION_BLOCK_I_SIZE) /
                self.in_channel_num))
        required_buffer_entries = (
            ACTIVATION_BLOCK_W_SIZE * ACTIVATION_BLOCK_H_SIZE /
            B_BUFFER_ENTRY_PIXEL_NUM)
        self.required_buffer_b_entries = int(
            required_buffer_entries * self.in_channel_num /
            B_BUFFER_ENTRY_ICH_NUM)
        self.required_buffer_size = (
            self.required_buffer_b_entries * B_BUFFER_SIZE_PER_ENTRY)
        self.addr = 0
        self.x = 0
        self.y = 0
        self.z = 0
        self.stg_ssc = None
        self.stg_wsc = None
        self.post_x = "setx"
        self.post_y = "sety"
        self.post_z = "setz"
        self.wsc = "wnil"
        self.ssc = "snil"
        self.uid = "u1"
        self.stg = assemble_instrution.staging_count["ldconv_off"]
        self.buf_offset = 0

        self.no_w_sync = True
        self.no_s_sync = True

    def _construct_staging_count_and_ld_instrs(self):
        if self.no_s_sync:
            ssc = "snil"
            stg_ssc = None
        else:
            ssc = self.ssc
            stg_ssc = self.wsc

        if self.no_w_sync:
            wsc = "wnil"
            stg_wsc = None
        else:
            wsc = self.wsc
            stg_wsc = self.stg_wsc
        construct_stg_item(
            self.block, self.stg, self.stg_index, addr0=self.addr,
            x=self.x, y=self.y, z=self.z, wsc=stg_wsc,
            ssc=stg_ssc)
        self.stg_index += 1

        if self.op_type == "bpa":
            use_dt = self.o_dt
        else:
            use_dt = self.i_dt
        construct_tcore_block0_1_instr(
            self.block, self.ld_index, self.shape, self.op_type, use_dt,
            "MAT-LSA_LDMMA_LDCONV1",
            self.in_channel,
            x=self.post_x, y=self.post_x, z=self.post_x, wgsc=wsc,
            sgsc=ssc, uid=self.uid)
        self.ld_index += 1

    def _set_pad_mode(self, x_block_index):
        if x_block_index == 0:
            self.pad_mode = "pb"
        else:
            self.pad_mode = "po"
            if self.w_shape[3] == 1:
                self.pad_mode = "pb"

    def _adjust_post_x_y_mode(self, x_block_index, y_block_index):
        self.post_x = "incx0"
        if x_block_index == 0 and x_block_index == self.aligned_w_ld_tm - 1:
            self.post_x = "incx0"
            if y_block_index != self.aligned_h_ld_tm - 1:
                self.post_y = "incy1"

    def _adjust_post_x_z_mode(self, x_block_indx, ich_block_index):
        self.post_z = "incz1"
        if (ich_block_index == 0 and
                ich_block_index == self.aligned_i_ld_tm - 1):
            self.post_z = "incz0"
            if x_block_indx != self.aligned_w_ld_tm - 1:
                self.post_x = "incx1"

    def _check_and_ajust_post_x_y_z_mode(
            self, x_block_index, y_block_index, ich_block_index):
        # check if it is last x
        if ich_block_index == self.aligned_i_ld_tm - 1:
            if self.post_z == "incz1":
                self.post_z = "resetz"
            self.post_x = "incx1"
        # check if it is last x and last y
        if (ich_block_index == self.aligned_i_ld_tm - 1 and
                x_block_index == self.aligned_w_ld_tm - 1):
            if self.post_x == "incx1":
                self.post_x = "resetx"
            self.post_y = "incy1"
        # check if it is last x, last y, last z
        if (ich_block_index == self.aligned_i_ld_tm - 1 and
            x_block_index == self.aligned_w_ld_tm - 1 and
                y_block_index == self.aligned_h_ld_tm - 1):
            self.post_z = "incz0"
            self.post_x = "incx0"
            self.post_y = "incy0"

    def _set_buf_addr(self, x_block_index):
        if x_block_index % 2 == 0:
            self.buffer_addr = self.buffer_offset
        else:
            self.buffer_addr = self.buffer_offset + HALF_B_BUFFER_SIZE

    def _set_ssc_sync_status(self):
        if self.ssc == "snil":
            self.ssc = "sset"
            self.stg_ssc = 0
        elif self.ssc == "sset":
            self.ssc = "sinc"
            self.stg_ssc = None
        elif self.ssc == "sinc":
            if self.s_sync_times % 16 == 0:
                self.ssc = "sset"
                self.stg_ssc = 0
        self.s_sync_times += 1

    def _set_wsc_sync_status(self):
        # Only when 'set sync' has been set, the 'wait sync' can be turn on
        if self.s_sync_times > 0:
            if self.wsc == "wnil":
                self.wsc = "wset"
                self.stg_wsc = 16
            elif self.wsc == "wset":
                self.wsc = "winc"
                self.stg_wsc = None
            elif self.wsc == "winc":
                if self.w_sync_times % 16 == 0:
                    self.wsc = "wset"
                    self.stg_wsc = 16
            self.w_sync_times += 1
        else:
            self.wsc = "wnil"
            self.stg_wsc = None

    def _clear_ssc_sync_status(self):
        self.no_s_sync = True

    def _clear_wsc_sync_status(self):
        self.no_w_sync = True

    def _generate_init_instruction(self):
        construct_psr_item(
            self.block, self.w_shape, self.op_type, 0, 0, 1, 1, 0,
            self.psr_index)
        self.psr_index += 1

        self._construct_staging_count_and_ld_instrs()
        self.x = None
        self.y = None
        self.z = None

    def _generate_loop_instructions(self):
        for i in range(self.aligned_h_ld_tm):
            self.post_y = "incy0"
            # buffer_offset = i * required_b_buffer_entries
            self.buffer_offset = 0
            for j in range(self.aligned_w_ld_tm):
                self._set_pad_mode(j)
                self._adjust_post_x_y_mode(j, i)
                self._set_buf_addr(j)
                cumulate_load_size = 0
                buf_usage_loops = 0
                for k in range(self.aligned_i_ld_tm):
                    self._adjust_post_x_y_mode(j, k)
                    if k < self.aligned_i_ld_tm - 1:
                        if (self.addr + self.required_buffer_b_entries >=
                                B_BUFFER_ENTRY_NUM):
                            self.addr = (
                                self.addr + self.required_buffer_b_entries -
                                B_BUFFER_ENTRY_NUM)
                            buf_usage_loops += 1
                        else:
                            self.addr += self.required_buffer_b_entries

                        cumulate_load_size += self.required_buffer_size
                        # print("sync_times is ", sync_times)
                        if cumulate_load_size >= LOAD_SYNC_SIZE:
                            if buf_usage_loops != 0:
                                self._set_wsc_sync_status()
                            self._set_ssc_sync_status()
                            cumulate_load_size = 0
                    else:
                        # need to wait first
                        self._set_wsc_sync_status()
                        self._set_ssc_sync_status()
                        buf_usage_loops += 1

                    self._check_and_ajust_post_x_y_z_mode(j, i, k)
                    self.stg = assemble_instrution.staging_count["ldconv_on"]
                    self._construct_staging_count_and_ld_instrs()

    def gen_instructions(self):
        self._generate_init_instruction()
        self._generate_loop_instructions()
        self.isa_params["block0_1"] = self.block

        return (self.required_buffer_b_entries, self.aligned_i_ld_tm,
                self.aligned_h_ld_tm, self.aligned_w_ld_tm)


class Block10_Gen(object):
    def __init__(
            self, isa_params, op_type, dt, ishape, wshape, oshape,
            selected_input_ch, buf_a_inc, buf_b_inc,
            och_ld_tm, ich_ld_tm, height_ld_tm, width_ld_tm):
        self.isa_params = isa_params
        self.op_type = op_type
        self.dt = dt
        self.ishape = ishape
        self.wshape = wshape
        self.oshape = oshape
        self.in_channel_num = int(selected_input_ch[3:])
        self.selected_input_ch = selected_input_ch
        self.buf_a_inc = buf_a_inc
        self.buf_b_inc = buf_b_inc
        self.required_buffer_b_size = (
            self.buf_b_inc * B_BUFFER_SIZE_PER_ENTRY)
        self.och_ld_tm = och_ld_tm
        self.ich_ld_tm = ich_ld_tm
        self.height_ld_tm = height_ld_tm
        self.width_ld_tm = width_ld_tm
        self.block = OrderedDict()
        self.psr_index = 0
        self.conv_index = 0
        self.stg_index = 0
        self.dest_x = 0
        self.dest_y = 0
        self.dest_z = 0
        self.buf_a_addr = 0
        self.buf_b_addr = 0
        self.buf_a_offset = 0
        self.buf_b_offset = 0

        if self.op_type == "bpw":
            self.stage_key = "mma_off"
        else:
            self.stage_key = "conv_off"
        self.stg_ssc = None
        self.stg_wsc = None
        self.ssc = "snil"
        self.wsc = "wnil"
        self.w_sync_times = 0
        self.s_sync_times = 0
        self.init = "ini1"

        self.prev_j = None
        self.prev_i = None
        self.prev_n = None
        self.prev_m = None

        self.no_w_sync = True
        self.no_s_sync = True

        self.i_dt, self.w_dt, self.o_dt = dt.split("x")
        self.stg = assemble_instrution.staging_count[self.stage_key]

    def _construct_staging_count_and_ld_instrs(self):
        # print("### self.buffer_a_addr is ", self.buf_a_addr)
        if self.no_s_sync:
            ssc = "snil"
            stg_ssc = None
        else:
            ssc = self.ssc
            stg_ssc = self.wsc

        if self.no_w_sync:
            wsc = "wnil"
            stg_wsc = None
        else:
            wsc = self.wsc
            stg_wsc = self.stg_wsc

        construct_stg_item(
            self.block, self.stg, self.stg_index, addr0=self.buf_a_addr,
            addr1=self.buf_b_addr, warp_count=0,
            x=self.dest_x, y=self.dest_y, z=self.dest_z,
            wsc=stg_wsc, ssc=stg_ssc)
        self.stg_index += 1

        construct_tcore_block1_0_instr(
            self.block, self.conv_index, self.ishape, self.wshape,
            self.oshape, self.op_type, self.i_dt, self.w_dt, self.o_dt,
            "MAT-LSA_MMA_CONV", self.selected_input_ch,
            self.init, wgsc=wsc, sgsc=ssc)
        self.conv_index += 1

    def _flip_buf_b_addr(self, x_block_index):
        if x_block_index % 2 == 0:
            self.buffer_b_addr = self.buffer_b_offset
        else:
            self.buffer_b_addr = self.buffer_b_offset + HALF_B_BUFFER_SIZE

    def _set_wsc_sync_status(self):
        if self.wsc == "wnil":
            self.wsc = "wset"
            self.stg_wsc = 0
        elif self.wsc == "wset":
            self.wsc = "winc"
            self.stg_wsc = None
        elif self.wsc == "winc":
            if self.w_sync_times % 16 == 0:
                self.wsc = "wset"
                self.stg_wsc = 0
        self.w_sync_times += 1
        self.no_w_sync = False

    def _set_ssc_sync_status(self):
        if self.ssc == "snil":
            self.ssc = "sset"
            self.stg_ssc = 16
        elif self.ssc == "sset":
            self.ssc = "sinc"
            self.stg_ssc = None
        elif self.ssc == "sinc":
            if self.s_sync_times % 16 == 0:
                self.ssc = "sset"
                self.stg_ssc = 16
        self.s_sync_times += 1
        self.no_w_sync = False

    def _clear_ssc_sync_status(self):
        self.no_s_sync = True

    def _clear_wsc_sync_status(self):
        self.no_w_sync = True

    def _set_accumulative_mode(self, ich_block_index):
        if ich_block_index == 0:
            self.init = "ini1"
        else:
            self.init = "ini0"

    def _calc_buffer_a_addr(self, och_block_index, ich_block_index):
        self.buf_a_addr = (
            (och_block_index * self.ich_ld_tm + ich_block_index) *
            self.buf_a_inc)
        # print("self.buf_a_addr is ", self.buf_a_addr)
        #self.buffer_b_addr += ich_block_index * buf_b_inc

    def _generate_init_instruction(self):
        self._construct_staging_count_and_ld_instrs()
        # self.

    def _generate_bpw_loop_instructions(self):
        self.stage_key = "mma_bpw_on"
        self.stg = assemble_instrution.staging_count[self.stage_key]
        self._construct_staging_count_and_ld_instrs()

    def _generate_bpa_loop_instructions(self):
        self.stage_key = "conv_on"
        self.stg = assemble_instrution.staging_count[self.stage_key]
        self._construct_staging_count_and_ld_instrs()

    def _generate_fwd_loop_instructions(self):
        self.stage_key = "conv_on"
        self.stg = assemble_instrution.staging_count[self.stage_key]

        for m in range(self.height_ld_tm):
            self.dest_y = m * ACTIVATION_BLOCK_H_SIZE
            self.buffer_b_offset = 0
            for n in range(self.width_ld_tm):
                self.dest_x = n * ACTIVATION_BLOCK_H_SIZE
                self._flip_buf_b_addr(n)
                # print("buffer_b_addr in %d loop is ", n, buffer_b_addr)
                for i in range(self.och_ld_tm):
                    self.dest_z = i * CONV_OCH_SIZE
                    cumulate_load_size = 0
                    buf_usage_loops = 0
                    for j in range(self.ich_ld_tm):
                        self._set_accumulative_mode(j)
                        self._calc_buffer_a_addr(i, j)

                        if cumulate_load_size == 0:
                            # print("come here 00022!")
                            if (self.prev_j != j or self.prev_n != n or
                                    self.prev_m != m):
                                self._set_wsc_sync_status()
                            else:
                                self._clear_wsc_sync_status()

                        if j < self.ich_ld_tm - 1:
                            # print("come here 00000!")
                            if (self.buf_b_addr + self.buf_b_inc >=
                                    B_BUFFER_ENTRY_NUM):
                                self.buf_b_addr = (
                                    self.buf_b_addr + self.buf_b_inc -
                                    B_BUFFER_ENTRY_NUM)
                                buf_usage_loops += 1
                            else:
                                self.buf_b_inc += self.buf_b_inc
                            cumulate_load_size += (
                                self.required_buffer_b_size)
                            if cumulate_load_size >= LOAD_SYNC_SIZE:
                                # print("come here 00011!")
                                self._set_ssc_sync_status()
                                cumulate_load_size = 0
                            else:
                                self._clear_ssc_sync_status()
                        else:
                            # print("come here!")
                            # need to wait first
                            if (i == self.och_ld_tm - 1 and
                                    self.width_ld_tm * self.height_ld_tm > 1):
                                self._set_ssc_sync_status()

                        self._construct_staging_count_and_ld_instrs()
                        self.prev_i = i
                        self.prev_j = j
                        self.prev_m = m
                        self.prev_n = n

    def generate_instructions(self):
        if self.op_type == "fwd":
            self._generate_init_instruction()
            self._generate_fwd_loop_instructions()
            self.isa_params["block1"] = self.block


def construct_block1(
        ishape, wshape, oshape, dt, op_type, isa_params,
        sel_input_ch, buf_a_inc, buf_b_inc,
        och_ld_tm, ich_ld_tm, height_ld_tm, width_ld_tm):
    construct_block1_0(
        isa_params, op_type, dt, ishape, wshape, oshape,
        sel_input_ch, buf_a_inc, buf_b_inc,
        och_ld_tm, ich_ld_tm, height_ld_tm, width_ld_tm)


def construct_block1_0(
        isa_params, op_type, dt, ishape, wshape, oshape,
        selected_input_ch, buf_a_inc, buf_b_inc,
        och_ld_tm, ich_ld_tm, height_ld_tm, width_ld_tm):

    block10_gen = Block10_Gen(isa_params, op_type, dt, ishape, wshape, oshape,
                              selected_input_ch, buf_a_inc, buf_b_inc,
                              och_ld_tm, ich_ld_tm, height_ld_tm, width_ld_tm)
    block10_gen.generate_instructions()


def construct_tcore_block0_0_instr(
        block, index, shape, op_type, dt, instr_name,
        in_channl, x=None, y=None, z=None, uid=None):
    instr_params = OrderedDict()
    key = instr_name + " {}".format(index)

    if index == 0:
        instr_params["OpDisable"] = "off"
    else:
        instr_params["OpDisable"] = "on"

    instr_params["DataType0"] = dt
    # print("shape is ", shape)

    instr_params["Mat0Col_InputCh"] = in_channl

    if op_type != "bpw":
        instr_params["PostInc_y"] = y
        instr_params["PostInc_z"] = z
        instr_params["DescIndex"] = uid
        instr_params["Mat0Row_OutputCh_Shape"] = "oc32"
    else:
        instr_params["PostInc_x"] = x
        instr_params["PostInc_y"] = y
        instr_params["PostInc_z"] = z
        instr_params["DescIndex"] = uid
        instr_params["Mat0Row_OutputCh_Shape"] = "8x8"

    block[key] = instr_params


def construct_tcore_block0_1_instr(
        block, index, shape, op_type, dt, instr_name, input_ch,
        x=None, y=None, z=None, wgsc=None, sgsc=None,
        pad=None, uid=None):
    instr_params = OrderedDict()
    key = instr_name + " {}".format(index)

    if index == 0:
        instr_params["OpDisable"] = "off"
    else:
        instr_params["OpDisable"] = "on"

    instr_params["DataType0"] = dt
    # print("shape is ", shape)

    instr_params["Mat0Col_InputCh"] = input_ch
    instr_params["PostInc_x"] = x
    instr_params["PostInc_y"] = y
    instr_params["PostInc_z"] = z
    instr_params["DescIndex"] = uid
    if pad is not None:
        instr_params["PadOnly_SlotSet"] = pad
    instr_params["Mat0Row_OutputCh_Shape"] = "8x8"
    if wgsc is not None:
        instr_params["Waitgsc"] = wgsc
    if sgsc is not None:
        instr_params["Setgsc"] = sgsc

    block[key] = instr_params


def construct_tcore_block1_0_instr(
        block, index, ishape, wshape, oshape, op_type, i_dt,
        w_dt, o_dt, instr_name, input_ch, init=None,
        wgsc=None, sgsc=None, uid=None):

    instr_params = OrderedDict()
    key = instr_name + " {}".format(index)
    instr_params["Opcode"] = "CONV"

    if op_type == "bpw":
        instr_params["Opcode"] = "MMA"
        instr_params["DataType0"] = o_dt
        instr_params["DataType1"] = i_dt
        instr_params["DstDataType"] = w_dt
    elif op_type == "bpa":
        instr_params["DataType0"] = o_dt
        instr_params["DataType1"] = w_dt
        instr_params["DstDataType"] = i_dt
    else:
        instr_params["DataType0"] = i_dt
        instr_params["DataType1"] = w_dt
        instr_params["DstDataType"] = o_dt

    if init is not None:
        instr_params["Init"] = init

    if op_type == "bpw":
        instr_params["Mat0Col_InputCh"] = "64"
        instr_params["Mat0Row_OutputCh_Shape"] = input_ch[3:]
        if op_type == "bpw":
            if ishape[1] < 32:
                instr_params["Mat1Col"] = "32"
            else:
                instr_params["Mat1Col"] = "64"
    else:
        instr_params["Mat0Col_InputCh"] = input_ch
        instr_params["Mat0Row_OutputCh_Shape"] = "oc32"

    if wgsc is not None:
        instr_params["Waitgsc"] = wgsc
    if sgsc is not None:
        instr_params["Setgsc"] = sgsc

    block[key] = instr_params


def construct_block0_1(
        isa_params, op_type, dt, shape, w_shape, selected_input_ch):
    block01_gen = Block01_Gen(
        isa_params, op_type, dt, shape, w_shape, selected_input_ch)
    return block01_gen.gen_instructions()


def pick_a_input_chanel(dt, shape):
    p = None
    if dt in assemble_instrution.MAT_LSA_INPUT_CODING_LDCONV_CONV_4_L:
        p = assemble_instrution.MAT_LSA_INPUT_CODING_LDCONV_CONV_4
    elif dt in assemble_instrution.MAT_LSA_INPUT_CODING_LDCONV_CONV_8_L:
        p = assemble_instrution.MAT_LSA_INPUT_CODING_LDCONV_CONV_8
    elif dt in assemble_instrution.MAT_LSA_INPUT_CODING_LDCONV_CONV_16_1_L:
        p = assemble_instrution.MAT_LSA_INPUT_CODING_LDCONV_CONV_16_1
    elif dt in assemble_instrution.MAT_LSA_INPUT_CODING_LDCONV_CONV_16_2_L:
        p = assemble_instrution.MAT_LSA_INPUT_CODING_LDCONV_CONV_16_2

    key_numbers = [e for e, _ in p.items()]
    # print("key_numbers are ", key_numbers)
    selected_ch_num = 0
    for e in key_numbers:
        input_ch_num = int(e[3:])
        if input_ch_num >= shape[1]:
            if selected_ch_num == 0:
                selected_ch_num = input_ch_num
            if input_ch_num < selected_ch_num:
                selected_ch_num = input_ch_num
    if selected_ch_num == 0:
        selected_ch_num = key_numbers[-1]
    else:
        selected_ch_num = "ich{}".format(selected_ch_num)

    # print("selected_ch_num is ", selected_ch_num)

    return selected_ch_num


def construct_block0(
        ishape, wshape, oshape, dt, op_type, isa_params, select_in_channl):
    buf_a_inc = None
    buf_b_inc = None
    if op_type == "bpw":
        buf_a_inc, blk00_o_ld_tm, blk00_i_ld_tm = construct_block0_0(
            isa_params, op_type, dt, wshape, oshape, select_in_channl)
        buf_b_inc, blk01_i_ld_tm, blk01_h_ld_tm, blk01_w_ld_tm =\
            construct_block0_1(
                isa_params, op_type, dt, ishape, wshape, select_in_channl)
    elif op_type == "fwd":
        buf_a_inc, blk00_o_ld_tm, blk00_i_ld_tm = construct_block0_0(
            isa_params, op_type, dt, wshape, oshape, select_in_channl)
        buf_b_inc, blk01_i_ld_tm, blk01_h_ld_tm, blk01_w_ld_tm =\
            construct_block0_1(
                isa_params, op_type, dt, ishape, wshape, select_in_channl)
    elif op_type == "bpa":
        buf_a_inc, blk00_o_ld_tm, blk00_i_ld_tm = construct_block0_0(
            isa_params, op_type, dt, wshape, oshape, select_in_channl)
        buf_b_inc, blk01_i_ld_tm, blk01_h_ld_tm, blk01_w_ld_tm =\
            construct_block0_1(
                isa_params, op_type, dt, oshape, wshape, select_in_channl)
    assert(blk00_i_ld_tm == blk01_i_ld_tm)
    o_ld_tm = blk00_o_ld_tm
    i_ld_tm = blk00_i_ld_tm
    h_ld_tm = blk01_h_ld_tm
    w_ld_tm = blk01_w_ld_tm
    return buf_a_inc, buf_b_inc, o_ld_tm, i_ld_tm, h_ld_tm, w_ld_tm


def construct_block0_0(isa_params, op_type, dt, wshape, oshape, selected_ld_ich):
    block = OrderedDict()
    psr_index = 0
    ld_index = 0
    stg_index = 0

    ld_ich_num = int(selected_ld_ich[3:])

    construct_psr_item(
        block, wshape, op_type, 0, 0, 1, 1, 0, psr_index)
    psr_index += 1

    i_dt, w_dt, o_dt = dt.split("x")
    # print("i_dt, w_dt, o_dt is", i_dt, w_dt, o_dt)
    stg = assemble_instrution.staging_count["ldconv_off"]

    # if in_channnel <= 32 and out_channel < 32:
    construct_stg_item(block, stg, stg_index, addr0=0, x=0, y=0, z=0)
    stg_index += 1
    if op_type == "bpw":
        construct_tcore_block0_0_instr(
            block, ld_index, oshape, op_type, o_dt, "MAT-LSA_LDMMA_LDCONV1",
            selected_ld_ich, x="setx", y="sety", z="setz", uid="u0")
    elif op_type == "fwd" or op_type == "bpa":
        construct_tcore_block0_0_instr(
            block, ld_index, wshape, op_type, w_dt, "MAT-LSA_LDMMA_LDCONV0",
            selected_ld_ich, y="sety", z="setz", uid="u0")
    ld_index += 1

    print("Selected loading in_channl number is ", ld_ich_num)
    stg = assemble_instrution.staging_count["ldconv_on"]
    if op_type == "bpw":
        aligned_w = int(((oshape[3] + ACTIVATION_BLOCK_W_SIZE - 1) /
                         ACTIVATION_BLOCK_W_SIZE))
        aligned_h = int(((oshape[2] + ACTIVATION_BLOCK_H_SIZE - 1) /
                         ACTIVATION_BLOCK_H_SIZE))
        aligned_i_block = int(((oshape[1] + ACTIVATION_BLOCK_I_SIZE - 1) /
                               ACTIVATION_BLOCK_I_SIZE))
        aligned_i_loading_times = int(
            math.ceil(
                (aligned_i_block * ACTIVATION_BLOCK_I_SIZE) / ld_ich_num))
        required_a_buffer_entries = (
            ACTIVATION_BLOCK_W_SIZE * ACTIVATION_BLOCK_H_SIZE /
            A_BUFFER_ENTRY_OCH_NUM)
        required_a_buffer_entries = int(
            required_a_buffer_entries * ld_ich_num /
            A_BUFFER_ENTRY_ICH_NUM)
        buffer_addr = 0
        for i in range(aligned_i_loading_times):
            post_z = "incz1"
            for j in range(aligned_h):
                if j != 0:
                    post_z = "incz0"
                post_y = "incy1"
                for k in range(aligned_w):
                    post_x = "incx1"
                    post_y = "incy0"
                    post_z = "incz0"
                    # check if it is last x
                    if k == aligned_w - 1:
                        post_x = "resetx"
                        post_y = "incy1"
                    # check if it is last x and last y
                    if k == aligned_w - 1 and j == aligned_h - 1:
                        post_x = "resetx"
                        post_y = "resety"
                        post_z = "incz1"
                    # check if it is last x, last y, last z
                    if (k == aligned_w - 1 and j == aligned_h - 1 and
                            i == aligned_i_loading_times - 1):
                        post_x = "resetx"
                        post_y = "resety"
                        post_z = "resetz"
                    construct_stg_item(
                        block, stg, stg_index, addr0=buffer_addr)
                    stg_index += 1
                    construct_tcore_block0_0_instr(
                        block, ld_index, oshape, op_type, o_dt,
                        "MAT-LSA_LDMMA_LDCONV1",
                        selected_ld_ich,
                        x=post_x, y=post_y, z=post_z, uid="u0")
                    ld_index += 1
                    buffer_addr += required_a_buffer_entries
    elif op_type == "fwd" or op_type == "bpa":
        aligned_ich_block = int(((wshape[1] + WEIGHT_BLOCK_ICH_SIZE - 1) /
                                 WEIGHT_BLOCK_ICH_SIZE))
        aligned_ich_num = aligned_ich_block * WEIGHT_BLOCK_ICH_SIZE
        aligned_ich_ld_tm = int(
            aligned_ich_num / ld_ich_num)
        aligned_och_block = int(((wshape[0] + WEIGHT_BLOCK_OCH_SIZE - 1) /
                                 WEIGHT_BLOCK_OCH_SIZE))
        aligned_och_num = aligned_och_block * WEIGHT_BLOCK_OCH_SIZE
        aligned_och_ld_tm = int(
            aligned_och_num / WEIGHT_OCH_LD_SIZE)
        if aligned_och_ld_tm == 0:
            aligned_och_ld_tm = 1

        total_entries_needed = int(aligned_och_num / A_BUFFER_ENTRY_OCH_NUM)
        total_entries_needed = int(
            total_entries_needed * aligned_ich_num / A_BUFFER_ENTRY_ICH_NUM)
        total_entries_needed *= wshape[2] * wshape[3]

        if total_entries_needed > A_BUFFER_ENTRY_NUM:
            print("Warning: weight matrix goes beyond the size of A buffer")

        # loading_size = calc_loading_size_in_byte(
        #     w_dt, h=in_channel_num, w=WEIGHT_OCH_LD_SIZE)
        required_buffer_a_entries_for_each_ld = math.ceil(
            WEIGHT_OCH_LD_SIZE / A_BUFFER_ENTRY_OCH_NUM)
        required_buffer_a_entries_for_each_ld = int(
            math.ceil(required_buffer_a_entries_for_each_ld *
                      (ld_ich_num / A_BUFFER_ENTRY_ICH_NUM)))
        required_buffer_a_entries_for_each_ld = (
            required_buffer_a_entries_for_each_ld * wshape[2] * wshape[3])
        buffer_addr = 0

        for i in range(aligned_och_ld_tm):
            for j in range(aligned_ich_ld_tm):
                # print("j value is ", j)
                post_z = "incz0"
                post_y = "incy1"
                # check if it is last x
                if j == aligned_ich_ld_tm - 1:
                    post_y = "resety"
                    post_z = "incz1"
                # check if it is last x and last y
                if (i == aligned_och_ld_tm - 1 and
                        j == aligned_ich_ld_tm - 1):
                    post_y = "incy0"
                    post_z = "incz0"
                construct_stg_item(block, stg, stg_index, addr0=buffer_addr)
                stg_index += 1
                construct_tcore_block0_0_instr(
                    block, ld_index, wshape, op_type, w_dt,
                    "MAT-LSA_LDMMA_LDCONV0",
                    selected_ld_ich, y=post_y, z=post_z, uid="u0")
                ld_index += 1
                buffer_addr += required_buffer_a_entries_for_each_ld

    isa_params["block0_0"] = block

    return (required_buffer_a_entries_for_each_ld, aligned_och_ld_tm,
            aligned_ich_ld_tm)

def construct_psr_item(
        block, shape, op_type, pad_x, pad_y, stride, dilation, half_tlr,
        index):
    psr = OrderedDict()
    key = "PSR " + "{}".format(index)
    psr["FilWidth"] = shape[3]
    psr["FilHeight"] = shape[2]
    if op_type != "fwd":
        psr["Direction"] = "bwd"
        psr["BwdType"] = op_type
    if pad_x != 0:
        psr["Padx"] = "{}".format(pad_x)
    if pad_y != 0:
        psr["Pady"] = "{}".format(pad_y)

    if stride != 1:
        psr["Stride"] = "{}".format(stride)
    if dilation != 1:
        psr["Dilation"] = "{}".format(dilation)
    if half_tlr != 0:
        psr["Dilation"] = "htlr{}".format(dilation)
    block[key] = psr


def construct_stg_item(
        block, stg, index, addr0=None, addr1=None, w=None, warp_count=None,
        x=None, y=None, z=None, wsc=None, ssc=None, slot=None):
    stg_setting = OrderedDict()
    key = "STG " + "{}".format(index)
    # print("stg is ", stg)
    if "gib_addr" in stg:
        stg_setting["gib_addr"] = addr0
    elif "gib0_addr" in stg:
        stg_setting["gib0_addr"] = addr0
    if "gib1_addr" in stg:
        stg_setting["gib1_addr"] = addr1
    if x is not None:
        stg_setting["x"] = x
    if y is not None:
        stg_setting["y"] = y
    if z is not None:
        stg_setting["z"] = z
    if w is not None and "w" in stg:
        stg_setting["w"] = w
    if "warp_count" in stg:
        stg_setting["warp_count"] = warp_count
    if slot is not None:
        stg_setting["slot"] = slot
    if wsc is not None:
        stg_setting["wsc"] = wsc
    if ssc is not None:
        stg_setting["ssc"] = ssc

    block[key] = stg_setting


def construct_pattern_tensor(n, c, h, w, value=None, dtype="fp32"):
    t = []
    total = n * c * h * w
    if value is None:
        for i in range(total):
            t.append(i)
    else:
        for i in range(total):
            t.append(value)
    if dtype == "fp32" or dtype == "bf16":
        tensor = torch.FloatTensor(t).reshape(n, c, h, w)
    elif dtype == "s8":
        tensor = torch.CharTensor(t).reshape(n, c, h, w)
    elif dtype == "u8":
        tensor = torch.ByteTensor(t).reshape(n, c, h, w)
    return tensor


def construct_random_tensor(size):
    t = torch.randn(1, 1, size, size)
    return t


def construct_kernel(o, i, kh, kw, w_value=None, dtype="fp32"):
    t = []
    total = o * i * kh * kw
    if w_value is None:
        for e in range(total):
            t.append(e + 1.0)
    else:
        for e in range(total):
            t.append(w_value)
    # print(t)
    if dtype == "fp32" or dtype == "bf16":
        tensor = torch.FloatTensor(t).reshape(o, i, kh, kw)
    elif dtype == "s8":
        tensor = torch.CharTensor(t).reshape(o, i, kh, kw)
    elif dtype == "u8":
        tensor = torch.ByteTensor(t).reshape(o, i, kh, kw)
    return tensor

def construct_fake_gamma(shape):
    return torch.ones(shape)


def construct_fake_beta(shape):
    return torch.ones(shape)


def br_conv(tensor_image, kernel, dilation_value, stride_value, padding_value):
    # kernel = torch.FloatTensor(kernel).expand(out_channel, channels, 3, 3)
    if dilation_value > 1:
        if tensor_image.dtype == torch.int32:
            tensor_image = tensor_image.double()
            kernel = kernel.double()
    weight = nn.Parameter(data=kernel, requires_grad=False)
    # print("conv weight is ", weight)

    result = F.conv2d(tensor_image, weight, bias=None, stride=stride_value,
                      padding=padding_value, dilation=dilation_value, groups=1)
    # print("result is ", result)
    return result if result.dtype == torch.float32 else result.int()


# Calculate the kernel derivative for valid case.
def br_bpw_conv(tensor_image, kernel, w_size, w_index=0):
    result = None
    A = kernel
    B = tensor_image
    m1_out = tensor_image.shape[0]
    m1_in = tensor_image.shape[1]
    m1_h = tensor_image.shape[2]
    m1_w = tensor_image.shape[3]

    m2_out = kernel.shape[0]
    m2_in = kernel.shape[1]
    m2_h = kernel.shape[2]
    m2_w = kernel.shape[3]

    if m1_out != 1 or m2_out != 1:
        print("Input image or gradient image is not a 3d image!")
        return
    w_size_h = w_size[2]
    w_size_w = w_size[3]
    w_x = 0
    w_y = 0
    if not isinstance(w_index, str):
        w_x = int(w_index % w_size_w)
        w_y = int(w_index / w_size_w)
    if w_x >= w_size_w or w_y >= w_size_h:
        print("Weight coordinates go beyond the weight size!")
        return

    if ((m1_h - w_size_h + 1 != m2_h) or
            (m1_w - w_size_w + 1 != m2_w)):
        print("Dimensions of input image and gradient "
              "image don't match with weight size!")
        return

    A = copy.deepcopy(kernel)
    A = A.reshape(m2_in, m2_h * m2_w)
    B = copy.deepcopy(tensor_image)
    if not isinstance(w_index, str) and w_index < (w_size_h * w_size_w):
        C = B[:, :, w_y:(m2_h + w_y), w_x:(m2_w + w_x)]
        C = C.reshape(m1_in, m2_h * m2_w)
        C = C.permute(1, 0)
        result = A.mm(C)
        result = result.reshape(result.shape[0], result.shape[1], 1)
    elif w_index == "all":
        result = None
        for i in range(w_size_w):
            for j in range(w_size_h):
                C = B[:, :, j:(m2_h + j), i:(m2_w + i)]
                C = C.reshape(m1_in, m2_h * m2_w)
                C = C.permute(1, 0)
                new = A.mm(C)
                if result is not None:
                    new = new.reshape(new.shape[0], new.shape[1], 1)
                    result = torch.cat((result, new), 2)
                else:
                    result = new.reshape(new.shape[0], new.shape[1], 1)

    if w_index != "all":
        result = result.reshape(result.shape[0], result.shape[1], 1, 1)
    else:
        result = result.reshape(result.shape[0], result.shape[1],
                                w_size_h, w_size_w)
    # print("Size of Result after reshape is ", result.size())
    return result


def flip_matrix_in_h_and_v(tensor_image):
    pass


def generate_instr_params(folder_name):
    test_folder = os.path.split(folder_name)[0]
    test_folder = os.path.split(test_folder)[1]
    isa_params = OrderedDict()
    op_type = test_folder[0:3]
    # print("op_type is ", op_type)
    in_shape_pattern = re.compile(r"_in_(.*?)_", re.S)
    in_shape = re.findall(in_shape_pattern, test_folder)[0]
    in_shape = [int(e) for e in in_shape.split("x")]
    #print("in_shape is ", in_shape)
    out_shape_pattern = re.compile(r"_out_(.*?)_", re.S)
    out_shape = re.findall(out_shape_pattern, test_folder)[0]
    out_shape = [int(e) for e in out_shape.split("x")]
    #print("out_shape is ", out_shape)
    weight_shape_pattern = re.compile(r"_w_(.*?)_", re.S)
    weight_shape = re.findall(weight_shape_pattern, test_folder)[0]
    #print("weight_shape is ", weight_shape)
    weight_shape = [int(e) for e in weight_shape.split("x")]
    #print("weight_shape is ", weight_shape)
    data_type_pattern = re.compile(r"_dt_(.*?)_", re.S)
    data_type = re.findall(data_type_pattern, test_folder)
    #print("data_type is ", data_type)
    if len(data_type) == 0:
        data_type_pattern = re.compile(r"_dt_(.*?)$", re.S)
        data_type = re.findall(data_type_pattern, test_folder)
    data_type = data_type[0]
    #print("data_type is ", data_type)

    i_dt, w_dt, o_dt = data_type.split("x")
    if op_type != "bpw":
        best_input_ch = pick_a_input_chanel(w_dt, weight_shape)
    else:
        best_input_ch = pick_a_input_chanel(o_dt, out_shape)

    buf_a_inc, buf_b_inc, o_ld_tm, i_ld_tm, h_ld_tm, w_ld_tm =\
        construct_block0(
            in_shape, weight_shape, out_shape, data_type, op_type,
            isa_params, best_input_ch)
    print("construct block0 finished.")
    construct_block1(
        in_shape, weight_shape, out_shape, data_type, op_type,
        isa_params, best_input_ch, buf_a_inc, buf_b_inc,
        o_ld_tm, i_ld_tm, h_ld_tm, w_ld_tm)
    print("construct block1 finished.")

    return isa_params


def get_unit_tests_folder(folder_name, dest_path=None):
    if dest_path:
        unit_path = os.path.join(dest_path)
    else:
        br_root = utils.brgen_root
        unit_path = os.path.join(br_root, "command_generator",
                                "vectors", "unit", folder_name)
    # print("unit_path is ", unit_path)

    if os.path.exists(unit_path):
        shutil.rmtree(unit_path)
    utils.biren_mkdir(unit_path)

    input_folder = os.path.join(unit_path, "input")
    os.mkdir(input_folder)

    return input_folder


def construct_folder(input_shape, weight_shape, operator_type,
                     dilation_value, stride_value, padding_value,
                     input_dt, weight_dt, output_dt, bpw_index=None,
                     delete=True, dest_path=None, fwd_ih_iw=None):
    weight_index = 0
    if operator_type == "bpw":
        if delete:
            index = args.index
        else:
            index = bpw_index
        if index.lower() != "all":
            weight_index = int(index)
        else:
            weight_index = "all"

    if ((not isinstance(weight_index, str)) and
            weight_index >= (weight_shape[2] * weight_shape[3])):
        print("Weight index goes beyong the weight number!")
        sys.exit(1)

    if operator_type == "fwd":
        if input_shape[1] != weight_shape[1]:
            print("The input channel is not matched with filter"
                  " input channel!")
            sys.exit(1)

    tensor_b = construct_pattern_tensor(
        input_shape[0], input_shape[1], input_shape[2], input_shape[3], dtype=input_dt)
    if input_dt == 'bf16':
        tensor_b = pt.from_numpy(br_fp32Tobf16Tofp32(tensor_b))
    #print("tensor_b", tensor_b)
    #print("size of tensor_b is ", tensor_b.shape)

    tensor_a = None
    if operator_type == "bpw":
        tensor_a = construct_pattern_tensor(
            output_shape[0], output_shape[1],
            output_shape[2], output_shape[3], dtype=output_dt)
    else:
        tensor_a = construct_kernel(
            weight_shape[0], weight_shape[1],
            weight_shape[2], weight_shape[3], dtype=weight_dt)
        if weight_dt == 'bf16':
            tensor_a = pt.from_numpy(br_fp32Tobf16Tofp32(tensor_a))
    #print("tensor_a", tensor_a)
    #print("size of tensor_a is ", tensor_a.shape)

    old_tensor_a = copy.deepcopy(tensor_a)
    old_tensor_b = copy.deepcopy(tensor_b)
    
    if input_dt == "s8" or input_dt == "u8":
        if weight_dt == "s8" or weight_dt == "u8":
            tensor_a = tensor_a.int()
            tensor_b = tensor_b.int()
        else:
            tensor_b = tensor_b.float()
    elif input_dt == "bf16":
        tensor_a = tensor_a.float()

    # print(tensor_a.size())

    if operator_type.lower() == "bpa":
        k = torch.flip(tensor_a, [2, 3])
        tensor_a = torch.transpose(k, 0, 1)

    # print("After flip: ")
    # print(k.size())

    # print(t0)

    # if operator_type.lower() == "bpa":
    #     p2d = ()
    #     if weight_shape[2] == 3 and weight_shape[3] == 3:
    #         p2d = (2, 2, 2, 2)
    #     elif weight_shape[2] == 5 and weight_shape[3] == 5:
    #         p2d = (4, 4, 4, 4)
    #     elif weight_shape[2] == 7 and weight_shape[3] == 7:
    #         p2d = (6, 6, 6, 6)
    #     t0 = F.pad(tensor_b, p2d, "constant", 0)
    #     tensor_b = t0
    if  operator_type.lower() == "bpa" and stride_value > 1:
        fwd_ih, fwd_iw = fwd_ih_iw
        tmp_tensor_b = torch.zeros(input_shape[0], input_shape[1], fwd_ih, fwd_iw)
        for n in range(input_shape[0]):
            for c in range(input_shape[1]):
                for h in range(input_shape[2]):
                    for w in range(input_shape[3]):
                        tmp_h = h * stride_value
                        tmp_w = w * stride_value
                        tmp_tensor_b[n, c, tmp_h, tmp_w] = tensor_b[n, c, h, w]
        tensor_b = tmp_tensor_b
        stride_value = 1

    conved0 = None
    if operator_type.lower() == "bpw":
        conved0 = br_bpw_conv(tensor_b, tensor_a, weight_shape, weight_index)
    else:
        conved0 = br_conv(tensor_b, tensor_a, dilation_value, stride_value, padding_value)

    # For the folder name:
    folder_name_format_string = ("{}_in_{}x{}x{}x{}_w_{}x{}x{}x{}_"
                                 "out_{}x{}x{}x{}_dt_{}x{}x{}")
    if operator_type == "bpw":
        folder_name_format_string += "_index_{}"

    folder_name = folder_name_format_string.format(
        operator_type,
        input_shape[0], input_shape[1], input_shape[2], input_shape[3],
        weight_shape[0], weight_shape[1], weight_shape[2],
        weight_shape[3],
        conved0.size(0), conved0.size(1), conved0.size(2),
        conved0.size(3),
        input_dt, weight_dt, output_dt, weight_index)
    unit_path = get_unit_tests_folder(folder_name, dest_path)
    return unit_path, conved0, old_tensor_b, tensor_b, old_tensor_a, tensor_a


def get_params():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        'input', default='32x32x3x3',
        help='Specify the input tenosr shape with format NxCxHxW,'
             ' for example: 1x32x8x8.')

    parser.add_argument(
        'weight', default='32x32x3x3',
        help='Specify the weight tensor shape with format OxIxKHxKW,'
             ' for example: 8x32x3x3.')

    parser.add_argument(
        'dilation', default='1',
        help='Specify the dilation,'
             ' for example: 1.')

    parser.add_argument(
        'stride', default='1',
        help='Specify the stride,'
             ' for example: 1.')

    parser.add_argument(
        'padx', default='1',
        help='Specify the padx,'
             ' for example: 1.')

    parser.add_argument(
        'pady', default='1',
        help='Specify the pady,'
             ' for example: 1.')

    parser.add_argument(
        '--weight_data_type', '-wdt', default='bf16',
        choices=utils.data_types,
        help='Specify the weight data type, for example: bf16.')
    parser.add_argument(
        '--input_data_type', '-idt', default='bf16',
        choices=utils.data_types,
        help='Specify the input data type, for example: bf16.')
    parser.add_argument(
        '--output_data_type', '-odt', default='bf16',
        choices=utils.data_types,
        help='Specify the output data type, for example: bf16.')

    parser.add_argument(
        '--type', '-t', default="fwd", choices=["fwd", "bpa", "bpw"],
        help='Specify the operator type currently,'
             ' only support fwd, bpa, bpw')
    parser.add_argument(
        '--index', '-i', default="0",
        help='Specify which weight is grandient weight'
             ' generation when bpw or "all" to generate all weight')

    parser.add_argument(
        '--wred', default=False,
        help='enable conv wred'
             ' eg. True')
    parser.add_argument(
        '--expansion', default=False, type = bool, choices=[False, True],
        help='enable axsis expansion,now only support top/bottom'
    )
    return parser


def gen_simple_conv(input_shape, weight_shape, dilation_value, stride_value, padding_value,
                    weight_dt, input_dt, output_dt, operator_type, dest_path=None, wred=False, expansion=False, fwd_ih_iw=None):
    if (len(input_shape) != 4 or
            len(weight_shape) != 4):
        print("Tensor dimensions must be 4!")
        sys.exit(1)

    if 0 in input_shape or 0 in weight_shape:
        print("Any dimemsion size of tensor cannot be zero!")
        sys.exit(1)

    folder_name, conved0, old_tensor_b, tensor_b, old_tensor_a, tensor_a = \
        construct_folder(input_shape, weight_shape, operator_type,
                         dilation_value, stride_value, padding_value,
                         input_dt, weight_dt, output_dt, dest_path=dest_path, fwd_ih_iw=fwd_ih_iw)

    # # The dump path setting
    # BrThDump.SetDumpPath(folder_name)
    if operator_type.lower() == "fwd":
        # BrThDump.DumpInput4dTensorToBF16(
        #     "br-unit-fwd-U1", "conv0-A-3DA", 1, old_tensor_b)
        if expansion:
            assert old_tensor_b.shape[0] % AXIS_EXPANSION_SAMPLE_NUM == 0
            n, c, h, w = old_tensor_b.shape
            old_tensor_b = old_tensor_b.permute(1, 0, 2, 3)
            old_tensor_b = old_tensor_b.reshape(
                c, int(n/AXIS_EXPANSION_SAMPLE_NUM), -1, w)
            old_tensor_b = old_tensor_b.permute(1, 0, 2, 3)
        file_info = os.path.join(folder_name, "br-unit-fwd-U1-conv0-A-3DA-" + tuple_to_string(old_tensor_b.shape))
        if input_dt == 'bf16':
            br_dump_ConvActivation_in_bf16(file_info, old_tensor_b)
        elif input_dt == 'fp32':
            br_dump_ConvActivation_in_fp32(file_info, old_tensor_b)
        elif input_dt == 's8' or input_dt == 'u8':
            br_dump_ConvActivation_in_s8_u8(file_info, old_tensor_b, input_dt)
    elif operator_type.lower() == "bpw":
        # BrThDump.DumpInput4dTensorToBF16(
        #     "br-unit-bpw-U1", "mma0-A-3DA", 1, old_tensor_b)
        raise NotImplementedError
    elif operator_type.lower() == "bpa":
        file_info = os.path.join(folder_name, "br-unit-bpa-U1-conv0-A-3DA-" + tuple_to_string(old_tensor_b.shape))
        if input_dt == 'bf16':
            br_dump_ConvActivation_in_bf16(file_info, old_tensor_b)
        elif input_dt == 'fp32':
            br_dump_ConvActivation_in_fp32(file_info, old_tensor_b)
        elif input_dt == 's8' or input_dt == 'u8':
            br_dump_ConvActivation_in_s8_u8(file_info, old_tensor_b, input_dt)

    if operator_type.lower() == "fwd":
        # param = torch.nn.Parameter(old_tensor_a)
        # BrThDump.SetConvWeightByIdx(param, 0)
        # BrThDump.DumpWeight4dTensorToBF16(
        #     "br-unit-fwd-U0", "conv0-W-4DW", 1, 0)
        file_info = os.path.join(folder_name, "br-unit-fwd-U0-conv0-W-4DW-" + tuple_to_string(weight_shape))
        if weight_dt == 'bf16':
            br_dump_ConvWeight_in_bf16(file_info, old_tensor_a)
        elif weight_dt == 'fp32':
            br_dump_ConvWeight_in_fp32(file_info, old_tensor_a)
        elif weight_dt == 's8' or weight_dt == 'u8':
            br_dump_ConvWeight_in_s8_u8(file_info, old_tensor_a, weight_dt)

    elif operator_type.lower() == "bpa":
        file_info = os.path.join(folder_name, "br-unit-bpa-U0-conv0-W-4DW-" + tuple_to_string(old_tensor_a.shape))
        if weight_dt == 'bf16':
            br_dump_ConvWeight_in_bf16(file_info, old_tensor_a)
        elif weight_dt == 'fp32':
            br_dump_ConvWeight_in_fp32(file_info, old_tensor_a)
        elif weight_dt == 's8' or weight_dt == 'u8':
            br_dump_ConvWeight_in_s8_u8(file_info, old_tensor_a, weight_dt)

    elif operator_type.lower() == "bpw":
        # BrThDump.DumpInput4dTensorToBF16(
        #     "br-unit-bpw-U0", "mma0-A-3DA", 1, old_tensor_a)
        raise NotImplementedError

    if conved0 is not None:
        if operator_type.lower() == "fwd":
            # BrThDump.DumpInput4dTensorToBF16(
            #     "br-unit-fwd-U2", "conv0-A-3DA", 1, conved0)
            if expansion:
                n, c, h, w = conved0.shape
                conved0 = conved0.permute(1, 0, 2, 3)
                conved0 = conved0.reshape(
                    c, int(n/AXIS_EXPANSION_SAMPLE_NUM), -1, w)
                conved0 = conved0.permute(1, 0, 2, 3)
            file_info = os.path.join(folder_name, "br-unit-fwd-U2-conv0-A-3DA-" + tuple_to_string(conved0.shape))
            if output_dt == 'bf16':
                br_dump_ConvActivation_in_bf16(file_info, conved0)
            elif output_dt == 'fp32':
                br_dump_ConvActivation_in_fp32(file_info, conved0)
            elif output_dt == 's8' or output_dt == 'u8':
                br_dump_ConvActivation_in_s8_u8(file_info, conved0, output_dt)
            # add wred of conv
            if wred:
                gamma = construct_fake_gamma(weight_shape[0])
                beta = construct_fake_beta(weight_shape[0])
                x_sum = br_sum(conved0)
                x_sq_sum = br_sq_sum(conved0)
                tensor_tp = (gamma, beta, x_sum, x_sq_sum)
                file_info = os.path.join(folder_name,"br-unit-fwd-U3-conv0-R-1DV-1x1x1x{}")
                br_dump_conv_wred_in_fp32(file_info,tensor_tp)
        elif operator_type.lower() == "bpa":
            file_info = os.path.join(folder_name, "br-unit-bpa-U2-conv0-A-3DA-" + tuple_to_string(conved0.shape))
            if output_dt == 'bf16':
                br_dump_ConvActivation_in_bf16(file_info, conved0)
            elif output_dt == 'fp32':
                br_dump_ConvActivation_in_fp32(file_info, conved0)
            elif output_dt == 's8' or output_dt == 'u8':
                br_dump_ConvActivation_in_s8_u8(file_info, conved0, output_dt)
        elif operator_type.lower() == "bpw":
            # # print("Here here here")
            # # print(conved0)
            # param = torch.nn.Parameter(conved0)
            # BrThDump.SetConvWeightByIdx(param, 0)
            # BrThDump.DumpWeight4dTensorToBF16(
            #     "br-unit-bpw-U2", "mma0-W-4DW", 1, 0)
            raise NotImplementedError


if __name__ == '__main__':
    parser = get_params()
    possible_index = ["{}".format(i) for i in range(49)]
    possible_index.append("all")

    args = parser.parse_args()

    input_shape = [int(e) for e in args.input.split("x")]
    weight_shape = [int(e) for e in args.weight.split("x")]
    dilation_value = int(args.dilation)
    stride_value = int(args.stride)
    padx_value = int(args.padx)
    pady_value = int(args.pady)
    padding_value = (padx_value, pady_value)
    weight_dt = args.weight_data_type
    input_dt = args.input_data_type
    output_dt = args.output_data_type
    operator_type = args.type
    wred = args.wred
    expansion = args.expansion

    gen_simple_conv(input_shape, weight_shape, dilation_value, stride_value, padding_value,
                    weight_dt, input_dt, output_dt, operator_type, wred=wred, expansion=expansion)

    #isa_params = generate_instr_params(folder_name)
    # print("isa_params is ", isa_params)
    #io_handler.simple_generate_json_file(
    #    isa_params, folder_name, "isa_params.json")

    # br_layout.align_4d_weight_tensor(old_tensor_a, folder_name)

    # t1 = construct_random_tensor(8)
    # print(t1)

    # t2 = construct_pattern_tensor(20, 64, 8)
    # BrThDump.DumpInput4dTensorToBF16("BR_CONV", "temp", 1, t2)

    # conved1, kernel1 = br_conv(t1, k)
    # print(conved1)
