# Copyright 2020, Biren Technologies Inc.
# All rights reserved.

import torch as pt
import numpy as np
import torch.nn.functional as F
import math
import os

# yhb: trunk the 16b lsb out
def fp32Tobf16(np_tensor):
    if type(np_tensor) != np.ndarray:
        raise("only support numpy tensor")

    if np_tensor.dtype != "float32":
        raise("only support float32")

    buf = np_tensor.tobytes()
    raw = np.frombuffer(buf, dtype="int16")

    raw_split = raw.reshape(int(raw.shape[0]/2), 2)
    raw_trans = raw_split.transpose(1, 0)

    bf16 = raw_trans[1]
    ret = bf16.reshape(np_tensor.shape)
    return ret

def bf16Tofp32(np_tensor):
    if type(np_tensor) != np.ndarray:
        raise("only support numpy tensor")

    if np_tensor.dtype != 'int16':
        raise("only support int16")

    bf_shape = np_tensor.shape
    totol_dem = np_tensor.size

    tensor_fp32 = np.zeros((2,totol_dem),dtype='int16')
    tensor_fp32[1] = np_tensor.reshape(1,totol_dem)

    tensor_fp32_tp = tensor_fp32.transpose()
    buf = tensor_fp32_tp.tobytes()

    tensor_fp32_checked = np.frombuffer(buf,dtype="float32")
    # tensor_fp32_tp = tensor_fp32_tp.reshape(1,-1)
    # tensor_fp32_tp.dtype = 'float32'

    ret = tensor_fp32_checked.reshape(bf_shape)
    return ret

CONV_C_TILE_2 = 16
CONV_C_TILE = 8
CONV_W_TILE = 8
CONV_H_TILE = 4

SUBBLOCK_NUM = 4
SUBBLOCK_H_TILE = 2

CONV_ALIGN_W = 8
CONV_ALIGN_H = 8
# shape from （C, H, W） to （ C/8,  W/8,  H/4,  C4,  H4,  W8,  C2）
# add alignment 8*8
def convertConvActivation(tensor):
    n = tensor.shape[0]
    c = tensor.shape[1]
    h = tensor.shape[2]
    w = tensor.shape[3]

    # do align_x align_y firstly
    align_w_block = int(math.ceil(w / CONV_ALIGN_W))
    align_h_block = int(math.ceil(h / CONV_ALIGN_H))

    aligned_w = align_w_block * CONV_ALIGN_W
    aligned_h = align_h_block * CONV_ALIGN_H

    pad_w = aligned_w - w
    pad_h = aligned_h - h

    hw_aligned = F.pad(input=tensor, pad=(0, pad_w, 0, pad_h, 0, 0, 0, 0), mode="constant", value=0)

    c_block = int(math.ceil(c / CONV_C_TILE))

    w_block = int(math.ceil(aligned_w / CONV_W_TILE))
    h_block = int(math.ceil(aligned_h / CONV_H_TILE))

    new_c = c_block * CONV_C_TILE
    new_w = w_block * CONV_W_TILE
    new_h = h_block * CONV_H_TILE

    pad_c = new_c - c
    pad_w = new_w - aligned_w
    pad_h = new_h - aligned_h

    chw_pad = F.pad(input=hw_aligned, pad=(0,pad_w, 0,pad_h, 0,pad_c, 0,0), mode="constant", value=0)
    c_reshape = chw_pad.reshape((n, c_block, SUBBLOCK_NUM, SUBBLOCK_H_TILE, h_block, CONV_H_TILE, w_block, CONV_W_TILE))
    ret = c_reshape.permute(0, 1, 6, 4, 2, 5, 7, 3)
    return ret


CONV_C4_TILE = 4
# shape from (C,H,W) to (C/8, W/8, H/4, C4, H4, W8),aligned to 8x8


def convertConvActivationFP32(tensor):
    n = tensor.shape[0]
    c = tensor.shape[1]
    h = tensor.shape[2]
    w = tensor.shape[3]

    # do align_x align_y firstly
    align_w_block = int(math.ceil(w / CONV_ALIGN_W))
    align_h_block = int(math.ceil(h / CONV_ALIGN_H))

    aligned_w = align_w_block * CONV_ALIGN_W
    aligned_h = align_h_block * CONV_ALIGN_H

    pad_w = aligned_w - w
    pad_h = aligned_h - h

    hw_aligned = F.pad(input=tensor, pad=(0, pad_w, 0, pad_h, 0, 0, 0, 0), mode="constant", value=0)

    c_block = int(math.ceil(c / CONV_C4_TILE))

    w_block = int(math.ceil(aligned_w / CONV_W_TILE))
    h_block = int(math.ceil(aligned_h / CONV_H_TILE))

    new_c = c_block * CONV_C4_TILE
    new_w = w_block * CONV_W_TILE
    new_h = h_block * CONV_H_TILE

    pad_c = new_c - c
    pad_w = new_w - aligned_w
    pad_h = new_h - aligned_h

    chw_pad = F.pad(input=hw_aligned, pad=(0,pad_w, 0,pad_h, 0,pad_c, 0,0), mode="constant", value=0)
    c_reshape = chw_pad.reshape((n, c_block, CONV_C4_TILE, h_block, CONV_H_TILE, w_block, CONV_W_TILE))
    ret = c_reshape.permute(0, 1, 5, 3, 2, 4, 6)
    return ret


SUBBLOCK_H4_TILE = 4
# shape from （C, H, W） to （ C/16,  W/8,  H/4,  C4,  H4,  W8,  C4）


def convertConvActivationS8(tensor):
    n = tensor.shape[0]
    c = tensor.shape[1]
    h = tensor.shape[2]
    w = tensor.shape[3]

    # do align_x align_y firstly
    align_w_block = int(math.ceil(w / CONV_ALIGN_W))
    align_h_block = int(math.ceil(h / CONV_ALIGN_H))

    aligned_w = align_w_block * CONV_ALIGN_W
    aligned_h = align_h_block * CONV_ALIGN_H
    pad_w = aligned_w - w
    pad_h = aligned_h - h

    hw_aligned = F.pad(input=tensor, pad=(0, pad_w, 0, pad_h, 0, 0, 0, 0), mode="constant", value=0)
    c_block = int(math.ceil(c / CONV_C_TILE_2))

    w_block = int(math.ceil(aligned_w / CONV_W_TILE))
    h_block = int(math.ceil(aligned_h / CONV_H_TILE))

    new_c = c_block * CONV_C_TILE_2
    new_w = w_block * CONV_W_TILE
    new_h = h_block * CONV_H_TILE

    pad_c = new_c - c
    pad_w = new_w - aligned_w
    pad_h = new_h - aligned_h

    chw_pad = F.pad(input=hw_aligned, pad=(0,pad_w, 0,pad_h, 0,pad_c, 0,0), mode="constant", value=0)
    c_reshape = chw_pad.reshape((n, c_block, SUBBLOCK_NUM, SUBBLOCK_H4_TILE, h_block, CONV_H_TILE, w_block, CONV_W_TILE))
    ret = c_reshape.permute(0, 1, 6, 4, 2, 5, 7, 3)
    return ret


CONV_COUT_TILE = 8
CONV_CIN_TILE = 32
SUBBLOCK_NUM = 4
SUBBLOCK_COUT_NUM = 2
# yhb: shape = [Sx, Sy, Cin, Cout] => [Cout/8, Cin/32, Sx, Sy, Cout8,Cin32]
# shape from [Sx, Sy, Cin, Cout] => [Cout/8, Cin/32, Sx, Sy, Cout8,Cin32] => [Cout/8, Cin/32, Sx, Sy, Cout4,Cin32,Cout2]
def convertConvWeight(tensor):
    tensor = tensor.permute(2,3,1,0)
    sx = tensor.shape[0]
    sy = tensor.shape[1]
    cin = tensor.shape[2]
    cout = tensor.shape[3]

    cout_block = int(math.ceil(cout / CONV_COUT_TILE))
    cin_block = int(math.ceil(cin / CONV_CIN_TILE))

    new_cout = cout_block * CONV_COUT_TILE
    new_cin = cin_block * CONV_CIN_TILE

    pad_cout = new_cout - cout
    pad_cin = new_cin - cin

    xy_reshape = tensor.reshape((sx * sy, cin, cout))
    c_pad = F.pad(input=xy_reshape, pad=(0,pad_cout, 0,pad_cin, 0,0), mode="constant", value=0)

    c_reshape = c_pad.reshape(sx * sy, cin_block, CONV_CIN_TILE, cout_block, SUBBLOCK_NUM, SUBBLOCK_COUT_NUM)
    ret = c_reshape.permute(3, 1, 0, 4, 2, 5)
    return ret


CONV_COUT4_TILE = 4
# shape from [Sx, Sy, Cin, Cout] => [Cout/4, Cin/32, Sx, Sy, Cout4,Cin32]


def convertConvWeightFP32(tensor):
    tensor = tensor.permute(2,3,1,0)
    sx = tensor.shape[0]
    sy = tensor.shape[1]
    cin = tensor.shape[2]
    cout = tensor.shape[3]

    cout_block = int(math.ceil(cout / CONV_COUT4_TILE))
    cin_block = int(math.ceil(cin / CONV_CIN_TILE))

    new_cout = cout_block * CONV_COUT4_TILE
    new_cin = cin_block * CONV_CIN_TILE

    pad_cout = new_cout - cout
    pad_cin = new_cin - cin

    xy_reshape = tensor.reshape((sx * sy, cin, cout))
    c_pad = F.pad(input=xy_reshape, pad=(0,pad_cout, 0,pad_cin, 0,0), mode="constant", value=0)

    c_reshape = c_pad.reshape(sx * sy, cin_block, CONV_CIN_TILE, cout_block, CONV_COUT4_TILE)
    ret = c_reshape.permute(3, 1, 0, 4, 2)
    return ret

CONV_CIN64_TILE = 64
CONV_CIN64_SUBNUMBER = 2
CONV_CIN64_SUBBLOCK = 32
# shape from [Sx, Sy, Cin, Cout] => [Cout/8, Cin/64, Sx, Sy, Cout8,Cin64] => [Cout/8, Cin/64, Sx, Sy, Cout4,Cin64,Cout2]


def convertConvWeightS8(tensor):
    tensor = tensor.permute(2,3,1,0)
    sx = tensor.shape[0]
    sy = tensor.shape[1]
    cin = tensor.shape[2]
    cout = tensor.shape[3]

    cout_block = int(math.ceil(cout / CONV_COUT_TILE))
    cin_block = int(math.ceil(cin / CONV_CIN64_TILE))

    new_cout = cout_block * CONV_COUT_TILE
    new_cin = cin_block * CONV_CIN64_TILE

    pad_cout = new_cout - cout
    pad_cin = new_cin - cin

    xy_reshape = tensor.reshape((sx * sy, cin, cout))
    c_pad = F.pad(input=xy_reshape, pad=(0,pad_cout, 0,pad_cin, 0,0), mode="constant", value=0)

    c_reshape = c_pad.reshape(sx * sy, cin_block, CONV_CIN64_SUBBLOCK, CONV_CIN64_SUBNUMBER, cout_block, SUBBLOCK_NUM, SUBBLOCK_COUT_NUM)
    ret = c_reshape.permute(4, 1, 0, 5, 2, 6, 3)
    return ret


DWC_CH_TILE = 32
DWC_CH_TILE_U8_S8 = 64

# from (C,1,H,W) to (C/32,H*W,C32)
def convertDWCWeight(tensor, dtype="bf16"):
    assert tensor.shape[1] == 1, "make sure DWC weight have right shape"

    c = tensor.shape[0]
    h = tensor.shape[2]
    w = tensor.shape[3]

    xy_reshape = tensor.reshape(c, h * w)
    if dtype == "bf16":
        ch_align_num = DWC_CH_TILE
    elif dtype == "s8" or dtype == "u8":
        ch_align_num = DWC_CH_TILE_U8_S8
    c_block = int(math.ceil(c / ch_align_num))
    new_c = c_block * ch_align_num

    pad_c = new_c - c

    c_pad = F.pad(input=xy_reshape,
                  pad=(0, 0, 0, pad_c),
                  mode="constant",
                  value=0)

    c_reshape = c_pad.reshape(c_block, ch_align_num, h * w)
    ret = c_reshape.permute(0, 2, 1)
    return ret