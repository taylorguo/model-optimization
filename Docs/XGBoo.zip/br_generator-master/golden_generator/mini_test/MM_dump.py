#! python3

import torch as pt
import numpy as np
import torch.nn.functional as F
import math
import os,copy
from command_generator import utils


MM_TILE_X3 = 32
MM_TILE_Y3 = 4
MM_TILE_X = 8
MM_TILE_Y = 32
MM_SUBBLOCK_NUM = 4
MM_SUBBLOCK_RP = 2
# yhb: blocklinear: shape = [x, y] => [x/8, y/32, x8, y32]
# add 2 rows packed firstly
def convertMMWeight(tensor):
    x = tensor.shape[0]
    y = tensor.shape[1]

    block_x = int(math.ceil(x/MM_TILE_X))
    block_y = int(math.ceil(y/(MM_TILE_Y*4)))
    block_y = block_y * 4

    new_x = block_x * MM_TILE_X
    new_y = block_y * MM_TILE_Y

    pad_x = new_x - x
    pad_y = new_y - y
    xy_pad = F.pad(input=tensor, pad=(0,pad_y,0,pad_x), mode="constant", value=0)

    y_tile = xy_pad.reshape((new_x, block_y, MM_TILE_Y))
    xy_tile = y_tile.reshape((block_x, MM_TILE_X, block_y, MM_TILE_Y))

    xy_tile = xy_tile.transpose(1, 2)
    xy_tile_cp = xy_tile.reshape(block_x,block_y,MM_SUBBLOCK_NUM,MM_SUBBLOCK_RP,MM_TILE_Y)
    ret = xy_tile_cp.transpose(3,4)

    return ret


MM_TILE_FP32_X = 4


def convertMMWeightFP32(tensor):
    x = tensor.shape[0]
    y = tensor.shape[1]

    block_x = int(math.ceil(x / MM_TILE_FP32_X))
    block_y = int(math.ceil(y / (MM_TILE_Y * 4)))
    block_y = block_y * 4

    new_x = block_x * MM_TILE_FP32_X
    new_y = block_y * MM_TILE_Y

    pad_x = new_x - x
    pad_y = new_y - y
    xy_pad = F.pad(input=tensor,
                   pad=(0, pad_y, 0, pad_x),
                   mode="constant",
                   value=0)

    y_tile = xy_pad.reshape((new_x, block_y, MM_TILE_Y))
    xy_tile = y_tile.reshape((block_x, MM_TILE_FP32_X, block_y, MM_TILE_Y))

    ret = xy_tile.transpose(1, 2)

    return ret


MM_TILE_S8_Y = 64
MM_TILE_S8_Y_SUBBLOCK = 32
MM_TILE_S8_Y_SUBNUM = 2


def convertMMWeightS8(tensor):
    x = tensor.shape[0]
    y = tensor.shape[1]

    block_x = int(math.ceil(x / MM_TILE_X))
    block_y = int(math.ceil(y / (MM_TILE_S8_Y * 4)))
    block_y = block_y * 4

    new_x = block_x * MM_TILE_X
    new_y = block_y * MM_TILE_S8_Y

    pad_x = new_x - x
    pad_y = new_y - y
    xy_pad = F.pad(input=tensor,
                   pad=(0, pad_y, 0, pad_x),
                   mode="constant",
                   value=0)

    y_tile = xy_pad.reshape((new_x, block_y, MM_TILE_S8_Y))
    xy_tile = y_tile.reshape((block_x, MM_TILE_X, block_y, MM_TILE_S8_Y))

    xy_tile = xy_tile.transpose(1, 2)
    xy_tile_cp = xy_tile.reshape(block_x, block_y, MM_SUBBLOCK_NUM,
                                 MM_SUBBLOCK_RP, MM_TILE_S8_Y)
    xy_tile_cp = xy_tile_cp.reshape(block_x, block_y, MM_SUBBLOCK_NUM,
                                    MM_SUBBLOCK_RP, MM_TILE_S8_Y_SUBBLOCK,
                                    MM_TILE_S8_Y_SUBNUM)
    ret = xy_tile_cp.transpose(3, 4)

    return ret



# yhb: y major blocklinear: shape = [x, y] => [y/32, x/8, x8, y32]
# add 2 rows packed firstly
def convertMMActivation(tensor):
    x = tensor.shape[0]
    y = tensor.shape[1]

    block_x = int(math.ceil(x/(MM_TILE_X*4)))
    block_y = int(math.ceil(y/MM_TILE_Y))
    block_x = block_x * 4

    new_x = block_x * MM_TILE_X
    new_y = block_y * MM_TILE_Y

    pad_x = new_x - x
    pad_y = new_y - y
    xy_pad = F.pad(input=tensor,pad=(0,pad_y,0,pad_x),mode="constant",value=0)

    y_tile = xy_pad.reshape((new_x, block_y, MM_TILE_Y))
    xy_tile = y_tile.reshape((block_x, MM_TILE_X, block_y, MM_TILE_Y))

    ret = xy_tile.transpose(1, 2)
    ret = ret.transpose(0,1)
    ret = ret.reshape(block_y,block_x,MM_SUBBLOCK_NUM,MM_SUBBLOCK_RP,MM_TILE_Y)
    ret = ret.transpose(3, 4)

    return ret
    #return convertMMActivation(y_major)


def convertMMActivationFP32(tensor):
    x = tensor.shape[0]
    y = tensor.shape[1]

    block_x = int(math.ceil(x / (MM_TILE_FP32_X * 4)))
    block_y = int(math.ceil(y / MM_TILE_Y))
    block_x = block_x * 4

    new_x = block_x * MM_TILE_FP32_X
    new_y = block_y * MM_TILE_Y

    pad_x = new_x - x
    pad_y = new_y - y
    xy_pad = F.pad(input=tensor,
                   pad=(0, pad_y, 0, pad_x),
                   mode="constant",
                   value=0)

    y_tile = xy_pad.reshape((new_x, block_y, MM_TILE_Y))
    xy_tile = y_tile.reshape((block_x, MM_TILE_FP32_X, block_y, MM_TILE_Y))

    ret = xy_tile.transpose(1, 2)

    return ret


MM_TILE_S8_X = 16
MM_TILE_S8_X_SUBNUM = 4


def convertMMActivationS8(tensor):
    x = tensor.shape[0]
    y = tensor.shape[1]

    block_x = int(math.ceil(x/(MM_TILE_S8_X*4)))
    block_y = int(math.ceil(y/MM_TILE_Y))
    block_x = block_x * 4

    new_x = block_x * MM_TILE_S8_X
    new_y = block_y * MM_TILE_Y

    pad_x = new_x - x
    pad_y = new_y - y
    xy_pad = F.pad(input=tensor,pad=(0,pad_y,0,pad_x),mode="constant",value=0)

    y_tile = xy_pad.reshape((new_x, block_y, MM_TILE_Y))
    xy_tile = y_tile.reshape((block_x, MM_TILE_S8_X, block_y, MM_TILE_Y))

    ret = xy_tile.transpose(1, 2)
    ret = ret.transpose(0,1)
    ret = ret.reshape(block_y,block_x,MM_SUBBLOCK_NUM,MM_TILE_S8_X_SUBNUM,MM_TILE_Y)
    ret = ret.transpose(3, 4)

    return ret


def construct_pattern_tensor(h, w, value=None, dtype="fp32"):
    t = []
    total = h * w
    if value is None:
        for i in range(total):
            t.append(i)
    else:
        for i in range(total):
            t.append(value)
    if dtype == "fp32" or dtype == "bf16":
        tensor = pt.FloatTensor(t).reshape(h, w)
    elif dtype == "s8":
        tensor = pt.CharTensor(t).reshape(h, w)
    elif dtype == "u8":
        tensor = pt.ByteTensor(t).reshape(h, w)
    return tensor


# yhb: trunk the 16b lsb out
def fp32Tobf16(np_tensor):
    if type(np_tensor) != np.ndarray:
        raise("only support numpy tensor")

    if np_tensor.dtype != 'float32':
        raise("only support float32")

    buf = np_tensor.tobytes()
    raw = np.frombuffer(buf, dtype="int16")

    raw_split = raw.reshape(int(raw.shape[0]/2), 2)
    raw_trans = raw_split.transpose(1, 0)

    bf16 = raw_trans[1]
    ret = bf16.reshape(np_tensor.shape)
    return ret


def bf16Tofp32(np_tensor):
    if type(np_tensor) != np.ndarray:
        raise("only support numpy tensor")

    if np_tensor.dtype != 'int16':
        raise("only support int16")

    bf_shape = np_tensor.shape
    totol_dem = np_tensor.size

    tensor_fp32 = np.zeros((2,totol_dem),dtype='int16')
    tensor_fp32[1] = np_tensor.reshape(1,totol_dem)

    tensor_fp32_tp = tensor_fp32.transpose()
    buf = tensor_fp32_tp.tobytes()

    tensor_fp32_checked = np.frombuffer(buf,dtype="float32")

    ret = tensor_fp32_checked.reshape(bf_shape)
    return ret


def br_fp32Tobf16Tofp32(tensor):
    tensor_cp = tensor.clone().detach()
    shape_cp = tensor_cp.shape
    if len(tensor_cp.shape) == 1:
        tensor_cp = tensor_cp.reshape((1, tensor_cp.shape[0]))
    # convert from fp32 to bf16
    tensor_n = fp32Tobf16(tensor_cp.numpy())
    # convert from bf16 to fp32
    tensor_c = bf16Tofp32(tensor_n)
    tensor_c = tensor_c.reshape(shape_cp)
    tensor_c_cp = copy.deepcopy(tensor_c)
    return tensor_c_cp


def br_dump_MMWeight(file_info, tensor, dtype="fp32"):
    tensor_cp = tensor.clone().detach()
    shape_cp = tensor_cp.shape
    if len(tensor_cp.shape) == 1:
        tensor_cp = tensor_cp.reshape((1, tensor_cp.shape[0]))

    if dtype == "fp32":
        tensor_ct = convertMMWeightFP32(tensor_cp)
    elif dtype == "bf16":
        if tensor_cp.dtype == pt.int32:
            tensor_cp = tensor_cp.float()
        # convert from fp32 to bf16
        tensor_n = fp32Tobf16(tensor_cp.numpy())
        tensor_n_cp = copy.deepcopy(tensor_n)
        tensor_ct = convertMMWeight(
            pt.from_numpy(tensor_n_cp).reshape(shape_cp))
    elif dtype == "s8" or dtype == "u8":
        tensor_ct = convertMMWeightS8(tensor_cp)
    # dump data
    # br_dump_tensor_in_bf16(file_info, tensor_ct.numpy())
    file_name = file_info + '-' + dtype + '.bin'
    tensor_ct.numpy().tofile(file_name)


def br_dump_MMActivation(file_info, tensor, dtype="fp32"):
    tensor_cp = tensor.clone().detach()
    shape_cp = tensor_cp.shape
    if len(tensor_cp.shape) == 1:
        tensor_cp = tensor_cp.reshape((1, tensor_cp.shape[0]))

    if dtype == "fp32":
        tensor_ct = convertMMActivationFP32(tensor_cp)
    elif dtype == "bf16":
        if tensor_cp.dtype == pt.int32:
            tensor_cp = tensor_cp.float()
        # convert from fp32 to bf16
        tensor_n = fp32Tobf16(tensor_cp.numpy())
        tensor_n_cp = copy.deepcopy(tensor_n)
        tensor_ct = convertMMActivation(
            pt.from_numpy(tensor_n_cp).reshape(shape_cp))
    elif dtype == "s8" or dtype == "u8":
        tensor_ct = convertMMActivationS8(tensor_cp)
    # dump data
    # br_dump_tensor_in_bf16(file_info, tensor_ct.numpy())
    file_name = file_info + '-' + dtype + '.bin'
    tensor_ct.numpy().tofile(file_name)


def testMMWeightAndActivation(shape_input,
                              shape_weight,
                              weight_dt='bf16',
                              input_dt='bf16',
                              output_dt='bf16',
                              dest_path=None):
    # 8*32 as a unit, no align to 2KB
    print(shape_input)
    print(shape_weight)
    shape_output = (shape_weight[0], shape_input[1])

    def dump_data_inbf16(order, type, shape, n_tensor):
        root_path = os.path.abspath(
            os.path.dirname(__file__)) if not dest_path else dest_path
        shape_str = '1x1x' + utils.tuple_to_string(shape)
        file_name = os.path.join(
            root_path, "br-unit-fwd-U{}-mma-{}-{}-{}-bf16.bin".format(
                str(order), type, '2D' + type, shape_str))
        n_tensor.tofile(file_name)

    def gen_data_file_name(order, type, shape):
        root_path = os.path.abspath(
            os.path.dirname(__file__)) if not dest_path else dest_path
        shape_str = '1x1x' + utils.tuple_to_string(shape)
        file_name = os.path.join(
            root_path,
            "br-unit-fwd-U{}-mma-{}-{}-{}".format(str(order), type,
                                                  '2D' + type, shape_str))
        return file_name

    tensorWeight = construct_pattern_tensor(shape_weight[0],
                                            shape_weight[1],
                                            dtype=weight_dt)
    tensorActivation = construct_pattern_tensor(shape_input[0],
                                                shape_input[1],
                                                dtype=input_dt)
    # keep bf16 accuracy of pytorch and cmodel is the same
    if weight_dt == 'bf16':
        tensorWeight = pt.from_numpy(br_fp32Tobf16Tofp32(tensorWeight))
    if input_dt == 'bf16':
        tensorActivation = pt.from_numpy(br_fp32Tobf16Tofp32(tensorActivation))
    old_Weight = copy.deepcopy(tensorWeight)
    old_Activation = copy.deepcopy(tensorActivation)
    # check input_dt&&weight_dt and do dtype conversion for computing
    if input_dt == "s8" or input_dt == "u8":
        if weight_dt == "s8" or weight_dt == "u8":
            tensorWeight = tensorWeight.int()
            tensorActivation = tensorActivation.int()
        else:
            tensorActivation = tensorActivation.float()
    elif input_dt == "bf16":
        tensorWeight = tensorWeight.float()
    tensorResult = pt.mm(tensorWeight, tensorActivation)

    weight_name = gen_data_file_name(0, 'W', shape_weight)
    input_name = gen_data_file_name(1, 'A', shape_input)
    output_name = gen_data_file_name(2, 'A', shape_output)

    br_dump_MMWeight(weight_name, old_Weight, weight_dt)
    br_dump_MMActivation(input_name, old_Activation, input_dt)
    br_dump_MMActivation(output_name, tensorResult, output_dt)

    # tW_n = fp32Tobf16(tensorWeight.numpy())
    # tA_n = fp32Tobf16(tensorActivation.numpy())
    # tR_n = fp32Tobf16(tensorResult.numpy())

    # # dump_data_inbf16(0, 'W', shape_weight, tW_n)
    # # dump_data_inbf16(1, 'A', shape_input, tA_n)
    # # dump_data_inbf16(2, 'A', shape_output, tR_n)

    # tW_n_cp = copy.deepcopy(tW_n)
    # tA_n_cp = copy.deepcopy(tA_n)
    # tR_n_cp = copy.deepcopy(tR_n)

    # tW_ct = convertMMWeight(pt.from_numpy(tW_n_cp).reshape(shape_weight))
    # tA_ct = convertMMActivation(pt.from_numpy(tA_n_cp).reshape(shape_input))
    # tR_ct = convertMMActivation(pt.from_numpy(tR_n_cp).reshape(shape_output))

    # dump_data_inbf16(0, 'W', shape_weight, tW_ct.numpy())
    # dump_data_inbf16(1, 'A', shape_input, tA_ct.numpy())
    # dump_data_inbf16(2, 'A', shape_output,  tR_ct.numpy())

    return tensorActivation, tensorWeight, tensorResult


if __name__ == "__main__":
    shape_weight = (200, 300)
    shape_input = (300, 400)
    shape_output = (200, 400)
    testMMWeightAndActivation(shape_input, shape_weight)
