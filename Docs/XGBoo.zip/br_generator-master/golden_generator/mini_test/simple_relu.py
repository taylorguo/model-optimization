# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import torch
import torch.nn as nn
import torch.nn.functional as F
import argparse
import shutil
from command_generator import utils
from br_dump import *

def br_relu(input_tensor,inplace = False):
    return F.relu(input_tensor,inplace)

def construct_fake_tensor(shape=(64,64,112,112), data_pattern="", value=None):
    if data_pattern == "random":
        return torch.randn(shape)
    elif data_pattern == "one":
        return torch.ones(shape)
    else:
        t = []
        total = shape[0]*shape[1]*shape[2]*shape[3]
        if value == None:
            for i in range(total):
                t.append(i)
        else:
            for i in range(total):
                t.append(value)
        return torch.FloatTensor(t).reshape(shape)

def test_br_relu(input_tensor,inplace = False):
    input_shape = input_tensor.shape
    target_addr = os.path.join(utils.brgen_root, unit_dest_path)
    folder_name = 'relu_in_' + tuple_to_string(input_shape)\
        + '_out_' + tuple_to_string(input_shape) + '_dt_bf16xbf16'
    print("folder name is :",folder_name)

    target_path = os.path.join(target_addr, folder_name, 'input')
    if os.path.exists(target_path):
        shutil.rmtree(target_path)
    biren_mkdir(target_path)

    # check the input from dump data
    input_tensor = pt.from_numpy(br_fp32Tobf16Tofp32(input_tensor))
    
    output = br_relu(input_tensor,inplace)

    file_info = os.path.join(target_path,"br-unit-fwd-U0-relu-A-4DA-" + tuple_to_string(input_shape))
    br_dump_ConvActivation_in_bf16(file_info,input_tensor)
    
    file_info = os.path.join(target_path,"br-unit-fwd-U1-relu-A-4DA-" + tuple_to_string(input_shape))
    br_dump_ConvActivation_in_bf16(file_info,output)

    return target_path

def get_params():
    parser = argparse.ArgumentParser()

    parser.add_argument('input', default='2x64x122x122',\
        help='Specify the input tenosr shape with format NxCxHxW,for example: 1x64x8x8.')

    parser.add_argument('--in_place', type=bool, default=False, \
        help='Specify the dilation, for example: False')

    parser.add_argument('--input_data_type', '-idt', default='bf16',\
        choices=utils.data_types,\
            help='Specify the input data type, for example: bf16.')

    parser.add_argument('--output_data_type', '-odt', default='bf16',\
        choices=utils.data_types,\
            help='Specify the output data type, for example: bf16.')

    parser.add_argument('--type', '-t', default="fwd", \
        choices=["fwd", "bpa", "bpw"],\
            help='Specify the operator type currently,only support fwd, bpa, bpw')

    return parser


if __name__ == "__main__":
    parser = get_params()
    args = parser.parse_args()

    input_shape = [int(e) for e in args.input.split("x")]
    assert(len(input_shape) >= 1),"make sure the shape of input_shape is 1D or higher"
    in_place = args.in_place
    input_shape = tuple(input_shape)
    input_tensor = construct_fake_tensor(input_shape)
    ret = test_br_relu(input_tensor,in_place)
    print("target path is :",ret)
    # maybe use in future for backward
    # nn_relu = nn.ReLU(in_place)
    # nn_output = nn_relu(input_tensor)

    # delta_out = torch.dist(ret,nn_output,2)
    # print("Delta output for the two ways : ",delta_out)