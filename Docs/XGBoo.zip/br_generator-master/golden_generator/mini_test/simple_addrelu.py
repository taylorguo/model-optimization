# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import torch
import torch.nn as nn
import torch.nn.functional as F
import argparse
import shutil
from command_generator import utils
from simple_reduce import br_sum,br_sq_sum
from br_dump import *
from simple_relu import br_relu
import copy
def br_addrelu(tensor_a, tensor_b,inplace = False):
    tmp = torch.add(tensor_a, tensor_b)
    tmp_cp = copy.deepcopy(tmp)
    ret = br_relu(tmp_cp,inplace)
    return tmp,ret

def construct_fake_tensor(shape=(64,64,56,56), data_pattern="", value=None):
    if data_pattern == "random":
        return torch.randn(shape)
    elif data_pattern == "one":
        return torch.ones(shape)
    else:
        t = []
        total = shape[0]*shape[1]*shape[2]*shape[3]
        if value == None:
            for i in range(total):
                t.append(i)
        else:
            for i in range(total):
                t.append(value)
        return torch.FloatTensor(t).reshape(shape)


def gen_simple_addrelu(add_shape, inplace=False, dest_path=None):

    input_shape = add_shape
    if not dest_path:
        target_addr = os.path.join(utils.brgen_root, unit_dest_path)
        folder_name = 'addrelu_in_' + tuple_to_string(input_shape) + \
            '_out_' + tuple_to_string(input_shape) + '_dt_bf16xbf16xbf16'
        print("folder name is :",folder_name)
        target_path = os.path.join(target_addr, folder_name, 'input')
    else:
        target_path = os.path.join(dest_path, 'input')
    if os.path.exists(target_path):
        shutil.rmtree(target_path)
    biren_mkdir(target_path)

    tensor_a = construct_fake_tensor(input_shape)
    tensor_b = construct_fake_tensor(input_shape)
    # check the input from dump data
    tensor_a = pt.from_numpy(br_fp32Tobf16Tofp32(tensor_a))
    tensor_b = pt.from_numpy(br_fp32Tobf16Tofp32(tensor_b))
    output = br_addrelu(tensor_a,tensor_b,inplace)
    
    file_info = os.path.join(target_path,"br-unit-fwd-U0-addrelu-A-4DA-" + tuple_to_string(input_shape))
    br_dump_ConvActivation_in_bf16(file_info,tensor_a)
    
    file_info = os.path.join(target_path,"br-unit-fwd-U1-addrelu-A-4DA-" + tuple_to_string(input_shape))
    br_dump_ConvActivation_in_bf16(file_info,tensor_b)

    file_info = os.path.join(target_path,"br-unit-fwd-U2-addrelu-A-4DA-" + tuple_to_string(input_shape))
    br_dump_ConvActivation_in_bf16(file_info,output[1])

    return target_path

def get_params():
    parser = argparse.ArgumentParser()

    parser.add_argument('add_shape', default='2x64x122x122',\
        help='Specify the additional tenosr shape with format NxCxHxW,for example: 1x64x8x8.')

    parser.add_argument('--input_data_type', '-idt', default='bf16',\
        choices=utils.data_types,\
            help='Specify the input data type, for example: bf16.')

    parser.add_argument('--output_data_type', '-odt', default='bf16',\
        choices=utils.data_types,\
            help='Specify the output data type, for example: bf16.')

    parser.add_argument('--type', '-t', default="fwd", \
        choices=["fwd", "bpa", "bpw"],\
            help='Specify the operator type currently,only support fwd, bpa, bpw')

    parser.add_argument('--in_place', type=bool, default=False, \
        help='Specify the dilation, for example: False')

    return parser

if __name__ == '__main__':

    parser = get_params()
    args = parser.parse_args()

    add_shape = [int(e) for e in args.add_shape.split("x")]
    input_dt = args.input_data_type
    output_dt = args.output_data_type
    operator_type = args.type
    in_place = args.in_place 
    if input_dt != "bf16" or output_dt != "bf16":
        raise NotImplementedError
    ret = gen_simple_addrelu(add_shape,in_place)
    print("target path is :",ret)