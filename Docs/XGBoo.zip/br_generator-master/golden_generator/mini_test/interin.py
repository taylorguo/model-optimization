
def construct_block0(
        ishape, wshape, oshape, dt, op_type, isa_params, select_in_channl):
    buf_a_inc = None
    buf_b_inc = None
    if op_type == "bpw":
        buf_a_inc, blk00_o_ld_tm, blk00_i_ld_tm = construct_block0_0(
            isa_params, op_type, dt, wshape, oshape, select_in_channl)
        buf_b_inc, blk01_i_ld_tm, blk01_h_ld_tm, blk01_w_ld_tm =\
            construct_block0_1(
                isa_params, op_type, dt, ishape, wshape, select_in_channl)
    elif op_type == "fwd":
        buf_a_inc, blk00_o_ld_tm, blk00_i_ld_tm = construct_block0_0(
            isa_params, op_type, dt, wshape, oshape, select_in_channl)
        buf_b_inc, blk01_i_ld_tm, blk01_h_ld_tm, blk01_w_ld_tm =\
            construct_block0_1(
                isa_params, op_type, dt, ishape, wshape, select_in_channl)
    elif op_type == "bpa":
        buf_a_inc, blk00_o_ld_tm, blk00_i_ld_tm = construct_block0_0(
            isa_params, op_type, dt, wshape, oshape, select_in_channl)
        buf_b_inc, blk01_i_ld_tm, blk01_h_ld_tm, blk01_w_ld_tm =\
            construct_block0_1(
                isa_params, op_type, dt, oshape, wshape, select_in_channl)
    assert(blk00_i_ld_tm == blk01_i_ld_tm)
    o_ld_tm = blk00_o_ld_tm
    i_ld_tm = blk00_i_ld_tm
    h_ld_tm = blk01_h_ld_tm
    w_ld_tm = blk01_w_ld_tm
    return buf_a_inc, buf_b_inc, o_ld_tm, i_ld_tm, h_ld_tm, w_ld_tm


def calc_loading_size_in_byte(dt, h=1, w=1, ich=1):
    total_size = h * w * ich
    if dt == "s4":
        total_size = int(total_size / 2)
    elif dt == "bf16":
        total_size = int(total_size * 2)
    elif dt == "f32":
        total_size = int(total_size * 4)
    return total_size


def align_4d_weight_tensor(tensor):
    OCH_ALIGN = 8
    ICH_ALIGN = 32
    och = tensor.shape[0]
    ich = tensor.shape[1]
    row = tensor.shape[2]
    col = tensor.shape[3]
    aligned_och = int((och + OCH_ALIGN - 1) / OCH_ALIGN) * OCH_ALIGN
    aligned_ich = int((ich + ICH_ALIGN - 1) / ICH_ALIGN) * ICH_ALIGN

    pad_och = aligned_och - och
    pad_ich = aligned_ich - ich

    p2d = (0, 0, 0, 0, 0, pad_och, 0, pad_ich)
    help(F.pad)
    tensor_pad = F.pad(tensor, p2d, "constant", 0)
    print("tensor_pad is ", tensor_pad)