# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import torch
import torch.nn as nn
import torch.nn.functional as F

def br_sum(in_tensor):
    assert(in_tensor.dim() == 4),\
        "in_tensor shape should be 4D for sum-reduction"
    x_sum = in_tensor.sum([0,2,3])
    return x_sum

def br_sq_sum(in_tensor):
    assert(in_tensor.dim() == 4),\
        "in_tensor shape should be 4D for sq-sum-reduction"
    x_sq = in_tensor*in_tensor
    x_sq_sum = x_sq.sum([0,2,3])
    return x_sq_sum