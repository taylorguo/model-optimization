#! /usr/bin/python3
# coding:utf-8

# Copyright 2020, Biren Technologies Inc.
# All rights reserved.
import os
import shutil
import torch
import torch.nn as nn
import torch.nn.functional as F
import argparse
from command_generator import utils
from br_dump import *

def br_maxpool2d(in_tensor,kernel_size,stride = None,padding = 0,\
    dilation = 1,return_indices = False,ceil_mode = False):
    assert(in_tensor.dim()==3 or in_tensor.dim()==4),\
        "in_tensor shape should be 3D or 4D for 2D maxpool"
    return F.max_pool2d(in_tensor,kernel_size,\
        stride,padding,dilation,return_indices,ceil_mode)

def construct_fake_tensor(shape=(64,64,112,112), data_pattern="" , value=None):
    if data_pattern == "random":
        return torch.randn(shape)
    elif data_pattern == "one":
        return torch.ones(shape)
    else:
        t = []
        total = shape[0]*shape[1]*shape[2]*shape[3]
        if value == None:
            for i in range(total):
                t.append(i)
        else:
            for i in range(total):
                t.append(value)
        return torch.FloatTensor(t).reshape(shape)

def test_br_maxpool2d(input_tensor,kernel_size = 3,stride = 2,padding = 1,\
    dilation = 1,return_indices = False,ceil_mode = False, dest_path=None):
    # check the input from dump data
    input_tensor = pt.from_numpy(br_fp32Tobf16Tofp32(input_tensor))
    output = br_maxpool2d(input_tensor,kernel_size,stride,padding,\
        dilation,return_indices,ceil_mode)
    input_shape = input_tensor.shape
    if not dest_path:
        target_addr = os.path.join(utils.brgen_root, unit_dest_path)
        folder_name = 'maxpool_in_' + tuple_to_string(input_shape)\
            + '_out_' + tuple_to_string(output.shape) + '_dt_bf16xbf16'
        print("folder name is :",folder_name)
        target_path = os.path.join(target_addr, folder_name, 'input')
    else:
        target_path = os.path.join(dest_path, 'input')

    if os.path.exists(target_path):
        shutil.rmtree(target_path)
    biren_mkdir(target_path)

    file_info = os.path.join(target_path,"br-unit-fwd-U0-maxpool-A-4DA-" + tuple_to_string(input_shape))
    br_dump_ConvActivation_in_bf16(file_info,input_tensor)
    
    file_info = os.path.join(target_path,"br-unit-fwd-U1-maxpool-A-4DA-" + tuple_to_string(output.shape))
    br_dump_ConvActivation_in_bf16(file_info,output)

    return target_path

def get_params():
    parser = argparse.ArgumentParser()

    parser.add_argument('--input', default='2x64x122x122',\
        help='Specify the input tenosr shape with format NxCxHxW,for example: 2x64x8x8.')

    parser.add_argument('kernel_size', default='3x3',\
        help='Specify the kernel shape with format KHxKW,for example: 3x3.')

    parser.add_argument('stride', default='2x2',\
        help='Specify the stride shape with format SHxSW,for example: 2x2.')
    
    parser.add_argument('padding', default='1x1',\
        help='Specify the padding shape with format PHxPW,for example: 1x1.')

    parser.add_argument('--dilation', default='1',\
        help='Specify the dilation value,for example: 1.')

    parser.add_argument('--return_indices', type=bool, default=False, \
        help='Specify if return the indices, for example: False')

    parser.add_argument('--ceil_mode', type=bool, default=False, \
        help='Specify the mode,True is ceil,False is floor,for example: True')

    parser.add_argument('--input_data_type', '-idt', default='bf16',\
        choices=utils.data_types,\
            help='Specify the input data type, for example: bf16.')

    parser.add_argument('--output_data_type', '-odt', default='bf16',\
        choices=utils.data_types,\
            help='Specify the output data type, for example: bf16.')

    parser.add_argument('--type', '-t', default="fwd", \
        choices=["fwd", "bpa", "bpw"],\
            help='Specify the operator type currently,only support fwd, bpa, bpw')

    return parser

if __name__ == "__main__":

    parser = get_params()
    args = parser.parse_args()

    input_shape = [int(e) for e in args.input.split("x")]
    assert(len(input_shape) == 4),"make sure the shape of input_shape is 4D"

    kernel_size = [int(e) for e in args.kernel_size.split("x")]
    assert(len(kernel_size) == 1 or len(kernel_size) == 2),"make sure the kernel size is right"

    stride = [int(e) for e in args.stride.split("x")]
    assert(len(stride) == 1 or len(stride) == 2),"make sure the stride is right"

    padding = [int(e) for e in args.padding.split("x")]
    assert(len(padding) == 1 or len(padding) == 2),"make sure the padding is right"

    dilation = int(args.dilation)
    return_indices = args.return_indices
    ceil_mode = args.ceil_mode

    input_shape = tuple(input_shape)
    kernel_size = tuple(kernel_size)
    stride = tuple(stride)
    padding = tuple(padding)

    input_tensor = construct_fake_tensor(input_shape)
    ret = test_br_maxpool2d(input_tensor,kernel_size,stride,padding,dilation,return_indices,ceil_mode)
    print("target path is :",ret)
    # maybe use in future for backward
    # nn_maxpool2d = nn.MaxPool2d(kernel_size,stride,padding)
    # nn_output = nn_maxpool2d(input_tensor)

    # delta_out = torch.dist(ret,nn_output,2)
    # print("Delta output for the two ways : ",delta_out)
