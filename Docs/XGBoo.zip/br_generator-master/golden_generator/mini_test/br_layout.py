
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import argparse
import shutil
import os
import copy
import sys
import simple_conv
import struct
from command_generator import io_handler


def align_4d_weight_tensor(tensor, output_folder):
    OCH_ALIGN = 8
    ICH_ALIGN = 32
    och = tensor.shape[0]
    ich = tensor.shape[1]
    row = tensor.shape[2]
    col = tensor.shape[3]

    block_och = int((och + OCH_ALIGN - 1) / OCH_ALIGN)
    block_ich = int((ich + ICH_ALIGN - 1) / ICH_ALIGN)

    aligned_och = block_och * OCH_ALIGN
    aligned_ich = block_ich * ICH_ALIGN

    pad_och = aligned_och - och
    pad_ich = aligned_ich - ich

    # np.set_printoptions(threshold=np.inf)
    tensor = tensor.reshape(och, ich, row * col)
    tensor = tensor.permute(2, 1, 0)

    flat = torch.flatten(tensor).numpy()
    print("flat -1:", flat)
    # print("tensor is ", tensor)
    p2d = (0, pad_och, 0, pad_ich)
    # help(F.pad)
    tensor_pad = F.pad(tensor, p2d, "constant", 0)
    flat = torch.flatten(tensor_pad).numpy()
    print("flat 0:", flat)

    # reshape_tensor = tensor_pad.reshape(aligned_och, aligned_ich, row * col)

    # flat = torch.flatten(reshape_tensor).numpy()
    # print("flat 1:", flat)

    # permute_tensor = reshape_tensor.permute(2, 1, 0)
    # flat = torch.flatten(permute_tensor).numpy()
    # print("flat 2:", flat)

    reshape_tensor2 = tensor_pad.reshape(
        row * col, block_ich, block_och, ICH_ALIGN, OCH_ALIGN)
    flat = torch.flatten(reshape_tensor2).numpy()
    print("flat 3:", flat)

    reshape_tensor3 = reshape_tensor2.permute(0, 1, 3, 2, 4)
    flat = torch.flatten(reshape_tensor3).numpy()
    print("flat 4:", flat)

    # permute_tensor2 = reshape_tensor2.permute(1, 2, 0, 3, 4)
    # flat = torch.flatten(reshape_tensor2).numpy()
    # print("flat 3:", flat)

    final = torch.flatten(reshape_tensor3).numpy()
    # bytes_final = permute_tensor2.byte()
    print(final)
    bytes_bf16 = []
    for e in final:
        a = struct.pack("f", e)
        # print(a)
        # if i % 4 == 2 or i % 4 == 3:
        bytes_bf16.append(a[2])
        bytes_bf16.append(a[3])

        # i += 1

    print("bytes_bf16 is ", bytes_bf16)
    # print("bytes_final is ", bytes_final)
    io_handler.generate_data_dump_file(bytes_bf16, "test_dump.bin",
                                       output_folder)

    return tensor_pad


if __name__ == '__main__':
    tensor = simple_conv.construct_pattern_tensor(8, 32, 1, 1)
    print("tensor is ", tensor)
    t = torch.flatten(tensor).numpy()
    print("t is ", t)

    tensor_pad = align_4d_weight_tensor(tensor, "./")
