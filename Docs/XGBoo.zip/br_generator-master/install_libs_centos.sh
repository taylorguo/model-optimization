#!/bin/bash

sudo yum -y install python3 python3-pip
pip3 install xlrd -i https://pypi.doubanio.com/simple/ --default-timeout=100 --no-cache-dir
pip3 install xlwt -i https://pypi.doubanio.com/simple/ --default-timeout=100 --no-cache-dir
pip3 install bitstring -i https://pypi.doubanio.com/simple/ --default-timeout=100 --no-cache-dir
pip3 install xlutils -i https://pypi.doubanio.com/simple/ --default-timeout=100 --no-cache-dir
pip3 install scikit-build -i https://pypi.doubanio.com/simple/ --default-timeout=100 --no-cache-dir
pip3 install opencv-python -i https://pypi.doubanio.com/simple/ --default-timeout=100 --no-cache-dir
pip3 install pytest -i https://pypi.doubanio.com/simple/ --default-timeout=100 --no-cache-dir
pip3 install openpyxl -i https://pypi.doubanio.com/simple/ --default-timeout=100 --no-cache-dir
pip install pytest-xdist
#pip3 install hashlib
pip3 install paramiko -i https://pypi.doubanio.com/simple/ --default-timeout=100 --no-cache-dir
pip3 install scp -i https://pypi.doubanio.com/simple/ --default-timeout=100 --no-cache-dir
pip3 install torch==1.5.1 torchvision==0.6.1 -i https://pypi.doubanio.com/simple/ --default-timeout=100 --no-cache-dir
pip3 install pytest-ordering -i https://pypi.doubanio.com/simple/ --default-timeout=100 --no-cache-dir
sudo yum -y install libncurses5
